// Shared helpers: page frame (nav / footer), login state, upgrade dialog, uploads with progress, API calls, PDF thumbnails
import { t, tr, ready, LANGUAGES, lang, setLang, applyI18n, href } from "/static/js/i18n.js";
export { t, tr, href };

export const $ = (s, el = document) => el.querySelector(s);
export const $$ = (s, el = document) => [...el.querySelectorAll(s)];
export const h = (tag, attrs = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === "class") e.className = v; else if (k === "html") e.innerHTML = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v); else if (v !== false && v != null) e.setAttribute(k, v);
  }
  for (const k of kids.flat()) if (k != null && k !== false) e.append(k.nodeType ? k : document.createTextNode(k));
  return e;
};
export const fmtSize = (b) => b < 1024 ? b + " B" : b < 1048576 ? (b / 1024).toFixed(1) + " KB" : (b / 1048576).toFixed(2) + " MB";
export const debounce = (f, ms) => { let x; return (...a) => { clearTimeout(x); x = setTimeout(() => f(...a), ms); }; };
export const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export let ME = null;
export let SITE = { name: "PDFiesta" };
const meReady = fetch("/api/me").then((r) => r.json()).then((j) => { ME = j; if (j.site?.name) SITE = j.site; return j; }).catch(() => null);
export const me = () => meReady;

export async function chrome({ slim = false } = {}) {
  await ready;
  const acct = h("a", { class: "btn sm", href: href("/login") }, t("nav.login", "Log in"));
  const sel = h("select", { class: "langsel", title: "Language", "aria-label": "Language", onchange: (e) => setLang(e.target.value) },
    LANGUAGES.map(([k, n]) => h("option", { value: k, selected: k === lang ? "" : null }, n)));
  const logo = h("a", { class: "logo", href: href("/") }, h("b", {}, "PDF"), h("span", { id: "sitename" }, "iesta"));
  const links = h("div", { class: "links" },
    ...[["nav.alltools", "All tools", "/"], ["tool.pdf-editor", "Edit PDF", "/tool/pdf-editor"], ["tool.compress", "Compress", "/tool/compress"], ["tool.merge", "Merge", "/tool/merge"],
      ["tool.pdf-to-word", "PDF to Word", "/tool/pdf-to-word"], ["tool.remove-background", "Remove background", "/tool/remove-background"], ["cat.AI PDF", "AI PDF", "/tool/ai-summarize"]]
      .map(([k, d, u]) => h("a", { href: href(u) }, t(k, d))));
  const burger = h("button", { class: "burger", "aria-label": "Menu", onclick: () => nav.classList.toggle("open") }, "☰");
  const nav = h("nav", { class: "nav" }, burger, logo, links, h("div", { class: "sp" }), sel,
    h("a", { href: href("/pricing"), class: "btn sm pro" }, "★ " + t("nav.pricing", "Pricing")), acct);
  document.body.prepend(nav);
  if (!slim) document.body.append(h("footer", {}, h("div", { class: "wrap" },
    h("p", {}, "🔒 " + t("footer.privacy", "Files are processed over an encrypted connection and deleted automatically after 2 hours.")),
    h("p", { class: "flinks" },
      ...[["/pricing", "nav.pricing", "Pricing"], ["/privacy", "legal.privacy", "Privacy"], ["/terms", "legal.terms", "Terms"], ["/refund", "legal.refund", "Refunds"], ["/contact", "legal.contact", "Contact"]]
        .flatMap(([u, k, d]) => [h("a", { href: href(u) }, t(k, d)), " · "]),
      h("a", { id: "srclink", href: "#", class: "hidden" }, t("footer.source", "Source code (AGPL)")), h("span", { id: "copy" })))));
  applyI18n();
  const m = await meReady;
  const name = SITE.name || "PDFiesta";
  if (/^pdf/i.test(name)) { logo.firstChild.textContent = name.slice(0, 3).toUpperCase(); $("#sitename").textContent = name.slice(3); }
  else { logo.firstChild.remove(); $("#sitename").textContent = name; }
  if ($("#copy")) $("#copy").textContent = `© ${new Date().getFullYear()} ${SITE.company || name}` + (SITE.gstin ? ` · GSTIN ${SITE.gstin}` : "") + " · Made in India 🇮🇳";
  if (m) {
    if (m.source_url && $("#srclink")) { $("#srclink").href = m.source_url; $("#srclink").classList.remove("hidden"); $("#srclink").after(" · "); }
    if (m.user) { acct.textContent = (m.user.pro ? "★ " : "") + (m.user.name || m.user.email).split(" ")[0]; acct.href = href("/account"); }
    if (m.user?.admin) acct.before(h("a", { class: "btn sm", href: href("/admin") }, "⚙ Admin"));
  }
}

export function showUpgrade(msg) {
  let m = $("#upgmodal");
  if (!m) {
    m = h("div", { class: "modal", id: "upgmodal" }, h("div", { class: "box center" },
      h("div", { style: "font-size:40px" }, "★"), h("h2", {}, t("upgrade.title", "Upgrade to Pro")), h("p", { id: "upgmsg", class: "muted" }),
      h("div", { class: "row", style: "justify-content:center" },
        h("a", { class: "btn primary big", href: href("/pricing") }, t("upgrade.btn", "See Pro plans")),
        ME && !ME.user ? h("a", { class: "btn big", href: href("/login") + "?m=signup&next=" + encodeURIComponent(location.pathname) }, t("upgrade.signup", "Free account")) : null),
      h("p", {}, h("a", { href: "#", class: "muted", onclick: (e) => { e.preventDefault(); m.classList.remove("on"); } }, t("upgrade.later", "Maybe later")))));
    document.body.append(m);
  }
  $("#upgmsg").textContent = tr(msg); m.classList.add("on");
}

export async function api(url, body, method = "POST") {
  let r;
  try { r = await fetch(url, { method, headers: body ? { "Content-Type": "application/json" } : {}, body: body ? JSON.stringify(body) : undefined }); }
  catch { throw new Error(tr("No connection to the server. Check your internet and try again.")); }
  const j = await r.json().catch(() => ({ error: r.statusText }));
  if (r.status === 402) { showUpgrade(j.error); const e = new Error(j.error); e.quota = true; throw e; }
  if (!r.ok) { const e = new Error(tr(j.error || j.detail || "Request failed")); e.status = r.status; throw e; }
  return j;
}

export function upload(files, onProgress) {
  return new Promise((res, rej) => {
    const fd = new FormData();
    for (const f of files) fd.append("files", f, f.name || "file");
    const x = new XMLHttpRequest();
    x.open("POST", "/api/upload");
    x.upload.onprogress = (e) => e.lengthComputable && onProgress && onProgress(e.loaded / e.total);
    x.onload = () => { let j; try { j = JSON.parse(x.responseText); } catch { j = { error: x.statusText }; }
      if (x.status === 402) showUpgrade(j.error);
      x.status < 300 ? res(j) : rej(new Error(tr(j.error || "Upload failed"))); };
    x.onerror = () => rej(new Error(tr("No connection to the server. Check your internet and try again.")));
    x.send(fd);
  });
}

export function toast(msg, ms = 2800) {
  let box = $("#toasts"); if (!box) { box = h("div", { id: "toasts" }); document.body.append(box); }
  const el = h("div", { class: "toast" }, msg); box.append(el); setTimeout(() => el.remove(), ms);
}

// PDF thumbnails (PDF.js is loaded only on pages that show them)
let pdfjsLib;
const docCache = new Map();
export async function loadPdf(fileId) {
  if (!pdfjsLib) { pdfjsLib = await import("/static/vendor/pdf.min.mjs"); pdfjsLib.GlobalWorkerOptions.workerSrc = "/static/vendor/pdf.worker.min.mjs"; }
  if (!docCache.has(fileId)) docCache.set(fileId, pdfjsLib.getDocument({ url: `/api/file/${fileId}`, wasmUrl: "/static/vendor/" }).promise);
  return docCache.get(fileId);
}
export async function renderPage(pdf, n, canvas, width, rotation = 0) {
  const page = await pdf.getPage(n);
  const rot = (page.rotate + rotation) % 360;
  const base = page.getViewport({ scale: 1, rotation: rot });
  const scale = width / base.width, dpr = Math.min(2, window.devicePixelRatio || 1);
  const vp = page.getViewport({ scale: scale * dpr, rotation: rot });
  canvas.width = vp.width; canvas.height = vp.height;
  canvas.style.width = vp.width / dpr + "px"; canvas.style.height = vp.height / dpr + "px";
  await page.render({ canvasContext: canvas.getContext("2d"), viewport: vp }).promise;
  return { page, scale, width: base.width, height: base.height };
}
export const lazy = new IntersectionObserver((ents) => {
  for (const e of ents) if (e.isIntersecting) { lazy.unobserve(e.target); e.target._render && e.target._render(); }
}, { rootMargin: "300px" });

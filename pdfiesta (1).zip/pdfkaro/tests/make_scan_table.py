# synthetic scanned balance sheet (book serif, table with vertical rules, number columns)
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np, pymupdf, io, random, glob
U = "/usr/share/fonts/opentype/urw-base35/"
reg = glob.glob(U + "P052-Roman.otf") or [U + "C059-Roman.otf"]; bold = glob.glob(U + "P052-Bold.otf") or [U + "C059-Bold.otf"]
R, B = ImageFont.truetype(reg[0], 36), ImageFont.truetype(bold[0], 36); T = ImageFont.truetype(bold[0], 52)
W, H = 2480, 3508
im = Image.new("L", (W, H), 255); d = ImageDraw.Draw(im)
d.text((W // 2, 300), "WHITE IMPACT", font=T, fill=0, anchor="mm"); d.text((W // 2, 380), "Balance Sheet as at 31st March, 2026", font=B, fill=0, anchor="mm")
X = [200, 320, 1650, 1800, 2090, 2380]; y0 = 470
d.rectangle((X[0], y0, X[-1], 2500), outline=0, width=4)
for x in X[1:-1]: d.line((x, y0, x, 2500), fill=0, width=3)
d.line((X[0], y0 + 110, X[-1], y0 + 110), fill=0, width=3)
d.text((X[1] + 20, y0 + 40), "Particulars", font=B, fill=0); d.text((X[2] + 15, y0 + 20), "Note", font=B, fill=0); d.text((X[3] + 10, y0 + 20), "31-3-2026", font=B, fill=0); d.text((X[4] + 10, y0 + 20), "31-3-25", font=B, fill=0)
rows = [("I", "EQUITY AND LIABILITIES", "", "", "", 1), ("1", "Partner's Funds", "", "", "", 1), ("(a)", "Capital Account", "2", "83,235,896", "86,582,376", 0),
        ("2", "Non-current liabilities", "", "", "", 1), ("(a)", "Long-term borrowings", "3", "7,099,020", "7,099,020", 0), ("(b)", "Other long-term liabilities", "", "-", "-", 0),
        ("3", "Current liabilities", "", "", "", 1), ("(a)", "Short-term borrowings", "3", "-", "-", 0), ("(b)", "Trade payables", "5", "22,850,571", "2,670,438", 0),
        ("(c)", "Other current liabilities", "6", "18,465,359", "11,803,490", 0), ("(d)", "Short-term provisions", "4", "75,000", "75,000", 0),
        ("II", "ASSETS", "", "", "", 1), ("1", "Property, Plant & Equipments", "", "", "", 1), ("(a)", "Property, Plant and Equipment", "7", "3,222,977", "2,962,535", 0),
        ("(b)", "Intangible assets", "7", "333,334", "239,643", 0), ("(c)", "Other non-current assets", "8", "22,777,783", "2,445,681", 0),
        ("2", "Investments", "", "-", "-", 1), ("3", "Loans", "9", "50,621,574", "15,774,912", 1), ("(a)", "Inventories", "10", "41,826,814", "13,370,761", 0),
        ("(b)", "Trade receivables", "11", "3,328,798", "58,225,664", 0), ("(c)", "Cash and bank balances", "12", "1,704,695", "9,160,609", 0)]
y = y0 + 150
for a, b, n, c1, c2, bo in rows:
    f = B if bo else R
    d.text(((X[0] + X[1]) // 2, y), a, font=R, fill=0, anchor="ma"); d.text((X[1] + 25, y), b, font=f, fill=0)
    if n: d.text(((X[2] + X[3]) // 2, y), n, font=R, fill=0, anchor="ma")
    if c1: d.text((X[4] - 20, y), c1, font=R, fill=0, anchor="ra")
    if c2: d.text((X[5] - 20, y), c2, font=R, fill=0, anchor="ra")
    y += 85
d.text((X[0], 2560), "The accompanying notes are an integral part of the financial statements.", font=R, fill=0)
im = im.rotate(0.35, resample=Image.BICUBIC, fillcolor=255).filter(ImageFilter.GaussianBlur(1.1))
a = np.asarray(im).astype(float); a = a * 0.86 + 22 + np.random.default_rng(1).normal(0, 7, a.shape)
rgb = np.stack([a, a * 0.99, a * 0.96], -1).clip(0, 255).astype(np.uint8)
buf = io.BytesIO(); Image.fromarray(rgb).save(buf, "JPEG", quality=80)
doc = pymupdf.open(); pg = doc.new_page(width=595, height=842); pg.insert_image(pg.rect, stream=buf.getvalue()); import sys; doc.save(sys.argv[1] if len(sys.argv) > 1 else "scan_table.pdf")

"""PDFiesta – HTTP API + website.

Run:  uvicorn app.main:app --host 0.0.0.0 --port 8000
"""
import asyncio, ctypes, datetime, gc, hashlib, html as _h, json, mimetypes, os, re, secrets, shutil, threading, time, traceback, uuid
from pathlib import Path
from typing import List
from urllib.parse import urlparse

import pymupdf
from fastapi import FastAPI, UploadFile, File, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, HTMLResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.concurrency import run_in_threadpool

from .util import DATA, BASE, new_job, cleanup_old, safe_name, fetch_url
from .tools import TOOLS, is_scanned, run_ocr
from . import images, images_more, tools_plus, tools_more  # noqa: F401 – importing registers their tools
from . import editor, fonts
from .accounts import ad_free, count, count_visit, router as acc_router, charge, refund, current_user, limits_for, client_ip, send_mail, throttle, housekeeping, SITE, SITE_NAME
from .payments import router as pay_router

app = FastAPI(title=f"{SITE_NAME} API", version="3.0", docs_url=None, redoc_url=None)
app.include_router(acc_router)
app.include_router(pay_router)

STATIC = BASE / "static"
UPLOADS = DATA / "uploads"; UPLOADS.mkdir(parents=True, exist_ok=True)
SIGN = DATA / "sign"; SIGN.mkdir(parents=True, exist_ok=True)
MAX_MB = int(os.environ.get("MAX_UPLOAD_MB", "1024"))
AI_TOOLS = {"ai_summarize", "ai_translate", "ai_chat", "ai_quiz", "ai_extract"}
HEAVY = asyncio.Semaphore(int(os.environ.get("MAX_PARALLEL_TASKS", max(2, os.cpu_count() or 2))))

EXT = {
    "pdf": {".pdf"},
    "image": {".jpg", ".jpeg", ".jfif", ".png", ".gif", ".bmp", ".tif", ".tiff", ".webp", ".heic", ".heif", ".avif", ".svg", ".ico", ".psd"},
    "office": set(tools_more.OFFICE_EXT),
    "text": {".txt", ".md", ".markdown", ".log"},
    "ebook": {".epub", ".mobi", ".fb2", ".xps", ".oxps", ".cbz"},
    "ps": {".ps", ".eps"}, "zip": {".zip"}, "cert": {".p12", ".pfx"},
}
ALL_EXT = set().union(*EXT.values())
KIND = {e: k for k, v in EXT.items() for e in v}
ACCEPT = {"pdf": {"pdf"}, "pdf,image": {"pdf", "image"}, "image": {"image"}, "office": {"office", "text"}, "text": {"text"},
          "ebook": {"ebook", "text"}, "ps": {"ps"}, "zip": {"zip"}, "any": set(EXT) - {"cert"}}


# ------------------------------------------------------------------ housekeeping
def _janitor():
    while True:
        try:
            cleanup_old()
            housekeeping()
            now = time.time()
            for d in UPLOADS.iterdir():
                if now - d.stat().st_mtime > 2 * 3600:
                    shutil.rmtree(d, ignore_errors=True)
            ttl = int(os.environ.get("SIGN_TTL_DAYS", "30")) * 86400
            for d in SIGN.iterdir():
                if d.is_dir() and now - d.stat().st_mtime > ttl:
                    shutil.rmtree(d, ignore_errors=True)
            images.release_idle(); images_more.release_idle()      # AI models unused for 15 minutes leave the memory
            gc.collect()
            try:
                ctypes.CDLL("libc.so.6").malloc_trim(0)
            except Exception:
                pass
        except Exception:
            pass
        time.sleep(300)


threading.Thread(target=_janitor, daemon=True).start()


@app.middleware("http")
async def security(req: Request, call_next):
    # browsers send Origin on cross-site POSTs: refuse them (CSRF), except payment webhooks (server-to-server)
    if req.method in ("POST", "PUT", "PATCH", "DELETE") and req.url.path.startswith("/api/") and not req.url.path.endswith("/webhook"):
        origin = req.headers.get("origin")
        if origin and urlparse(origin).netloc != (req.headers.get("x-forwarded-host") or req.headers.get("host")):
            return JSONResponse({"error": "Cross-site request blocked."}, status_code=403)
        # everything except file uploads is a small JSON message (the editor sends pictures the user added: allow for those)
        if not req.url.path.startswith("/api/upload") and int(req.headers.get("content-length") or 0) > 96 * 1024 * 1024:
            return JSONResponse({"error": "This request is too large."}, status_code=413)
    resp = await call_next(req)
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    resp.headers.setdefault("Permissions-Policy", "camera=(self), microphone=(), geolocation=()")
    if SITE.startswith("https"):
        resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000")
    return resp


@app.exception_handler(HTTPException)
async def http_err(req, exc):
    return JSONResponse({"error": exc.detail}, status_code=exc.status_code)


def _file(fid):
    d = UPLOADS / safe_name(str(fid))
    meta = d / "meta.json"
    if not meta.exists():
        raise HTTPException(404, "File expired or not found. Please upload again.")
    return d, json.loads(meta.read_text())


def _describe(p: Path, fid, name, size):
    """look inside an uploaded file → meta"""
    ext = p.suffix.lower()
    meta = {"id": fid, "name": name, "size": size, "path": str(p), "kind": KIND.get(ext, "other"), "pages": None, "encrypted": False, "scanned": False}
    if ext == ".pdf":
        try:
            with open(p, "rb") as fh:
                if b"%PDF-" not in fh.read(1024):
                    raise ValueError("no PDF header")
            doc = pymupdf.open(p)
            meta["encrypted"] = bool(doc.needs_pass)
            if not doc.needs_pass:
                meta["pages"] = doc.page_count
                meta["scanned"] = is_scanned(doc)
                meta["toc"] = doc.get_toc()[:500]
                meta["metadata"] = doc.metadata
                meta["has_forms"] = any(True for pg in list(doc)[:30] for _ in pg.widgets())
                if doc.page_count:
                    meta["w"], meta["h"] = round(doc[0].rect.width, 1), round(doc[0].rect.height, 1)
            doc.close()
        except Exception:
            meta["damaged"] = True
    elif meta["kind"] == "image" and ext != ".svg":
        try:
            from PIL import Image
            with Image.open(p) as im:
                meta["w"], meta["h"] = im.size
        except Exception:
            meta["damaged"] = True
    return meta


def _store(fid, d, meta):
    """save the file's description on the server; the copy that goes to the browser carries no server path"""
    (d / "meta.json").write_text(json.dumps(meta))
    return {k: v for k, v in meta.items() if k != "path"}


# ------------------------------------------------------------------ upload
@app.post("/api/upload")
async def upload(req: Request, files: List[UploadFile] = File(...)):
    throttle("up:" + client_ip(req), limit=int(os.environ.get("UPLOADS_PER_10MIN", "300")), window=600)
    lim = limits_for(current_user(req))
    if len(files) > max(lim["max_files"], 10):
        raise HTTPException(402, f"Your plan allows {lim['max_files']} files at once. Upgrade to Pro for up to 200.")
    out = []
    for f in files:
        name = safe_name(re.split(r"[\\/]", f.filename or "file.pdf")[-1])      # the name only, never a path (old browsers send C:\…\doc.pdf)
        ext = Path(name).suffix.lower()
        if ext not in ALL_EXT:
            raise HTTPException(415, f"“{name}”: this file type is not supported.")
        fid = uuid.uuid4().hex[:16]
        d = UPLOADS / fid; d.mkdir(parents=True)
        p = d / name
        size = 0
        with open(p, "wb") as fh:
            while chunk := await f.read(1 << 20):
                size += len(chunk)
                if size > min(MAX_MB, lim["max_mb"]) * 1024 * 1024:
                    fh.close(); shutil.rmtree(d, ignore_errors=True)
                    if lim["max_mb"] < MAX_MB:
                        raise HTTPException(402, f"“{name}” is larger than {lim['max_mb']} MB. Upgrade to Pro for files up to 1 GB.")
                    raise HTTPException(413, f"File too large (max {MAX_MB} MB).")
                fh.write(chunk)
        if size == 0:
            shutil.rmtree(d, ignore_errors=True)
            raise HTTPException(400, f"“{name}” is empty.")
        out.append(_store(fid, d, await run_in_threadpool(_describe, p, fid, name, size)))
    return out


@app.post("/api/upload-url")
async def upload_url(req: Request):
    throttle("url:" + client_ip(req), limit=30, window=600)
    url = ((await req.json()).get("url") or "").strip()
    lim = limits_for(current_user(req))
    fid = uuid.uuid4().hex[:16]; d = UPLOADS / fid; d.mkdir(parents=True)
    name = safe_name(urlparse(url).path.rsplit("/", 1)[-1] or "download.pdf")
    if Path(name).suffix.lower() not in ALL_EXT:
        name += ".pdf"
    p = d / name
    try:
        size = await run_in_threadpool(fetch_url, url, p, min(MAX_MB, lim["max_mb"]))
    except ValueError as e:
        shutil.rmtree(d, ignore_errors=True); raise HTTPException(422, str(e))
    except Exception:
        shutil.rmtree(d, ignore_errors=True); raise HTTPException(422, "Could not download this address.")
    return _store(fid, d, await run_in_threadpool(_describe, p, fid, name, size))


@app.post("/api/file/{fid}/unlock")
async def unlock_upload(fid: str, req: Request):
    d, m = _file(fid)
    throttle("unlock:" + fid, limit=20, window=600)
    pw = (await req.json()).get("password", "")
    import pikepdf
    try:
        with pikepdf.open(m["path"], password=pw) as pdf:
            tmp = Path(m["path"]).with_suffix(".unlocked.pdf"); pdf.save(tmp)
    except pikepdf.PasswordError:
        raise HTTPException(403, "Incorrect password")
    os.replace(tmp, m["path"])
    return _store(fid, d, _describe(Path(m["path"]), fid, m["name"], Path(m["path"]).stat().st_size))


@app.get("/api/file/{fid}")
def get_file(fid: str):
    d, m = _file(fid)
    kind = m.get("kind")
    if kind not in ("pdf", "image") or m["name"].lower().endswith(".svg"):
        return FileResponse(m["path"], filename=m["name"], media_type="application/octet-stream")
    return FileResponse(m["path"], media_type=mimetypes.guess_type(m["name"])[0] or "application/pdf", headers={"Cache-Control": "private, no-store"})


@app.get("/api/file/{fid}/meta")
def get_meta(fid: str):
    m = dict(_file(fid)[1]); m.pop("path", None)
    return m


@app.post("/api/blank")
def blank():
    fid = uuid.uuid4().hex[:16]; d = UPLOADS / fid; d.mkdir(parents=True)
    p = d / "new_document.pdf"
    doc = pymupdf.open(); doc.new_page(width=595, height=842); doc.save(p)
    return _store(fid, d, _describe(p, fid, p.name, p.stat().st_size))


# ------------------------------------------------------------------ tasks
@app.get("/api/tools")
def list_tools():
    return {k: {"multi": v["multi"], "accept": v["accept"]} for k, v in TOOLS.items()}


def _opts(raw):
    """client options → tool options. Server paths can never be injected: *_path keys are dropped, *_file ids are resolved."""
    opts = {k: v for k, v in (raw or {}).items() if isinstance(k, str) and not k.endswith("_path")}
    for k in [k for k in list(opts) if k.endswith("_file") and opts[k]]:
        opts[k[:-5] + "_path"] = _file(opts[k])[1]["path"]
    return opts


def _check_inputs(name, metas):
    acc = TOOLS[name]["accept"]
    if acc == "none":
        return
    if not metas:
        raise HTTPException(400, "Please upload a file first.")
    ok = ACCEPT.get(acc, {"pdf"})
    for m in metas:
        if m.get("kind") not in ok and not (name == "attachments" and m is not metas[0]):
            raise HTTPException(422, f"“{m['name']}” cannot be used with this tool.")
        if m.get("encrypted") and name not in ("unlock", "repair"):
            raise HTTPException(422, f"“{m['name']}” is password protected. Enter its password first.")
    if not TOOLS[name]["multi"] and len(metas) > 1:
        raise HTTPException(422, "This tool works with one file at a time.")


def _register_result(res: Path):
    """the result becomes an input file for 'continue with another tool'."""
    fid = uuid.uuid4().hex[:16]; d = UPLOADS / fid; d.mkdir(parents=True)
    p = d / res.name; shutil.copy(res, p)
    if p.suffix.lower() not in ALL_EXT:
        meta = {"id": fid, "name": p.name, "size": p.stat().st_size, "path": str(p), "kind": "other"}
    else:
        meta = _describe(p, fid, p.name, p.stat().st_size)
    _store(fid, d, meta)
    return fid


@app.post("/api/task")
async def task(req: Request):
    body = await req.json()
    name = body.get("tool")
    if name not in TOOLS:
        raise HTTPException(404, f"Unknown tool {name}")
    metas = [_file(fid)[1] for fid in (body.get("files") or [])]
    _check_inputs(name, metas)
    opts = _opts(body.get("options"))
    inputs = [Path(m["path"]) for m in metas]
    kind = "ai" if name in AI_TOOLS else "task"
    charge(req, kind, files=len(inputs), pages=max([m.get("pages") or 0 for m in metas] or [0]), mb=sum(m["size"] for m in metas) / 1048576)
    count("tasks"); count("tool:" + name)
    jid, out = new_job()
    t0 = time.time()
    try:
        async with HEAVY:
            res = await run_in_threadpool(TOOLS[name]["fn"], inputs, opts, out)
    except (ValueError, RuntimeError) as e:
        refund(req, kind); shutil.rmtree(out, ignore_errors=True)
        raise HTTPException(422, str(e)[:400])
    except HTTPException:
        refund(req, kind); shutil.rmtree(out, ignore_errors=True); raise
    except Exception as e:
        traceback.print_exc()
        refund(req, kind); shutil.rmtree(out, ignore_errors=True)
        msg = "This file could not be processed. It may be damaged – try the Repair tool first." if metas else "Processing failed."
        raise HTTPException(500, msg if os.environ.get("DEBUG") != "1" else f"{msg} ({type(e).__name__}: {e})")
    res = Path(res)
    if res.parent != out:
        res = Path(shutil.copy(res, out / safe_name(res.name)))
    for junk in out.iterdir():  # keep only the deliverable
        if junk != res:
            shutil.rmtree(junk, ignore_errors=True) if junk.is_dir() else junk.unlink(missing_ok=True)
    return {"task": jid, "name": res.name, "size": res.stat().st_size, "input_size": sum(m["size"] for m in metas),
            "seconds": round(time.time() - t0, 2), "download": f"/api/download/{jid}/{res.name}", "file_id": _register_result(res)}


PREVIEWABLE = {"watermark", "page_numbers", "header_footer", "bates", "crop", "resize", "nup", "flip", "grayscale", "invert", "overlay",
               "redact", "booklet", "poster", "split_half", "rotate"}


@app.post("/api/preview")
async def preview(req: Request):
    """Run a tool on ONE page and return a picture of the result – lets people see watermark / numbering / crop before processing."""
    b = await req.json()
    name = b.get("tool")
    if name not in PREVIEWABLE:
        raise HTTPException(404, "No preview for this tool")
    metas = [_file(f)[1] for f in (b.get("files") or [])][:2]
    if not metas or metas[0].get("kind") != "pdf" or metas[0].get("encrypted"):
        raise HTTPException(400, "Upload a PDF first")
    throttle("pv:" + client_ip(req), limit=240, window=600)
    opts = _opts(b.get("options")); pno = max(0, int(b.get("page") or 0))

    def work():
        jid, out = new_job()
        try:
            ins = []
            for k, m in enumerate(metas):
                if m.get("kind") != "pdf":
                    continue
                src = pymupdf.open(m["path"])
                n = src.page_count
                keep = list(range(min(n, 8))) if name in ("nup", "booklet") else [min(pno, n - 1)]
                src.select(keep if k == 0 else [0]); p = out / f"in{k}.pdf"; src.save(p); ins.append(p)
            o2 = {k: v for k, v in opts.items() if k not in ("pages",)}
            if name == "watermark" and o2.get("text"):
                o2["text"] = str(o2["text"]).split("\n")[0]
            if name == "rotate":
                o2 = {"angle": int((opts.get("per_page") or {}).get(str(pno), opts.get("angle") or 0) or 0) or 360}
            res = Path(TOOLS[name]["fn"](ins, o2, out))
            if res.suffix == ".zip":
                import zipfile
                with zipfile.ZipFile(res) as z:
                    first = sorted(n for n in z.namelist() if n.lower().endswith(".pdf"))[0]; z.extract(first, out); res = out / first
            d = pymupdf.open(res)
            pix = d[0].get_pixmap(dpi=96)
            return pix.tobytes("png")
        finally:
            shutil.rmtree(out, ignore_errors=True)
    try:
        png = await run_in_threadpool(work)
    except (ValueError, RuntimeError) as e:
        raise HTTPException(422, str(e)[:300])
    except Exception:
        raise HTTPException(422, "Preview is not available for these options.")
    return Response(png, media_type="image/png", headers={"Cache-Control": "no-store"})


INLINE = {".pdf": "application/pdf", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif",
          ".txt": "text/plain; charset=utf-8", ".md": "text/plain; charset=utf-8", ".csv": "text/plain; charset=utf-8"}


@app.get("/api/download/{jid}/{name}")
def download(jid: str, name: str, inline: int = 0):
    p = DATA / safe_name(jid) / safe_name(name)
    if not re.fullmatch(r"[0-9a-f]{16}", jid) or not p.is_file():
        raise HTTPException(404, "Result expired. Please process the file again.")
    ext = p.suffix.lower()
    if inline and ext in INLINE:  # only passive formats are ever shown in the browser (never HTML / SVG)
        return FileResponse(p, media_type=INLINE[ext], headers={"Cache-Control": "private, no-store", "Content-Disposition": "inline"})
    return FileResponse(p, filename=p.name, media_type="application/octet-stream", headers={"Cache-Control": "private, no-store"})


@app.delete("/api/task/{jid}")
def delete_task(jid: str):
    if re.fullmatch(r"[0-9a-f]{16}", jid):
        shutil.rmtree(DATA / jid, ignore_errors=True)
    return {"deleted": True}


# ------------------------------------------------------------------ editor
# The browser shows pages as pictures rendered by the SAME engine that writes the PDF, so what people see is what they get.
# Every change to existing content is committed at once into a new working version (v1, v2 …) – that makes undo trivial and
# keeps reflow, scans and fonts exact. New objects (pictures, shapes, signatures …) stay in the browser until "Apply".
KEEP_VERSIONS = 30
RENDER = asyncio.Semaphore(max(4, (os.cpu_count() or 2) * 2))


def _ver(d, m, v):
    """file of working version v (0 = the uploaded document)"""
    try:
        v = int(v or 0)
    except (TypeError, ValueError):
        raise HTTPException(400, "Bad version")
    p = Path(m["path"]) if v <= 0 else d / f"v{v}.pdf"
    if v < 0 or v > int(m.get("versions", 0)) or not p.exists():
        raise HTTPException(409, "This version of the document is no longer available. Please reload the page.")
    return p, v


def _cache(d, v):
    c = d / f"c{int(v)}"; c.mkdir(exist_ok=True)
    return c


def _lang(v):
    return editor.ocr_langs(re.sub(r"[^a-z_+]", "", str(v or "eng+hin").lower()))


def _sizes(path):
    doc = pymupdf.open(path)
    try:
        return [[round(p.rect.width, 2), round(p.rect.height, 2)] for p in doc]
    finally:
        doc.close()


@app.post("/api/editor/{fid}/prepare")
async def editor_prepare(fid: str):
    d, m = _file(fid)
    if m.get("kind") != "pdf" or m.get("encrypted") or m.get("damaged"):
        raise HTTPException(422, "This file cannot be opened in the editor." if not m.get("encrypted") else "Enter the password first.")
    if not m.get("prepared"):
        info = await run_in_threadpool(editor.prepare, m["path"])
        m = _describe(Path(m["path"]), fid, m["name"], Path(m["path"]).stat().st_size); m["prepared"] = True; m["versions"] = 0; m.update(info)
        _store(fid, d, m)
    pub = {k: v for k, v in m.items() if k != "path"}
    return {"meta": pub, "version": int(m.get("versions", 0)), "pages": await run_in_threadpool(_sizes, _ver(d, m, m.get("versions", 0))[0]),
            "fonts": fonts.menu(), "ocr_languages": sorted(editor.tess_langs() - {"osd", "equ"}),
            "ai": bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("OPENAI_BASE_URL"))}


@app.get("/api/font/{key}")
def font_file_(key: str, b: int = 0, i: int = 0):
    """font files for the browser preview (only fonts of the registry can be requested)."""
    if not fonts.has(key):
        raise HTTPException(404, "Unknown font")
    path, _ = fonts.face(key, bool(b), bool(i))
    return FileResponse(path, media_type="font/otf" if path.lower().endswith(".otf") else "font/ttf", headers={"Cache-Control": "public, max-age=604800"})


@app.get("/api/editor/{fid}/render/{pno}")
async def editor_render(fid: str, pno: int, v: int = 0, s: float = 1.5):
    """picture of one page of a working version (JPEG)"""
    d, m = _file(fid)
    src, v = _ver(d, m, v)
    s = min(5.0, max(0.05, float(s)))

    def work():
        doc = pymupdf.open(src)
        try:
            if not 0 <= pno < doc.page_count:
                raise HTTPException(404, "No such page")
            pg = doc[pno]
            k = min(s, (24_000_000 / max(1.0, pg.rect.width * pg.rect.height)) ** 0.5)   # at most 24 megapixels
            return pg.get_pixmap(matrix=pymupdf.Matrix(k, k), alpha=False).tobytes("jpeg", jpg_quality=88)
        finally:
            doc.close()
    async with RENDER:
        data = await run_in_threadpool(work)
    return Response(data, media_type="image/jpeg", headers={"Cache-Control": "private, max-age=86400"})


@app.get("/api/editor/{fid}/page/{pno}")
async def editor_page(fid: str, pno: int, lang: str = "eng+hin", v: int = 0):
    d, m = _file(fid)
    src, v = _ver(d, m, v)

    def work():
        doc = pymupdf.open(src)
        try:
            if not 0 <= pno < doc.page_count:
                raise HTTPException(404, "No such page")
            return editor.page_model(doc, pno, _lang(lang), cache_dir=_cache(d, v))
        finally:
            doc.close()
    async with HEAVY:
        return await run_in_threadpool(work)


def _apply(m, d, body, dst, src=None, cache=None):
    ops = body.get("ops") or []
    if not isinstance(ops, list) or len(ops) > 5000:
        raise ValueError("Too many changes in one go.")
    report = {}
    editor.apply_ops(str(src or m["path"]), ops, str(dst), "", cache or _cache(d, 0), _lang(body.get("lang")), report)
    for kind, err in report.get("failed", []):
        print(f"[editor] skipped {kind}: {err}", flush=True)
    return report


_commit_locks = {}


@app.post("/api/editor/{fid}/commit")
async def editor_commit(fid: str, req: Request):
    """apply changes to existing content → new working version (free of charge; the download is what counts)"""
    d, m = _file(fid)
    body = await req.json()
    throttle("commit:" + client_ip(req), limit=600, window=600)
    lock = _commit_locks.setdefault(fid, asyncio.Lock())
    if len(_commit_locks) > 2000:
        for k in list(_commit_locks)[:1000]:
            if not _commit_locks[k].locked():
                _commit_locks.pop(k, None)
    async with lock:
        d, m = _file(fid)
        src, base = _ver(d, m, body.get("base"))
        new = base + 1
        dst = d / f"v{new}.pdf"; tmp = d / f"v{new}.tmp.pdf"
        try:
            async with HEAVY:
                report = await run_in_threadpool(_apply, m, d, body, tmp, src, _cache(d, base))
        except ValueError as e:
            tmp.unlink(missing_ok=True); raise HTTPException(422, str(e))
        except Exception as e:
            traceback.print_exc(); tmp.unlink(missing_ok=True)
            raise HTTPException(500, "Could not apply the change." + (f" ({e})" if os.environ.get("DEBUG") == "1" else ""))
        for k in range(new, int(m.get("versions", 0)) + 1):      # a new change after "undo" replaces the undone ones
            (d / f"v{k}.pdf").unlink(missing_ok=True); shutil.rmtree(d / f"c{k}", ignore_errors=True)
        os.replace(tmp, dst)
        nc = _cache(d, new)
        if not report.get("structure"):                           # text recognition of untouched pages stays valid
            touched = {f"ocr_{p}_" for p in report.get("pages", [])}
            for f in _cache(d, base).glob("ocr_*.json"):
                if not any(f.name.startswith(t) for t in touched):
                    shutil.copy(f, nc / f.name)
        for k in range(1, new - KEEP_VERSIONS + 1):               # very old steps are dropped
            (d / f"v{k}.pdf").unlink(missing_ok=True); shutil.rmtree(d / f"c{k}", ignore_errors=True)
        m["versions"] = new
        (d / "meta.json").write_text(json.dumps(m))
    return {"version": new, "oldest": max(0, new - KEEP_VERSIONS + 1) if new > KEEP_VERSIONS else 0, "pages": report.get("pages", []),
            "structure": bool(report.get("structure")), "shifts": report.get("shifts", {}), "skipped": len(report.get("failed", [])),
            "replaced": report.get("replaced"), "sizes": await run_in_threadpool(_sizes, dst) if report.get("structure") else None}


@app.post("/api/editor/{fid}/apply")
async def editor_apply(fid: str, req: Request):
    """final document = working version + the objects placed in the browser → download"""
    d, m = _file(fid)
    body = await req.json()
    src, v = _ver(d, m, body.get("version"))
    first = not m.get("counted")          # one document = one task: downloading it again after another small change is free
    if first:
        charge(req, "task", files=1, pages=m.get("pages") or 0, mb=m["size"] / 1048576)
        count("tasks"); count("editor"); count("tool:pdf-editor")
    jid, out = new_job()
    dst = out / (Path(m["name"]).stem + ".pdf")
    try:
        async with HEAVY:
            report = await run_in_threadpool(_apply, m, d, body, dst, src, _cache(d, v))
    except ValueError as e:
        if first:
            refund(req)
        shutil.rmtree(out, ignore_errors=True); raise HTTPException(422, str(e))
    except Exception as e:
        traceback.print_exc()
        if first:
            refund(req)
        shutil.rmtree(out, ignore_errors=True)
        raise HTTPException(500, "Could not apply the changes." + (f" ({e})" if os.environ.get("DEBUG") == "1" else ""))
    if first:
        async with _commit_locks.setdefault(fid, asyncio.Lock()):      # the file's description is also rewritten by commits
            d2, m2 = _file(fid); m2["counted"] = True
            (d2 / "meta.json").write_text(json.dumps(m2))
    return {"task": jid, "name": dst.name, "size": dst.stat().st_size, "download": f"/api/download/{jid}/{dst.name}", "file_id": _register_result(dst),
            "skipped": len(report.get("failed", [])), "replaced": report.get("replaced")}


@app.get("/api/editor/{fid}/fields")
def editor_fields(fid: str, v: int = 0):
    d, m = _file(fid)
    doc = pymupdf.open(_ver(d, m, v)[0])
    out = []
    try:
        for pg in doc:
            for w in pg.widgets():
                out.append({"page": pg.number, "name": w.field_name, "type": w.field_type_string, "value": w.field_value, "xref": w.xref,
                            "rect": [round(x, 2) for x in w.rect], "options": w.choice_values, "on": w.on_state() if w.field_type in (2, 5) else None,
                            "multiline": bool(w.field_flags & pymupdf.PDF_TX_FIELD_IS_MULTILINE) if w.field_type == pymupdf.PDF_WIDGET_TYPE_TEXT else False})
    finally:
        doc.close()
    return out


@app.post("/api/ai")
async def ai(req: Request):
    """small AI helpers inside the editor: {action: rewrite|fix|shorter|longer|translate, text, lang}"""
    b = await req.json()
    text = str(b.get("text") or "")[:20000]
    if not text.strip():
        raise HTTPException(400, "No text selected")
    prompts = {
        "rewrite": "Rewrite this text to be clearer and more professional. Keep the meaning and a similar length.",
        "fix": "Fix spelling and grammar. Change nothing else.",
        "shorter": "Make this text about 40% shorter without losing the key information.",
        "longer": "Expand this text with one or two fitting sentences, same tone.",
        "translate": f"Translate this text to {re.sub(r'[^A-Za-z ()]', '', str(b.get('lang') or 'Hindi'))[:30]}.",
    }
    charge(req, "ai")
    try:
        res = await run_in_threadpool(tools_plus.ai_complete, prompts.get(b.get("action"), prompts["rewrite"]) +
                                      " Return only the resulting text, in the same language unless told otherwise.\n\n<text>\n" + text + "\n</text>", 3000)
    except RuntimeError as e:
        refund(req, "ai"); raise HTTPException(501, str(e))
    except Exception:
        refund(req, "ai"); raise HTTPException(502, "The AI service did not answer. Please try again.")
    return {"result": res.strip()}


# ------------------------------------------------------------------ e-sign requests (send a link, the other person signs online)
def _sign_dir(token):
    if not re.fullmatch(r"[0-9a-f]{40}", token or ""):
        raise HTTPException(404, "Unknown signing link")
    d = SIGN / token
    if not (d / "meta.json").exists():
        raise HTTPException(404, "This signing link does not exist or has expired.")
    return d, json.loads((d / "meta.json").read_text())


def _site_cert():
    p12 = os.environ.get("SIGN_CERT_P12")
    if p12 and Path(p12).exists():
        return p12, (os.environ.get("SIGN_CERT_PASSWORD") or "").encode() or None
    p, pwf = SIGN / "_site.p12", SIGN / "_site.pw"
    if not p.exists() or not pwf.exists():
        import fcntl
        with open(SIGN / "_site.lock", "w") as lk:           # several server processes may get here at the same moment
            fcntl.flock(lk, fcntl.LOCK_EX)
            if not p.exists() or not pwf.exists():
                tmp = SIGN / f"_site.{os.getpid()}.tmp"
                pw = tools_plus.make_certificate(f"{SITE_NAME} e-Sign", os.environ.get("SUPPORT_EMAIL", ""), tmp)
                pwf.write_bytes(pw); os.chmod(pwf, 0o600); os.replace(tmp, p)
    return p, pwf.read_bytes()


@app.post("/api/sign/create")
async def sign_create(req: Request):
    b = await req.json()
    d, m = _file(b.get("file_id"))
    if m.get("kind") != "pdf":
        raise HTTPException(422, "Only PDF documents can be sent for signature.")
    u = charge(req, "task", files=1, pages=m.get("pages") or 0, mb=m["size"] / 1048576)
    token = secrets.token_hex(20)
    sd = SIGN / token; sd.mkdir(parents=True)
    try:
        src, v = _ver(d, m, b.get("version"))
        if b.get("ops"):
            await run_in_threadpool(_apply, m, d, b, sd / "doc.pdf", src, _cache(d, v))
        else:
            shutil.copy(src, sd / "doc.pdf")
    except HTTPException:
        shutil.rmtree(sd, ignore_errors=True); refund(req); raise
    except Exception:
        shutil.rmtree(sd, ignore_errors=True); refund(req)
        raise HTTPException(500, "Could not prepare the document.")
    meta = {"token": token, "title": str(b.get("title") or m["name"])[:150], "message": str(b.get("message") or "")[:1000],
            "owner": u["id"] if u else None, "owner_email": (u["email"] if u else str(b.get("email") or ""))[:200],
            "signer_email": str(b.get("signer_email") or "")[:200], "created": time.time(), "status": "pending", "name": Path(m["name"]).stem + ".pdf"}
    (sd / "meta.json").write_text(json.dumps(meta))
    url = f"{SITE}/sign/{token}"
    if meta["signer_email"] and "@" in meta["signer_email"]:
        send_mail(meta["signer_email"], f"Please sign: {meta['title']}",
                  f"Hello,\n\nyou have been asked to sign “{meta['title']}”.\n{meta['message']}\n\nOpen this link to read and sign the document:\n{url}\n\n– {SITE_NAME}")
    return {"token": token, "url": url}


@app.get("/api/sign/{token}")
def sign_get(token: str):
    sd, meta = _sign_dir(token)
    res = {k: meta.get(k) for k in ("title", "message", "status", "created")}
    if meta["status"] == "signed":
        res.update(download=f"/api/sign/{token}/download", signer=meta.get("signer", {}).get("name"), signed_at=meta.get("signer", {}).get("time"))
        return res
    fid = uuid.uuid4().hex[:16]; d = UPLOADS / fid; d.mkdir(parents=True)
    p = d / meta["name"]; shutil.copy(sd / "doc.pdf", p)
    _store(fid, d, _describe(p, fid, p.name, p.stat().st_size))
    res["file_id"] = fid
    return res


SIGNER_OPS = {"signature", "image", "add_text", "fill_forms", "ink", "line"}     # a signer may add things, never change the document


def _finish_signing(sd, meta, body, signer):
    tmp = sd / "_filled.pdf"
    src = pymupdf.open(sd / "doc.pdf")
    areas = [p.rect.width * p.rect.height for p in src]; src.close()
    ops = []
    for o in (body.get("ops") or [])[:400]:
        if not isinstance(o, dict) or o.get("type") not in SIGNER_OPS:
            continue
        if o["type"] in ("signature", "image"):      # a "signature" that covers the page could hide what was agreed
            try:
                r = o["rect"]; pg = int(o["page"])
                if (r[2] - r[0]) * (r[3] - r[1]) > 0.35 * areas[pg]:
                    continue
            except Exception:
                continue
        ops.append(o)
    (sd / "cache").mkdir(exist_ok=True)
    _apply({"path": str(sd / "doc.pdf")}, sd, {"ops": ops, "lang": body.get("lang")}, tmp, sd / "doc.pdf", sd / "cache")
    before = hashlib.sha256((sd / "doc.pdf").read_bytes()).hexdigest()
    doc = pymupdf.open(tmp)
    r = doc[0].rect
    pg = doc.new_page(width=max(420, r.width), height=max(595, r.height))
    run = lambda t, b=0, c="#111111", s=10.5: {"t": str(t), "b": b, "i": 0, "c": c, "s": s, "fam": "liberationsans", "f": ""}
    rows = [("Document", meta["title"]), ("Signed by", signer["name"]), ("E-mail", signer["email"] or "–"), ("Date and time (UTC)", signer["time"]),
            ("IP address", signer["ip"]), ("Device", signer["ua"][:110]), ("Reference", meta["token"])]
    paras = [[run("Signature certificate", 1, s=18)], [run("")],
             [run(f"This page was added by {SITE_NAME} when the document was signed electronically. "
                  "The signer confirmed that they have read the document and agree to sign it electronically.")], [run("")]]
    paras += [[run(k + ":   ", c="#555555"), run(v, 1)] for k, v in rows]      # names in any language (Hindi, Arabic …) are typeset correctly
    paras += [[run("Document fingerprint before signing (SHA-256):", c="#555555")], [run(before[:32]), run(" "), run(before[32:])], [run("")],
              [run("The file is sealed with a digital certificate: any change made after signing is detected by PDF readers.", c="#555555")]]
    editor.typeset(pg, 45, pg.rect.width - 45, None, paras, "left", 1.55, top_y=45)
    sealed_in = sd / "_audit.pdf"; editor.save(doc, sealed_in)
    cert, pw = _site_cert()
    tools_plus.sign_pdf(sealed_in, sd / "signed.pdf", cert, pw, name=f"{SITE_NAME} e-Sign", reason=f"Signed electronically by {signer['name']}", field="eSignSeal")
    tmp.unlink(missing_ok=True); sealed_in.unlink(missing_ok=True)


@app.post("/api/sign/{token}/complete")
async def sign_complete(token: str, req: Request):
    sd, meta = _sign_dir(token)
    if meta["status"] != "pending":
        raise HTTPException(409, "This document has already been signed.")
    b = await req.json()
    name = str(b.get("name") or "").strip()[:120]
    if len(name) < 2 or not b.get("consent"):
        raise HTTPException(422, "Please type your full name and tick the consent box.")
    signer = {"name": name, "email": str(b.get("email") or "").strip()[:200], "ip": client_ip(req), "ua": req.headers.get("user-agent", "")[:300],
              "time": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")}
    try:   # only one request may complete a document (double clicks, two people with the same link)
        os.close(os.open(sd / "_lock", os.O_CREAT | os.O_EXCL | os.O_WRONLY))
    except FileExistsError:
        raise HTTPException(409, "This document is being signed right now.")
    try:
        async with HEAVY:
            await run_in_threadpool(_finish_signing, sd, meta, b, signer)
    except Exception:
        traceback.print_exc()
        (sd / "_lock").unlink(missing_ok=True)
        raise HTTPException(500, "Signing failed. Please try again.")
    meta.update(status="signed", signer=signer)
    (sd / "meta.json").write_text(json.dumps(meta))
    link = f"{SITE}/sign/{token}"
    for to in {meta.get("owner_email"), signer["email"]} - {None, ""}:
        if "@" in to:
            send_mail(to, f"Signed: {meta['title']}", f"“{meta['title']}” was signed by {name} on {signer['time']} UTC.\n\nDownload the signed document:\n{link}\n\n– {SITE_NAME}")
    return {"status": "signed", "download": f"/api/sign/{token}/download"}


@app.get("/api/sign/{token}/download")
def sign_download(token: str):
    sd, meta = _sign_dir(token)
    if meta["status"] != "signed":
        raise HTTPException(409, "Not signed yet.")
    return FileResponse(sd / "signed.pdf", filename=Path(meta["name"]).stem + "_signed.pdf", media_type="application/pdf")


# ------------------------------------------------------------------ website (server-side titles / descriptions for search engines)
_I18N = {}
RTL = {"ar", "ur", "fa", "he"}


def _dict(lang):
    p = STATIC / "i18n" / f"{lang}.json"
    try:
        mt = p.stat().st_mtime
    except FileNotFoundError:
        return {}
    if _I18N.get(lang, (0, None))[0] != mt:
        _I18N[lang] = (mt, json.loads(p.read_text("utf-8")))
    return _I18N[lang][1]


def _langs():
    return sorted(p.stem for p in (STATIC / "i18n").glob("*.json"))


def _indexable():
    """languages that are translated well enough to be shown to search engines (the others work for visitors, but are not advertised)"""
    p = STATIC / "i18n.coverage.json"
    try:
        mt = p.stat().st_mtime
        if _I18N.get("#cov", (0, None))[0] != mt:
            _I18N["#cov"] = (mt, json.loads(p.read_text("utf-8")))
        cov = _I18N["#cov"][1]
    except Exception:
        cov = {}
    have = set(_langs())
    return sorted({"en"} | {l for l in have if cov.get(l, 1.0 if not cov else 0) >= 0.6})


def _t(lang, key, default=""):
    return _dict(lang).get(key) or _dict("en").get(key) or default


ADSENSE = re.sub(r"[^a-z0-9-]", "", os.environ.get("ADSENSE_CLIENT", "").strip().lower())   # ca-pub-1234567890123456
ADS_PAGES = ("index.html", "tool.html")
GA_ID = re.sub(r"[^A-Z0-9-]", "", os.environ.get("GA_ID", "").strip().upper())                 # Google Analytics 4: G-XXXXXXXXXX
GSV = re.sub(r"[^A-Za-z0-9_-]", "", os.environ.get("GOOGLE_SITE_VERIFICATION", "").strip())     # Search Console HTML-tag code
EEA = ["AT","BE","BG","HR","CY","CZ","DK","EE","FI","FR","DE","GR","HU","IE","IT","LV","LT","LU","MT","NL","PL","PT","RO","SK","SI","ES","SE","IS","LI","NO","GB","CH"]                                                      # never on the editor, sign, account or payment pages


def _page(file, lang, path, title=None, desc=None, index=True, req=None):
    html = (STATIC / file).read_text("utf-8")
    ads = bool(ADSENSE.startswith("ca-pub-") and file in ADS_PAGES and not (req and ad_free(req)))
    if req is not None:
        count_visit(req, path if file != "tool.html" else path)
    if ads:   # Google AdSense "Auto ads": Google picks the places on the page; Pro users never see adverts
        html = html.replace("</head>", f'<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={ADSENSE}" crossorigin="anonymous"></script></head>', 1)
    ga = bool(GA_ID.startswith("G-"))
    if ga:   # consent mode: no analytics cookies in the EEA/UK/CH until the visitor agrees
        html = html.replace("</head>", f'<script async src="https://www.googletagmanager.com/gtag/js?id={GA_ID}"></script><script>window.dataLayer=window.dataLayer||[];function gtag(){{dataLayer.push(arguments)}}'
                            f'gtag("consent","default",{{analytics_storage:"denied",ad_storage:"denied",ad_user_data:"denied",ad_personalization:"denied",region:{json.dumps(EEA)}}});'
                            f'gtag("js",new Date());gtag("config","{GA_ID}");</script></head>', 1)
    if GSV and path == "/":
        html = html.replace("</head>", f'<meta name="google-site-verification" content="{GSV}"></head>', 1)
    e = lambda v: _h.escape(v or "", quote=True)
    full = f"{title} – {SITE_NAME}" if title else SITE_NAME
    langs = _indexable()
    index = index and lang in langs
    alts = "".join(f'<link rel="alternate" hreflang="{l}" href="{SITE}{"" if l == "en" else "/" + l}{path if path != "/" or l == "en" else ""}">' for l in langs) if index else ""
    head = (f"<title>{e(full)}</title><meta name=\"description\" content=\"{e(desc)}\">"
            f'<link rel="canonical" href="{SITE}{"" if lang == "en" else "/" + lang}{path if path != "/" or lang == "en" else ""}">{alts}'
            f'<link rel="alternate" hreflang="x-default" href="{SITE}{path}">'
            f'<meta property="og:title" content="{e(full)}"><meta property="og:description" content="{e(desc)}"><meta property="og:type" content="website">'
            f'<meta property="og:site_name" content="{e(SITE_NAME)}"><link rel="icon" href="/static/favicon.svg" type="image/svg+xml">'
            f'<link rel="apple-touch-icon" href="/static/apple-touch-icon.png"><link rel="manifest" href="/manifest.webmanifest"><meta name="theme-color" content="#e5322d">'
            + ("" if index else '<meta name="robots" content="noindex">'))
    html = re.sub(r'<meta name="description"[^>]*>', "", html)
    html = re.sub(r"<title>.*?</title>", lambda m: head, html, count=1, flags=re.S)
    html = html.replace('<html lang="en">', f'<html lang="{lang}"' + (' dir="rtl"' if lang in RTL else "") + ">", 1)
    headers = {"Cache-Control": "no-cache"}
    if os.environ.get("CSP", "on").lower() not in ("off", "0", "no"):
        # only our own scripts run (inline ones carry a one-time number); the two payment / login widgets are the only outsiders
        nonce = secrets.token_urlsafe(16)
        html = html.replace("<script", f'<script nonce="{nonce}"')
        adh = (" https://pagead2.googlesyndication.com https://*.googlesyndication.com https://*.doubleclick.net https://*.google.com https://*.gstatic.com"
               " https://*.googleadservices.com https://*.adtrafficquality.google https://www.googletagservices.com") if ads else ""
        if ga:
            adh += " https://www.googletagmanager.com https://*.google-analytics.com https://*.analytics.google.com"
        headers["Content-Security-Policy"] = (
            f"default-src 'self'; script-src 'self' 'nonce-{nonce}' 'wasm-unsafe-eval' https://*.razorpay.com https://accounts.google.com{adh}; "
            "style-src 'self' 'unsafe-inline' https://accounts.google.com; img-src 'self' data: blob: https:; font-src 'self' data:; "
            f"connect-src 'self' https://*.razorpay.com https://accounts.google.com{adh}; frame-src 'self' https://*.razorpay.com https://accounts.google.com{adh}; "
            "worker-src 'self' blob:; object-src 'none'; base-uri 'self'; frame-ancestors 'self'; form-action 'self'")
    return HTMLResponse(html, headers=headers)


SIMPLE = {"pricing": ("pricing.html", "pricing.title", "pricing.sub", True), "login": ("login.html", "auth.login", "", False),
          "account": ("account.html", "nav.account", "", False), "admin": ("admin.html", "Admin", "", False),
          "privacy": ("legal.html", "legal.privacy", "", True), "terms": ("legal.html", "legal.terms", "", True),
          "refund": ("legal.html", "legal.refund", "", True), "contact": ("legal.html", "legal.contact", "", True)}


@app.get("/healthz", include_in_schema=False)
def healthz():
    import shutil as sh
    need = {"ghostscript": sh.which("gs"), "tesseract": sh.which("tesseract"), "libreoffice": sh.which("soffice") or sh.which("libreoffice"),
            "ocrmypdf": sh.which("ocrmypdf"), "qpdf (pikepdf)": True}
    try:
        from PIL import features
        shaping = bool(features.check("raqm"))
    except Exception:
        shaping = False
    return {"ok": all(need.values()), "missing": [k for k, v in need.items() if not v], "tools": len(TOOLS), "font_families": len(fonts.scan()),
            "text_shaping": shaping,   # Hindi / Arabic text on pictures needs Pillow with Raqm (libfribidi0 installed)
            "ocr_languages": len(editor.tess_langs()), "ai": bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("OPENAI_BASE_URL")),
            "payments": {"razorpay": bool(os.environ.get("RAZORPAY_KEY_ID") and os.environ.get("RAZORPAY_KEY_SECRET")), "stripe": bool(os.environ.get("STRIPE_SECRET_KEY"))},
            "mail": bool(os.environ.get("SMTP_HOST"))}


@app.get("/manifest.webmanifest", include_in_schema=False)
def manifest():
    """lets phones add the site to the home screen like an app (name follows SITE_NAME)"""
    return Response(json.dumps({
        "name": f"{SITE_NAME} – PDF & image tools", "short_name": SITE_NAME[:12], "description": "Edit, convert, compress, sign and scan PDF files and pictures.",
        "start_url": "/", "scope": "/", "display": "standalone", "background_color": "#f7f8fb", "theme_color": "#e5322d",
        "icons": [{"src": "/static/favicon.svg", "sizes": "any", "type": "image/svg+xml", "purpose": "any"},
                  {"src": "/static/icon-192.png", "sizes": "192x192", "type": "image/png"}, {"src": "/static/icon-512.png", "sizes": "512x512", "type": "image/png"},
                  {"src": "/static/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"}]}),
        media_type="application/manifest+json", headers={"Cache-Control": "public, max-age=86400"})


@app.get("/google{code}.html", include_in_schema=False)
def google_verify_file(code: str):
    """Search Console "HTML file" verification (GOOGLE_VERIFY_FILE=google284c….html)"""
    want = os.environ.get("GOOGLE_VERIFY_FILE", "").strip()
    if not want or want != f"google{code}.html" or not re.fullmatch(r"[0-9a-f]{8,32}", code):
        raise HTTPException(404, "Not found")
    return PlainTextResponse(f"google-site-verification: {want}")


@app.get("/ads.txt", include_in_schema=False)
def ads_txt():
    """AdSense checks this file before it shows ads on the site"""
    if not ADSENSE.startswith("ca-pub-"):
        raise HTTPException(404, "Not found")
    return PlainTextResponse(f"google.com, {ADSENSE[3:]}, DIRECT, f08c47fec0942fa0\n")


@app.get("/robots.txt", include_in_schema=False)
def robots():
    return PlainTextResponse(f"User-agent: *\nDisallow: /api/\nDisallow: /sign/\nDisallow: /account\nDisallow: /admin\nSitemap: {SITE}/sitemap.xml\n")


@app.get("/sitemap.xml", include_in_schema=False)
def sitemap():
    en = _dict("en")
    slugs = [k[5:] for k in en if k.startswith("tool.")]
    urls = [f"{SITE}/", f"{SITE}/pricing"] + [f"{SITE}/tool/{s}" for s in slugs]
    for l in _indexable():
        if l == "en":
            continue
        d = _dict(l)
        urls.append(f"{SITE}/{l}")
        urls += [f"{SITE}/{l}/tool/{s}" for s in slugs if d.get(f"tool.{s}")]
    xml = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + "".join(f"<url><loc>{_h.escape(u)}</loc></url>" for u in urls) + "</urlset>"
    return Response(xml, media_type="application/xml")


app.mount("/static", StaticFiles(directory=STATIC), name="static")
app.mount("/fonts", StaticFiles(directory=BASE / "fonts"), name="fonts")


@app.get("/{full:path}", include_in_schema=False)
def site(full: str, req: Request):
    parts = [p for p in full.split("/") if p]
    lang = "en"
    if parts and parts[0] in _langs() and parts[0] != "en":
        lang = parts.pop(0)
    path = "/" + "/".join(parts)
    if path == "/":
        return _page("index.html", lang, "/", _t(lang, "hero.title", "PDF & image tools"), _t(lang, "hero.sub"), req=req)
    if len(parts) == 2 and parts[0] == "tool" and re.fullmatch(r"[a-z0-9-]+", parts[1]):
        slug = parts[1]
        if not _dict("en").get(f"tool.{slug}") and slug != "workflows":
            raise HTTPException(404, "Page not found")
        return _page("tool.html", lang, path, _t(lang, f"tool.{slug}", "Workflows"), _t(lang, f"desc.{slug}"), req=req)
    if path == "/edit":
        return _page("editor.html", lang, path, _t(lang, "tool.pdf-editor", "PDF Editor"), _t(lang, "desc.pdf-editor"), req=req)
    if len(parts) == 2 and parts[0] == "sign":
        return _page("editor.html", lang, path, "Sign document", "", index=False)
    if len(parts) == 1 and parts[0] in SIMPLE:
        f, tk, dk, idx = SIMPLE[parts[0]]
        return _page(f, lang, path, _t(lang, tk, tk.split(".")[-1].title()), _t(lang, dk) if dk else "", index=idx, req=req)
    return HTMLResponse(f"<!doctype html><meta charset=utf-8><title>Not found – {_h.escape(SITE_NAME)}</title><body style='font-family:sans-serif;text-align:center;padding:80px'>"
                        "<h1>404</h1><p>This page does not exist.</p><p><a href='/'>All tools</a></p>", status_code=404)

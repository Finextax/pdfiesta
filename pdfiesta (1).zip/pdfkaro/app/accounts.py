"""Users, sessions, usage quotas (SQLite – zero setup; switch DATABASE to Postgres later if needed)."""
import hashlib, hmac, json, os, secrets, smtplib, sqlite3, threading, time, datetime
from email.message import EmailMessage
from fastapi import APIRouter, HTTPException, Request, Response
from .util import DATA
from .plans import FREE, PRO, PLANS, PRO_FEATURES, QUOTA_WINDOW, QUOTA_HOURS

DB_PATH = os.environ.get("DATABASE", str(DATA / "app.db"))
_local = threading.local()
router = APIRouter()
COOKIE = "pk_session"
SITE = os.environ.get("SITE_URL", "http://localhost:8000").rstrip("/")
SITE_NAME = os.environ.get("SITE_NAME", "PDFiesta")


def db():
    c = getattr(_local, "c", None)
    if c is None:
        c = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False, isolation_level=None)  # autocommit
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        _local.c = c
    return c


def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE, name TEXT, pw TEXT, google_sub TEXT,
        plan TEXT DEFAULT 'free', plan_until REAL DEFAULT 0, stripe_customer TEXT, lang TEXT, created REAL);
    CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER, expires REAL);
    CREATE TABLE IF NOT EXISTS usage(who TEXT, day TEXT, kind TEXT, n INTEGER, PRIMARY KEY(who, day, kind));
    CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY, user_id INTEGER, provider TEXT, ref TEXT UNIQUE, plan TEXT,
        amount REAL, currency TEXT, status TEXT, created REAL, raw TEXT);
    CREATE TABLE IF NOT EXISTS resets(token TEXT PRIMARY KEY, user_id INTEGER, expires REAL);
    CREATE TABLE IF NOT EXISTS stats(day TEXT, key TEXT, n INTEGER, PRIMARY KEY(day, key));
    CREATE TABLE IF NOT EXISTS visitors(day TEXT, h TEXT, PRIMARY KEY(day, h));
    """)
    c.commit()


init_db()


# ------------------------------------------------------------------ passwords (scrypt, stdlib)
def hash_pw(pw):
    salt = secrets.token_bytes(16)
    h = hashlib.scrypt(pw.encode(), salt=salt, n=2 ** 14, r=8, p=1)
    return "scrypt$" + salt.hex() + "$" + h.hex()


def check_pw(pw, stored):
    try:
        _, salt, h = stored.split("$")
        return hmac.compare_digest(hashlib.scrypt(pw.encode(), salt=bytes.fromhex(salt), n=2 ** 14, r=8, p=1).hex(), h)
    except Exception:
        return False


# ------------------------------------------------------------------ sessions
# ------------------------------------------------------------------ simple, private statistics for the owner (/admin)
_SALT = secrets.token_hex(8)       # changes on every restart: a visitor cannot be followed from one day to the next


def count(key, n=1):
    """add to a daily counter, e.g. count("tool:merge") – never raises"""
    try:
        db().execute("INSERT INTO stats VALUES(?,?,?) ON CONFLICT(day,key) DO UPDATE SET n=n+?", (time.strftime("%Y-%m-%d"), key[:80], n, n)); db().commit()
    except Exception:
        pass


def count_visit(req: Request, page):
    """one page view; unique visitors are counted by a salted hash of address + browser (nothing personal is stored)"""
    try:
        day = time.strftime("%Y-%m-%d")
        h = hashlib.sha256(f"{_SALT}|{client_ip(req)}|{req.headers.get('user-agent', '')}".encode()).hexdigest()[:16]
        c = db()
        new = c.execute("INSERT OR IGNORE INTO visitors VALUES(?,?)", (day, h)).rowcount
        for k, n in (("pageviews", 1), ("visitors", new), ("page:" + page, 1)):
            if n:
                c.execute("INSERT INTO stats VALUES(?,?,?) ON CONFLICT(day,key) DO UPDATE SET n=n+?", (day, k[:80], n, n))
        c.commit()
    except Exception:
        pass


def _login(resp: Response, uid: int):
    tok = secrets.token_urlsafe(32)
    db().execute("INSERT INTO sessions VALUES(?,?,?)", (tok, uid, time.time() + 60 * 86400)); db().commit()
    resp.set_cookie(COOKIE, tok, max_age=60 * 86400, httponly=True, samesite="lax",
                    secure=SITE.startswith("https"))


def current_user(req: Request):
    tok = req.cookies.get(COOKIE)
    if not tok:
        return None
    r = db().execute("SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>?",
                     (tok, time.time())).fetchone()
    return dict(r) if r else None


def admin_emails():
    return [e.strip().lower() for e in os.environ.get("ADMIN_EMAILS", "").split(",") if e.strip()]


def is_admin(u):
    return bool(u and (u["email"] or "").lower() in admin_emails())


def is_pro(u):
    """paid Pro – the site owners (ADMIN_EMAILS) always have everything, without limits or adverts."""
    return bool(u and (u["plan_until"] > time.time() or is_admin(u)))


def public_user(u):
    if not u:
        return None
    paid = bool(u["plan_until"] > time.time())
    if is_admin(u) and not paid:
        return {"id": u["id"], "email": u["email"], "name": u["name"], "pro": True, "admin": True, "plan": "owner", "plan_until": "always (site owner)"}
    return {"id": u["id"], "email": u["email"], "name": u["name"], "pro": is_pro(u), "admin": is_admin(u),
            "plan": u["plan"] if paid else "free",
            "plan_until": datetime.datetime.fromtimestamp(u["plan_until"]).strftime("%d %b %Y") if paid else None}


# ------------------------------------------------------------------ quotas
def client_ip(req: Request):
    """Real visitor address. Proxy headers are trusted only when you say the app sits behind that proxy
    (otherwise anybody could fake them and reset their free limit)."""
    if os.environ.get("BEHIND_CLOUDFLARE") == "1" and req.headers.get("cf-connecting-ip"):
        return req.headers["cf-connecting-ip"]
    if os.environ.get("TRUST_PROXY") == "1" and req.headers.get("x-forwarded-for"):
        return req.headers["x-forwarded-for"].split(",")[0].strip()
    return req.client.host if req.client else "unknown"


def _who(req: Request, u):
    if u:
        return f"u{u['id']}"
    return f"ip{client_ip(req)}"  # IP based so clearing cookies doesn't reset the free limit


def refund(req: Request, kind="task"):
    """a task that failed does not count against the free limit."""
    who = _who(req, current_user(req))
    db().execute("UPDATE usage SET n=MAX(n-1,0) WHERE who=? AND day=? AND kind=?", (who, bucket() if kind != "ai" else time.strftime("%Y-%m-%d"), kind))
    db().commit()


_attempts = {}


def throttle(key, limit=8, window=600):
    """simple brute-force brake (per process): max `limit` tries per `window` seconds."""
    now = time.time()
    q = [t for t in _attempts.get(key, []) if now - t < window]
    if len(q) >= limit:
        raise HTTPException(429, "Too many attempts. Please wait a few minutes and try again.")
    q.append(now); _attempts[key] = q
    if len(_attempts) > 5000:
        for k in list(_attempts)[:2500]:
            _attempts.pop(k, None)


def limits_for(u):
    return PRO if is_pro(u) else FREE


def bucket(t=None):
    """the period free limits are counted in: this hour or today"""
    lt = time.localtime(t if t else time.time())
    if QUOTA_WINDOW != "hour":
        return time.strftime("%Y-%m-%d", lt)
    return time.strftime("%Y-%m-%d ", lt) + "%02d" % (lt.tm_hour - lt.tm_hour % QUOTA_HOURS)


PERIOD = "hour" if QUOTA_WINDOW == "hour" else "day"


def usage_today(who, kind="task"):
    r = db().execute("SELECT n FROM usage WHERE who=? AND day=? AND kind=?", (who, bucket() if kind != "ai" else time.strftime("%Y-%m-%d"), kind)).fetchone()
    return r["n"] if r else 0


def charge(req: Request, kind="task", files=None, pages=0, mb=0.0):
    """Raise 402 if the free quota is used up; otherwise count one use."""
    u = current_user(req)
    who = _who(req, u)
    lim = limits_for(u)
    if mb > lim["max_mb"]:
        raise HTTPException(402, f"File too large for your plan (max {lim['max_mb']} MB). Upgrade to Pro for up to {PRO['max_mb']} MB.")
    if pages > lim["max_pages"]:
        raise HTTPException(402, f"Your plan allows up to {lim['max_pages']} pages per document. Upgrade to Pro for unlimited pages.")
    if files and files > lim["max_files"]:
        raise HTTPException(402, f"Your plan allows {lim['max_files']} files per task. Upgrade to Pro for up to {PRO['max_files']}.")
    if kind == "ai":
        if usage_today(who, "ai") >= lim["ai_per_day"]:
            raise HTTPException(402, "AI tools are part of Pro. Upgrade to use summarize, translate and chat with PDF." if not is_pro(u)
                                else "Daily AI limit reached. Try again tomorrow.")
    elif not is_pro(u):
        per_day = FREE["user_per_day"] if u else FREE["guest_per_day"]
        if usage_today(who) >= per_day:
            if PERIOD == "hour":
                span = "hour" if QUOTA_HOURS == 1 else f"{QUOTA_HOURS} hours"
                lt = time.localtime(); left = (QUOTA_HOURS - lt.tm_hour % QUOTA_HOURS) * 60 - lt.tm_min
                wait = f"{left} minutes" if left < 90 else f"about {round(left / 60)} hours"
                raise HTTPException(402, f"You used your {per_day} free documents for these {span}. New free documents in {wait}. You can "
                                         + ("log in to get " + str(FREE['user_per_day']) + " per " + span + ", or u" if not u else "or u")
                                         + "pgrade to Pro for unlimited use.")
            raise HTTPException(402, f"You used your {per_day} free tasks for today. "
                                     + ("Log in to get " + str(FREE['user_per_day']) + " per day, or u" if not u else "U")
                                     + "pgrade to Pro for unlimited use.")
    day = bucket() if kind != "ai" else time.strftime("%Y-%m-%d")
    db().execute("INSERT INTO usage VALUES(?,?,?,1) ON CONFLICT(who,day,kind) DO UPDATE SET n=n+1", (who, day, kind))
    db().commit()
    return u


# ------------------------------------------------------------------ email (SMTP: Resend/Postmark/SES/Gmail all work)
def send_mail(to, subject, body):
    """Never raises: a mail server that is down must not break sign-up, payments or signing."""
    host = os.environ.get("SMTP_HOST")
    if not host:
        print(f"[mail disabled] to={to} subject={subject}", flush=True)
        return False
    try:
        m = EmailMessage(); m["From"] = os.environ.get("MAIL_FROM", f"{SITE_NAME} <no-reply@example.com>"); m["To"] = to
        m["Subject"] = subject; m.set_content(body)
        port = int(os.environ.get("SMTP_PORT", "587"))
        with (smtplib.SMTP_SSL(host, port, timeout=20) if port == 465 else smtplib.SMTP(host, port, timeout=20)) as s:
            if port != 465:
                try:
                    s.starttls()
                except smtplib.SMTPNotSupportedError:
                    pass
            if os.environ.get("SMTP_USER"):
                s.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASSWORD", ""))
            s.send_message(m)
        return True
    except Exception as e:
        print(f"[mail failed] to={to} subject={subject}: {e!r}", flush=True)
        return False


def housekeeping():
    """forget expired logins / reset links and old usage counters (called by the janitor thread)."""
    try:
        c = db(); now = time.time()
        c.execute("DELETE FROM sessions WHERE expires<?", (now,))
        c.execute("DELETE FROM resets WHERE expires<?", (now,))
        c.execute("DELETE FROM visitors WHERE day<?", (time.strftime("%Y-%m-%d", time.localtime(now - 2 * 86400)),))
        c.execute("DELETE FROM usage WHERE day<?", (time.strftime("%Y-%m-%d", time.localtime(now - 40 * 86400)),))
    except Exception:
        pass


def ad_free(req: Request):
    """Pro users see no adverts"""
    try:
        return is_pro(current_user(req))
    except Exception:
        return False


# ------------------------------------------------------------------ routes
@router.post("/api/auth/signup")
async def signup(req: Request, resp: Response):
    b = await req.json()
    throttle("signup:" + client_ip(req), limit=5, window=3600)
    email = (b.get("email") or "").strip().lower(); pw = b.get("password") or ""
    import re as _re
    if len(email) > 200 or not _re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]{2,}", email):
        raise HTTPException(400, "Please enter a valid email address.")
    if len(pw) < 8:
        raise HTTPException(400, "Password must be at least 8 characters.")
    try:
        cur = db().execute("INSERT INTO users(email,name,pw,created) VALUES(?,?,?,?)", (email, str(b.get("name") or email.split("@")[0])[:80], hash_pw(pw), time.time()))
        db().commit()
    except sqlite3.IntegrityError:
        raise HTTPException(409, "An account with this email already exists. Please log in.")
    _login(resp, cur.lastrowid); count("signups")
    send_mail(email, f"Welcome to {SITE_NAME}", f"Hi,\n\nYour {SITE_NAME} account is ready. Start here: {SITE}\n")
    return {"ok": True}


@router.post("/api/auth/login")
async def login(req: Request, resp: Response):
    b = await req.json()
    throttle("login:" + client_ip(req)); throttle("login:" + (b.get("email") or "").strip().lower(), limit=10)
    u = db().execute("SELECT * FROM users WHERE email=?", ((b.get("email") or "").strip().lower(),)).fetchone()
    if not u or not u["pw"] or not check_pw(b.get("password") or "", u["pw"]):
        time.sleep(0.5)
        raise HTTPException(401, "Wrong email or password.")
    _login(resp, u["id"]); count("logins")
    return {"ok": True}


@router.post("/api/auth/google")
async def google(req: Request, resp: Response):
    """Google Identity Services: browser sends the ID token, we verify it with Google."""
    import httpx
    cid = os.environ.get("GOOGLE_CLIENT_ID")
    if not cid:
        raise HTTPException(501, "Google login is not configured (GOOGLE_CLIENT_ID).")
    tok = (await req.json()).get("credential")
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get("https://oauth2.googleapis.com/tokeninfo", params={"id_token": tok})
    info = r.json()
    if r.status_code != 200 or info.get("aud") != cid or info.get("email_verified") not in ("true", True):
        raise HTTPException(401, "Google sign-in failed.")
    email = info["email"].lower()
    u = db().execute("SELECT * FROM users WHERE google_sub=? OR email=?", (info["sub"], email)).fetchone()
    if u:
        db().execute("UPDATE users SET google_sub=? WHERE id=?", (info["sub"], u["id"])); uid = u["id"]
    else:
        uid = db().execute("INSERT INTO users(email,name,google_sub,created) VALUES(?,?,?,?)",
                           (email, info.get("name") or email, info["sub"], time.time())).lastrowid
    db().commit(); _login(resp, uid); count("logins")
    return {"ok": True}


@router.post("/api/auth/logout")
def logout(req: Request, resp: Response):
    db().execute("DELETE FROM sessions WHERE token=?", (req.cookies.get(COOKIE, ""),)); db().commit()
    resp.delete_cookie(COOKIE)
    return {"ok": True}


@router.post("/api/auth/forgot")
async def forgot(req: Request):
    email = ((await req.json()).get("email") or "").strip().lower()
    throttle("forgot:" + client_ip(req), limit=5, window=3600)
    u = db().execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()
    if u:
        tok = secrets.token_urlsafe(24)
        db().execute("INSERT INTO resets VALUES(?,?,?)", (tok, u["id"], time.time() + 3600)); db().commit()
        send_mail(email, f"Reset your {SITE_NAME} password", f"Click to set a new password (valid 1 hour):\n{SITE}/login?reset={tok}\n")
    return {"ok": True}  # same answer either way (no account enumeration)


@router.post("/api/auth/reset")
async def reset(req: Request, resp: Response):
    b = await req.json()
    r = db().execute("SELECT * FROM resets WHERE token=? AND expires>?", (b.get("token"), time.time())).fetchone()
    if not r:
        raise HTTPException(400, "This reset link is invalid or expired.")
    if len(b.get("password") or "") < 8:
        raise HTTPException(400, "Password must be at least 8 characters.")
    db().execute("UPDATE users SET pw=? WHERE id=?", (hash_pw(b["password"]), r["user_id"]))
    db().execute("DELETE FROM resets WHERE user_id=?", (r["user_id"],))
    db().execute("DELETE FROM sessions WHERE user_id=?", (r["user_id"],)); db().commit()   # a new password signs out every other device
    _login(resp, r["user_id"])
    return {"ok": True}


@router.post("/api/account/password")
async def change_password(req: Request, resp: Response):
    u = current_user(req)
    if not u:
        raise HTTPException(401, "Not logged in")
    b = await req.json()
    throttle(f"pw:{u['id']}", limit=8)
    if u["pw"] and not check_pw(b.get("old") or "", u["pw"]):
        raise HTTPException(403, "The current password is wrong.")
    if len(b.get("new") or "") < 8:
        raise HTTPException(400, "Password must be at least 8 characters.")
    db().execute("UPDATE users SET pw=? WHERE id=?", (hash_pw(b["new"]), u["id"]))
    db().execute("DELETE FROM sessions WHERE user_id=?", (u["id"],)); db().commit()
    _login(resp, u["id"])
    return {"ok": True}


@router.post("/api/account/profile")
async def profile(req: Request):
    u = current_user(req)
    if not u:
        raise HTTPException(401, "Not logged in")
    b = await req.json()
    db().execute("UPDATE users SET name=?, lang=? WHERE id=?", (str(b.get("name") or u["name"])[:80], str(b.get("lang") or u.get("lang") or "")[:8], u["id"])); db().commit()
    return {"ok": True}


@router.get("/api/me")
def me(req: Request):
    u = current_user(req)
    who = _who(req, u)
    lim = limits_for(u)
    per_day = None if is_pro(u) else (FREE["user_per_day"] if u else FREE["guest_per_day"])
    pays = [dict(p) for p in db().execute("SELECT provider,plan,amount,currency,status,created FROM payments WHERE user_id=? ORDER BY created DESC LIMIT 20",
                                          (u["id"],))] if u else []
    return {"user": public_user(u), "used_today": usage_today(who), "per_day": per_day, "period": PERIOD, "hours": QUOTA_HOURS, "limits": lim, "payments": pays,
            "subscription": bool(u and u["stripe_customer"]),          # an automatically renewing plan that can be cancelled on the account page
            "google_client_id": os.environ.get("GOOGLE_CLIENT_ID", ""), "source_url": os.environ.get("SOURCE_URL", ""),
            "site": {"name": SITE_NAME, "company": os.environ.get("COMPANY_NAME", ""),
                     "email": os.environ.get("SUPPORT_EMAIL", ""), "address": os.environ.get("COMPANY_ADDRESS", ""),
                     "country": os.environ.get("COMPANY_COUNTRY", "India"),
                     "gstin": os.environ.get("COMPANY_GSTIN", ""), "phone": os.environ.get("COMPANY_PHONE", ""),
                     "people": os.environ.get("COMPANY_PARTNERS", "")}}


@router.post("/api/account/delete")
async def delete_account(req: Request, resp: Response):
    u = current_user(req)
    if not u:
        raise HTTPException(401, "Not logged in")
    if u["stripe_customer"]:                      # an automatically renewing plan must end with the account
        from .payments import cancel_subscriptions
        try:
            await cancel_subscriptions(u["stripe_customer"])
        except Exception:
            raise HTTPException(502, "Your subscription could not be cancelled right now. Please cancel it with “Manage or cancel subscription” first, then delete the account.")
    db().execute("DELETE FROM sessions WHERE user_id=?", (u["id"],))
    db().execute("DELETE FROM resets WHERE user_id=?", (u["id"],))
    db().execute("UPDATE users SET email=?, name='', pw=NULL, google_sub=NULL, stripe_customer=NULL, plan='free', plan_until=0 WHERE id=?", (f"deleted-{u['id']}@deleted", u["id"]))
    db().commit(); resp.delete_cookie(COOKIE)
    return {"ok": True}


@router.get("/api/plans")
def plans(req: Request):
    country = (req.headers.get("cf-ipcountry") or "").upper() if os.environ.get("BEHIND_CLOUDFLARE") == "1" else ""
    lang = req.headers.get("accept-language", "")
    cur = "INR" if country == "IN" or (not country and ("-IN" in lang or lang.startswith("hi"))) else "USD"
    return {"currency": cur, "free": FREE, "pro": PRO, "period": PERIOD, "hours": QUOTA_HOURS, "features": PRO_FEATURES,
            "plans": {k: {**v, "price": v["inr"] if cur == "INR" else v["usd"]} for k, v in PLANS.items()},
            "providers": {"razorpay": bool(os.environ.get("RAZORPAY_KEY_ID") and os.environ.get("RAZORPAY_KEY_SECRET")), "stripe": bool(os.environ.get("STRIPE_SECRET_KEY"))}}


def activate(uid, plan, provider, ref, amount, currency, raw=""):
    """Idempotent: a payment ref is only applied once (webhook + browser callback may both arrive)."""
    if plan not in PLANS:
        raise ValueError("unknown plan")
    c = db()
    c.execute("BEGIN IMMEDIATE")
    try:
        c.execute("INSERT INTO payments(user_id,provider,ref,plan,amount,currency,status,created,raw) VALUES(?,?,?,?,?,?,?,?,?)",
                  (uid, provider, ref, plan, amount, currency, "paid", time.time(), raw[:4000]))
        u = c.execute("SELECT plan_until FROM users WHERE id=?", (uid,)).fetchone()
        start = max(time.time(), u["plan_until"] or 0)
        c.execute("UPDATE users SET plan=?, plan_until=? WHERE id=?", (plan, start + PLANS[plan]["days"] * 86400, uid))
        c.execute("COMMIT")
        count("payments"); count("plan:" + plan)
        return True
    except sqlite3.IntegrityError:  # same payment delivered twice (webhook + browser) → ignore
        c.execute("ROLLBACK")
        return False
    except Exception:
        c.execute("ROLLBACK"); raise


# ------------------------------------------------------------------ admin
@router.get("/api/admin/stats")
def admin(req: Request):
    u = current_user(req)
    if not is_admin(u):
        raise HTTPException(403, "Admins only")
    c = db()
    return {
        "users": c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"],
        "pro_users": c.execute("SELECT COUNT(*) n FROM users WHERE plan_until>?", (time.time(),)).fetchone()["n"],
        "tasks_today": c.execute("SELECT COALESCE(SUM(n),0) n FROM usage WHERE day LIKE ? AND kind='task'", (time.strftime("%Y-%m-%d") + "%",)).fetchone()["n"],
        "revenue": [dict(r) for r in c.execute("SELECT currency, SUM(amount) total, COUNT(*) n FROM payments WHERE status='paid' GROUP BY currency")],
        "recent_payments": [dict(r) for r in c.execute("SELECT p.created,u.email,p.provider,p.plan,p.amount,p.currency FROM payments p JOIN users u ON u.id=p.user_id ORDER BY p.created DESC LIMIT 50")],
        "days": [dict(r) for r in c.execute("SELECT day, key, n FROM stats WHERE day>=? AND key IN ('visitors','pageviews','signups','logins','tasks','payments','editor')",
                                             (time.strftime("%Y-%m-%d", time.localtime(time.time() - 30 * 86400)),))],
        "tools": [dict(r) for r in c.execute("SELECT substr(key,6) tool, SUM(n) n FROM stats WHERE key LIKE 'tool:%' AND day>=? GROUP BY key ORDER BY n DESC LIMIT 40",
                                              (time.strftime("%Y-%m-%d", time.localtime(time.time() - 30 * 86400)),))],
        "pages": [dict(r) for r in c.execute("SELECT substr(key,6) page, SUM(n) n FROM stats WHERE key LIKE 'page:%' AND day>=? GROUP BY key ORDER BY n DESC LIMIT 20",
                                              (time.strftime("%Y-%m-%d", time.localtime(time.time() - 30 * 86400)),))],
        "users_total": c.execute("SELECT COUNT(*) n FROM users WHERE email NOT LIKE 'deleted-%'").fetchone()["n"],
        "subscribers": [dict(r) for r in c.execute("SELECT email, plan, plan_until FROM users WHERE plan_until>? ORDER BY plan_until DESC LIMIT 100", (time.time(),))],
    }

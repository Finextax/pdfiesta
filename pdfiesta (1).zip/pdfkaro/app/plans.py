"""Plans, prices and free-tier limits. Change prices here (or via env) – the pricing page reads /api/plans."""
import os

def _env(k, d):
    return type(d)(os.environ.get(k, d))

# QUOTA_WINDOW=hour → the free limits below count per hour instead of per day (e.g. 3 documents every hour)
QUOTA_WINDOW = "hour" if os.environ.get("QUOTA_WINDOW", "day").lower().startswith("h") else "day"
# QUOTA_HOURS=3 (with QUOTA_WINDOW=hour) → the limit is counted per block of 3 hours (00-03, 03-06, …)
QUOTA_HOURS = max(1, min(12, int(os.environ.get("QUOTA_HOURS", "1") or 1))) if QUOTA_WINDOW == "hour" else 24

FREE = {
    "guest_per_day": _env("FREE_GUEST_PER_DAY", 2),      # without login
    "user_per_day": _env("FREE_USER_PER_DAY", 3),        # free account
    "max_mb": _env("FREE_MAX_MB", 50),
    "max_pages": _env("FREE_MAX_PAGES", 100),
    "max_files": _env("FREE_MAX_FILES", 5),               # files per task (merge etc.)
    "ai_per_day": _env("FREE_AI_PER_DAY", 0),             # AI tools are Pro-only by default
}
PRO = {"max_mb": _env("PRO_MAX_MB", 1024), "max_pages": 10000, "max_files": 200, "ai_per_day": _env("PRO_AI_PER_DAY", 100)}

# one-time passes; amounts in the smallest unit are computed from these
PLANS = {
    "week":  {"name": "Pro Week Pass", "days": 7,   "inr": _env("PRICE_WEEK_INR", 149),  "usd": _env("PRICE_WEEK_USD", 3.0)},
    "month": {"name": "Pro Monthly",   "days": 31,  "inr": _env("PRICE_MONTH_INR", 399), "usd": _env("PRICE_MONTH_USD", 6.0)},
    "year":  {"name": "Pro Yearly",    "days": 366, "inr": _env("PRICE_YEAR_INR", 2999), "usd": _env("PRICE_YEAR_USD", 48.0)},
}
# PRO_PLANS=month,year → only these passes are offered (default: all three)
_offer = [x.strip() for x in os.environ.get("PRO_PLANS", "week,month,year").split(",") if x.strip()]
PLANS = {k: v for k, v in PLANS.items() if k in _offer} or PLANS
# optional Stripe recurring prices (create them in the Stripe dashboard, then set the ids) → auto-renew
STRIPE_PRICE_IDS = {"month": os.environ.get("STRIPE_PRICE_MONTH", ""), "year": os.environ.get("STRIPE_PRICE_YEAR", "")}

PRO_FEATURES = [      # what Pro adds to the free plan (the pricing page shows these with the numbers above)
    "Unlimited tasks – no daily limit",
    "Bigger files and longer documents",
    "More files in one go",
    "AI tools: summarise, chat with PDF, translate, questions, data extraction, rewrite",
]

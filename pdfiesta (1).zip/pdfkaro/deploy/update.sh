#!/bin/bash
# Rebuild and restart after new code was unpacked (settings in .env and all data are kept):   bash deploy/update.sh
set -euo pipefail
cd "$(dirname "$0")/.."
docker compose -f deploy/docker-compose.prod.yml up -d --build
docker image prune -f >/dev/null
sleep 15; docker compose -f deploy/docker-compose.prod.yml ps
echo "UPDATED"

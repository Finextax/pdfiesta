#!/bin/bash
# Change one setting and restart the site:   bash deploy/setenv.sh KEY value
# Without a value it asks for it hidden (for secret keys):   bash deploy/setenv.sh RAZORPAY_KEY_SECRET
set -euo pipefail
cd "$(dirname "$0")/.."
KEY="${1:?usage: bash deploy/setenv.sh KEY [value]}"
[[ "$KEY" =~ ^[A-Z0-9_]+$ ]] || { echo "bad key"; exit 1; }
if [ $# -ge 2 ]; then VAL="$2"; else read -rsp "$KEY = " VAL; echo; fi
touch .env; chmod 600 .env
grep -v "^$KEY=" .env > .env.tmp || true
printf '%s=%s\n' "$KEY" "$VAL" >> .env.tmp && mv .env.tmp .env && chmod 600 .env
docker compose -f deploy/docker-compose.prod.yml up -d pdfkaro >/dev/null
echo "$KEY saved, site restarted"

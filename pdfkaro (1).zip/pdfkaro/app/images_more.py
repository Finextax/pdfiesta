"""More image tools: object eraser (inpainting), collage, splitter, round crop, border, GIF maker, favicon set,
vectorise to SVG, EXIF viewer/remover, colour palette, profile picture, ID card → A4 PDF, exam / government form photo,
change DPI."""
import time
import io, json, os, zipfile
from pathlib import Path
import numpy as np
from PIL import Image, ImageOps, ImageDraw, ImageFilter, ImageColor
from .tools import tool, _b, _f, _multi_out, _stem
from .images import load, save, _outfmt, _each, MODELS, remove_background, detect_faces, find_document

_lama = None
_lama_used = [0.0]


def release_idle(max_idle=900):
    global _lama
    if _lama is not None and time.time() - _lama_used[0] > max_idle:
        _lama = None


def inpaint(rgb, mask):
    """Fill the masked area with plausible background. Uses the LaMa neural network when the model file is present
    (models/inpainting_lama_2025jan.onnx, Apache-2.0), otherwise OpenCV's Telea algorithm."""
    import cv2
    global _lama
    h, w = rgb.shape[:2]
    mask = (mask > 127).astype(np.uint8) * 255
    mask = cv2.dilate(mask, np.ones((9, 9), np.uint8))
    model = MODELS / "inpainting_lama_2025jan.onnx"
    if model.exists():
        try:
            import onnxruntime as ort
            from .images import ort_options
            sess = _lama
            if sess is None:
                sess = _lama = ort.InferenceSession(str(model), sess_options=ort_options(), providers=["CPUExecutionProvider"])
            _lama_used[0] = time.time()
            ys, xs = np.where(mask > 0)
            if not len(xs):
                return rgb
            # work on a square crop around the hole (keeps detail on large photos)
            side = int(min(max(h, w), max(512, 2.2 * max(xs.max() - xs.min(), ys.max() - ys.min()))))
            cx, cy = (xs.min() + xs.max()) // 2, (ys.min() + ys.max()) // 2
            x0 = int(max(0, min(w - side, cx - side // 2))); y0 = int(max(0, min(h - side, cy - side // 2)))
            x1, y1 = min(w, x0 + side), min(h, y0 + side)
            crop, cm = rgb[y0:y1, x0:x1], mask[y0:y1, x0:x1]
            ci = cv2.resize(crop, (512, 512), interpolation=cv2.INTER_AREA).astype(np.float32) / 255.0
            mi = (cv2.resize(cm, (512, 512), interpolation=cv2.INTER_NEAREST) > 0).astype(np.float32)
            res = sess.run(None, {"image": ci.transpose(2, 0, 1)[None], "mask": mi[None, None]})[0][0].transpose(1, 2, 0)
            if res.max() <= 1.5:
                res = res * 255.0
            res = cv2.resize(np.clip(res, 0, 255).astype(np.uint8), (x1 - x0, y1 - y0), interpolation=cv2.INTER_CUBIC)
            soft = cv2.GaussianBlur(cm, (0, 0), 3).astype(np.float32)[..., None] / 255.0
            out = rgb.copy()
            out[y0:y1, x0:x1] = (res * soft + crop * (1 - soft)).astype(np.uint8)
            return out
        except Exception:
            pass
    return cv2.inpaint(np.ascontiguousarray(rgb), mask, 5, cv2.INPAINT_TELEA)


@tool("img_erase", accept="image")
def img_erase(inputs, o, out):
    """Remove objects / people / text / watermarks you painted over (mask = PNG where painted pixels are opaque or white)."""
    import base64
    im = load(inputs[0]).convert("RGB")
    if o.get("mask"):
        m = Image.open(io.BytesIO(base64.b64decode(o["mask"].split(",", 1)[-1])))
    elif o.get("mask_path"):
        m = Image.open(o["mask_path"])
    else:
        raise ValueError("Paint over the object you want to remove first.")
    m = m.convert("RGBA").resize(im.size, Image.NEAREST)
    a = np.array(m)
    mask = ((a[:, :, 3] > 40) & (a[:, :, :3].sum(axis=2) > 60)).astype(np.uint8) * 255 if a[:, :, 3].min() < 250 else (a[:, :, :3].mean(axis=2) > 127).astype(np.uint8) * 255
    if not mask.any():
        raise ValueError("Paint over the object you want to remove first.")
    res = Image.fromarray(inpaint(np.array(im), mask))
    return save(res, out, _stem(inputs[0]) + "_erased", _outfmt(o, inputs[0]), 93)


@tool("img_combine", multi=True, accept="image")
def img_combine(inputs, o, out):
    """Join pictures: side by side, stacked, or a grid collage."""
    ims = [load(p).convert("RGB") for p in inputs]
    if len(ims) < 2:
        raise ValueError("Upload at least 2 images.")
    gap = int(_f(o, "gap", 10)); bg = o.get("background") or "#ffffff"
    layout = o.get("layout", "horizontal")
    if layout == "horizontal":
        H = min(i.height for i in ims); ims = [i.resize((max(1, round(i.width * H / i.height)), H), Image.LANCZOS) for i in ims]
        sheet = Image.new("RGB", (sum(i.width for i in ims) + gap * (len(ims) + 1), H + 2 * gap), bg); x = gap
        for i in ims:
            sheet.paste(i, (x, gap)); x += i.width + gap
    elif layout == "vertical":
        W = min(i.width for i in ims); ims = [i.resize((W, max(1, round(i.height * W / i.width))), Image.LANCZOS) for i in ims]
        sheet = Image.new("RGB", (W + 2 * gap, sum(i.height for i in ims) + gap * (len(ims) + 1)), bg); y = gap
        for i in ims:
            sheet.paste(i, (gap, y)); y += i.height + gap
    else:  # grid
        cols = int(_f(o, "cols", 0)) or int(np.ceil(np.sqrt(len(ims)))); rows = int(np.ceil(len(ims) / cols))
        cell = int(min(1200, max(200, _f(o, "cell", 600))))
        sheet = Image.new("RGB", (cols * cell + (cols + 1) * gap, rows * cell + (rows + 1) * gap), bg)
        for k, i in enumerate(ims):
            t = ImageOps.fit(i, (cell, cell), Image.LANCZOS, centering=(0.5, 0.4))
            sheet.paste(t, (gap + (k % cols) * (cell + gap), gap + (k // cols) * (cell + gap)))
    return save(sheet, out, "combined", o.get("format") or "jpg", 92)


@tool("img_split", accept="image")
def img_split(inputs, o, out):
    """Cut a picture into a grid (e.g. 3×3 Instagram tiles, or 2 halves)."""
    im = load(inputs[0]); cols, rows = max(1, min(10, int(_f(o, "cols", 3)))), max(1, min(10, int(_f(o, "rows", 3))))
    fmt = _outfmt(o, inputs[0]); paths = []
    for r in range(rows):
        for c in range(cols):
            box = (c * im.width // cols, r * im.height // rows, (c + 1) * im.width // cols, (r + 1) * im.height // rows)
            paths.append(save(im.crop(box), out, f"{_stem(inputs[0])}_{r + 1}_{c + 1}", fmt, 93))
    return _multi_out(paths, out, f"{_stem(inputs[0])}_tiles")


@tool("img_circle", multi=True, accept="image")
def img_circle(inputs, o, out):
    """Round picture (transparent corners) or rounded corners."""
    def one(p):
        im = load(p).convert("RGBA")
        shape = o.get("shape", "circle")
        if shape == "circle":
            s = min(im.size); im = ImageOps.fit(im, (s, s), Image.LANCZOS, centering=(0.5, 0.4))
        k = 4
        m = Image.new("L", (im.width * k, im.height * k), 0); d = ImageDraw.Draw(m)
        if shape == "circle":
            d.ellipse((0, 0, m.width - 1, m.height - 1), fill=255)
        else:
            d.rounded_rectangle((0, 0, m.width - 1, m.height - 1), radius=int(min(m.size) * min(50, max(1, _f(o, "radius", 12))) / 100), fill=255)
        m = m.resize(im.size, Image.LANCZOS)
        im.putalpha(Image.composite(im.getchannel("A"), Image.new("L", im.size, 0), m))
        if o.get("background") and o["background"] != "transparent":
            bg = Image.new("RGBA", im.size, ImageColor.getrgb(o["background"]) + (255,)); bg.alpha_composite(im); im = bg
        return save(im, out, _stem(p) + "_round", "png")
    return _each(inputs, out, "round_images", one)


@tool("img_border", multi=True, accept="image")
def img_border(inputs, o, out):
    def one(p):
        im = load(p).convert("RGB")
        w = int(_f(o, "width", 0)) or max(4, round(min(im.size) * _f(o, "percent", 4) / 100))
        res = ImageOps.expand(im, border=w, fill=o.get("color") or "#ffffff")
        if _b(o, "square"):   # square canvas (Instagram "no crop")
            s = max(res.size); sq = Image.new("RGB", (s, s), o.get("color") or "#ffffff"); sq.paste(res, ((s - res.width) // 2, (s - res.height) // 2)); res = sq
        return save(res, out, _stem(p) + "_border", _outfmt(o, p), 92)
    return _each(inputs, out, "bordered_images", one)


@tool("gif_maker", multi=True, accept="image")
def gif_maker(inputs, o, out):
    ims = [load(p).convert("RGB") for p in inputs]
    if len(ims) < 2:
        raise ValueError("Upload at least 2 images.")
    W = int(min(1200, max(64, _f(o, "width", 480)))); H = round(W * ims[0].height / ims[0].width)
    frames = [ImageOps.pad(i, (W, H), Image.LANCZOS, color=o.get("background") or "#ffffff") for i in ims]
    dst = Path(out) / "animation.gif"
    frames[0].save(dst, save_all=True, append_images=frames[1:], duration=int(min(10000, max(20, _f(o, "delay", 500)))), loop=0 if _b(o, "loop", True) else 1, optimize=True)
    return dst


@tool("favicon", accept="image")
def favicon(inputs, o, out):
    """Complete favicon set for a website: favicon.ico, PNG sizes, Apple touch icon, web manifest and the HTML to paste."""
    im = load(inputs[0]).convert("RGBA")
    s = max(im.size); sq = Image.new("RGBA", (s, s), (0, 0, 0, 0)); sq.paste(im, ((s - im.width) // 2, (s - im.height) // 2))
    d = Path(out) / "favicon"; d.mkdir()
    sq.resize((256, 256), Image.LANCZOS).save(d / "favicon.ico", sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    for n, name in ((16, "favicon-16x16.png"), (32, "favicon-32x32.png"), (180, "apple-touch-icon.png"), (192, "android-chrome-192x192.png"), (512, "android-chrome-512x512.png")):
        sq.resize((n, n), Image.LANCZOS).save(d / name)
    (d / "site.webmanifest").write_text(json.dumps({"name": o.get("name") or "My site", "icons": [
        {"src": "/android-chrome-192x192.png", "sizes": "192x192", "type": "image/png"}, {"src": "/android-chrome-512x512.png", "sizes": "512x512", "type": "image/png"}],
        "theme_color": o.get("color") or "#ffffff", "background_color": "#ffffff", "display": "standalone"}, indent=1))
    (d / "how-to-use.html.txt").write_text('<link rel="icon" href="/favicon.ico" sizes="any">\n<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">\n'
                                           '<link rel="apple-touch-icon" href="/apple-touch-icon.png">\n<link rel="manifest" href="/site.webmanifest">\n')
    dst = Path(out) / "favicon.zip"
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(d.iterdir()):
            z.write(f, f.name)
    return dst


@tool("img_to_svg", multi=True, accept="image")
def img_to_svg(inputs, o, out):
    """Vectorise a logo / drawing (PNG, JPG) into a scalable SVG (vtracer, MIT)."""
    import vtracer
    def one(p):
        im = load(p)
        if max(im.size) > 2000:
            im.thumbnail((2000, 2000))
        tmp = Path(out) / f"_{_stem(p)}.png"; im.convert("RGBA").save(tmp)
        dst = Path(out) / f"{_stem(p)}.svg"
        vtracer.convert_image_to_svg_py(str(tmp), str(dst), colormode="binary" if o.get("colors") == "bw" else "color", mode="spline",
                                        filter_speckle=int(_f(o, "speckle", 4)), color_precision=int(min(8, max(2, _f(o, "precision", 6)))))
        tmp.unlink(missing_ok=True)
        return dst
    return _each(inputs, out, "vector_images", one)


@tool("img_metadata", multi=True, accept="image")
def img_metadata(inputs, o, out):
    """View what a photo reveals (camera, date, GPS location …) or strip it for privacy."""
    from PIL.ExifTags import TAGS, GPSTAGS
    if o.get("mode", "remove") == "view":
        L = []
        for p in inputs:
            im = Image.open(p); ex = im.getexif()
            L += [f"# {Path(p).name}", "", f"- Size: {im.width} × {im.height} px", f"- Format: {im.format}", f"- Colour mode: {im.mode}",
                  f"- DPI: {im.info.get('dpi', '–')}"]
            for k, v in ex.items():
                if isinstance(v, bytes) or k in (0x8769, 0x8825):
                    continue
                L.append(f"- {TAGS.get(k, k)}: {str(v)[:120]}")
            for k, v in ex.get_ifd(0x8769).items():
                if not isinstance(v, bytes):
                    L.append(f"- {TAGS.get(k, k)}: {str(v)[:120]}")
            gps = ex.get_ifd(0x8825)
            if gps:
                L.append("- **GPS location is stored in this photo:** " + ", ".join(f"{GPSTAGS.get(k, k)}={v}" for k, v in gps.items() if not isinstance(v, bytes))[:300])
            L.append("")
        dst = Path(out) / "image_info.md"; dst.write_text("\n".join(L), encoding="utf-8")
        return dst

    def one(p):
        im = ImageOps.exif_transpose(Image.open(p))   # keep the picture upright, then drop every metadata block
        clean = im.copy(); clean.info = {k: v for k, v in im.info.items() if k in ("transparency",)}
        return save(clean, out, _stem(p) + "_clean", _outfmt(o, p), 95)
    return _each(inputs, out, "clean_images", one)


@tool("color_palette", accept="image")
def color_palette(inputs, o, out):
    im = load(inputs[0]).convert("RGB"); im.thumbnail((400, 400))
    n = int(min(12, max(3, _f(o, "count", 6))))
    q = im.quantize(colors=n, method=Image.Quantize.MEDIANCUT)
    pal = q.getpalette()[: n * 3]; counts = sorted(q.getcolors(), reverse=True)
    cols = [tuple(pal[i * 3:i * 3 + 3]) for _, i in counts]
    W = 140; sheet = Image.new("RGB", (W * len(cols), 190), "white"); d = ImageDraw.Draw(sheet)
    from .images import _font
    f = _font(18, "sans", True)
    for k, c in enumerate(cols):
        d.rectangle((k * W, 0, (k + 1) * W, 150), fill=c)
        d.text((k * W + 22, 158), "#%02X%02X%02X" % c, font=f, fill="#111111")
    return save(sheet, out, _stem(inputs[0]) + "_palette", "png")


@tool("profile_photo", accept="image")
def profile_photo(inputs, o, out):
    """Profile picture for WhatsApp / LinkedIn / résumé: background removed, colour or gradient behind, round or square."""
    import cv2
    im = load(inputs[0]).convert("RGB")
    cut = remove_background(im)
    faces = detect_faces(cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR))
    bb = cut.getchannel("A").getbbox() or (0, 0, im.width, im.height)
    if faces:
        x, y, w, h = max(faces, key=lambda f: f[2] * f[3]); cx, cy, side = x + w / 2, y + h * 0.55, max(w, h) * 2.6
    else:
        cx, cy, side = (bb[0] + bb[2]) / 2, (bb[1] + bb[3]) / 2, max(bb[2] - bb[0], bb[3] - bb[1]) * 1.15
    S = int(min(1600, max(256, _f(o, "size", 800))))
    c1 = ImageColor.getrgb(o.get("color") or "#2563eb"); c2 = ImageColor.getrgb(o.get("color2") or o.get("color") or "#2563eb")
    grad = np.linspace(0, 1, S)[:, None, None]
    bg = Image.fromarray((np.array(c1) * (1 - grad) + np.array(c2) * grad).astype(np.uint8).repeat(S, axis=1)).convert("RGBA")
    k = S / side
    subj = cut.resize((max(1, round(cut.width * k)), max(1, round(cut.height * k))), Image.LANCZOS)
    ox, oy = round(S / 2 - cx * k), round(S / 2 - cy * k)
    sx, sy = max(0, -ox), max(0, -oy)
    part = subj.crop((sx, sy, min(subj.width, sx + S - max(0, ox)), min(subj.height, sy + S - max(0, oy))))
    if part.width > 0 and part.height > 0:
        bg.alpha_composite(part, (max(0, ox), max(0, oy)))
    if o.get("shape", "circle") == "circle":
        m = Image.new("L", (S * 4, S * 4), 0); ImageDraw.Draw(m).ellipse((0, 0, S * 4 - 1, S * 4 - 1), fill=255); bg.putalpha(m.resize((S, S), Image.LANCZOS))
        return save(bg, out, _stem(inputs[0]) + "_profile", "png")
    return save(bg, out, _stem(inputs[0]) + "_profile", o.get("format") or "jpg", 93)


def _card(im):
    """find the card in a photo and straighten it (falls back to the whole picture)."""
    import cv2
    arr = cv2.cvtColor(np.array(im.convert("RGB")), cv2.COLOR_RGB2BGR)
    q = find_document(arr)
    if q is None:
        return im.convert("RGB")
    tl, tr, br, bl = q
    W = int(max(np.linalg.norm(br - bl), np.linalg.norm(tr - tl))); H = int(max(np.linalg.norm(tr - br), np.linalg.norm(tl - bl)))
    M = cv2.getPerspectiveTransform(q, np.array([[0, 0], [W - 1, 0], [W - 1, H - 1], [0, H - 1]], dtype="float32"))
    return Image.fromarray(cv2.cvtColor(cv2.warpPerspective(arr, M, (W, H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE), cv2.COLOR_BGR2RGB))


@tool("id_card_pdf", multi=True, accept="image")
def id_card_pdf(inputs, o, out):
    """Front + back of an ID card (Aadhaar, PAN, driving licence, …) on ONE A4 page, ready to print or submit."""
    import pymupdf
    cards = [_card(load(p)) if _b(o, "auto_crop", True) else load(p).convert("RGB") for p in inputs[:4]]
    d = pymupdf.open(); pg = d.new_page(width=595, height=842)
    scale = {"actual": 1.0, "large": 1.6, "xl": 2.1}.get(o.get("size", "large"), 1.6)
    cw = 85.6 / 25.4 * 72 * scale   # ISO ID-1 card width
    y = 70 if len(cards) > 1 else 200
    for im in cards:
        if im.height > im.width:
            im = im.rotate(90, expand=True)
        ch = cw * im.height / im.width
        buf = io.BytesIO(); im.save(buf, "JPEG", quality=92)
        r = pymupdf.Rect((595 - cw) / 2, y, (595 + cw) / 2, y + ch)
        pg.insert_image(r, stream=buf.getvalue())
        if _b(o, "border", True):
            pg.draw_rect(r, color=(0.6, 0.6, 0.6), width=0.5)
        y += ch + 40
    if (o.get("note") or "").strip():
        from .tools import draw_text
        draw_text(pg, str(o["note"]).strip()[:140], 297.5, 808, 9, (0.3, 0.3, 0.3), "sans", False, "center")
    dst = Path(out) / "id_card.pdf"; d.save(dst, deflate=True)
    return dst


EXAM = {  # (width px, height px, min KB, max KB)
    "ssc_photo": (413, 531, 20, 50), "ssc_sign": (472, 236, 10, 20), "upsc_photo": (550, 550, 20, 300), "upsc_sign": (550, 550, 20, 300),
    "ibps_photo": (200, 230, 20, 50), "ibps_sign": (140, 60, 10, 20), "rrb_photo": (413, 531, 30, 70), "rrb_sign": (472, 236, 30, 70),
    "neet_photo": (413, 531, 10, 200), "neet_sign": (472, 236, 4, 30), "jee_photo": (413, 531, 10, 200), "jee_sign": (472, 236, 4, 30),
    "pan_photo": (213, 213, 5, 30), "pan_sign": (400, 200, 5, 60), "passport_in": (413, 531, 10, 250),
}


def _fit_kb(im, lo, hi, fmt="jpg"):
    """JPEG whose size lands between lo and hi kilobytes (binary search on quality; pads if still too small)."""
    best = None
    a, b = 8, 97
    while a <= b:
        q = (a + b) // 2
        buf = io.BytesIO(); im.save(buf, "JPEG", quality=q, optimize=True)
        kb = buf.tell() / 1024
        if kb <= hi:
            best = buf.getvalue(); a = q + 1
        else:
            b = q - 1
    if best is None:
        buf = io.BytesIO(); im.save(buf, "JPEG", quality=8); best = buf.getvalue()
    if len(best) / 1024 < lo:   # some portals reject files that are too SMALL: pad with a harmless comment segment
        need = int(lo * 1024) - len(best) + 64
        pos = 2
        while pos + 4 <= len(best) and best[pos] == 0xFF and 0xE0 <= best[pos + 1] <= 0xEF:   # keep JFIF / EXIF headers first
            pos += 2 + int.from_bytes(best[pos + 2:pos + 4], "big")
        pad = b"".join(b"\xff\xfe" + (min(65533, need - i) + 2).to_bytes(2, "big") + b" " * min(65533, need - i) for i in range(0, need, 65533))
        best = best[:pos] + pad + best[pos:]
    return best


@tool("exam_photo", accept="image")
def exam_photo(inputs, o, out):
    """Photo / signature in the exact pixel size AND file size that Indian exam & government portals demand."""
    preset = o.get("preset", "ssc_photo")
    if preset == "custom":
        W, H = int(_f(o, "width", 413)), int(_f(o, "height", 531)); lo, hi = _f(o, "min_kb", 0), _f(o, "max_kb", 50)
        if not (20 <= W <= 5000 and 20 <= H <= 5000 and hi > 0):
            raise ValueError("Please enter width, height and the maximum size in KB.")
    else:
        W, H, lo, hi = EXAM.get(preset, EXAM["ssc_photo"])
    im = load(inputs[0]).convert("RGB")
    sign = preset.endswith("_sign") or _b(o, "is_signature")
    if sign:
        im = ImageOps.pad(ImageOps.autocontrast(im, cutoff=1), (W, H), Image.LANCZOS, color="#ffffff")
    else:
        if _b(o, "white_bg"):
            cut = remove_background(im); bg = Image.new("RGBA", cut.size, (255, 255, 255, 255)); bg.alpha_composite(cut); im = bg.convert("RGB")
        im = ImageOps.fit(im, (W, H), Image.LANCZOS, centering=(0.5, 0.3))
    data = _fit_kb(im, lo, hi)
    dst = Path(out) / f"{_stem(inputs[0])}_{W}x{H}_{len(data) // 1024 or 1}kb.jpg"; dst.write_bytes(data)
    return dst


@tool("img_dpi", multi=True, accept="image")
def img_dpi(inputs, o, out):
    """Set the DPI stored in the file (e.g. 300 dpi for print / forms) – with or without resampling the pixels."""
    dpi = int(min(2400, max(30, _f(o, "dpi", 300))))
    def one(p):
        im = load(p)
        if _b(o, "resample"):
            old = float((im.info.get("dpi") or (72, 72))[0] or 72); k = dpi / (old if 30 <= old <= 2400 else 72)
            im = im.resize((max(1, round(im.width * k)), max(1, round(im.height * k))), Image.LANCZOS)
        fmt = _outfmt(o, p)
        if fmt not in ("jpg", "png", "tiff"):
            fmt = "jpg"
        if fmt == "jpg" and im.mode != "RGB":
            im = im.convert("RGB")
        dst = Path(out) / f"{_stem(p)}_{dpi}dpi.{fmt}"
        im.save(dst, {"jpg": "JPEG", "png": "PNG", "tiff": "TIFF"}[fmt], dpi=(dpi, dpi), **({"quality": 95} if fmt == "jpg" else {}))
        return dst
    return _each(inputs, out, "dpi_images", one)

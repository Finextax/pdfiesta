"""Shared helpers: page-range parsing, paths, fonts."""
import unicodedata
import os, re, uuid, zipfile, shutil, time
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
DATA = Path(os.environ.get("PDFKARO_DATA", BASE / "data"))
FONTS = BASE / "fonts"
DATA.mkdir(parents=True, exist_ok=True)

# font family name used by the UI -> (regular, bold, italic, bolditalic) files
FONT_FILES = {
    "sans": ("LiberationSans-Regular.ttf", "LiberationSans-Bold.ttf", "LiberationSans-Italic.ttf", "LiberationSans-BoldItalic.ttf"),
    "serif": ("LiberationSerif-Regular.ttf", "LiberationSerif-Bold.ttf", "LiberationSerif-Italic.ttf", "LiberationSerif-BoldItalic.ttf"),
    "mono": ("LiberationMono-Regular.ttf", "LiberationMono-Bold.ttf", "LiberationMono-Regular.ttf", "LiberationMono-Bold.ttf"),
    "noto": ("NotoSans-Regular.ttf", "NotoSans-Bold.ttf", "NotoSans-Regular.ttf", "NotoSans-Bold.ttf"),
    "hindi": ("NotoSansDevanagari-Regular.ttf", "NotoSansDevanagari-Bold.ttf", "NotoSansDevanagari-Regular.ttf", "NotoSansDevanagari-Bold.ttf"),
    "dancing": ("DancingScript.ttf",) * 4,
    "greatvibes": ("GreatVibes.ttf",) * 4,
    "caveat": ("Caveat.ttf",) * 4,
    "sacramento": ("Sacramento.ttf",) * 4,
}

DEVANAGARI = re.compile(r"[ऀ-ॿ]")


def font_file(family="sans", bold=False, italic=False, text=""):
    if text and DEVANAGARI.search(text) and family in ("sans", "serif", "mono", "noto"):
        family = "hindi"
    files = FONT_FILES.get(family, FONT_FILES["sans"])
    return str(FONTS / files[(1 if bold else 0) + (2 if italic else 0)])


def guess_family(fontname: str) -> str:
    f = (fontname or "").lower()
    if any(k in f for k in ("courier", "mono", "consol")):
        return "mono"
    if any(k in f for k in ("times", "serif", "roman", "georgia", "garamond", "cambria", "book", "charis", "minion",
                            "palatino", "baskerville", "caslon", "century", "nimbusrom", "tiro", "libertine")) and "sans" not in f:
        return "serif"
    return "sans"


def new_job():
    jid = uuid.uuid4().hex[:16]
    d = DATA / jid
    d.mkdir(parents=True)
    return jid, d


def parse_ranges(spec: str, n: int):
    """'1-3,5,8-' -> [0,1,2,4,7..n-1]; also 'odd' / 'even' / 'all'. 1-based input, 0-based output."""
    spec = (spec or "").strip().lower().replace(" ", "")
    if spec in ("", "all"):
        return list(range(n))
    if spec == "odd":
        return list(range(0, n, 2))
    if spec == "even":
        return list(range(1, n, 2))
    out = []
    for part in spec.split(","):
        if not part:
            continue
        if part == "last":
            out.append(n - 1); continue
        m = re.fullmatch(r"(\d*)-(\d*|last)", part)
        if m:
            a = int(m.group(1)) if m.group(1) else 1
            b = n if m.group(2) in ("", "last") else int(m.group(2))
            step = 1 if b >= a else -1
            out.extend(i - 1 for i in range(a, b + step, step) if 1 <= i <= n)
        elif part.isdigit():
            i = int(part)
            if 1 <= i <= n:
                out.append(i - 1)
        else:
            raise ValueError(f"Invalid page range: {part}")
    return out


def zip_files(paths, dest):
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for p in paths:
            z.write(p, Path(p).name)
    return dest


def safe_name(s, default="file"):
    """A harmless file name: letters, marks and digits of every script stay (हिन्दी, বাংলা, தமிழ், 中文 …), everything that could be a path,
    a control character or a shell / URL special becomes "_". Long names are shortened without losing the extension."""
    out = "".join(ch if (unicodedata.category(ch)[0] in "LMN" or ch in "-. _()[],+@=") else "_" for ch in unicodedata.normalize("NFC", s or ""))
    out = re.sub(r"_{2,}", "_", out).strip(" ._")
    if len(out) > 120:
        stem, dot, ext = out.rpartition(".")
        out = (stem[:120 - len(ext) - 1].rstrip(" ._") + "." + ext) if dot and 0 < len(ext) <= 8 and stem else out[:120]
    return out or default


JOB_RE = re.compile(r"^[0-9a-f]{16}$")


def cleanup_old(max_age_sec=2 * 3600):
    """Delete result folders older than 2 hours. Only job folders are touched (never uploads/, sign/, the database …)."""
    now = time.time()
    for d in DATA.iterdir():
        try:
            if d.is_dir() and JOB_RE.match(d.name) and now - d.stat().st_mtime > max_age_sec:
                shutil.rmtree(d, ignore_errors=True)
        except FileNotFoundError:
            pass


# ------------------------------------------------------------------ SSRF protection
_HOST_OK = {}


def _proxy_only():
    # behind an egress proxy the proxy resolves names (they may not resolve locally)
    return bool(os.environ.get("HTML2PDF_PROXY") or os.environ.get("HTTPS_PROXY")) and os.environ.get("STRICT_DNS") != "1"


def host_allowed(host):
    """True only for public internet hosts. Blocks localhost, private ranges (10.x, 192.168.x, 172.16-31.x),
    link-local / cloud metadata (169.254.169.254), IPv6 local addresses and single-label intranet names."""
    import ipaddress, socket
    host = (host or "").strip("[]").lower().rstrip(".")
    if os.environ.get("ALLOW_PRIVATE_URLS") == "1":
        return bool(host)
    if not host:
        return False
    try:
        return ipaddress.ip_address(host.split("%")[0]).is_global  # literal address
    except ValueError:
        pass
    if "." not in host or host == "localhost" or host.endswith((".local", ".internal", ".localhost", ".lan", ".home", ".corp")):
        return False
    if _proxy_only():
        return True
    hit = _HOST_OK.get(host)
    if hit and time.time() - hit[1] < 300:
        return hit[0]
    try:
        infos = socket.getaddrinfo(host, None)
        ok = bool(infos) and all(ipaddress.ip_address(i[4][0].split("%")[0]).is_global for i in infos)
    except Exception:
        ok = False
    _HOST_OK[host] = (ok, time.time())
    return ok


def check_url(url):
    """normalise + validate a user supplied URL; raises ValueError for anything that is not a public http(s) address."""
    from urllib.parse import urlparse
    url = (url or "").strip()
    if "://" in url and not re.match(r"^https?://", url, re.I):
        raise ValueError("Only http:// and https:// addresses are allowed.")
    if not re.match(r"^https?://", url, re.I):
        url = "https://" + url
    p = urlparse(url)
    try:
        port = p.port
    except ValueError:
        raise ValueError("Please enter a valid web address.")
    if not p.hostname or port not in (None, 80, 443, 8080, 8443):
        raise ValueError("Please enter a valid web address (http:// or https://).")
    if not host_allowed(p.hostname):
        raise ValueError("This address is not reachable from the public internet.")
    return url


def guard_browser(page):
    """Playwright page: abort every request (page, iframe, image, redirect …) that targets a non-public address."""
    from urllib.parse import urlparse

    def handler(route):
        try:
            p = urlparse(route.request.url)
            if p.scheme in ("data", "blob", "about"):
                return route.continue_()
            if p.scheme in ("http", "https") and host_allowed(p.hostname):
                return route.continue_()
            return route.abort()
        except Exception:
            try:
                route.abort()
            except Exception:
                pass
    page.route("**/*", handler)


def fetch_url(url, dst, max_mb=200, timeout=60):
    """download a public file with a size cap; redirects are re-validated."""
    import urllib.request

    class NoPrivateRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            check_url(newurl)
            return super().redirect_request(req, fp, code, msg, headers, newurl)

    url = check_url(url)
    opener = urllib.request.build_opener(NoPrivateRedirect)
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (PDFiesta fetch)"})
    n = 0
    with opener.open(req, timeout=timeout) as r, open(dst, "wb") as fh:
        while chunk := r.read(1 << 20):
            n += len(chunk)
            if n > max_mb * 1024 * 1024:
                raise ValueError(f"File is larger than {max_mb} MB.")
            fh.write(chunk)
    return n

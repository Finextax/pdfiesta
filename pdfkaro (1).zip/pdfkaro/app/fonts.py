"""Font registry.

Scans the bundled fonts/ folder and the system fonts (via fontconfig) and answers two questions:
  * which open font is the closest match for a font name found inside a PDF (Arial → Liberation Sans,
    Calibri → Carlito, Cambria → Caladea, Mangal → Noto Sans Devanagari …)
  * which font file renders a given family / bold / italic combination.
"""
import functools, re, subprocess, unicodedata
from pathlib import Path
from .util import FONTS

REG = {}      # key -> {"name": str, "faces": {(bold, italic): path}, "mono": bool}
_SCANNED = False


def key(name):
    return re.sub(r"[^a-z0-9]", "", (name or "").lower())


def _add(path, family, weight, slant, spacing, index=0, width=100):
    if index or not family:
        return
    p = str(path)
    if not p.lower().endswith((".ttf", ".otf")):
        return
    k = key(family)
    fam = REG.setdefault(k, {"name": family, "faces": {}, "w": {}, "mono": spacing >= 100})
    bold, italic = weight >= 150, slant > 0
    score = abs(weight - (200 if bold else 80)) + abs(width - 100) * 10  # prefer normal width, Regular/Bold weights
    prev = fam["w"].get((bold, italic))
    if prev is None or score < prev:
        fam["faces"][(bold, italic)] = p
        fam["w"][(bold, italic)] = score


def scan(force=False):
    global _SCANNED
    if _SCANNED and not force:
        return REG
    _SCANNED = True
    fmt = "%{file}|%{family[0]}|%{weight}|%{slant}|%{spacing}|%{index}|%{width}\n"
    outs = []
    for cmd in (["fc-scan", "--format", fmt, str(FONTS)], ["fc-list", "--format", fmt]):
        try:
            outs.append(subprocess.run(cmd, capture_output=True, text=True, timeout=60).stdout)
        except Exception:
            pass
    for out in outs:
        for line in out.splitlines():
            parts = line.split("|")
            if len(parts) < 6:
                continue
            def num(v, d):
                try:
                    return float(v)
                except ValueError:
                    return d  # variable fonts report ranges like "[100 900]" – treat as the default instance
            _add(parts[0], parts[1], num(parts[2], 80), num(parts[3], 0), num(parts[4], 0), int(num(parts[5], 0)),
                 num(parts[6], 100) if len(parts) > 6 else 100)
    if not REG:  # no fontconfig available: fall back to the bundled files by name
        for f in sorted(FONTS.glob("*.ttf")):
            n = f.stem
            fam = re.sub(r"-(Regular|Bold|Italic|BoldItalic)$", "", n)
            fam = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", fam)
            _add(f, fam, 200 if "Bold" in n else 80, 100 if "Italic" in n else 0, 100 if "Mono" in n else 0)
    return REG


def face(family_key, bold=False, italic=False):
    """Best font file for the family (falls back to other weights of the same family, then Liberation Sans)."""
    scan()
    fam = REG.get(family_key) or REG.get("liberationsans") or next(iter(REG.values()))
    for combo in ((bold, italic), (bold, False), (False, italic), (False, False)):
        if combo in fam["faces"]:
            return fam["faces"][combo], combo
    p = next(iter(fam["faces"].items()))
    return p[1], p[0]


def has(family_key):
    scan()
    return family_key in REG


# PDF font name (normalised) contains …  →  our family
ALIASES = [
    (("arial", "helvetica", "arimo", "nimbussans", "swiss", "liberationsans", "microsoftsansserif"), "liberationsans"),
    (("timesnewroman", "times", "tinos", "nimbusrom", "thorndale", "liberationserif"), "liberationserif"),
    (("courier", "cousine", "nimbusmono", "liberationmono", "consolas", "lucidaconsole"), "liberationmono"),
    (("calibri", "carlito", "aptos"), "carlito"),
    (("cambria", "caladea"), "caladea"),
    (("verdana", "tahoma", "dejavusans", "bitstreamvera"), "dejavusans"),
    (("georgia", "dejavuserif", "bookantiqua", "palatino", "charis"), "dejavuserif"),
    (("roboto",), "roboto"), (("opensans",), "opensans"), (("lato",), "lato"),
    (("montserrat", "gotham", "proximanova", "centurygothic", "futura"), "montserrat"),
    (("inter", "sfpro", "sanfrancisco", "segoeui", "selawik"), "inter"),
    (("garamond",), "ebgaramond"), (("ptsans",), "ptsans"), (("ptserif",), "ptserif"),
    (("comicsans", "comicneue"), "comicneue"), (("notoserif",), "notoserif"),
    (("devanagari", "mangal", "kokila", "aparajita", "utsaah", "nirmala", "lohit", "hind", "mukta"), "notosansdevanagari"),
    (("bengali", "vrinda", "shonar"), "notosansbengali"), (("tamil", "latha"), "notosanstamil"),
    (("telugu", "gautami"), "notosanstelugu"), (("gujarati", "shruti"), "notosansgujarati"),
    (("kannada", "tunga"), "notosanskannada"), (("malayalam", "kartika"), "notosansmalayalam"),
    (("gurmukhi", "raavi"), "notosansgurmukhi"),
    (("arabic", "naskh", "amiri", "traditionalarabic", "simplifiedarabic"), "notonaskharabic"),
    (("nastaliq", "jameel"), "notonastaliqurdu"), (("hebrew", "david"), "notosanshebrew"), (("thai",), "notosansthai"),
    (("notosans",), "notosans"),
]


def match(pdf_font, flags=0):
    """PDF font name (+ span flags: 4 = serif, 8 = mono) → registry family key."""
    scan()
    n = key((pdf_font or "").split("+")[-1])
    for t in ("psmt", "mt", "regular", "bolditalic", "boldoblique", "bold", "italic", "oblique", "semibold", "light", "medium"):
        if n.endswith(t) and len(n) > len(t) + 2:
            n = n[: -len(t)]
    if n in REG:
        return n
    for needles, fam in ALIASES:
        if any(x in n for x in needles) and fam in REG:
            return fam
    if flags & 8 and "liberationmono" in REG:
        return "liberationmono"
    if flags & 4 and "liberationserif" in REG:
        return "liberationserif"
    return "liberationsans" if "liberationsans" in REG else next(iter(REG))


# ------------------------------------------------------------------ scripts
SCRIPTS = [  # (first, last, family key, tesseract language)
    (0x0900, 0x097F, "notosansdevanagari", "hin"), (0x0980, 0x09FF, "notosansbengali", "ben"),
    (0x0A00, 0x0A7F, "notosansgurmukhi", "pan"), (0x0A80, 0x0AFF, "notosansgujarati", "guj"),
    (0x0B80, 0x0BFF, "notosanstamil", "tam"), (0x0C00, 0x0C7F, "notosanstelugu", "tel"),
    (0x0C80, 0x0CFF, "notosanskannada", "kan"), (0x0D00, 0x0D7F, "notosansmalayalam", "mal"),
    (0x0590, 0x05FF, "notosanshebrew", "heb"), (0x0600, 0x06FF, "notonaskharabic", "ara"),
    (0x0750, 0x077F, "notonaskharabic", "ara"), (0xFB50, 0xFDFF, "notonaskharabic", "ara"), (0xFE70, 0xFEFF, "notonaskharabic", "ara"),
    (0x0E00, 0x0E7F, "notosansthai", "tha"),
]
INDIC = (0x0900, 0x0D7F)


def script_of(ch):
    o = ord(ch)
    if o < 0x0590:
        return None
    for a, b, fam, _ in SCRIPTS:
        if a <= o <= b:
            return fam
    return None


def split_scripts(text):
    """'Hello नमस्ते' → [(None, 'Hello '), ('notosansdevanagari', 'नमस्ते')]. Spaces/marks stick to the current run."""
    out, cur, buf = [], None, ""
    for ch in text:
        s = script_of(ch)
        if s is None and buf and cur is not None and (ch.isspace() or unicodedata.category(ch).startswith(("M", "P")) or ch in "‌‍"):
            s = cur
        if s != cur and buf:
            out.append((cur, buf)); buf = ""
        cur = s; buf += ch
    if buf:
        out.append((cur, buf))
    return out


def ocr_lang_for(text):
    for ch in text:
        o = ord(ch)
        for a, b, _, lang in SCRIPTS:
            if a <= o <= b:
                return lang
    return None


def indic_suspicious(text):
    """True when Indic text extracted from a PDF is probably garbled (broken ToUnicode maps)."""
    if any(ch == "�" or 0xE000 <= ord(ch) <= 0xF8FF for ch in text):
        return True
    if not any(INDIC[0] <= ord(c) <= INDIC[1] for c in text):
        return False
    prev = " "
    for ch in text:
        o = ord(ch)
        if 0x80 <= o <= 0xFF and ch not in "«»°©®·":  # Latin-1 symbols mixed into Indic words (×, Ê, …)
            return True
        if INDIC[0] <= o <= INDIC[1] and unicodedata.category(ch) in ("Mn", "Mc") and (prev.isspace() or prev in "([{\"'"):
            return True  # a vowel sign / virama cannot start a word
        prev = ch
    return False


# families offered in the editor's font menu (shown only when installed)
MENU = [
    ("liberationsans", "Arial / Helvetica"), ("liberationserif", "Times New Roman"), ("liberationmono", "Courier"),
    ("carlito", "Calibri (Carlito)"), ("caladea", "Cambria (Caladea)"), ("dejavusans", "Verdana (DejaVu Sans)"),
    ("dejavuserif", "Georgia (DejaVu Serif)"), ("roboto", "Roboto"), ("opensans", "Open Sans"), ("lato", "Lato"),
    ("montserrat", "Montserrat"), ("inter", "Inter"), ("notosans", "Noto Sans"), ("notoserif", "Noto Serif"),
    ("ebgaramond", "EB Garamond"), ("ptsans", "PT Sans"), ("ptserif", "PT Serif"), ("comicneue", "Comic Neue"),
    ("notosansdevanagari", "हिन्दी – Noto Sans Devanagari"), ("notosansbengali", "বাংলা – Noto Sans Bengali"),
    ("notosanstamil", "தமிழ் – Noto Sans Tamil"), ("notosanstelugu", "తెలుగు – Noto Sans Telugu"),
    ("notosansgujarati", "ગુજરાતી – Noto Sans Gujarati"), ("notosanskannada", "ಕನ್ನಡ – Noto Sans Kannada"),
    ("notosansmalayalam", "മലയാളം – Noto Sans Malayalam"), ("notosansgurmukhi", "ਪੰਜਾਬੀ – Noto Sans Gurmukhi"),
    ("notonaskharabic", "العربية – Noto Naskh Arabic"), ("notonastaliqurdu", "اردو – Noto Nastaliq Urdu"),
    ("notosanshebrew", "עברית – Noto Sans Hebrew"), ("notosansthai", "ไทย – Noto Sans Thai"),
    ("dancingscript", "Dancing Script"), ("greatvibes", "Great Vibes"), ("caveat", "Caveat"), ("sacramento", "Sacramento"),
]


def menu():
    """families for the editor's font list; faces = which real cuts exist (r, b, i, bi) – the browser fakes the others like the server does"""
    scan()
    out = []
    for k, n in MENU:
        if k in REG:
            fc = REG[k]["faces"]
            out.append({"key": k, "name": n, "faces": [t for t, key in (("r", (False, False)), ("b", (True, False)), ("i", (False, True)), ("bi", (True, True))) if key in fc]})
    return out


@functools.lru_cache(maxsize=256)
def file_bytes(path):
    return Path(path).read_bytes()

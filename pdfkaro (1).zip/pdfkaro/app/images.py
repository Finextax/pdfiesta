"""Image tools (iLoveIMG / remove.bg style): compress, resize, crop, convert, rotate, adjust, remove/replace background,
upscale (AI super-resolution), watermark, blur faces, meme, signature cleaner, passport photo, image→text, HTML→image.

Engines: Pillow (+pillow-heif for iPhone HEIC), rembg/ONNX (IS-Net / BiRefNet background removal),
OpenCV (EDSR/FSRCNN super-resolution, YuNet face detection, document detection), Tesseract.
"""
import time
import io, os, math, subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageOps, ImageEnhance, ImageFilter, ImageDraw, ImageFont, ImageColor
from .tools import tool, _b, _f, _multi_out, _stem
from .util import font_file, BASE

try:
    import pillow_heif
    pillow_heif.register_heif_opener()  # open .heic/.heif photos from iPhones
except Exception:
    pass

MODELS = Path(os.environ.get("MODELS_DIR", BASE / "models"))
os.environ.setdefault("U2NET_HOME", str(MODELS / "rembg"))
FMT = {"jpg": "JPEG", "jpeg": "JPEG", "png": "PNG", "webp": "WEBP", "gif": "GIF", "bmp": "BMP", "tiff": "TIFF", "ico": "ICO", "avif": "AVIF", "pdf": "PDF"}


def load(p):
    im = Image.open(p)
    im = ImageOps.exif_transpose(im)  # respect phone orientation
    return im


def save(im, out, stem, fmt="png", quality=90, keep_meta=False):
    fmt = (fmt or "png").lower().replace("jpeg", "jpg")
    if fmt not in FMT:
        fmt = "png"
    if fmt in ("jpg", "bmp", "pdf") and im.mode in ("RGBA", "LA", "P"):
        bg = Image.new("RGB", im.size, "white")
        im = im.convert("RGBA"); bg.paste(im, mask=im.split()[-1]); im = bg
    elif fmt == "jpg" and im.mode != "RGB":
        im = im.convert("RGB")
    dst = Path(out) / f"{stem}.{fmt}"
    kw = {}
    if fmt in ("jpg", "webp", "avif"):
        kw = {"quality": int(quality), "optimize": True}
        if fmt == "jpg":
            kw["progressive"] = True
    if fmt == "png":
        kw = {"optimize": True}
    if fmt == "ico":
        kw = {"sizes": [(s, s) for s in (16, 32, 48, 64, 128, 256) if s <= max(im.size)]}
    im.save(dst, FMT[fmt], **kw)
    return dst


def _outfmt(o, p):
    f = (o.get("format") or "same").lower()
    if f == "same":
        f = Path(p).suffix.lower().lstrip(".")
        if f in ("heic", "heif", "jfif"):
            f = "jpg"
    return f


def _each(inputs, out, name, fn):
    paths = [fn(Path(p)) for p in inputs]
    return _multi_out(paths, out, name)


# ------------------------------------------------------------------ compress
@tool("img_compress", multi=True, accept="image")
def img_compress(inputs, o, out):
    target_kb = _f(o, "target_kb", 0)
    def one(p):
        im = load(p); fmt = _outfmt(o, p)
        if fmt == "png" and _b(o, "lossy_png", True):  # quantize to 256 colours (like TinyPNG) – huge savings
            q = im.convert("RGBA").quantize(colors=256, method=Image.Quantize.FASTOCTREE, dither=Image.Dither.FLOYDSTEINBERG)
            dst = save(q, out, _stem(p) + "_compressed", "png")
        elif target_kb and fmt in ("jpg", "webp"):
            lo, hi, best = 10, 95, None
            while lo <= hi:  # binary search the quality that fits the target size
                mid = (lo + hi) // 2
                dst = save(im, out, _stem(p) + "_compressed", fmt, mid)
                if dst.stat().st_size <= target_kb * 1024:
                    best, lo = mid, mid + 1
                else:
                    hi = mid - 1
            q = best or 10
            if not best:  # still too big at q10 → also downscale
                while dst.stat().st_size > target_kb * 1024 and im.width > 200:
                    im = im.resize((int(im.width * .85), int(im.height * .85)), Image.LANCZOS)
                    dst = save(im, out, _stem(p) + "_compressed", fmt, 10)
            else:
                dst = save(im, out, _stem(p) + "_compressed", fmt, q)
        else:
            q = {"low": 85, "recommended": 72, "extreme": 50}.get(o.get("level", "recommended"), 72)
            dst = save(im, out, _stem(p) + "_compressed", fmt, q)
        if dst.stat().st_size > p.stat().st_size and fmt == p.suffix.lower().lstrip("."):
            dst.write_bytes(p.read_bytes())
        return dst
    return _each(inputs, out, "compressed_images", one)


# ------------------------------------------------------------------ resize / crop / rotate / convert / adjust
PRESETS = {"instagram_post": (1080, 1080), "instagram_story": (1080, 1920), "facebook_cover": (820, 312), "youtube_thumb": (1280, 720),
           "whatsapp_dp": (500, 500), "linkedin_banner": (1584, 396), "twitter_header": (1500, 500), "hd": (1280, 720), "fullhd": (1920, 1080), "4k": (3840, 2160)}


@tool("img_resize", multi=True, accept="image")
def img_resize(inputs, o, out):
    def one(p):
        im = load(p)
        mode = o.get("mode", "pixels")
        if mode == "percent":
            k = _f(o, "percent", 50) / 100
            im = im.resize((max(1, round(im.width * k)), max(1, round(im.height * k))), Image.LANCZOS)
        elif mode == "preset":
            W, H = PRESETS.get(o.get("preset"), (1080, 1080))
            im = ImageOps.fit(im, (W, H), Image.LANCZOS) if o.get("fit", "cover") == "cover" else ImageOps.pad(im, (W, H), Image.LANCZOS, color=o.get("bg", "#ffffff"))
        elif mode == "cm":  # print size: cm at DPI
            dpi = _f(o, "dpi", 300); W = round(_f(o, "width", 3.5) / 2.54 * dpi); H = round(_f(o, "height", 4.5) / 2.54 * dpi)
            im = ImageOps.fit(im, (W, H), Image.LANCZOS)
        else:
            W, H = int(_f(o, "width", 0)), int(_f(o, "height", 0))
            if _b(o, "keep_ratio", True):
                if W and not H: H = round(im.height * W / im.width)
                elif H and not W: W = round(im.width * H / im.height)
                elif W and H:
                    k = min(W / im.width, H / im.height); W, H = round(im.width * k), round(im.height * k)
            if W and H and not (_b(o, "no_enlarge") and (W > im.width or H > im.height)):
                im = im.resize((W, H), Image.LANCZOS)
        return save(im, out, _stem(p) + "_resized", _outfmt(o, p), 92)
    return _each(inputs, out, "resized_images", one)


RATIOS = {"1:1": 1, "4:3": 4 / 3, "3:4": 3 / 4, "16:9": 16 / 9, "9:16": 9 / 16, "3:2": 1.5, "2:3": 2 / 3, "4:5": 0.8}


@tool("img_crop", multi=True, accept="image")
def img_crop(inputs, o, out):
    def one(p):
        im = load(p)
        if o.get("box"):
            b = o["box"]; im = im.crop((round(b["x0"] * im.width), round(b["y0"] * im.height), round(b["x1"] * im.width), round(b["y1"] * im.height)))
        elif o.get("ratio") in RATIOS:
            r = RATIOS[o["ratio"]]
            W, H = (im.width, round(im.width / r)) if im.width / im.height < r else (round(im.height * r), im.height)
            im = ImageOps.fit(im, (W, H), Image.LANCZOS, centering=(0.5, 0.4))
        elif o.get("mode") == "auto":  # trim uniform borders
            bg = Image.new(im.mode, im.size, im.getpixel((0, 0)))
            from PIL import ImageChops
            bbox = ImageChops.difference(im.convert("RGB"), bg.convert("RGB")).getbbox()
            if bbox: im = im.crop(bbox)
        return save(im, out, _stem(p) + "_cropped", _outfmt(o, p), 92)
    return _each(inputs, out, "cropped_images", one)


@tool("img_rotate", multi=True, accept="image")
def img_rotate(inputs, o, out):
    def one(p):
        im = load(p)
        if im.mode not in ("RGB", "RGBA"):
            im = im.convert("RGBA" if (im.mode in ("LA", "PA") or "transparency" in im.info) else "RGB")
        ang = _f(o, "angle", 0 if o.get("flip") in ("horizontal", "vertical") else 90)
        if ang:
            im = im.rotate(-ang, expand=True, resample=Image.BICUBIC, fillcolor=(255, 255, 255, 0) if im.mode == "RGBA" else "white")
        if o.get("flip") == "horizontal": im = ImageOps.mirror(im)
        if o.get("flip") == "vertical": im = ImageOps.flip(im)
        return save(im, out, _stem(p) + "_rotated", _outfmt(o, p), 92)
    return _each(inputs, out, "rotated_images", one)


@tool("img_convert", multi=True, accept="image")
def img_convert(inputs, o, out):
    fmt = (o.get("format") or "jpg").lower()
    if fmt == "pdf":
        from .tools import image_to_pdf
        return image_to_pdf(inputs, {"page_size": "fit"}, out)
    return _each(inputs, out, "converted_images", lambda p: save(load(p), out, _stem(p), fmt, _f(o, "quality", 90)))


@tool("img_adjust", multi=True, accept="image")
def img_adjust(inputs, o, out):
    """Photo editor: brightness, contrast, saturation, sharpness, filters."""
    def one(p):
        im = load(p).convert("RGBA")
        rgb, a = im.convert("RGB"), im.getchannel("A")
        for k, E in (("brightness", ImageEnhance.Brightness), ("contrast", ImageEnhance.Contrast), ("saturation", ImageEnhance.Color), ("sharpness", ImageEnhance.Sharpness)):
            v = _f(o, k, 100)
            if v != 100: rgb = E(rgb).enhance(v / 100)
        f = o.get("filter", "none")
        if f == "grayscale": rgb = ImageOps.grayscale(rgb).convert("RGB")
        elif f == "sepia":
            g = ImageOps.grayscale(rgb); rgb = ImageOps.colorize(g, "#2e1d0e", "#f3e3c3")
        elif f == "invert": rgb = ImageOps.invert(rgb)
        elif f == "blur": rgb = rgb.filter(ImageFilter.GaussianBlur(3))
        elif f == "vintage":
            rgb = ImageEnhance.Color(rgb).enhance(0.6); rgb = ImageOps.colorize(ImageOps.grayscale(rgb), "#1a1206", "#fff1d0").convert("RGB")
        elif f == "auto": rgb = ImageOps.autocontrast(rgb, cutoff=1)
        elif f == "pixelate":
            k = max(6, rgb.width // 64); rgb = rgb.resize((max(1, rgb.width // k), max(1, rgb.height // k)), Image.NEAREST).resize(rgb.size, Image.NEAREST)
        elif f == "sharpen": rgb = rgb.filter(ImageFilter.UnsharpMask(radius=2.2, percent=170, threshold=2))
        elif f == "bw": rgb = ImageOps.grayscale(rgb).point(lambda v: 255 if v > 135 else 0).convert("RGB")
        im = rgb.convert("RGBA"); im.putalpha(a)
        return save(im, out, _stem(p) + "_edited", _outfmt(o, p), 92)
    return _each(inputs, out, "edited_images", one)


# ------------------------------------------------------------------ background removal
_sessions, _used = {}, {}


def ort_options():
    """ONNX Runtime settings for the AI models: memory is given back after each picture instead of being kept at its peak."""
    import onnxruntime as ort
    so = ort.SessionOptions(); so.log_severity_level = 3
    so.enable_cpu_mem_arena = False
    return so


def remove_background(im, model=None, alpha_matting=False):
    from rembg import new_session, remove
    model = model or os.environ.get("REMBG_MODEL", "isnet-general-use")  # birefnet-general = best quality (bigger)
    sess = _sessions.get(model)
    if sess is None:
        sess = _sessions[model] = new_session(model, sess_opts=ort_options())
    _used[model] = time.time()
    return remove(im.convert("RGB"), session=sess, alpha_matting=alpha_matting,
                  alpha_matting_foreground_threshold=240, alpha_matting_background_threshold=10, post_process_mask=True)


def release_idle(max_idle=900):
    """Forget AI models nobody used for a while – they are loaded again when needed (keeps the memory of a small server free)."""
    now = time.time()
    for k in [k for k, t in list(_used.items()) if now - t > max_idle]:
        _sessions.pop(k, None); _used.pop(k, None)


@tool("remove_bg", multi=True, accept="image")
def remove_bg(inputs, o, out):
    def one(p):
        im = load(p)
        cut = remove_background(im, o.get("model") if o.get("model") in ("isnet-general-use", "birefnet-general", "u2net", "u2net_human_seg", "isnet-anime") else None, _b(o, "fine_edges"))
        bg = o.get("background", "transparent")  # transparent | color | blur | image
        if _b(o, "shadow"):   # soft drop shadow under the subject (product photos)
            a = cut.getchannel("A"); off = (max(2, cut.width // 60), max(3, cut.height // 45))
            sh = Image.new("L", cut.size, 0); sh.paste(a.point(lambda v: v * 90 // 255), off)
            sh = sh.filter(ImageFilter.GaussianBlur(max(4, cut.width // 70)))
            layer = Image.new("RGBA", cut.size, (0, 0, 0, 0)); layer.putalpha(sh)
            layer.alpha_composite(cut); cut = layer
        if bg == "color":
            base = Image.new("RGBA", cut.size, ImageColor.getrgb(o.get("color", "#ffffff")) + (255,))
            base.alpha_composite(cut); cut = base
        elif bg == "blur":
            base = im.convert("RGBA").filter(ImageFilter.GaussianBlur(_f(o, "blur", 12))); base.alpha_composite(cut); cut = base
        elif bg == "image" and o.get("bg_image_path"):
            base = ImageOps.fit(load(o["bg_image_path"]).convert("RGBA"), cut.size, Image.LANCZOS); base.alpha_composite(cut); cut = base
        if _b(o, "crop_subject"):
            bb = cut.getchannel("A").getbbox() if bg == "transparent" else remove_background(im).getchannel("A").getbbox()
            if bb:
                m = int(max(cut.size) * 0.03); cut = cut.crop((max(0, bb[0] - m), max(0, bb[1] - m), min(cut.width, bb[2] + m), min(cut.height, bb[3] + m)))
        fmt = "png" if bg == "transparent" else (o.get("format") or "png")
        return save(cut, out, _stem(p) + "_nobg", fmt, 92)
    return _each(inputs, out, "no_background", one)


# ------------------------------------------------------------------ upscale (AI super-resolution, OpenCV dnn_superres)
@tool("img_upscale", multi=True, accept="image")
def img_upscale(inputs, o, out):
    import cv2
    scale = int(_f(o, "scale", 2)); scale = 4 if scale >= 4 else 2
    def one(p):
        im = load(p).convert("RGBA"); a = im.getchannel("A")
        arr = cv2.cvtColor(np.array(im.convert("RGB")), cv2.COLOR_RGB2BGR)
        algo = "edsr" if (o.get("quality") == "max" and (MODELS / f"EDSR_x{scale}.pb").exists() and arr.shape[0] * arr.shape[1] <= 700 * 700) else "fsrcnn"
        sr = cv2.dnn_superres.DnnSuperResImpl_create()
        sr.readModel(str(MODELS / f"{algo.upper()}_x{scale}.pb")); sr.setModel(algo, scale)
        up = sr.upsample(arr)
        res = Image.fromarray(cv2.cvtColor(up, cv2.COLOR_BGR2RGB)).filter(ImageFilter.UnsharpMask(radius=1.2, percent=60, threshold=2))
        if im.getextrema()[3][0] < 255:  # keep transparency
            res = res.convert("RGBA"); res.putalpha(a.resize(res.size, Image.LANCZOS))
        return save(res, out, _stem(p) + f"_x{scale}", _outfmt(o, p), 93)
    return _each(inputs, out, "upscaled_images", one)


# ------------------------------------------------------------------ watermark / meme
def _font(size, family="sans", bold=True, text=""):
    return ImageFont.truetype(font_file(family, bold, False, text), int(size))


def _segments(text, size, family="sans", bold=True):
    """text → [(part, font, width)] – every script gets a font that really has its letters (Hindi + English in one line etc.)."""
    from . import fonts as F
    segs = []
    for script, part in F.split_scripts(text):
        try:
            f = ImageFont.truetype(F.face(script, bold, False)[0], int(size)) if (script and F.has(script)) else _font(size, family, bold, part)
        except Exception:
            f = _font(size, family, bold, part)
        segs.append((part, f, f.getlength(part)))
    return segs


def _draw_text(d, x, base_y, segs, **kw):
    """draw the segments on one common baseline; returns the total width"""
    x0 = x
    for part, f, w in segs:
        d.text((x, base_y), part, font=f, anchor="ls", **kw); x += w
    return x - x0


@tool("img_watermark", multi=True, accept="image")
def img_watermark(inputs, o, out):
    def one(p):
        im = load(p).convert("RGBA")
        layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
        op = int(255 * min(1.0, max(0.03, _f(o, "opacity", 0.4))))
        txt = (o.get("text") or "").strip()
        if o.get("image_path"):
            wm = load(o["image_path"]).convert("RGBA"); w = max(8, int(im.width * min(1.0, max(0.03, _f(o, "img_scale", 0.25))))); wm = wm.resize((w, max(1, int(wm.height * w / wm.width))), Image.LANCZOS)
            wm.putalpha(wm.getchannel("A").point(lambda v: v * op // 255))
            if o.get("position") == "tiled":
                for r, y in enumerate(range(0, im.height, int(wm.height * 1.8) + 1)):
                    for x in range(-(wm.width if r % 2 else 0), im.width, int(wm.width * 2) + 1):
                        if x + wm.width > 0:
                            layer.alpha_composite(wm, (max(0, x), y)) if x >= 0 else layer.alpha_composite(wm.crop((-x, 0, wm.width, wm.height)), (0, y))
            else:
                layer.alpha_composite(wm, _pos(im.size, wm.size, o.get("position", "bottom-right")))
        if txt:
            size = _f(o, "size", 0) or max(14, im.width // 18)
            segs = _segments(txt, size, o.get("font", "sans"), True)
            tw = int(sum(w for _, _, w in segs))
            col = ImageColor.getrgb(o.get("color") or "#ffffff") + (op,)
            if o.get("position") == "tiled":   # the whole pattern is drawn upright on a big canvas and then turned: even coverage, staggered rows
                side = int(math.hypot(im.width, im.height)) + 4
                big = Image.new("RGBA", (side, side), (0, 0, 0, 0)); bd = ImageDraw.Draw(big)
                sx, sy = tw + int(size * 1.6), int(size * 2.6)
                for r, y in enumerate(range(int(size), side + sy, sy)):
                    for x in range(-(sx // 2 if r % 2 else 0), side + sx, sx):
                        _draw_text(bd, x, y, segs, fill=col)
                big = big.rotate(_f(o, "rotation", 30), resample=Image.BICUBIC)
                layer.alpha_composite(big.crop(((side - im.width) // 2, (side - im.height) // 2, (side - im.width) // 2 + im.width, (side - im.height) // 2 + im.height)))
            else:
                d = ImageDraw.Draw(layer)
                x, y = _pos(im.size, (tw, int(size * 1.15)), o.get("position", "bottom-right"))
                _draw_text(d, x, y + int(size * 0.9), segs, fill=col, stroke_width=max(1, int(size / 25)), stroke_fill=(0, 0, 0, op // 2))
        if not txt and not o.get("image_path"):
            raise ValueError("Please enter the watermark text or choose a logo.")
        im.alpha_composite(layer)
        return save(im, out, _stem(p) + "_watermarked", _outfmt(o, p), 92)
    return _each(inputs, out, "watermarked_images", one)


def _pos(size, obj, where, m=None):
    W, H = size; w, h = obj; m = m if m is not None else int(min(W, H) * 0.03)
    v, _, hz = (where or "center").partition("-")
    if v == "center": hz = "center"
    x = {"left": m, "center": (W - w) // 2, "right": W - w - m}.get(hz, (W - w) // 2)
    y = {"top": m, "center": (H - h) // 2, "bottom": H - h - m}.get(v, (H - h) // 2)
    return int(x), int(y)


@tool("meme", accept="image")
def meme(inputs, o, out):
    im = load(inputs[0]).convert("RGB"); d = ImageDraw.Draw(im)
    if not (o.get("top") or o.get("bottom")):
        raise ValueError("Please enter the text for the top or the bottom.")
    for key, top in (("top", True), ("bottom", False)):
        t = str(o.get(key) or "").strip()
        t = t.upper() if t.isascii() else t          # capitals only make sense for Latin letters
        if not t:
            continue
        size = im.width // 9
        while True:
            segs = _segments(t, size, "sans", True); w = sum(x for _, _, x in segs)
            if w <= im.width * 0.94 or size <= 12:
                break
            size -= 2
        base = int(im.height * 0.02 + size) if top else im.height - int(im.height * 0.04) - int(size * 0.15)
        _draw_text(d, (im.width - w) / 2, base, segs, fill="white", stroke_width=max(2, size // 12), stroke_fill="black")
    return save(im, out, _stem(inputs[0]) + "_meme", "jpg", 92)


# ------------------------------------------------------------------ faces: blur / passport photo
def detect_faces(arr_bgr):
    import cv2
    model = MODELS / "face_detection_yunet_2023mar.onnx"
    h, w = arr_bgr.shape[:2]
    if model.exists():
        det = cv2.FaceDetectorYN.create(str(model), "", (w, h), 0.7, 0.3, 5000)
        _, faces = det.detect(arr_bgr)
        return [] if faces is None else [tuple(int(v) for v in f[:4]) for f in faces]
    cas = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    return [tuple(map(int, r)) for r in cas.detectMultiScale(cv2.cvtColor(arr_bgr, cv2.COLOR_BGR2GRAY), 1.1, 5, minSize=(24, 24))]


@tool("blur_face", multi=True, accept="image")
def blur_face(inputs, o, out):
    import cv2
    def one(p):
        im = load(p).convert("RGB"); arr = cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR)
        faces = detect_faces(arr)
        style = o.get("style", "blur")
        for x, y, w, h in faces:   # every face gets an effect that matches ITS size – a fixed blur leaves big faces recognisable
            s = max(w, h); pad = int(0.18 * s)
            box = (max(0, x - pad), max(0, y - pad * 2), min(im.width, x + w + pad), min(im.height, y + h + pad))
            part = im.crop(box)
            if style == "pixelate":
                k = max(6, s // 7); eff = part.resize((max(1, part.width // k), max(1, part.height // k)), Image.BILINEAR).resize(part.size, Image.NEAREST)
            elif style == "black":
                eff = Image.new("RGB", part.size, "black")
            else:
                eff = part.filter(ImageFilter.GaussianBlur(max(10, s * 0.3)))
            mask = Image.new("L", part.size, 0)
            ImageDraw.Draw(mask).ellipse((2, 2, part.width - 3, part.height - 3), fill=255)
            im.paste(eff, box[:2], mask=mask.filter(ImageFilter.GaussianBlur(max(2, s // 40))))
        return save(im, out, _stem(p) + "_blurred", _outfmt(o, p), 92)
    return _each(inputs, out, "blurred_images", one)


PASSPORT = {"india": (35, 45), "us": (51, 51), "uk": (35, 45), "schengen": (35, 45), "canada": (50, 70), "china": (33, 48), "pan": (25, 35), "stamp": (20, 25)}


@tool("passport_photo", accept="image")
def passport_photo(inputs, o, out):
    """Remove background → plain colour, centre the face at the official head size, output single photo + printable 4×6 sheet."""
    import cv2
    im = load(inputs[0]).convert("RGB")
    wmm, hmm = PASSPORT.get(o.get("country", "india"), (35, 45))
    dpi = 300; W, H = round(wmm / 25.4 * dpi), round(hmm / 25.4 * dpi)
    cut = remove_background(im)
    bg = Image.new("RGBA", cut.size, ImageColor.getrgb(o.get("color", "#ffffff")) + (255,)); bg.alpha_composite(cut)
    photo = bg.convert("RGB")
    faces = detect_faces(cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR))
    if faces:
        x, y, w, h = max(faces, key=lambda f: f[2] * f[3])
        head_h = h * 1.45                     # chin to top of hair ≈ 1.45 × detected face box
        k = (H * 0.62) / head_h               # head ≈ 62% of photo height (ICAO 50–69%)
        cx, top = x + w / 2, y - h * 0.38
        crop_w, crop_h = W / k, H / k
        x0, y0 = cx - crop_w / 2, top - crop_h * 0.10
        canvas = Image.new("RGB", (round(crop_w), round(crop_h)), o.get("color", "#ffffff"))
        canvas.paste(photo, (round(-x0), round(-y0)))
        photo = canvas.resize((W, H), Image.LANCZOS)
    else:
        photo = ImageOps.fit(photo, (W, H), Image.LANCZOS, centering=(0.5, 0.35))
    single = save(photo, out, f"passport_{wmm}x{hmm}mm", "jpg", 95)
    # printable 6x4 inch sheet with cut lines
    SW, SH = 6 * dpi, 4 * dpi
    sheet = Image.new("RGB", (SW, SH), "white"); d = ImageDraw.Draw(sheet)
    gap = 20; cols = max(1, (SW - gap) // (W + gap)); rows = max(1, (SH - gap) // (H + gap))
    ox = (SW - cols * (W + gap) + gap) // 2; oy = (SH - rows * (H + gap) + gap) // 2
    for r in range(rows):
        for c in range(cols):
            x, y = ox + c * (W + gap), oy + r * (H + gap); sheet.paste(photo, (x, y)); d.rectangle((x - 1, y - 1, x + W, y + H), outline="#cccccc")
    sheet_p = Path(out) / f"passport_sheet_4x6_{cols*rows}photos.jpg"; sheet.save(sheet_p, "JPEG", quality=95, dpi=(dpi, dpi))
    return _multi_out([single, sheet_p], out, "passport_photos")


# ------------------------------------------------------------------ signature cleaner / image OCR / HTML → image
@tool("signature_clean", accept="image")
def signature_clean(inputs, o, out):
    """Photo of a signature on paper → clean transparent PNG (ink colour selectable)."""
    import cv2
    im = load(inputs[0]).convert("RGB"); g = cv2.cvtColor(np.array(im), cv2.COLOR_RGB2GRAY)
    g = cv2.GaussianBlur(g, (3, 3), 0)
    th = cv2.adaptiveThreshold(g, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 31, 15)
    th = cv2.morphologyEx(th, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    ink = ImageColor.getrgb(o.get("color", "#0b3fa6"))
    alpha = Image.fromarray(th).filter(ImageFilter.GaussianBlur(0.6))
    res = Image.new("RGBA", im.size, ink + (0,)); res.putalpha(alpha)
    bb = alpha.point(lambda v: 255 if v > 40 else 0).getbbox()
    if bb: res = res.crop((max(0, bb[0] - 10), max(0, bb[1] - 10), min(im.width, bb[2] + 10), min(im.height, bb[3] + 10)))
    return save(res, out, _stem(inputs[0]) + "_signature", "png")


@tool("img_to_text", multi=True, accept="image")
def img_to_text(inputs, o, out):
    from .editor import ocr_langs
    lang = ocr_langs(str(o.get("lang") or "eng+hin").lower())
    def one(p):
        dst = Path(out) / f"{_stem(p)}.txt"
        tmp = Path(out) / f"_{_stem(p)}.png"; load(p).convert("RGB").save(tmp)
        r = subprocess.run(["tesseract", str(tmp), "stdout", "-l", lang, "--psm", "3"], capture_output=True, text=True, timeout=300)
        dst.write_text(r.stdout, encoding="utf-8"); tmp.unlink(missing_ok=True)
        return dst
    return _each(inputs, out, "image_text", one)


@tool("html_to_image", accept="none")
def html_to_image(inputs, o, out):
    from playwright.sync_api import sync_playwright
    from .util import check_url, guard_browser
    url = (o.get("url") or "").strip(); fmt = o.get("format", "png")
    if not url and not o.get("html"):
        raise ValueError("Please enter a web address.")
    if url:
        url = check_url(url)
    proxy = os.environ.get("HTML2PDF_PROXY") or os.environ.get("HTTPS_PROXY")
    with sync_playwright() as pw:
        br = pw.chromium.launch(proxy={"server": proxy} if proxy else None)
        try:
            pg = br.new_page(viewport={"width": int(min(3000, max(320, _f(o, "viewport", 1280)))), "height": 800},
                             device_scale_factor=float(min(3, max(1, _f(o, "scale", 1)))))
            guard_browser(pg)
            try:
                if url:
                    pg.goto(url, wait_until="networkidle", timeout=60000)
                else:
                    pg.set_content(o.get("html"), wait_until="networkidle", timeout=60000)
            except Exception as e:
                raise ValueError(f"Could not load the page: {str(e).splitlines()[0][:120]}")
            dst = Path(out) / f"screenshot.{'jpg' if fmt == 'jpg' else 'png'}"
            pg.screenshot(path=str(dst), full_page=_b(o, "full_page", True), type="jpeg" if fmt == "jpg" else "png")
        finally:
            br.close()
    return dst


# ------------------------------------------------------------------ camera scan → clean PDF (document detection + perspective fix)
def _order(pts):
    s = pts.sum(1); d = np.diff(pts, axis=1).ravel()
    return np.array([pts[np.argmin(s)], pts[np.argmin(d)], pts[np.argmax(s)], pts[np.argmax(d)]], dtype="float32")


def find_document(arr_bgr):
    import cv2
    h, w = arr_bgr.shape[:2]; k = 1000 / max(h, w); small = cv2.resize(arr_bgr, (int(w * k), int(h * k)), interpolation=cv2.INTER_AREA)
    blur = cv2.GaussianBlur(small, (5, 5), 0)
    edges = cv2.Canny(cv2.cvtColor(blur, cv2.COLOR_BGR2GRAY), 50, 150)
    for ch in cv2.split(blur):   # a coloured band on a dark table shows up in one channel only
        edges |= cv2.Canny(ch, 50, 150)
    edges = cv2.dilate(edges, np.ones((3, 3), np.uint8))
    area = small.shape[0] * small.shape[1]
    # outer outlines first (the whole sheet / card), then inner ones
    for mode in (cv2.RETR_EXTERNAL, cv2.RETR_LIST):
        cnts, _ = cv2.findContours(edges, mode, cv2.CHAIN_APPROX_SIMPLE)
        for c in sorted(cnts, key=cv2.contourArea, reverse=True)[:8]:
            hull = cv2.convexHull(c)
            ap = cv2.approxPolyDP(hull, 0.02 * cv2.arcLength(hull, True), True)
            if len(ap) == 4 and 0.15 * area < cv2.contourArea(ap) < 0.985 * area:
                return _order(ap.reshape(4, 2).astype("float32") / k)
    return None


def scan_page(im, mode="color"):
    """phone photo of a document → cropped, straightened, evenly lit page."""
    import cv2
    arr = cv2.cvtColor(np.array(im.convert("RGB")), cv2.COLOR_RGB2BGR)
    q = find_document(arr)
    if q is not None:
        (tl, tr, br, bl) = q
        W = int(max(np.linalg.norm(br - bl), np.linalg.norm(tr - tl))); H = int(max(np.linalg.norm(tr - br), np.linalg.norm(tl - bl)))
        M = cv2.getPerspectiveTransform(q, np.array([[0, 0], [W - 1, 0], [W - 1, H - 1], [0, H - 1]], dtype="float32"))
        arr = cv2.warpPerspective(arr, M, (W, H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
    return clean_scan(Image.fromarray(cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)), mode)


def clean_scan(im, mode="color"):
    """even out the lighting of a (flat) scanned page; optional grayscale / crisp black & white."""
    import cv2
    arr = cv2.cvtColor(np.array(im.convert("RGB")), cv2.COLOR_RGB2BGR)
    if mode == "bw":  # crisp black & white "scanner" look
        g = cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY)
        arr = cv2.adaptiveThreshold(g, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 25, 12)
        return Image.fromarray(arr)
    if mode == "gray":
        return ImageOps.autocontrast(Image.fromarray(cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY)), cutoff=1)
    # colour: estimate the paper (text removed by dilation, then smoothed) and divide by it → shadows and yellowing vanish
    k = max(15, (min(arr.shape[:2]) // 45) | 1)
    paper = cv2.dilate(arr, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    small = cv2.resize(paper, (max(1, arr.shape[1] // 4), max(1, arr.shape[0] // 4)), interpolation=cv2.INTER_AREA)
    small = cv2.GaussianBlur(cv2.medianBlur(small, 21), (0, 0), 8)
    paper = cv2.resize(small, (arr.shape[1], arr.shape[0]), interpolation=cv2.INTER_LINEAR)
    norm = cv2.divide(arr, np.maximum(paper, 1), scale=250)
    return Image.fromarray(cv2.cvtColor(norm, cv2.COLOR_BGR2RGB))


@tool("scan_to_pdf", multi=True, accept="image")
def scan_to_pdf(inputs, o, out):
    import pymupdf
    pages = [scan_page(load(p), o.get("mode", "color")) for p in inputs]
    res = pymupdf.open()
    bw = o.get("mode") == "bw"
    for im in pages:
        buf = io.BytesIO()
        if bw:   # 1-bit picture: crisp letters and a tiny file
            im.convert("L").point(lambda v: 255 if v > 127 else 0).convert("1").save(buf, "PNG", optimize=True)
        else:
            im.convert("RGB" if im.mode != "L" else "L").save(buf, "JPEG", quality=85)
        W = 595; H = W * im.height / im.width
        pg = res.new_page(width=W, height=H); pg.insert_image(pg.rect, stream=buf.getvalue())
    dst = Path(out) / "scan.pdf"; res.save(dst, garbage=3, deflate=True)
    if _b(o, "ocr", True):
        from .tools import run_ocr
        ocr_dst = Path(out) / "scan_searchable.pdf"
        try:
            run_ocr(dst, ocr_dst, o.get("lang") or "eng+hin"); return ocr_dst
        except Exception:
            pass
    return dst

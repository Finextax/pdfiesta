"""More PDF tools (everything the big PDF sites offer, plus a few they don't):
overlay / letterhead, web-optimise, sanitise, invert colours, booklet, poster, attachments, PDF info, search in PDFs,
viewer preferences, PDF→SVG / EPUB, e-book / text / Markdown / PostScript / ZIP → PDF, enhance scans, QR & barcodes,
GST invoice generator, AI quiz and AI data extraction."""
import csv, datetime, html as _h, io, json, math, os, re, shutil, subprocess, zipfile
from pathlib import Path
import pymupdf, pikepdf
from .tools import (tool, _b, _f, _save, _stem, _multi_out, open_pdf, ensure_text, parse_ranges, unrotate, SIZES, IMG_EXT, page_resource, draw_text,
                    OCR_LANGS, _gs, is_scanned, run_ocr, safe_name, zip_files)


# ------------------------------------------------------------------ overlay / letterhead
@tool("overlay", multi=True)
def overlay(inputs, o, out):
    if len(inputs) < 2:
        raise ValueError("Upload two PDFs: first your document, then the PDF to lay over it (letterhead, stamp, background).")
    base, ov = open_pdf(inputs[0]), open_pdf(inputs[1])
    unrotate(base)
    below = o.get("layer", "below") == "below"
    mode = o.get("mode", "repeat")  # repeat = first overlay page on every page | pages = page 1 on page 1, 2 on 2 …
    for pg in base:
        k = 0 if mode == "repeat" else pg.number
        if k >= ov.page_count:
            if mode != "pages_repeat_last":
                continue
            k = ov.page_count - 1
        pg.show_pdf_page(pg.rect, ov, k, overlay=not below)
    return _save(base, out / f"{_stem(inputs[0])}_overlay.pdf", garbage=4)


@tool("linearize")
def linearize(inputs, o, out):
    """'Fast web view': the first page shows while the rest is still downloading."""
    dst = out / f"{_stem(inputs[0])}_web.pdf"
    with pikepdf.open(inputs[0], password=o.get("password") or "") as pdf:
        pdf.remove_unreferenced_resources()
        pdf.save(dst, linearize=True, compress_streams=True, object_stream_mode=pikepdf.ObjectStreamMode.generate)
    return dst


RISKY_ACTIONS = ("/JavaScript", "/Launch", "/SubmitForm", "/ImportData", "/RichMedia", "/Movie", "/Sound", "/Rendition", "/GoToE")


def drop_actions(d):
    """remove scripts and other active content: document / page / field actions, JavaScript name tree, launch actions."""
    cat = d.pdf_catalog()
    for key in ("OpenAction", "AA"):
        t, v = d.xref_get_key(cat, key)
        if t == "null":
            continue
        body = d.xref_object(int(v.split()[0]), compressed=True) if t == "xref" else v
        if key == "AA" or any(r in body for r in RISKY_ACTIONS):
            d.xref_set_key(cat, key, "null")
    t, v = d.xref_get_key(cat, "Names")
    if t == "xref":
        d.xref_set_key(int(v.split()[0]), "JavaScript", "null")
    elif t == "dict" and "JavaScript" in v:
        d.xref_set_key(cat, "Names/JavaScript", "null")
    for x in range(1, d.xref_length()):
        try:
            obj = d.xref_object(x, compressed=True)
        except Exception:
            continue
        if re.search(r"/S\s*/(JavaScript|Launch|SubmitForm|ImportData|Rendition|Movie|Sound|GoToE)\b", obj):
            d.update_object(x, "<<>>")
        elif "/AA" in obj and re.search(r"/Type\s*/(Page|Annot)\b|/Subtype\s*/Widget\b|/FT\s*/", obj):
            d.xref_set_key(x, "AA", "null")


@tool("sanitize")
def sanitize(inputs, o, out):
    """Remove everything a reader does not see: metadata, scripts, attachments, thumbnails, (optionally) hidden text and links."""
    d = open_pdf(inputs[0], o.get("password"))
    att = _b(o, "attachments", True)
    d.scrub(attached_files=att, embedded_files=att, javascript=_b(o, "javascript", True),
            metadata=_b(o, "metadata", True), xml_metadata=_b(o, "metadata", True), hidden_text=_b(o, "hidden_text", False),
            thumbnails=True, reset_responses=True, redactions=True, remove_links=_b(o, "links", False), reset_fields=False, clean_pages=True)
    if _b(o, "javascript", True):
        drop_actions(d)
    if att:
        cat = d.pdf_catalog()
        if d.xref_get_key(cat, "PageMode")[1] == "/UseAttachments":
            d.xref_set_key(cat, "PageMode", "/UseNone")
        t, v = d.xref_get_key(cat, "Names")
        if t == "dict" and "EmbeddedFiles" in v:
            d.xref_set_key(cat, "Names/EmbeddedFiles", "null")
        elif t == "xref":
            d.xref_set_key(int(v.split()[0]), "EmbeddedFiles", "null")
    return _save(d, out / f"{_stem(inputs[0])}_clean.pdf", garbage=4)


@tool("invert")
def invert(inputs, o, out):
    """Invert all colours (white paper → black, for reading at night). Text and vectors stay sharp."""
    d = open_pdf(inputs[0], o.get("password"))
    for i in parse_ranges(o.get("pages", "all"), d.page_count):
        pg = d[i]
        gs = page_resource(d, pg, "ExtGState", "PKinv", "<</Type/ExtGState/BM/Difference/CA 1/ca 1>>")
        mb = pg.mediabox
        x = d.get_new_xref(); d.update_object(x, "<<>>")
        d.update_stream(x, f"\nq /{gs} gs 1 1 1 rg {mb.x0 - 5:.2f} {mb.y0 - 5:.2f} {mb.width + 10:.2f} {mb.height + 10:.2f} re f Q\n".encode())
        # blend modes need something to blend with: paint the paper white first (a PDF page has no colour of its own)
        pre = d.get_new_xref(); d.update_object(pre, "<<>>")
        d.update_stream(pre, f"q 1 1 1 rg {mb.x0 - 5:.2f} {mb.y0 - 5:.2f} {mb.width + 10:.2f} {mb.height + 10:.2f} re f Q\nq\n".encode())
        post = d.get_new_xref(); d.update_object(post, "<<>>"); d.update_stream(post, b"\nQ\n")
        inner = " ".join(f"{c} 0 R" for c in pg.get_contents())
        d.xref_set_key(pg.xref, "Contents", f"[{pre} 0 R {inner} {post} 0 R {x} 0 R]")
    return _save(d, out / f"{_stem(inputs[0])}_inverted.pdf")


# ------------------------------------------------------------------ print layouts
@tool("booklet")
def booklet(inputs, o, out):
    """Pages re-ordered and placed 2-up so that the printed, folded stack becomes a booklet (print double-sided, flip on short edge)."""
    src = open_pdf(inputs[0], o.get("password"))
    n = src.page_count
    total = math.ceil(n / 4) * 4
    r = src[0].rect
    rtl = _b(o, "rtl")
    res = pymupdf.open()
    for i in range(total // 4):
        for a, b in ((total - 1 - 2 * i, 2 * i), (2 * i + 1, total - 2 - 2 * i)):
            sheet = res.new_page(width=r.width * 2, height=r.height)
            for k, idx in enumerate((b, a) if rtl else (a, b)):
                if idx < n:
                    sheet.show_pdf_page(pymupdf.Rect(k * r.width, 0, (k + 1) * r.width, r.height), src, idx)
    return _save(res, out / f"{_stem(inputs[0])}_booklet.pdf")


@tool("poster")
def poster(inputs, o, out):
    """Print one page BIG: cut it into cols × rows sheets (with a small overlap for gluing)."""
    src = open_pdf(inputs[0], o.get("password"))
    cols, rows = max(1, min(10, int(_f(o, "cols", 2)))), max(1, min(10, int(_f(o, "rows", 2))))
    PW, PH = SIZES.get((o.get("size") or "a4").lower(), SIZES["a4"])
    ov = _f(o, "overlap", 10)
    res = pymupdf.open()
    for i in parse_ranges(o.get("pages", "all"), src.page_count):
        R = src[i].rect
        tw, th = R.width / cols, R.height / rows
        land = tw > th
        for r in range(rows):
            for c in range(cols):
                clip = pymupdf.Rect(c * tw - ov / 2, r * th - ov / 2, (c + 1) * tw + ov / 2, (r + 1) * th + ov / 2) & R
                pg = res.new_page(width=PH if land else PW, height=PW if land else PH)
                pg.show_pdf_page(pg.rect + (12, 12, -12, -12), src, i, clip=clip)
    return _save(res, out / f"{_stem(inputs[0])}_poster_{cols}x{rows}.pdf")


# ------------------------------------------------------------------ attachments
@tool("attachments", multi=True, accept="any")
def attachments(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    if o.get("mode", "add") == "extract":
        paths = []
        for name in d.embfile_names():
            info = d.embfile_info(name)
            p = out / safe_name(info.get("filename") or name); p.write_bytes(d.embfile_get(name)); paths.append(p)
        for pg in d:
            for a in pg.annots(types=[pymupdf.PDF_ANNOT_FILE_ATTACHMENT]) or []:
                f = a.file_info
                p = out / safe_name(f.get("filename") or f"attachment_{a.xref}"); p.write_bytes(a.get_file()); paths.append(p)
        if not paths:
            raise ValueError("This PDF has no attachments.")
        return _multi_out(paths, out, f"{_stem(inputs[0])}_attachments")
    if len(inputs) < 2:
        raise ValueError("Upload the PDF first, then the files you want to attach to it.")
    for p in inputs[1:]:
        d.embfile_add(Path(p).name, Path(p).read_bytes(), filename=Path(p).name, desc=Path(p).name)
    return _save(d, out / f"{_stem(inputs[0])}_with_attachments.pdf")


# ------------------------------------------------------------------ information / search / viewer
@tool("pdf_info")
def pdf_info(inputs, o, out):
    p = Path(inputs[0]); d = open_pdf(p, o.get("password"))
    md = d.metadata or {}
    sizes = {}
    fonts, images, annots, widgets, chars = {}, 0, 0, 0, 0
    for pg in d:
        k = f"{pg.rect.width / 72 * 25.4:.0f} × {pg.rect.height / 72 * 25.4:.0f} mm"
        sizes[k] = sizes.get(k, 0) + 1
        for f in pg.get_fonts():
            fonts[f[3].split("+")[-1]] = "embedded" if f[1] not in ("n/a", "") else "NOT embedded"
        images += len(pg.get_images()); annots += len(list(pg.annots() or [])); widgets += len(list(pg.widgets() or []))
        chars += len(pg.get_text())
    xml = d.get_xml_metadata() or ""
    pdfa = re.search(r"pdfaid:part[>=\"' ]+(\d)", xml); conf = re.search(r"pdfaid:conformance[>=\"' ]+([ABU])", xml)
    try:
        from .tools_plus import verify_signatures
        sigs = len(verify_signatures(p))
    except Exception:
        sigs = 0
    L = [f"# {p.name}", "", f"- File size: {p.stat().st_size / 1024:.1f} KB", f"- Pages: {d.page_count}",
         f"- Page sizes: {', '.join(f'{k} ({v})' for k, v in sizes.items())}", f"- PDF version: {md.get('format', '?')}",
         f"- Encrypted: {'yes (' + str(md.get('encryption')) + ')' if md.get('encryption') else 'no'}",
         f"- Scanned document: {'yes' if is_scanned(d) else 'no'}", f"- Text characters: {chars}", f"- Images: {images}",
         f"- Bookmarks: {len(d.get_toc())}", f"- Annotations / comments: {annots}", f"- Form fields: {widgets}", f"- Digital signatures: {sigs}",
         f"- Attachments: {d.embfile_count()}", f"- PDF/A claim: {'PDF/A-' + pdfa.group(1) + (conf.group(1) if conf else '') if pdfa else 'none'}", "",
         "## Document information", ""] + [f"- {k.title()}: {md.get(k) or '–'}" for k in ("title", "author", "subject", "keywords", "creator", "producer", "creationDate", "modDate")] + \
        ["", "## Fonts", ""] + ([f"- {k} – {v}" for k, v in sorted(fonts.items())] or ["- none"])
    dst = out / f"{_stem(p)}_info.md"; dst.write_text("\n".join(L), encoding="utf-8")
    return dst


@tool("search", multi=True)
def search(inputs, o, out):
    """Find a word or phrase in many PDFs at once (scanned ones too) → report + copies with the hits highlighted."""
    q = (o.get("query") or "").strip()
    if len(q) < 2:
        raise ValueError("Please enter at least 2 characters to search for.")
    L, marked, total = [f"# Search results for “{q}”", ""], [], 0
    for p in inputs:
        src, _ = ensure_text(p, out)
        d = open_pdf(src); lines, n, pages = [], 0, 0
        for pg in d:
            rects = pg.search_for(q)
            if not rects:
                continue
            n += len(rects); pages += 1
            text = " ".join(pg.get_text().split())
            for m in list(re.finditer(re.escape(q), text, re.I))[:3]:
                lines.append(f"- p. {pg.number + 1}: …{text[max(0, m.start() - 60):m.end() + 60]}…")
            if _b(o, "highlight", True):
                for r in rects:
                    pg.add_highlight_annot(r)
        total += n
        L += [f"## {Path(p).name} – {n} match(es) on {pages} page(s)" if n else f"## {Path(p).name} – not found", ""] + lines + [""]
        if n and _b(o, "highlight", True):
            marked.append(_save(d, out / f"{_stem(p)}_highlighted.pdf"))
        else:
            d.close()
    L.insert(1, f"**{total} match(es)** in {len(inputs)} file(s).")
    rep = out / "search_results.md"; rep.write_text("\n".join(L), encoding="utf-8")
    return rep if not marked else _multi_out([rep] + marked, out, "search_results")


@tool("viewer_prefs")
def viewer_prefs(inputs, o, out):
    """How the PDF opens in a reader: page layout, sidebar, full screen, window options."""
    d = open_pdf(inputs[0], o.get("password"))
    d.set_pagelayout(o.get("layout") if o.get("layout") in ("SinglePage", "OneColumn", "TwoColumnLeft", "TwoColumnRight", "TwoPageLeft", "TwoPageRight") else "SinglePage")
    d.set_pagemode(o.get("mode") if o.get("mode") in ("UseNone", "UseOutlines", "UseThumbs", "FullScreen", "UseAttachments") else "UseNone")
    cat = d.pdf_catalog()
    for key, opt in (("HideToolbar", "hide_toolbar"), ("HideMenubar", "hide_menubar"), ("FitWindow", "fit_window"), ("CenterWindow", "center_window"), ("DisplayDocTitle", "show_title")):
        d.xref_set_key(cat, f"ViewerPreferences/{key}", "true" if _b(o, opt) else "false")
    return _save(d, out / f"{_stem(inputs[0])}.pdf")


# ------------------------------------------------------------------ more conversions from PDF
@tool("pdf_to_svg")
def pdf_to_svg(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password")); stem = _stem(inputs[0])
    paths = []
    for i in parse_ranges(o.get("pages", "all"), d.page_count):
        p = out / f"{stem}-{i+1}.svg"; p.write_text(d[i].get_svg_image(text_as_path=_b(o, "text_as_path", False)), encoding="utf-8"); paths.append(p)
    return _multi_out(paths, out, f"{stem}_svg")


@tool("pdf_to_epub")
def pdf_to_epub(inputs, o, out):
    """Reflowable e-book (EPUB 3) from the text of the PDF – one chapter per bookmark (or per page)."""
    from .editor import page_model
    src, _ = ensure_text(inputs[0], out, o.get("lang") or OCR_LANGS, visible=True)
    d = open_pdf(src); stem = _stem(inputs[0])
    title = (d.metadata or {}).get("title") or stem
    toc = [(t[1], t[2] - 1) for t in d.get_toc() if t[0] == 1 and t[2] > 0]
    starts = sorted({s for _, s in toc} | {0}) if len(toc) > 1 else list(range(d.page_count))
    names = {s: t for t, s in toc}
    chapters = []
    for k, s in enumerate(starts):
        e = (starts[k + 1] if k + 1 < len(starts) else d.page_count)
        body = []
        for pno in range(s, e):
            for b in page_model(d, pno)["blocks"]:
                tag = "h2" if (b["size"] >= 15 and b["single"]) else "p"
                for para in b["paras"]:
                    inner = "".join(("<b>" if r.get("b") else "") + ("<i>" if r.get("i") else "") + _h.escape(r["t"]) + ("</i>" if r.get("i") else "") + ("</b>" if r.get("b") else "") for r in para)
                    if inner.strip():
                        body.append(f"<{tag}>{inner}</{tag}>")
        if body:
            chapters.append((names.get(s) or f"Page {s + 1}" if len(toc) <= 1 else names.get(s, f"Part {k + 1}"), "\n".join(body)))
    if not chapters:
        raise ValueError("No text found in this PDF.")
    dst = out / f"{stem}.epub"
    uid = f"urn:pdfkaro:{stem}:{d.page_count}"
    xh = lambda t, b: f'<?xml version="1.0" encoding="utf-8"?>\n<!DOCTYPE html>\n<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops"><head><title>{_h.escape(t)}</title><meta charset="utf-8"/></head><body>{b}</body></html>'
    with zipfile.ZipFile(dst, "w") as z:
        z.writestr(zipfile.ZipInfo("mimetype"), "application/epub+zip", compress_type=zipfile.ZIP_STORED)
        z.writestr("META-INF/container.xml", '<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>', zipfile.ZIP_DEFLATED)
        items = "".join(f'<item id="c{i}" href="c{i}.xhtml" media-type="application/xhtml+xml"/>' for i in range(len(chapters)))
        spine = "".join(f'<itemref idref="c{i}"/>' for i in range(len(chapters)))
        z.writestr("OEBPS/content.opf", f'<?xml version="1.0" encoding="utf-8"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="id"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="id">{_h.escape(uid)}</dc:identifier><dc:title>{_h.escape(title)}</dc:title><dc:language>{o.get("language") or "en"}</dc:language><meta property="dcterms:modified">{datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}</meta></metadata><manifest><item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>{items}</manifest><spine>{spine}</spine></package>', zipfile.ZIP_DEFLATED)
        nav = "".join(f'<li><a href="c{i}.xhtml">{_h.escape(t)}</a></li>' for i, (t, _) in enumerate(chapters))
        z.writestr("OEBPS/nav.xhtml", xh("Contents", f'<nav epub:type="toc"><h1>Contents</h1><ol>{nav}</ol></nav>'), zipfile.ZIP_DEFLATED)
        for i, (t, b) in enumerate(chapters):
            z.writestr(f"OEBPS/c{i}.xhtml", xh(t, (f"<h1>{_h.escape(t)}</h1>" if len(toc) > 1 else "") + b), zipfile.ZIP_DEFLATED)
    return dst


# ------------------------------------------------------------------ more conversions to PDF
def _chromium_pdf(html, dst, page_size="A4", margin="18mm"):
    from playwright.sync_api import sync_playwright
    from .util import guard_browser
    proxy = os.environ.get("HTML2PDF_PROXY") or os.environ.get("HTTPS_PROXY")
    with sync_playwright() as pw:
        br = pw.chromium.launch(proxy={"server": proxy} if proxy else None)
        try:
            pg = br.new_page(); guard_browser(pg)
            pg.set_content(html, wait_until="load", timeout=60000)
            pg.pdf(path=str(dst), format=page_size, print_background=True, margin={k: margin for k in ("top", "bottom", "left", "right")})
        finally:
            br.close()
    return dst


DOC_CSS = """body{font-family:'Noto Sans','Liberation Sans','Noto Sans Devanagari',Arial,sans-serif;font-size:11.5pt;line-height:1.5;color:#111}
h1,h2,h3{line-height:1.25} code,pre{font-family:'Liberation Mono',monospace;font-size:10pt;background:#f4f5f7;border-radius:4px}
pre{padding:10px;white-space:pre-wrap} code{padding:1px 4px} table{border-collapse:collapse;margin:10px 0} td,th{border:1px solid #999;padding:5px 9px}
th{background:#eef1f6} blockquote{border-left:4px solid #ccd;margin-left:0;padding-left:14px;color:#445} img{max-width:100%} a{color:#1a56db}"""


@tool("markdown_to_pdf", multi=True, accept="text")
def markdown_to_pdf(inputs, o, out):
    import markdown
    paths = []
    for p in inputs:
        text = Path(p).read_text(encoding="utf-8", errors="replace")
        if Path(p).suffix.lower() in (".md", ".markdown"):
            body = markdown.markdown(text, extensions=["tables", "fenced_code", "sane_lists", "toc"])
            body = re.sub(r"<script.*?</script>", "", body, flags=re.S | re.I)
        else:  # plain text keeps its line breaks and spacing
            body = f"<pre style='background:none;padding:0;font-family:{'Liberation Mono' if _b(o, 'mono') else 'inherit'};font-size:11pt'>{_h.escape(text)}</pre>"
        html = f"<!doctype html><html><head><meta charset='utf-8'><style>{DOC_CSS}</style></head><body>{body}</body></html>"
        paths.append(_chromium_pdf(html, out / f"{_stem(p)}.pdf", (o.get("page_size") or "a4").upper() if (o.get("page_size") or "a4").lower() != "letter" else "Letter"))
    return _multi_out(paths, out, "documents")


@tool("ebook_to_pdf", multi=True, accept="ebook")
def ebook_to_pdf(inputs, o, out):
    """EPUB, MOBI, FB2, XPS, CBZ (comics) → PDF (MuPDF reads them natively)."""
    W, H = SIZES.get((o.get("page_size") or "a5").lower(), SIZES["a5"])
    paths = []
    for p in inputs:
        try:
            d = pymupdf.open(p)
        except Exception:
            raise ValueError(f"Could not read {Path(p).name}.")
        if d.is_reflowable:
            d.layout(width=W, height=H, fontsize=_f(o, "font_size", 11))
        pdf = pymupdf.open("pdf", d.convert_to_pdf())
        try:
            pdf.set_toc(d.get_toc())
        except Exception:
            pass
        paths.append(_save(pdf, out / f"{_stem(p)}.pdf"))
    return _multi_out(paths, out, "ebooks")


@tool("ps_to_pdf", multi=True, accept="ps")
def ps_to_pdf(inputs, o, out):
    paths = []
    for p in inputs:
        dst = out / f"{_stem(p)}.pdf"
        try:
            _gs([f"-sOutputFile={dst}"] + (["-dEPSCrop"] if Path(p).suffix.lower() == ".eps" else []) + [str(p)])
        except Exception:
            raise ValueError(f"Could not convert {Path(p).name} – it does not look like a valid PostScript file.")
        paths.append(dst)
    return _multi_out(paths, out, "postscript")


OFFICE_EXT = {".doc", ".docx", ".odt", ".rtf", ".xls", ".xlsx", ".ods", ".csv", ".ppt", ".pptx", ".odp", ".pub", ".vsd", ".vsdx", ".odg",
              ".pages", ".numbers", ".key", ".hwp", ".wps", ".dot", ".dotx", ".xlsm", ".pptm", ".pps", ".ppsx"}


def any_to_pdf(p, out):
    """one file of any supported kind → PDF path (used by ZIP → PDF and by 'convert anything')."""
    from .tools import image_to_pdf, office_to_pdf
    suf = Path(p).suffix.lower()
    work = out / f"_any_{abs(hash(str(p))) % 10**8}"; work.mkdir(exist_ok=True)
    if suf == ".pdf":
        return Path(p)
    if suf in IMG_EXT:
        return image_to_pdf([p], {"page_size": "a4"}, work)
    if suf in OFFICE_EXT:
        return office_to_pdf([p], {}, work)
    if suf in (".txt", ".md", ".markdown", ".log"):
        return markdown_to_pdf([p], {}, work)
    if suf in (".epub", ".mobi", ".fb2", ".xps", ".oxps", ".cbz"):
        return ebook_to_pdf([p], {"page_size": "a4"}, work)
    if suf in (".ps", ".eps"):
        return ps_to_pdf([p], {}, work)
    return None


@tool("zip_to_pdf", accept="zip")
def zip_to_pdf(inputs, o, out):
    """Every document and picture inside a ZIP → one PDF (in file-name order) or one PDF per file."""
    src = out / "_zip"; src.mkdir()
    try:
        z = zipfile.ZipFile(inputs[0])
    except zipfile.BadZipFile:
        raise ValueError("This is not a valid ZIP file.")
    names = [i for i in z.infolist() if not i.is_dir() and not Path(i.filename).name.startswith((".", "__")) and "__MACOSX" not in i.filename
             and ".." not in Path(i.filename).parts and not i.filename.startswith(("/", "\\"))]
    if len(names) > 300 or sum(i.file_size for i in names) > 800 * 1024 * 1024:
        raise ValueError("The ZIP is too large (max 300 files / 800 MB unpacked).")
    natural = lambda i: [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", i.filename.lower())]   # page2 before page10
    files = []
    for k, i in enumerate(sorted(names, key=natural)):
        p = src / f"{k:04d}_{safe_name(Path(i.filename).name)}"      # flat, safe names – no path tricks
        with z.open(i) as fh, open(p, "wb") as dst:
            shutil.copyfileobj(fh, dst)
        files.append(p)
    pdfs = []
    for p in files:
        try:
            r = any_to_pdf(p, out)
            if r:
                pdfs.append((re.sub(r"^\d{4}_", "", p.stem), Path(r)))
        except Exception:
            continue
    if not pdfs:
        raise ValueError("No convertible files found in the ZIP (PDF, images, Office documents, text).")
    if o.get("mode") == "separate":
        paths = []
        for name, p in pdfs:
            dst = out / f"{safe_name(name)}.pdf"; shutil.copy(p, dst); paths.append(dst)
        return _multi_out(paths, out, f"{_stem(inputs[0])}_pdfs")
    res = pymupdf.open(); toc = []
    for name, p in pdfs:
        d = pymupdf.open(p); toc.append([1, name, res.page_count + 1]); res.insert_pdf(d); d.close()
    res.set_toc(toc)
    return _save(res, out / f"{_stem(inputs[0])}.pdf", garbage=4)


@tool("to_pdf", multi=True, accept="any")
def to_pdf(inputs, o, out):
    """'Convert to PDF' – any supported file type; several files become several PDFs."""
    paths = []
    for p in inputs:
        r = any_to_pdf(p, out)
        if r is None:
            raise ValueError(f"{Path(p).name}: this file type cannot be converted to PDF.")
        dst = out / f"{_stem(p)}.pdf"
        if Path(r) != dst:
            shutil.copy(r, dst)
        paths.append(dst)
    return _multi_out(paths, out, "converted")


# ------------------------------------------------------------------ scans
@tool("enhance_scan")
def enhance_scan(inputs, o, out):
    """Clean up a scanned PDF: even lighting, white paper, crisp text; optional black & white and OCR."""
    from PIL import Image
    from .images import clean_scan
    d = open_pdf(inputs[0], o.get("password"))
    mode = o.get("mode", "color")
    res = pymupdf.open()
    for pg in d:
        if not is_scanned_page_safe(pg):
            res.insert_pdf(d, from_page=pg.number, to_page=pg.number); continue
        pix = pg.get_pixmap(dpi=int(min(300, max(100, _f(o, "dpi", 200)))))
        im = clean_scan(Image.frombytes("RGB", (pix.width, pix.height), pix.samples), mode)
        buf = io.BytesIO()
        if mode == "bw":
            im.convert("1").save(buf, "PNG", optimize=True)
        else:
            im.save(buf, "JPEG", quality=82)
        np_ = res.new_page(width=pg.rect.width, height=pg.rect.height); np_.insert_image(np_.rect, stream=buf.getvalue())
    dst = _save(res, out / f"{_stem(inputs[0])}_enhanced.pdf")
    if _b(o, "ocr", True):
        try:
            return run_ocr(dst, out / f"{_stem(inputs[0])}_enhanced_ocr.pdf", o.get("lang") or OCR_LANGS)
        except Exception:
            pass
    return dst


def is_scanned_page_safe(pg):
    try:
        from .editor import is_scanned_page
        return is_scanned_page(pg)
    except Exception:
        return False


# ------------------------------------------------------------------ QR codes / barcodes
@tool("qr_code", accept="none")
def qr_code(inputs, o, out):
    import segno
    kind = o.get("kind", "text")
    if kind == "wifi":
        esc = lambda v: re.sub(r'([\\;,:"])', r"\\\1", v or "")
        data = f"WIFI:T:{o.get('security') or 'WPA'};S:{esc(o.get('ssid'))};P:{esc(o.get('wifi_password'))};;"
    elif kind == "upi":   # UPI payment QR (India) – works with GPay, PhonePe, Paytm, BHIM …
        from urllib.parse import quote
        if not re.match(r"^[\w.\-]{2,}@[\w.\-]{2,}$", o.get("vpa") or ""):
            raise ValueError("Please enter a valid UPI ID, e.g. yourname@okhdfcbank")
        data = f"upi://pay?pa={o['vpa']}&pn={quote(o.get('payee') or '')}" + (f"&am={float(o['amount']):.2f}" if str(o.get("amount") or "").strip() else "") + \
               "&cu=INR" + (f"&tn={quote(o['note'])}" if o.get("note") else "")
    else:
        data = (o.get("text") or "").strip()
    if not data:
        raise ValueError("Please enter the text or link for the QR code.")
    qr = segno.make(data, error="h" if o.get("logo_path") else "m", micro=False)
    fmt = o.get("format", "png")
    dark, light = o.get("color") or "#000000", o.get("background") or "#ffffff"
    if fmt == "svg":
        dst = out / "qr_code.svg"; qr.save(str(dst), scale=10, dark=dark, light=light, border=3)
        return dst
    buf = io.BytesIO(); qr.save(buf, kind="png", scale=int(min(40, max(4, _f(o, "scale", 16)))), dark=dark, light=light, border=3)
    from PIL import Image
    im = Image.open(buf).convert("RGBA")
    if o.get("logo_path"):   # logo in the middle (error correction level H keeps the code readable)
        logo = Image.open(o["logo_path"]).convert("RGBA"); s = im.width // 5
        logo.thumbnail((s, s)); pad = Image.new("RGBA", (logo.width + 12, logo.height + 12), light)
        pad.alpha_composite(logo, (6, 6)); im.alpha_composite(pad, ((im.width - pad.width) // 2, (im.height - pad.height) // 2))
    dst = out / "qr_code.png"; im.save(dst)
    if fmt == "pdf":
        d = pymupdf.open(); pg = d.new_page(); s = 300
        pg.insert_image(pymupdf.Rect((595 - s) / 2, 150, (595 + s) / 2, 150 + s), filename=str(dst))
        for k, line in enumerate(str(o.get("caption") or "").splitlines()[:4]):
            if line.strip():
                draw_text(pg, line.strip(), 297.5, 492 + k * 24, 16, (0, 0, 0), "sans", False, "center")
        return _save(d, out / "qr_code.pdf")
    return dst


@tool("barcode", accept="none")
def barcode_tool(inputs, o, out):
    import barcode
    from barcode.writer import ImageWriter
    kind = o.get("kind", "code128")
    data = (o.get("text") or "").strip()
    if not data:
        raise ValueError("Please enter the barcode content.")
    try:
        cls = barcode.get_barcode_class(kind if kind in ("code128", "code39", "ean13", "ean8", "upca", "isbn13", "itf") else "code128")
        bc = cls(data, writer=ImageWriter())
        dst = bc.save(str(out / "barcode"), options={"module_height": 15, "font_size": 9, "text_distance": 4, "quiet_zone": 4, "dpi": 300})
    except Exception as e:
        raise ValueError(f"This text is not valid for a {kind.upper()} barcode: {e}")
    return Path(dst)


# ------------------------------------------------------------------ GST invoice generator
ONES = "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split()
TENS = "x x twenty thirty forty fifty sixty seventy eighty ninety".split()


def _words(n):
    if n < 20: return ONES[n]
    if n < 100: return TENS[n // 10] + ("-" + ONES[n % 10] if n % 10 else "")
    if n < 1000: return ONES[n // 100] + " hundred" + (" " + _words(n % 100) if n % 100 else "")
    for size, name in ((10 ** 7, "crore"), (10 ** 5, "lakh"), (10 ** 3, "thousand")):
        if n >= size:
            return _words(n // size) + " " + name + (" " + _words(n % size) if n % size else "")


def amount_in_words(v, unit="Rupees", sub="Paise"):
    r, p = int(v), int(round((v - int(v)) * 100))
    return (f"{unit} {_words(r)}" + (f" and {_words(p)} {sub}" if p else "") + " only").title()


def _inr(v):
    s = f"{abs(v):.2f}"; i, d = s.split(".")
    if len(i) > 3:
        i = re.sub(r"(\d)(?=(\d\d)+$)", r"\1,", i[:-3]) + "," + i[-3:]
    return ("-" if v < 0 else "") + i + "." + d


def _n(v, d=0.0):
    """numbers as people type them: "1,150.50", " 18% ", "₹ 450" → float"""
    try:
        return float(re.sub(r"[^0-9.\-]", "", str(v if v is not None else "")) or d)
    except ValueError:
        return d


@tool("invoice", accept="none")
def invoice(inputs, o, out):
    e = lambda v: _h.escape(str(v or "")).replace("\n", "<br>")
    items = [i for i in (o.get("items") or []) if isinstance(i, dict) and str(i.get("desc") or "").strip()][:200]
    if not items:
        raise ValueError("Please add at least one item.")
    cur = str(o.get("currency") or "₹")[:6]
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", str(o.get("color") or "")):
        o = dict(o, color="#1a3c8f")
    inter = o.get("tax_mode") == "igst"
    notax = o.get("tax_mode") == "none"
    has_disc = any(_n(x.get("discount")) for x in items)
    rows, sub, tax_total, by_rate = [], 0.0, 0.0, {}
    for k, it in enumerate(items, 1):
        q, r, g = _n(it.get("qty"), 1.0), _n(it.get("rate")), 0.0 if notax else min(100.0, max(0.0, _n(it.get("gst"))))
        disc = min(100.0, max(0.0, _n(it.get("discount"))))
        amt = round(q * r * (1 - disc / 100), 2); tax = amt * g / 100
        sub += amt; tax_total += tax; by_rate[g] = by_rate.get(g, 0) + tax
        rows.append(f"<tr><td>{k}</td><td>{e(it.get('desc'))}</td><td>{e(it.get('hsn'))}</td><td class=r>{q:g}</td><td class=r>{_inr(r)}</td>"
                    + (f"<td class=r>{disc:g}%</td>" if has_disc else "")
                    + ("" if notax else f"<td class=r>{g:g}%</td>") + f"<td class=r>{_inr(amt)}</td></tr>")
    by_rate = {g: round(t, 2) for g, t in by_rate.items()}
    tax_total = sum((round(t / 2, 2) * 2 if not inter else t) for t in by_rate.values())   # CGST + SGST are each rounded to paise
    ship = _n(o.get("shipping"))
    total = sub + tax_total + ship
    rounded = round(total) if _b(o, "round_off", True) else total
    taxrows = ""
    if not notax:
        for g, t in sorted(by_rate.items()):
            if g:
                taxrows += (f"<tr><td>IGST {g:g}%</td><td class=r>{_inr(t)}</td></tr>" if inter else
                            f"<tr><td>CGST {g / 2:g}%</td><td class=r>{_inr(round(t / 2, 2))}</td></tr><tr><td>SGST {g / 2:g}%</td><td class=r>{_inr(round(t / 2, 2))}</td></tr>")
    logo = ""
    if o.get("logo_path"):
        import base64
        logo = f"<img src='data:image/png;base64,{base64.b64encode(_png(o['logo_path'])).decode()}' style='max-height:70px;max-width:200px'>"
    html = f"""<!doctype html><html><head><meta charset=utf-8><style>
    body{{font-family:'Noto Sans','Liberation Sans','Noto Sans Devanagari',sans-serif;font-size:10.5pt;color:#111;margin:0}}
    h1{{font-size:22pt;margin:0;color:{e(o.get('color') or '#1a3c8f')}}} .top{{display:flex;justify-content:space-between;align-items:flex-start}}
    .muted{{color:#555}} .box{{display:flex;gap:30px;margin:18px 0}} .box>div{{flex:1}} .lbl{{font-size:8.5pt;text-transform:uppercase;color:#777;letter-spacing:.05em;margin-bottom:3px}}
    table{{border-collapse:collapse;width:100%}} .items th{{background:{e(o.get('color') or '#1a3c8f')};color:#fff;text-align:left;padding:7px 8px;font-size:9.5pt}}
    .items td{{padding:7px 8px;border-bottom:1px solid #ddd;vertical-align:top}} .r{{text-align:right!important}}
    .tot{{width:46%;margin-left:54%;margin-top:10px}} .tot td{{padding:4px 8px}} .grand td{{font-weight:700;font-size:12pt;border-top:2px solid #111}}
    .foot{{margin-top:26px;display:flex;justify-content:space-between;gap:30px}} .sign{{text-align:right;margin-top:50px}}
    </style></head><body>
    <div class=top><div>{logo}<div style="font-size:14pt;font-weight:700;margin-top:4px">{e(o.get('seller_name'))}</div><div class=muted>{e(o.get('seller_address'))}</div>
    {f"<div>GSTIN: <b>{e(o.get('seller_gstin'))}</b></div>" if o.get('seller_gstin') else ""}</div>
    <div style="text-align:right"><h1>{e(o.get('title') or ('TAX INVOICE' if not notax else 'INVOICE'))}</h1>
    <div>No: <b>{e(o.get('number'))}</b></div><div>Date: <b>{e(o.get('date') or datetime.date.today().strftime('%d-%m-%Y'))}</b></div>
    {f"<div>Due: <b>{e(o.get('due'))}</b></div>" if o.get('due') else ""}</div></div>
    <div class=box><div><div class=lbl>Bill to</div><b>{e(o.get('buyer_name'))}</b><br><span class=muted>{e(o.get('buyer_address'))}</span>
    {f"<br>GSTIN: <b>{e(o.get('buyer_gstin'))}</b>" if o.get('buyer_gstin') else ""}</div>
    <div>{f"<div class=lbl>Place of supply</div>{e(o.get('place'))}" if o.get('place') else ""}</div></div>
    <table class=items><tr><th>#</th><th>Description</th><th>HSN/SAC</th><th class=r>Qty</th><th class=r>Rate</th>{"<th class=r>Disc.</th>" if has_disc else ""}{"" if notax else "<th class=r>GST</th>"}<th class=r>Amount ({e(cur)})</th></tr>{''.join(rows)}</table>
    <table class=tot><tr><td>Subtotal</td><td class=r>{_inr(sub)}</td></tr>{taxrows}
    {f"<tr><td>Shipping</td><td class=r>{_inr(ship)}</td></tr>" if ship else ""}
    {f"<tr><td>Round off</td><td class=r>{_inr(rounded - total)}</td></tr>" if abs(rounded - total) >= 0.005 else ""}
    <tr class=grand><td>Total</td><td class=r>{e(cur)} {_inr(rounded)}</td></tr></table>
    <div style="margin-top:8px"><span class=lbl>Amount in words: </span>{amount_in_words(rounded) if cur in ('₹', 'Rs', 'Rs.', 'INR') else ''}</div>
    <div class=foot><div style="flex:1.4">{f"<div class=lbl>Bank details</div>{e(o.get('bank'))}" if o.get('bank') else ""}
    {f"<div class=lbl style='margin-top:10px'>Notes / terms</div>{e(o.get('notes'))}" if o.get('notes') else ""}</div>
    <div style="flex:1" class=sign>For <b>{e(o.get('seller_name'))}</b><br><br><br><span class=muted>Authorised signatory</span></div></div>
    </body></html>"""
    return _chromium_pdf(html, out / f"invoice_{safe_name(str(o.get('number') or 'draft'))}.pdf", "A4", "14mm")


def _png(path):
    from PIL import Image
    im = Image.open(path).convert("RGBA"); im.thumbnail((600, 300)); buf = io.BytesIO(); im.save(buf, "PNG")
    return buf.getvalue()


# ------------------------------------------------------------------ more AI
@tool("ai_quiz")
def ai_quiz(inputs, o, out):
    from .tools_plus import ai_complete, _doc_text
    n = int(min(30, max(3, _f(o, "count", 10)))); kind = o.get("kind", "mcq")
    what = {"mcq": f"{n} multiple-choice questions (4 options each, mark the correct one)", "short": f"{n} short-answer questions with model answers",
            "flashcards": f"{n} flashcards (Front / Back)", "truefalse": f"{n} true/false statements with the correct answer"}.get(kind)
    text = ai_complete(f"From this document write {what} in {o.get('lang') or 'English'}. Put an answer key at the end. Use Markdown.\n\n<document>\n{_doc_text(inputs[0], out)}\n</document>")
    dst = out / f"{_stem(inputs[0])}_quiz.md"; dst.write_text(text, encoding="utf-8")
    return dst


@tool("ai_extract", multi=True)
def ai_extract(inputs, o, out):
    """Invoices, forms, résumés … → one spreadsheet row per PDF with the fields you name."""
    from .tools_plus import ai_complete, _doc_text
    fields = [f.strip() for f in re.split(r"[\n,]", o.get("fields") or "") if f.strip()][:40]
    if not fields:
        raise ValueError("Please list the fields to extract, e.g. Invoice number, Date, Total amount.")
    rows = []
    for p in inputs:
        raw = ai_complete("Extract these fields from the document. Return ONLY a JSON object with exactly these keys (use \"\" when a value is missing): "
                          + json.dumps(fields, ensure_ascii=False) + f"\n\n<document>\n{_doc_text(p, out, 60000)}\n</document>", 2000)
        m = re.search(r"\{.*\}", raw, re.S)
        try:
            data = json.loads(m.group(0)) if m else {}
        except Exception:
            data = {}
        rows.append([Path(p).name] + [str(data.get(f, "")) for f in fields])
    if o.get("format") == "csv":
        dst = out / "extracted.csv"
        with open(dst, "w", newline="", encoding="utf-8-sig") as fh:
            csv.writer(fh).writerows([["File"] + fields] + rows)
        return dst
    import openpyxl
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Extracted"; ws.append(["File"] + fields)
    for r in rows:
        ws.append(r)
    dst = out / "extracted.xlsx"; wb.save(dst)
    return dst

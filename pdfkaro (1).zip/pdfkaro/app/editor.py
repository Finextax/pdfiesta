"""PDF editor engine (v2).

Reading   page_model()  → paragraphs with rich-text runs (bold / italic / colour / size / font per run),
                           existing images, links and annotations.
                           Scanned pages – also scans that already carry an invisible OCR layer, and
                           digital text stamped on top of a scan – are recognised with Tesseract.
                           Indic text with broken Unicode maps is re-read with OCR.
Writing   apply_ops()   → applies the operations recorded by the browser editor.
  * edit text: old glyphs are removed (redaction; background and graphics stay), the new text is typeset
    in the same box with word-wrap. The PDF's own embedded font is reused when it has the glyphs
    (subset TrueType fonts get their character map rebuilt from the page), otherwise the closest
    open font is used (Arial→Liberation Sans, Calibri→Carlito, Cambria→Caladea …).
  * reflow: when a paragraph gets taller/shorter, the text below it in the same column is moved
    losslessly (as a text-only form XObject – fonts, kerning and justification are untouched).
  * scans: text pixels are removed with inpainting inside the scan image, then real text is written.
"""
import base64, functools, hashlib, html as _h, io, json, os, re, statistics, subprocess
from pathlib import Path
import pymupdf
from . import fonts as F

TESSDATA = os.environ.get("TESSDATA_PREFIX") or next(
    (p for p in ("/usr/share/tesseract-ocr/5/tessdata", "/usr/share/tesseract-ocr/4.00/tessdata", "/usr/share/tessdata")
     if Path(p).exists()), None)
TEXT_FLAGS = pymupdf.TEXT_PRESERVE_WHITESPACE | pymupdf.TEXT_MEDIABOX_CLIP
COMPLEX = {"notosansdevanagari", "notosansbengali", "notosansgurmukhi", "notosansgujarati", "notosanstamil", "notosanstelugu",
           "notosanskannada", "notosansmalayalam", "notonaskharabic", "notosanshebrew", "notosansthai"}


# ------------------------------------------------------------------ small helpers
def _hex(c):
    if isinstance(c, int):
        return "#%06x" % (c & 0xFFFFFF)
    if isinstance(c, (tuple, list)):
        return "#%02x%02x%02x" % tuple(int(max(0, min(1, v)) * 255) for v in c[:3])
    return c or "#000000"


def _rgb(hexs):
    h = (hexs or "#000000").lstrip("#")
    if len(h) != 6:
        h = "000000"
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def _union(rects):
    r = pymupdf.Rect()
    for x in rects:
        r |= pymupdf.Rect(x)
    return r


@functools.lru_cache(maxsize=1)
def tess_langs():
    try:
        out = subprocess.run(["tesseract", "--list-langs"], capture_output=True, text=True, timeout=20).stdout
        return frozenset(l.strip() for l in out.splitlines()[1:] if l.strip())
    except Exception:
        return frozenset()


def ocr_langs(req):
    have = tess_langs()
    parts = [p for p in (req or "eng").split("+") if p in have]
    return "+".join(parts) or "eng"


# ------------------------------------------------------------------ prepare (normalise rotation once)
def prepare(path):
    """Editor coordinates assume unrotated pages: bake /Rotate into the page content (appearance is unchanged)."""
    doc = pymupdf.open(path)
    rotated = [p.number for p in doc if p.rotation]
    for n in rotated:
        doc[n].remove_rotation()
    if rotated:
        tmp = str(path) + ".norm"
        doc.save(tmp, garbage=1, deflate=True); doc.close(); os.replace(tmp, path)
    else:
        doc.close()
    return {"rotated_pages": len(rotated)}


# ------------------------------------------------------------------ page analysis
def page_stats(pg):
    """(visible chars, invisible chars, share of the page covered by images, rects of invisible text)."""
    area = max(1.0, pg.rect.get_area())
    cover = 0.0
    for im in pg.get_image_info():
        r = pymupdf.Rect(im["bbox"]) & pg.rect
        if not r.is_empty:
            cover += r.get_area()
    vis = invis = 0
    inv = []
    try:
        for t in pg.get_texttrace():
            n = sum(1 for c in t["chars"] if c[0] > 32)
            if t.get("type") == 3 or t.get("opacity", 1) < 0.03:
                invis += n; inv.append(pymupdf.Rect(t["bbox"]))
            else:
                vis += n
    except Exception:
        vis = len(pg.get_text().strip())
    return vis, invis, min(1.0, cover / area), inv


def is_scanned_page(pg):
    vis, invis, cover, _ = page_stats(pg)
    return cover >= 0.6 and vis < 20


_PROPS = rb"<<(?:[^<>]|<[0-9A-Fa-f\s]*>)*>>"                      # a flat property dictionary: names, numbers, arrays, hex strings
_SPAN_OPEN = re.compile(rb"/Span\s*(" + _PROPS + rb")\s*BDC")
_TJ_OP = re.compile(rb"\[(?:\s*<[0-9A-Fa-f\s]*>|\s*-?[0-9.]+)*\s*\]\s*TJ|<[0-9A-Fa-f\s]*>\s*Tj")
_EMC = re.compile(rb"\bEMC\b")
_EMPTY_SPAN = re.compile(rb"/Span\s*(" + _PROPS + rb")\s*BDC((?:(?!\bEMC\b|\bBDC\b|<[0-9A-Fa-f]{4}).)*?)\bEMC\b", re.S)


def _own_ops(raw):
    """text-showing operators of a stream we wrote → [(exact text or None, glyph ids)]"""
    ev = [(m.start(), 0, m) for m in _SPAN_OPEN.finditer(raw) if b"/ActualText" in m.group(1)]
    ev += [(m.start(), 1, m) for m in _TJ_OP.finditer(raw)] + [(m.start(), 2, m) for m in _EMC.finditer(raw)]
    out, span = [], None
    for _, kind, m in sorted(ev, key=lambda e: e[0]):
        if kind == 0:
            hx = re.search(rb"/ActualText\s*<\s*FEFF([0-9A-Fa-f\s]*)>", m.group(1))
            cn = re.search(rb"/PKr\s*\[([0-9\s]*)\]", m.group(1))
            try:
                text = bytes.fromhex(re.sub(rb"\s", b"", hx.group(1)).decode()).decode("utf-16-be") if hx else None
            except Exception:
                text = None
            span = {"text": text, "counts": [int(x) for x in cn.group(1).split()] if cn else None, "k": 0, "off": 0}
        elif kind == 2:
            span = None
        else:
            gids = _op_gids(m.group(0))
            if not gids:
                continue
            piece = None
            if span and span["text"] is not None:
                n = span["counts"][span["k"]] if (span["counts"] and span["k"] < len(span["counts"])) else len(span["text"]) - span["off"]
                piece = span["text"][span["off"]:span["off"] + n]; span["off"] += n; span["k"] += 1
            out.append((piece, gids))
    return out


def _op_gids(tok):
    hexs = re.sub(rb"\s", b"", b"".join(re.findall(rb"<([0-9A-Fa-f\s]*)>", tok)))
    return [int(hexs[i:i + 4], 16) for i in range(0, len(hexs) - len(hexs) % 4, 4)]


def own_blocks(pg):
    """Hindi / Indic text written by this engine is read back EXACTLY: the letters come from the /ActualText we stored,
    position, font, size and colour from the glyphs. (Generic readers – MuPDF included – stumble over reordered glyphs.)
    → layout blocks, one per text box we wrote."""
    doc = pg.parent
    try:
        xos = [x[0] for x in pg.get_xobjects() if x[1] == "fullpage"]
    except Exception:
        return []
    cand = []
    for x in xos:
        try:
            raw = doc.xref_stream(x)
        except Exception:
            continue
        if not raw or b"/ActualText" not in raw:
            continue
        ops = _own_ops(raw)
        if ops:
            cand.append(ops)
    if not cand:
        return []
    trace = pg.get_texttrace()
    flat = [(c[1], si, c) for si, sp in enumerate(trace) for c in sp["chars"]]
    import array
    u16 = lambda g: g if 0 <= g < 65535 else 65535      # trace reports -1 for characters without a glyph
    hay = array.array("H", [u16(f[0]) for f in flat]).tobytes()
    used, blocks = set(), []
    for ops in cand:
        seq = [g for _, gl in ops for g in gl]
        needle = array.array("H", [u16(g) for g in seq]).tobytes()
        pos, start = -1, 0
        while True:
            i = hay.find(needle, start)
            if i < 0:
                break
            if i % 2 == 0 and i // 2 not in used:
                pos = i // 2; break
            start = i + 1
        if pos < 0:
            continue
        used.add(pos)
        spans, p = [], pos
        for actual, gl in ops:
            chars = [flat[p + k] for k in range(len(gl))]; p += len(gl)
            sp = trace[chars[0][1]]
            if sp.get("type") == 3 or abs(sp["dir"][1]) > 0.02 or sp["dir"][0] <= 0:
                spans = None; break   # invisible or rotated (watermark): not editable text
            text = actual if actual is not None else "".join(chr(c[2][0]) for c in chars if 32 <= c[2][0] < 0x110000)
            col = sp.get("color") or (0, 0, 0)
            col = (col,) * 3 if isinstance(col, (int, float)) else tuple(col)[:3] if len(col) >= 3 else (col[0],) * 3
            spans.append({"text": text, "font": sp["font"], "size": sp["size"], "flags": sp.get("flags", 0),
                          "color": (int(col[0] * 255) << 16) | (int(col[1] * 255) << 8) | int(col[2] * 255),
                          "bbox": tuple(_union(c[2][3] for c in chars)), "origin": tuple(chars[0][2][2])})
        if not spans:
            continue
        rows = {}
        for sp in spans:
            rows.setdefault(round(sp["origin"][1] * 2), []).append(sp)
        lines = [{"bbox": _union(x["bbox"] for x in r if x["text"].strip()), "spans": r, "base": r[0]["origin"][1]}
                 for _, r in sorted(rows.items()) if any(x["text"].strip() for x in r)]
        if lines:
            blocks.append({"bbox": _union(l["bbox"] for l in lines), "lines": lines, "own": True})
    return blocks


def drop_empty_spans(pg):
    """after text was removed: delete /ActualText wrappers that no longer hold any glyphs (readers would still 'see' the old words)."""
    doc = pg.parent
    try:
        for x in [x[0] for x in pg.get_xobjects() if x[1] == "fullpage"]:
            raw = doc.xref_stream(x)
            if raw and b"/ActualText" in raw:
                # the wrapper goes, font / position commands inside it stay (later runs may rely on them)
                new = _EMPTY_SPAN.sub(lambda m: m.group(2) if b"/ActualText" in m.group(1) else m.group(0), raw)
                if new != raw:
                    doc.update_stream(x, new)
    except Exception:
        pass


def layout(pg, inv_rects=(), textpage=None):
    """Text blocks → lines → spans (visible, horizontal text only). Table rows are split into cells."""
    d = pg.get_text("dict", flags=TEXT_FLAGS, textpage=textpage)
    own = own_blocks(pg) if textpage is None else []
    own_rects = [pymupdf.Rect(l["bbox"]) + (-1.5, -1.5, 1.5, 1.5) for b in own for l in b["lines"]]
    blocks = []
    for b in d["blocks"]:
        if b["type"] != 0:
            continue
        lines = []
        for l in b["lines"]:
            if abs(l["dir"][1]) > 0.02 or l["dir"][0] <= 0:
                continue  # rotated / vertical text is left alone
            spans = []
            for s in l["spans"]:
                if s["text"].strip() and (inv_rects or own_rects):
                    r = pymupdf.Rect(s["bbox"]); c = pymupdf.Point((r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2)
                    if any(c in ir for ir in inv_rects) or any(c in o for o in own_rects):
                        continue
                spans.append(s)
            ink = [s for s in spans if s["text"].strip()]
            if ink:
                lines.append({"bbox": _union(s["bbox"] for s in ink), "spans": spans, "base": ink[0]["origin"][1]})
        if not lines:
            continue
        rows = []
        for l in sorted(lines, key=lambda l: (round(l["base"]), l["bbox"].x0)):
            if rows and abs(rows[-1][0]["base"] - l["base"]) < 2:
                rows[-1].append(l)
            else:
                rows.append([l])
        multi = [r for r in rows if len(r) > 1]
        if multi and len(rows) >= 3 and len(multi) <= 0.4 * len(rows):
            # a paragraph whose justified lines were reported in pieces → glue the pieces together
            lines = []
            for r in rows:
                spans = []
                for seg in r:
                    if spans and not spans[-1]["text"].endswith(" ") and not seg["spans"][0]["text"].startswith(" "):
                        spans.append(dict(spans[-1], text=" ", bbox=(spans[-1]["bbox"][2], spans[-1]["bbox"][1], seg["bbox"].x0, spans[-1]["bbox"][3])))
                    spans += seg["spans"]
                lines.append({"bbox": _union(x["bbox"] for x in r), "spans": spans, "base": r[0]["base"]})
            blocks.append({"bbox": _union(l["bbox"] for l in lines), "lines": lines})
        elif multi:  # table rows / form lines: every cell is its own block
            for l in lines:
                blocks.append({"bbox": pymupdf.Rect(l["bbox"]), "lines": [l]})
        else:
            blocks.append({"bbox": _union(l["bbox"] for l in lines), "lines": lines})
    return blocks + own


def _spans_in(blocks, rect, grow=1.5):
    r = pymupdf.Rect(rect) + (-grow, -grow, grow, grow)
    out = []
    for b in blocks:
        for l in b["lines"]:
            for s in l["spans"]:
                if not s["text"].strip():
                    continue
                sr = pymupdf.Rect(s["bbox"]); c = pymupdf.Point((sr.x0 + sr.x1) / 2, (sr.y0 + sr.y1) / 2)
                if c in r:
                    out.append(s)
    return out


def _band(s):
    """thin horizontal band through the middle of a span: removes its glyphs without touching neighbouring lines."""
    r = pymupdf.Rect(s["bbox"]) if isinstance(s, dict) else pymupdf.Rect(s)
    mid, h = (r.y0 + r.y1) / 2, r.height
    return pymupdf.Rect(r.x0 - 0.3, mid - h * 0.18, r.x1 + 0.3, mid + h * 0.18)


def _vrules(pg):
    """thin vertical strokes (table cell borders, column rules) → [(x, y0, y1)]"""
    out = []
    try:
        dr = pg.get_cdrawings()
        if len(dr) > 8000:
            return out
        for d in dr:
            r = pymupdf.Rect(d["rect"])
            if r.width <= 2.2 and r.height >= 6:
                out.append(((r.x0 + r.x1) / 2, r.y0, r.y1))
    except Exception:
        pass
    return out


def _extent(blocks, bbox, page_rect, vrules=()):
    """how far a single-line block may grow to the left / right before it hits a neighbour, a cell border or the margin."""
    b = pymupdf.Rect(bbox)
    left = max(6.0, min([x["bbox"].x0 for x in blocks] + [b.x0]))
    right = min(page_rect.width - 6.0, max([x["bbox"].x1 for x in blocks] + [page_rect.width - left, b.x1]))
    lo, hi = min(left, b.x0), max(right, b.x1)
    for o in blocks:
        r = o["bbox"]
        if abs(r.x0 - b.x0) < 0.5 and abs(r.y0 - b.y0) < 0.5 and abs(r.x1 - b.x1) < 0.5:
            continue
        ov = min(r.y1, b.y1) - max(r.y0, b.y0)
        if ov > 0.3 * min(r.height, b.height):
            if r.x1 <= b.x0 + 1:
                lo = max(lo, r.x1 + 3)
            elif r.x0 >= b.x1 - 1:
                hi = min(hi, r.x0 - 3)
    mid = (b.y0 + b.y1) / 2
    for x, y0, y1 in vrules:
        if y0 <= mid <= y1:
            if x <= b.x0 + 0.5:
                lo = max(lo, x + 2.5)
            elif x >= b.x1 - 0.5:
                hi = min(hi, x - 2.5)
    return min(lo, b.x0), max(hi, b.x1)


def _edit_x(bbox, align, single, lo, hi):
    b = pymupdf.Rect(bbox)
    if not single:
        return b.x0, b.x1
    if align == "center":
        c = (b.x0 + b.x1) / 2; half = max(b.width / 2, min(c - lo, hi - c))
        return c - half, c + half
    if align == "right":
        return min(lo, b.x0), b.x1
    return b.x0, max(hi, b.x1)


# ------------------------------------------------------------------ model
def _hlines(pg):
    """thin horizontal strokes on the page (candidates for underline / strike-through)."""
    out = []
    try:
        dr = pg.get_cdrawings()
        if len(dr) > 8000:
            return out
        for d in dr:
            r = pymupdf.Rect(d["rect"])
            if r.width >= 4 and r.height <= 1.8:
                out.append((r.x0, r.x1, (r.y0 + r.y1) / 2))
    except Exception:
        pass
    return out


def _decor(s, line_bbox, hl):
    """(underlined, struck) for a span, judged from the line art around its baseline."""
    if not hl or not s["text"].strip():
        return 0, 0
    x0, _, x1, _ = s["bbox"]; base, size = s["origin"][1], s["size"]
    w = max(1.0, x1 - x0)
    u = st = 0
    for a, b, y in hl:
        if a < line_bbox.x0 - 2 or b > line_bbox.x1 + 2 or min(b, x1) - max(a, x0) < 0.6 * w:
            continue
        if base + 0.3 <= y <= base + 0.3 * size + 1:
            u = 1
        elif base - 0.45 * size <= y <= base - 0.18 * size:
            st = 1
    return u, st


def _run(s):
    f = s.get("font") or ""
    fl = f.lower()
    return {"u": s.get("_u", 0), "st": s.get("_st", 0), "t": s["text"], "b": int(bool(s["flags"] & 16) or any(k in fl for k in ("bold", "black", "heavy"))),
            "i": int(bool(s["flags"] & 2) or "italic" in fl or "oblique" in fl),
            "c": _hex(s.get("color", 0)), "s": round(s["size"], 2), "f": f, "fam": F.match(f, s["flags"])}


def _same(a, b):
    return all(a.get(k) == b.get(k) for k in ("b", "i", "c", "s", "f", "u", "st"))


def _block_model(blk, page_rect, blocks, scanned=False, style=None, hl=None, vrules=()):
    lines = blk["lines"]
    bbox = blk["bbox"]
    line_runs = []
    for l in lines:
        runs = []
        for s in l["spans"]:
            if not s["text"]:
                continue
            if hl:
                s["_u"], s["_st"] = _decor(s, l["bbox"], hl)
            r = _run(s)
            if style:
                r.update(style, f="")
            if runs and (_same(runs[-1], r) or not s["text"].strip()):
                runs[-1]["t"] += r["t"]
            else:
                runs.append(r)
        if runs:
            runs[0]["t"] = runs[0]["t"].lstrip(); runs[-1]["t"] = runs[-1]["t"].rstrip()
        line_runs.append([r for r in runs if r["t"]])
    x0s = [l["bbox"].x0 for l in lines]; x1s = [l["bbox"].x1 for l in lines]
    n = len(lines)
    align = "left"
    if n > 1:
        dl, dr = max(x0s) - min(x0s), max(x1s) - min(x1s)
        centers = [(a + b) / 2 for a, b in zip(x0s, x1s)]
        if dl > 4 and dr > 4 and max(centers) - min(centers) < 3:
            align = "center"
        elif dr < 2 and dl > 4:
            align = "right"
        elif n > 2 and max(x1s[:-1]) - min(x1s[:-1]) < 2 and dl < 2:
            align = "justify"
    elif abs((bbox.x0 + bbox.x1) / 2 - page_rect.width / 2) < 2.5 and bbox.x0 > min(b["bbox"].x0 for b in blocks) + 12:
        align = "center"
    # join wrapped lines into paragraphs
    paras = [[]]
    bw = max(1.0, bbox.width)
    for k, runs in enumerate(line_runs):
        for r in runs:
            if paras[-1] and _same(paras[-1][-1], r):
                paras[-1][-1]["t"] += r["t"]
            else:
                paras[-1].append(dict(r))
        if k < n - 1:
            lb = lines[k]["bbox"]
            fill = {"left": lb.x1 - bbox.x0, "justify": lb.x1 - bbox.x0, "right": bbox.x1 - lb.x0, "center": lb.width}[align]
            if fill > 0.82 * bw and paras[-1]:
                if not paras[-1][-1]["t"].endswith(("-", " ")):
                    paras[-1][-1]["t"] += " "
            else:
                paras.append([])
    paras = [p for p in paras if p] or [[]]
    allruns = [r for p in paras for r in p]
    dom = max(allruns, key=lambda r: len(r["t"])) if allruns else {"b": 0, "i": 0, "c": "#000000", "s": 11, "fam": "liberationsans"}
    size = dom["s"]
    bases = [l["base"] for l in lines]
    lh = statistics.median(b - a for a, b in zip(bases, bases[1:])) / max(size, 1) if n > 1 else 1.2
    lo, hi = _extent(blocks, bbox, page_rect, vrules)
    ex0, ex1 = _edit_x(bbox, align, n == 1, lo, hi)
    extra = {"line_texts": ["".join(r["t"] for r in runs) for runs in line_runs]} if scanned else {}
    return {**extra, "bbox": [round(v, 2) for v in bbox], "lines": [[round(v, 2) for v in l["bbox"]] for l in lines], "base": round(bases[0], 2),
            "paras": paras, "text": "\n".join("".join(r["t"] for r in p) for p in paras),
            "align": align, "lh": round(min(3.0, max(0.9, lh)), 3), "size": size, "color": dom["c"], "fam": dom["fam"],
            "bold": dom["b"], "italic": dom["i"], "single": n == 1, "box": [round(ex0, 2), round(ex1, 2)], "scanned": scanned,
            "cell": n == 1 and bool(_row_mates(blocks, bbox))}


def _ocr_clip(pg, rect, lang):
    pix = pg.get_pixmap(clip=pymupdf.Rect(rect) + (-3, -3, 3, 3), dpi=300, colorspace=pymupdf.csGRAY)
    r = subprocess.run(["tesseract", "stdin", "stdout", "-l", lang, "--psm", "6"], input=pix.tobytes("png"),
                       capture_output=True, timeout=90)
    return [l.strip() for l in r.stdout.decode("utf-8", "ignore").splitlines() if l.strip()]


def _fix_indic(pg, ms):
    """Indic text with a broken Unicode map: read those paragraphs again with OCR (the glyphs on screen are right).
    The pictures are cut out here, the (slow) recognition runs in parallel."""
    from concurrent.futures import ThreadPoolExecutor
    have = tess_langs()
    jobs = []
    for m in ms:
        lang = F.ocr_lang_for(m["text"])
        if not lang or lang not in have:
            continue
        try:
            pix = pg.get_pixmap(clip=pymupdf.Rect(m["bbox"]) + (-3, -3, 3, 3), dpi=300, colorspace=pymupdf.csGRAY)
            jobs.append((m, lang + ("+eng" if "eng" in have else ""), pix.tobytes("png")))
        except Exception:
            continue

    def read(job):
        try:
            r = subprocess.run(["tesseract", "stdin", "stdout", "-l", job[1], "--psm", "6"], input=job[2], capture_output=True, timeout=90,
                               env=dict(os.environ, OMP_THREAD_LIMIT="1"))
            return [l.strip() for l in r.stdout.decode("utf-8", "ignore").splitlines() if l.strip()]
        except Exception:
            return []

    if not jobs:
        return
    with ThreadPoolExecutor(max_workers=max(1, min(6, os.cpu_count() or 2))) as ex:
        results = list(ex.map(read, jobs))
    for (m, _, _), got in zip(jobs, results):
        if not got:
            continue
        fam = next((F.script_of(c) for c in m["text"] if F.script_of(c)), None) or next((F.script_of(c) for l in got for c in l if F.script_of(c)), None) or m["fam"]
        base = {"b": m["bold"], "i": 0, "c": m["color"], "s": m["size"], "f": "", "fam": fam}
        text = " ".join(got) if not m["single"] and len(m["paras"]) == 1 else "\n".join(got)
        m["paras"] = [[dict(base, t=t)] for t in text.split("\n")]
        m["text"] = text; m["fam"] = fam; m["reread"] = True


def _ink_color(pg, rect):
    pix = pg.get_pixmap(clip=rect, dpi=100)
    px = [tuple(pix.pixel(x, y)[:3]) for y in range(0, pix.height, 2) for x in range(0, pix.width, 2)]
    if not px:
        return "#000000"
    px.sort(key=sum)
    dark = px[: max(1, len(px) // 12)]
    return "#%02x%02x%02x" % tuple(int(statistics.median(c[i] for c in dark)) for i in range(3))


def _bg_color(pg, rect):
    ring = (pymupdf.Rect(rect) + (-4, -4, 4, 4)) & pg.rect
    pix = pg.get_pixmap(clip=ring, dpi=72)
    px = [pix.pixel(x, y)[:3] for x in range(pix.width) for y in (0, pix.height - 1)] + \
         [pix.pixel(x, y)[:3] for y in range(pix.height) for x in (0, pix.width - 1)]
    if not px:
        return (1, 1, 1)
    return tuple(statistics.median(c[i] for c in px) / 255 for i in range(3))


def fit_size(text, width, h, family="liberationsans", bold=False):
    """font size that makes `text` as wide as the scanned line (clamped by the line height)."""
    try:
        f = pymupdf.Font(fontfile=F.face(family, bold, False)[0])
        L = f.text_length(text, fontsize=1)
        s = width / L if L else h * 0.8
    except Exception:
        s = h * 0.8
    return round(max(h * 0.55, min(s, h * 1.1)), 1)


def _scan_style(pg, line_rect, text):
    """Which font class did the scanner see? Render the OCR text in sans / serif / mono, regular / bold,
    and keep the candidate whose ink overlaps the scanned pixels best."""
    if not text or sum(1 for c in text if ord(c) < 128) < 0.9 * len(text) or len(text) < 3:
        return None
    try:
        import numpy as np
        from PIL import Image, ImageDraw, ImageFont
        pix = pg.get_pixmap(clip=line_rect, dpi=150, colorspace=pymupdf.csGRAY)
        a = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width)
        m = a < (int(a.min()) + int(np.median(a))) // 2
        if m.sum() < 20:
            return None
        ys, xs = np.where(m)
        m = m[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
        H, W = m.shape
        best = (0.0, "liberationsans", 0)
        for fam in ("liberationsans", "liberationserif", "liberationmono"):
            for bold in (0,):
                f = ImageFont.truetype(F.face(fam, bool(bold), False)[0], 72)
                l, t, r, b = f.getbbox(text)
                if r - l < 5 or b - t < 5:
                    continue
                im = Image.new("L", (r - l, b - t), 0)
                ImageDraw.Draw(im).text((-l, -t), text, font=f, fill=255)
                c = np.asarray(im.resize((W, H), Image.BILINEAR)) > 100
                iou = float((c & m).sum()) / max(1, int((c | m).sum()))
                if iou > best[0]:
                    best = (iou, fam, bold)
        return best if best[0] > 0.2 else None
    except Exception:
        return None


def _ink_ratio(pg, rect):
    pix = pg.get_pixmap(clip=rect, dpi=100, colorspace=pymupdf.csGRAY)
    s = pix.samples
    return sum(1 for v in s if v < 128) / max(1, len(s))


def _ocr_blocks(pg, lang):
    tp = pg.get_textpage_ocr(flags=TEXT_FLAGS, language=ocr_langs(lang), dpi=300, full=True, tessdata=TESSDATA)
    return layout(pg, textpage=tp)


def _scan_block_model(pg, blk, blocks):
    longest = max(blk["lines"], key=lambda l: l["bbox"].width)
    text = "".join(s["text"] for s in longest["spans"]).strip()
    h = statistics.median(l["bbox"].height for l in blk["lines"])
    guess = _scan_style(pg, longest["bbox"], text)
    script = next((F.script_of(c) for c in text if F.script_of(c)), None)
    fam = script or (guess[1] if guess else "liberationsans")
    size = fit_size(text, longest["bbox"].width, h, fam if not script else "liberationsans", False)
    style = {"b": 0, "i": 0, "c": _ink_color(pg, blk["bbox"]), "s": size, "fam": fam}
    m = _block_model(blk, pg.rect, blocks, scanned=True, style=style)
    m["line_h"] = round(h, 2); m["_ink"] = _ink_ratio(pg, blk["bbox"]); m["_w"] = (text, longest["bbox"].width)
    return m


def _mark_bold(ms):
    """bold = clearly more ink than the ordinary paragraphs of the same page."""
    if len(ms) < 3:
        return
    inks = sorted(m["_ink"] for m in ms)
    base = inks[len(inks) // 4]
    for m in ms:
        if m["_ink"] > base * 1.4:
            size = fit_size(m["_w"][0], m["_w"][1], m["line_h"], m["fam"] if m["fam"] not in COMPLEX else "liberationsans", True)
            m["bold"] = 1; m["size"] = size
            for p in m["paras"]:
                for r in p:
                    r["b"] = 1; r["s"] = size


def page_model(doc, pno, lang="eng+hin", cache_dir=None):
    pg = doc[pno]
    vis, invis, cover, inv = page_stats(pg)
    scanned = cover >= 0.6 and vis < 20
    hybrid = cover >= 0.6 and not scanned
    cache = Path(cache_dir) / f"ocr_{pno}_{re.sub(r'[^a-z+]', '', lang)}.json" if (cache_dir and (scanned or hybrid)) else None
    if cache and cache.exists():
        return json.loads(cache.read_text())
    out = []
    dig = [] if scanned else layout(pg, inv)
    hl = _hlines(pg) if dig else []
    vr = _vrules(pg) if dig else []
    for b in dig:
        out.append(_block_model(b, pg.rect, dig, hl=hl, vrules=vr))
    sus = [m for m in out if F.indic_suspicious(m["text"])]
    if sus:
        _fix_indic(pg, sus)
    if scanned or hybrid:
        try:
            ocr = _ocr_blocks(pg, lang)
        except Exception:
            ocr = []
        if hybrid:  # keep OCR paragraphs only where there is no real text
            ocr = [o for o in ocr if not any((o["bbox"] & d["bbox"]).get_area() > 0.3 * o["bbox"].get_area() for d in dig)]
        allb = dig + ocr
        sm = [_scan_block_model(pg, o, allb) for o in ocr]
        _mark_bold(sm)
        for m in sm:
            m.pop("_ink", None); m.pop("_w", None)
        out += sm
    for i, m in enumerate(out):
        m["id"] = i
    area = pg.rect.get_area()
    images = []
    if not scanned:
        for im in pg.get_image_info(xrefs=True):
            r = pymupdf.Rect(im["bbox"]) & pg.rect
            if im.get("xref") and 0.002 * area < r.get_area() < 0.6 * area:
                images.append({"bbox": [round(v, 2) for v in r], "xref": im["xref"]})
    links = [{"rect": [round(v, 2) for v in l["from"]], "uri": l.get("uri"), "page": (l.get("page", -1) + 1) or None}
             for l in pg.get_links() if l.get("kind") in (pymupdf.LINK_URI, pymupdf.LINK_GOTO)]
    annots = [{"rect": [round(v, 2) for v in a.rect], "type": a.type[1], "xref": a.xref} for a in (pg.annots() or [])
              if a.type[0] not in (pymupdf.PDF_ANNOT_WIDGET, pymupdf.PDF_ANNOT_LINK, pymupdf.PDF_ANNOT_POPUP)]
    res = {"page": pno, "width": pg.rect.width, "height": pg.rect.height, "scanned": scanned, "hybrid": hybrid,
           "blocks": out, "images": images, "links": links, "annots": annots}
    if cache:
        cache.write_text(json.dumps(res))
    return res


# ------------------------------------------------------------------ fonts for typesetting
_ORIG = {}


def _norm_font(n):
    n = re.sub(r"[^a-z0-9]", "", (n or "").split("+")[-1].lower())
    for t in ("psmt", "mt", "regular", "roman"):
        if n.endswith(t) and len(n) > len(t) + 2:
            n = n[: -len(t)]
    return n


def _fix_cmap(buf, pairs):
    """Subset TrueType fonts inside PDFs usually have no character map. Rebuild one from the
    (unicode → glyph id) pairs MuPDF saw on the page, so the font can be used to typeset again."""
    from fontTools.ttLib import TTFont, newTable
    from fontTools.ttLib.tables._c_m_a_p import CmapSubtable
    f = TTFont(io.BytesIO(buf), lazy=False, recalcBBoxes=False, recalcTimestamp=False)
    order = f.getGlyphOrder()
    mapping = {u: order[g] for u, g in pairs.items() if 0 < g < len(order) and 32 <= u}
    if not mapping:
        return None
    if 32 not in mapping and "cmap" in f:  # keep whatever mapping already exists (space etc.)
        for t in f["cmap"].tables:
            if t.isUnicode():
                for u, name in t.cmap.items():
                    mapping.setdefault(u, name)
    cm = newTable("cmap"); cm.tableVersion = 0; cm.tables = []
    bmp = {u: n for u, n in mapping.items() if u < 0x10000}
    for fmt, plat, enc, data in ((4, 3, 1, bmp), (12, 3, 10, mapping)):
        if fmt == 12 and len(bmp) == len(mapping):
            continue
        st = CmapSubtable.newSubtable(fmt); st.platformID, st.platEncID, st.language, st.cmap = plat, enc, 0, data
        cm.tables.append(st)
    f["cmap"] = cm
    _no_ligatures(f)
    out = io.BytesIO(); f.save(out)
    return out.getvalue()


def _page_pairs(pg):
    pairs = {}
    try:
        for t in pg.get_texttrace():
            d = pairs.setdefault(_norm_font(t["font"]), {})
            for c in t["chars"]:
                d.setdefault(c[0], c[1])
    except Exception:
        pass
    return pairs


def orig_font(doc, pg, fontname, need):
    """The PDF's own embedded font, if it can draw every character in `need` → (tag, buffer, ext) or None."""
    if not fontname:
        return None
    want = _norm_font(fontname)
    ck = (id(doc), pg.number, want)
    if ck not in _ORIG:
        cands = []
        pairs = None
        for f in pg.get_fonts(full=True):
            xref, ext, ftype, base = f[0], f[1], f[2], f[3]
            if _norm_font(base) != want or ftype == "Type3" or ext in ("n/a", ""):
                continue
            try:
                _, ext2, _, buf = doc.extract_font(xref)
                if not buf:
                    continue
                if buf[:4] in (b"\x00\x01\x00\x00", b"true"):
                    if pairs is None:
                        pairs = _page_pairs(pg)
                    try:
                        buf = _fix_cmap(buf, pairs.get(want, {})) or buf
                    except Exception:
                        pass
                    ext2 = "ttf"
                elif buf[:4] == b"OTTO":
                    ext2 = "otf"
                cands.append((f"orig{xref}", buf, ext2 if ext2 not in ("n/a", "cid", "") else "cff", pymupdf.Font(fontbuffer=buf)))
            except Exception:
                continue
        _ORIG[ck] = cands
        if len(_ORIG) > 400:
            for k in list(_ORIG)[:200]:
                _ORIG.pop(k, None)
    for tag, buf, ext, fnt in _ORIG[ck]:
        try:
            if all(fnt.has_glyph(ord(ch)) for ch in need):
                return tag, buf, ext
        except Exception:
            continue
    return None


@functools.lru_cache(maxsize=128)
def _font_obj(fam):
    return pymupdf.Font(fontfile=F.face(fam, False, False)[0])


def _covers(fam, text):
    try:
        f = _font_obj(fam)
        return all(f.has_glyph(ord(ch)) for ch in text if not ch.isspace() and ch not in "\u200c\u200d")
    except Exception:
        return False


def _no_ligatures(f):
    """Switch off fi / fl / ti … ligatures in a font (fontTools TTFont, changed in place). A ligature is ONE glyph for several
    letters – readers that copy or search the PDF then get "conﬁdenࢢal" instead of "confidential". Returns True if changed."""
    changed = False
    if "GSUB" in f:
        try:
            for rec in f["GSUB"].table.FeatureList.FeatureRecord:
                if rec.FeatureTag in ("liga", "dlig", "clig", "hlig") and rec.Feature.LookupListIndex:
                    rec.Feature.LookupListIndex = []; rec.Feature.LookupCount = 0; changed = True
        except Exception:
            pass
    try:   # a glyph shared by several characters (space = no-break space) must read back as the ordinary one
        for t in f["cmap"].tables:
            if t.isUnicode() and t.cmap.get(0x20) and t.cmap.get(0xA0) == t.cmap.get(0x20):
                del t.cmap[0xA0]; changed = True
    except Exception:
        pass
    return changed


@functools.lru_cache(maxsize=96)
def embed_bytes(path):
    """font file as it is embedded for Latin / Greek / Cyrillic text: same letters, no ligatures."""
    raw = F.file_bytes(path)
    try:
        from fontTools.ttLib import TTFont
        f = TTFont(io.BytesIO(raw), lazy=False, recalcBBoxes=False, recalcTimestamp=False)
        if _no_ligatures(f):
            out = io.BytesIO(); f.save(out)
            return out.getvalue()
    except Exception:
        pass
    return raw


class Faces:
    """@font-face rules + archive for one piece of HTML."""

    def __init__(self):
        self.css, self.arch, self.seen = [], pymupdf.Archive(), set()

    def _reg(self, tag, data, ext):
        if tag not in self.seen:
            self.seen.add(tag)
            self.arch.add((data, f"{tag}.{ext}"))
            self.css.append(f"@font-face {{font-family: {tag}; src: url({tag}.{ext});}}")
        return tag

    def family(self, fam, bold, italic):
        path, (fb, fi) = F.face(fam, bool(bold), bool(italic))
        tag = "f" + hashlib.md5(path.encode()).hexdigest()[:10]
        self._reg(tag, F.file_bytes(path) if fam in COMPLEX else embed_bytes(path), Path(path).suffix.lstrip(".").lower())
        return tag, bool(bold) and not fb, bool(italic) and not fi

    def orig(self, o):
        return self._reg(o[0], o[1], o[2])


class _Html(tuple):
    """(html, css, archive) plus .segs = the logical text of every span, in order."""
    segs = ()


def build_html(paras, align, lh, doc=None, pg=None, scale=1.0, nowrap=False):
    """rich-text paragraphs → (html, css, archive)."""
    faces = Faces()
    use = {}
    segs = _Segs()
    segs.fancy = any((r.get("fam") in HANDWRITING) for p in paras for r in p)
    if doc is not None:
        need = {}
        for p in paras:
            for r in p:
                if r.get("f"):
                    need.setdefault(r["f"], set()).update(ch for ch in r["t"] if not ch.isspace() and not F.script_of(ch))
        for name, chars in need.items():
            o = orig_font(doc, pg, name, chars)
            if o:
                use[name] = o
    out = []
    for p in paras:
        if not any(r["t"] for r in p):
            s = (p[0]["s"] if p else 11) * scale
            out.append(f'<p style="font-size:{s:.2f}px">&nbsp;</p>'); continue
        bits = []
        for r in p:
            size = float(r.get("s") or 11) * scale
            for script, text in F.split_scripts(r["t"]):
                weight = style = "normal"
                if script and (F.has(script) or F.has(r.get("fam") or "")):
                    fam = r["fam"] if (r.get("fam") and F.has(r["fam"]) and _covers(r["fam"], text)) else script
                    tag, sb, si = faces.family(fam, r.get("b"), r.get("i"))
                    weight, style = ("bold" if sb else "normal"), ("italic" if si else "normal")
                elif r.get("f") in use and not script:
                    tag = faces.orig(use[r["f"]])
                else:
                    fam = r.get("fam") if F.has(r.get("fam") or "") else "liberationsans"
                    if not _covers(fam, text):   # e.g. English words inside a run set in a Hindi-only font
                        fam = next((f for f in ("notosans", "liberationsans", "dejavusans") if F.has(f) and _covers(f, text)), fam)
                    tag, sb, si = faces.family(fam, r.get("b"), r.get("i"))
                    weight, style = ("bold" if sb else "normal"), ("italic" if si else "normal")
                deco = "underline" if r.get("u") else ("line-through" if r.get("st") else "none")
                segs.append(text)
                bits.append(f'<span style="font-family:{tag};font-size:{size:.2f}px;color:{r.get("c") or "#000000"};'
                            f'font-weight:{weight};font-style:{style};text-decoration:{deco}">{_h.escape(text)}</span>')
        out.append("<p>" + "".join(bits) + "</p>")
    css = "\n".join(faces.css) + (f"\np {{margin:0; padding:0; text-align:{align if align in ('left', 'center', 'right', 'justify') else 'left'};"
                                  f" line-height:{lh}; white-space:{'pre' if nowrap else 'pre-wrap'};}}")
    res = _Html(("".join(out), css, faces.arch)); res.segs = segs
    return res


# ------------------------------------------------------------------ real Unicode for complex scripts (/ActualText)
_TJ = re.compile(rb"\[((?:\s*<[0-9A-Fa-f\s]*>|\s*-?[0-9.]+)*)\s*\]\s*TJ|<([0-9A-Fa-f\s]*)>\s*Tj")
_REORDER = COMPLEX - {"notonaskharabic", "notosanshebrew", "notosansthai"}   # scripts whose glyph order differs from the letters typed


HANDWRITING = {"dancingscript", "greatvibes", "caveat", "sacramento"}   # joined-up fonts swap letter shapes by context


def needs_actualtext(segs):
    return getattr(segs, "fancy", False) or any(F.script_of(ch) in _REORDER for t in segs for ch in t)


class _Segs(list):
    fancy = False


def add_actualtext(doc, pg, old_xrefs, segs):
    """Hindi, Bengali, Tamil … are drawn with reordered glyphs and ligatures, so readers that copy or search the PDF get garbage.
    Every text run just written gets an /ActualText with the letters as typed → copy, search and screen readers work
    (Acrobat, Chrome, Edge, Firefox, Preview). Words are matched run by run; if anything does not add up nothing is changed."""
    try:
        if any(F.script_of(ch) in ("notonaskharabic", "notosanshebrew") for t in segs for ch in t):
            return False   # right-to-left text is emitted in visual order – left alone
        new = [x[0] for x in pg.get_xobjects() if x[0] not in old_xrefs and x[1] == "fullpage"]
        if len(new) != 1:
            return False
        raw = doc.xref_stream(new[0])
        ops = list(_TJ.finditer(raw))
        gid_lists = []
        for m in ops:
            hexs = b"".join(re.findall(rb"<([0-9A-Fa-f\s]*)>", m.group(1))) if m.group(1) is not None else m.group(2)
            hexs = re.sub(rb"\s", b"", hexs)
            if len(hexs) % 4:
                return False
            gid_lists.append([int(hexs[i:i + 4], 16) for i in range(0, len(hexs), 4)])
        total = sum(len(g) for g in gid_lists)
        trace = [(c[0], c[1], c[2]) for sp in pg.get_texttrace() for c in sp["chars"]]
        tail = [(u, g) for u, g, _ in trace[-total:]] if total else []
        origins = [o for _, _, o in trace[-total:]] if total else []
        if not total or [g for _, g in tail] != [g for gl in gid_lists for g in gl]:
            return False
        words = [w for t in segs for w in re.findall(r"\S+", t)]
        wi, pos, pieces = 0, 0, []
        for gl in gid_lists:
            txt, seen, inword = "", "", False
            for u, _ in tail[pos:pos + len(gl)]:
                seen += " " if u in (32, 160) else chr(u) if 0 < u < 0x110000 else "\ufffd"
                if u in (32, 160):
                    txt += " "; inword = False
                elif not inword:
                    if wi >= len(words):
                        return False
                    txt += words[wi]; wi += 1; inword = True
            pos += len(gl)
            pieces.append((txt, seen))
        if wi != len(words):
            return False
        if not any(t != seen for t, seen in pieces):
            return False
        # runs of one line are wrapped together: other readers then get the whole line as typed, with no gaps at font changes
        ys, pos = [], 0
        for gl in gid_lists:
            ys.append(origins[pos][1] if gl else None); pos += len(gl)
        groups, cur = [], []
        for k, m in enumerate(ops):
            if cur and (ys[k] is None or ys[cur[-1]] is None or abs(ys[k] - ys[cur[-1]]) > 0.6 or re.search(rb"\b(ET|BT|EMC|BDC|Do)\b", raw[ops[cur[-1]].end():m.start()])):
                groups.append(cur); cur = []
            cur.append(k)
        if cur:
            groups.append(cur)
        out, last = [], 0
        for g in groups:
            first, end = ops[g[0]], ops[g[-1]]
            out.append(raw[last:first.start()])
            if any(pieces[k][0] != pieces[k][1] for k in g):   # the glyphs do not read back as typed (reordering, conjuncts, contextual shapes)
                text = "".join(pieces[k][0] for k in g)
                counts = " ".join(str(len(pieces[k][0])) for k in g)
                out.append(b"/Span <</ActualText <FEFF" + text.encode("utf-16-be").hex().upper().encode() + b"> /PKr [" + counts.encode() + b"]>> BDC "
                           + raw[first.start():end.end()] + b" EMC")
            else:
                out.append(raw[first.start():end.end()])
            last = end.end()
        out.append(raw[last:])
        doc.update_stream(new[0], b"".join(out))
        return True
    except Exception:
        return False


def htmlbox(doc, pg, rect, built, scale_low=1):
    """insert_htmlbox + /ActualText for complex scripts. `built` = result of build_html()."""
    html, css, arch = built
    need = needs_actualtext(getattr(built, "segs", ()))
    old = {x[0] for x in pg.get_xobjects()} if need else ()
    res = pg.insert_htmlbox(rect, html, css=css, archive=arch, scale_low=scale_low)
    if need:
        add_actualtext(doc if doc is not None else pg.parent, pg, old, built.segs)
    return res


def measure(width, html, css, arch):
    """lay the HTML out on a scratch page → {"h": box height, "base": first baseline, "bottom": last line bottom, "width": widest line}."""
    t = pymupdf.open(); p = t.new_page(width=width + 20, height=6000)
    spare, _ = p.insert_htmlbox(pymupdf.Rect(0, 0, width, 6000), html, css=css, archive=arch, scale_low=1)
    lines = [l for b in p.get_text("dict")["blocks"] if b["type"] == 0 for l in b["lines"]]
    t.close()
    if not lines:
        return {"h": 0.0, "base": 0.0, "bottom": 0.0, "width": 0.0}
    top = min(lines, key=lambda l: l["bbox"][1])
    base = min(s["origin"][1] for s in top["spans"]) if top["spans"] else top["bbox"][3]
    rows = {}
    for l in lines:  # spans of one visual line may be reported as several "lines"
        k = round(l["bbox"][3])
        r = rows.setdefault(k, [l["bbox"][0], l["bbox"][2]])
        r[0] = min(r[0], l["bbox"][0]); r[1] = max(r[1], l["bbox"][2])
    return {"h": (6000 - spare if spare >= 0 else 6000), "base": base, "bottom": max(l["bbox"][3] for l in lines),
            "width": max(r[1] - r[0] for r in rows.values())}


def typeset(pg, x0, x1, base_y, paras, align, lh, doc=None, scale=1.0, top_y=None, nowrap=False):
    """write paragraphs so that the first baseline lands on base_y (or the box starts at top_y)."""
    built = build_html(paras, align, lh, doc, pg, scale, nowrap)
    w = max(10.0, x1 - x0)
    m = measure(6000 if nowrap else w, *built)
    if m["h"] <= 0 and not nowrap:   # one unbreakable word wider than the box: better to run over than to lose the text
        nowrap = True
        built = build_html(paras, align, lh, doc, pg, scale, True); m = measure(6000, *built)
    if m["h"] <= 0:
        return None
    y0 = (base_y - m["base"]) if base_y is not None else (top_y or 0)
    if nowrap:   # single line: the box is as wide as the text and placed according to the alignment
        cw = m["width"] + 3
        xa = x1 - cw if align == "right" else (x0 + x1 - cw) / 2 if align == "center" else x0
        r = pymupdf.Rect(xa, y0, xa + cw, y0 + m["h"] + 3)
    else:
        r = pymupdf.Rect(x0, y0, x0 + w, y0 + m["h"] + 3)
    htmlbox(pg.parent, pg, r, built)
    return r


# ------------------------------------------------------------------ one line of text in any language (stamps, watermarks, labels)
def page_resource(doc, pg, kind, name, body):
    """Add one entry (e.g. an ExtGState) to the page's resources – also when they are shared or inherited from the page tree."""
    t, v = doc.xref_get_key(pg.xref, "Resources")
    if t == "xref":
        rx, pre = int(v.split()[0]), ""
    elif t == "dict":
        rx, pre = pg.xref, "Resources/"
    else:   # inherited from a parent node: give the page its own copy first
        rx, pre, x = pg.xref, "Resources/", pg.xref
        found = "<<>>"
        for _ in range(60):
            pt, pv = doc.xref_get_key(x, "Parent")
            if pt != "xref":
                break
            x = int(pv.split()[0])
            rt, rv = doc.xref_get_key(x, "Resources")
            if rt == "xref":
                found = doc.xref_object(int(rv.split()[0]), compressed=True); break
            if rt == "dict":
                found = rv; break
        doc.xref_set_key(pg.xref, "Resources", found)
    t, v = doc.xref_get_key(rx, pre + kind)
    if t == "xref":
        doc.xref_set_key(int(v.split()[0]), name, body)
    else:
        doc.xref_set_key(rx, f"{pre}{kind}/{name}", body)
    return name


def needs_shaping(text, fam="liberationsans"):
    """True if the text cannot simply be written letter by letter with `fam` (Indic, Arabic, Thai … or missing glyphs)."""
    return any(F.script_of(ch) for ch in text) or not _covers(fam if F.has(fam) else "liberationsans", text)


def text_form(text, size, color="#000000", bold=False, italic=False, fam="liberationsans"):
    """One line of text in any script as a tiny PDF page: shaped, fonts embedded, searchable. → (doc, width, height, baseline)"""
    built = build_html([[{"t": text, "b": int(bool(bold)), "i": int(bool(italic)), "c": color, "s": size, "fam": fam, "f": ""}]], "left", 1.25, nowrap=True)
    m = measure(6000, *built)
    w, h = m["width"] + 3, m["bottom"] + 2
    t = pymupdf.open(); p = t.new_page(width=w, height=h)
    htmlbox(t, p, pymupdf.Rect(0, 0, w + 200, h + 50), built)
    try:
        t.subset_fonts()
    except Exception:
        pass
    return t, w, h, m["base"]


def put_text(pg, text, x, y, size, color="#000000", bold=False, italic=False, fam="liberationsans", anchor="left", angle=0.0,
             opacity=1.0, overlay=True, cache=None):
    """Write one line in ANY language. (x, y) = left / center / right end of the baseline (anchor); with an angle,
    (x, y) is the centre of the text, turned counter-clockwise by `angle` degrees. → text width"""
    import math
    key = ("form", text, size, color, bool(bold), bool(italic), fam)
    form = cache.get(key) if cache is not None else None
    if form is None:
        form = text_form(text, size, color, bold, italic, fam)
        if cache is not None:
            cache[key] = form
    t, w, h, base = form
    if angle:
        a = math.radians(angle)
        W, H = abs(w * math.cos(a)) + abs(h * math.sin(a)), abs(w * math.sin(a)) + abs(h * math.cos(a))
        rect = pymupdf.Rect(x - W / 2, y - H / 2, x + W / 2, y + H / 2)
    else:
        x0 = x if anchor == "left" else x - w / 2 if anchor == "center" else x - w
        rect = pymupdf.Rect(x0, y - base, x0 + w, y - base + h)
    before = set(pg.get_contents())
    pg.show_pdf_page(rect, t, 0, rotate=angle, overlay=overlay)
    if opacity < 0.995:
        doc = pg.parent
        gs = page_resource(doc, pg, "ExtGState", f"PKop{int(round(opacity * 100)):02d}", f"<</Type/ExtGState/ca {opacity:.2f}/CA {opacity:.2f}>>")
        for xr in pg.get_contents():
            if xr not in before:
                st = doc.xref_stream(xr)
                if st and b" Do" in st and b" gs " not in st:
                    doc.update_stream(xr, re.sub(rb"(/fzFrm\d+\s+Do)", b"/" + gs.encode() + b" gs \\1", st, count=1))
    return w


# ------------------------------------------------------------------ lossless move of text (reflow)
def _mid(r):
    r = pymupdf.Rect(r)
    return pymupdf.Point((r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2)


def _row_mates(blocks, bbox):
    """other blocks on the same row (left / right of bbox) → the block is a table cell or a form value."""
    out = []
    for o in blocks:
        r = o["bbox"]
        if abs(r.x0 - bbox.x0) < 0.5 and abs(r.y0 - bbox.y0) < 0.5:
            continue
        ov = min(r.y1, bbox.y1) - max(r.y0, bbox.y0)
        if ov > 0.5 * min(r.height, bbox.height) and (r.x1 <= bbox.x0 + 1 or r.x0 >= bbox.x1 - 1):
            out.append(o)
    return out


def _region_below(pg, blocks, bbox):
    """What has to travel when the paragraph in `bbox` changes height: the text below it in the same column
    plus tables / boxes / pictures that belong to that text. → (strip rect, top of first moved line) or None."""
    foot, floor = pg.rect.height * FOOT, bbox.y1 - 1
    col = [b for b in blocks if floor <= b["bbox"].y0 <= foot and min(b["bbox"].x1, bbox.x1) - max(b["bbox"].x0, bbox.x0) > 2]
    if not col:
        return None
    strip = _union(b["bbox"] for b in col)
    extra = [pymupdf.Rect(i["bbox"]) for i in pg.get_image_info()]
    try:
        dr = pg.get_cdrawings()
        if len(dr) <= 6000:
            extra += [pymupdf.Rect(d["rect"]) + (-0.5, -0.5, 0.5, 0.5) for d in dr]
    except Exception:
        pass
    area = pg.rect.get_area()
    extra = [r for r in extra if r.y0 >= floor and r.y1 <= pg.rect.height - 4 and r.get_area() < 0.85 * area]
    for _ in range(5):
        grown = pymupdf.Rect(strip)
        for r in extra:
            if r.intersects(strip + (-2, -2, 2, 2)):
                grown |= r
        for b in blocks:
            if floor <= b["bbox"].y0 <= foot and _mid(b["bbox"]) in grown:
                grown |= b["bbox"]
        if grown == strip:
            break
        strip = grown
    top = min(b["bbox"].y0 for b in blocks if floor <= b["bbox"].y0 and _mid(b["bbox"]) in strip)
    strip = (strip + (-2, -1, 2, 2)) & pg.rect
    strip.y0 = max(strip.y0, floor)
    return strip, top


def _put_link(pg, l, rect):
    """(re)create a link at rect – redactions delete the links they touch."""
    try:
        if any(x.get("xref") == l.get("xref") for x in pg.get_links()):
            pg.delete_link(l)
    except Exception:
        pass
    nl = {"kind": l["kind"], "from": pymupdf.Rect(rect)}
    for k in ("uri", "page", "to", "file", "zoom"):
        if k in l and l[k] is not None:
            nl[k] = l[k]
    try:
        pg.insert_link(nl)
    except Exception:
        pass


def move_region(doc, pg, strip, delta):
    """Move everything that lies completely inside `strip` (text, tables, boxes, pictures) by delta points –
    losslessly: the content is lifted into a form XObject and painted back at the new place."""
    if abs(delta) < 0.5:
        return
    big = strip + (-0.5, -0.5, 0.5, 0.5)
    links = [l for l in pg.get_links() if _mid(l["from"]) in strip]
    snap = pymupdf.open()
    snap.insert_pdf(doc, from_page=pg.number, to_page=pg.number, links=False, annots=False, widgets=False)
    sp = snap[0]
    NONE_I, NONE_G, KEEP_T = pymupdf.PDF_REDACT_IMAGE_NONE, pymupdf.PDF_REDACT_LINE_ART_NONE, pymupdf.PDF_REDACT_TEXT_NONE
    moved, n = [], 0
    for b in layout(sp):
        for l in b["lines"]:
            for s in l["spans"]:
                if not s["text"].strip():
                    continue
                if _mid(s["bbox"]) in strip:
                    moved.append(s)
                else:
                    sp.add_redact_annot(_band(s), fill=False); n += 1
    if n:
        sp.apply_redactions(images=NONE_I, graphics=NONE_G)
    imgs = [pymupdf.Rect(i["bbox"]) for i in pg.get_image_info()]
    inner = [r for r in imgs if r in big]
    spanning = [r for r in imgs if r.intersects(strip) and r not in big]
    R = sp.rect
    for r in (pymupdf.Rect(R.x0, R.y0, R.x1, strip.y0), pymupdf.Rect(R.x0, strip.y1, R.x1, R.y1),
              pymupdf.Rect(R.x0, strip.y0, strip.x0, strip.y1), pymupdf.Rect(strip.x1, strip.y0, R.x1, strip.y1)):
        if r.width > 0.2 and r.height > 0.2:
            sp.add_redact_annot(r, fill=False)
    # in the copy: keep only line art / pictures that are completely inside the strip
    sp.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_REMOVE, graphics=pymupdf.PDF_REDACT_LINE_ART_REMOVE_IF_TOUCHED, text=KEEP_T)
    move_images = bool(inner) and not spanning
    if inner and not move_images:
        for r in inner:
            sp.add_redact_annot(r + (0.5, 0.5, -0.5, -0.5), fill=False)
        sp.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_REMOVE, graphics=NONE_G, text=KEEP_T)
    # on the page: take the travelling content out …
    for s in moved:
        pg.add_redact_annot(_band(s), fill=False)
    if moved:
        pg.apply_redactions(images=NONE_I, graphics=NONE_G)
    pg.add_redact_annot(strip, fill=False)
    pg.apply_redactions(images=NONE_I, graphics=pymupdf.PDF_REDACT_LINE_ART_REMOVE_IF_COVERED, text=KEEP_T)
    if move_images:
        for r in inner:
            pg.add_redact_annot(r + (0.5, 0.5, -0.5, -0.5), fill=False)
        pg.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_REMOVE, graphics=NONE_G, text=KEEP_T)
    # … and paint it back, shifted
    pg.show_pdf_page(strip + (0, delta, 0, delta), snap, 0, clip=strip, overlay=True)
    snap.close()
    for l in links:
        _put_link(pg, l, pymupdf.Rect(l["from"]) + (0, delta, 0, delta))
    for w in list(pg.widgets()):
        if _mid(w.rect) in strip:
            try:
                w.rect = w.rect + (0, delta, 0, delta); w.update()
            except Exception:
                pass


# ------------------------------------------------------------------ scans: work inside the scan image
class ScanCanvas:
    """The page's scan image as a numpy array + page↔pixel mapping. Erase text (inpainting) and move strips in place."""

    def __init__(self, doc, pg):
        import numpy as np
        self.np, self.doc, self.pg, self.ok, self.dirty = np, doc, pg, False, False
        infos = [i for i in pg.get_image_info(xrefs=True) if i.get("xref") and
                 (pymupdf.Rect(i["bbox"]) & pg.rect).get_area() > 0.5 * pg.rect.get_area()]
        if not infos:
            return
        info = max(infos, key=lambda i: pymupdf.Rect(i["bbox"]).get_area())
        T = pymupdf.Matrix(info["transform"])
        if abs(T.b) > 1e-3 * max(1, abs(T.a)) and abs(T.a) > 1e-3 * max(1, abs(T.b)):
            return  # skewed image – not handled here
        try:
            pix = pymupdf.Pixmap(doc, info["xref"])
            if pix.alpha:
                pix = pymupdf.Pixmap(pix, 0)
            if pix.colorspace is None or pix.n not in (1, 3):
                pix = pymupdf.Pixmap(pymupdf.csRGB, pix)
            arr = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width, pix.n).copy()
        except Exception:
            return
        self.xref, self.inv, self.arr = info["xref"], ~T, arr
        self.H, self.W = arr.shape[:2]
        try:
            self.bilevel = doc.extract_image(self.xref).get("bpc") == 1
        except Exception:
            self.bilevel = False
        # image masks / inverted Decode arrays: compare with what the page really shows
        try:
            ref = pg.get_pixmap(clip=pymupdf.Rect(info["bbox"]) & pg.rect, dpi=24, colorspace=pymupdf.csGRAY)
            a = np.frombuffer(ref.samples, np.uint8).reshape(ref.height, ref.width).astype(np.int16)
            import cv2
            g = arr if arr.shape[2] == 1 else cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)
            b = cv2.resize(g.reshape(self.H, self.W), (ref.width, ref.height), interpolation=cv2.INTER_AREA).astype(np.int16)
            if abs(T.b) < 1e-3 and np.abs(a - b).mean() > np.abs(a - (255 - b)).mean() + 20:
                self.arr = 255 - self.arr
        except Exception:
            pass
        self.ok = True

    def px(self, rect):
        r = pymupdf.Rect(rect)
        pts = [pymupdf.Point(x, y) * self.inv for x, y in ((r.x0, r.y0), (r.x1, r.y0), (r.x1, r.y1), (r.x0, r.y1))]
        xs = [p.x * self.W for p in pts]; ys = [p.y * self.H for p in pts]
        x0, x1 = max(0, int(min(xs))), min(self.W, int(max(xs)) + 1)
        y0, y1 = max(0, int(min(ys))), min(self.H, int(max(ys)) + 1)
        return x0, y0, x1, y1

    def _ink_mask(self, roi, k):
        """pixels that are ink (text, lines) rather than paper: darker than the paper around them (or lighter, on dark paper).
        Faint halos around the letters (blur, JPEG) are included when they touch real ink – otherwise they stay behind as specks."""
        import cv2
        np = self.np
        gray = roi[:, :, 0] if roi.shape[2] == 1 else cv2.cvtColor(roi, cv2.COLOR_RGB2GRAY)
        k = int(min(61, max(9, k | 1)))
        kern = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
        dark_bg = float(np.median(gray)) < 110
        bg = cv2.morphologyEx(gray, cv2.MORPH_OPEN if dark_bg else cv2.MORPH_CLOSE, kern)
        diff = (gray.astype(np.int16) - bg) if dark_bg else (bg.astype(np.int16) - gray)
        strong = (diff > 28).astype(np.uint8)
        near = cv2.dilate(strong, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (11, 11)))
        mask = (((strong > 0) | ((diff > 9) & (near > 0))).astype(np.uint8)) * 255
        # the paper inside letters (e, a, o …) and between the strokes of one letter is brightened by the scan's ringing: treat it as ink too
        c = max(3, (k // 3) | 1)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (c, c)))
        g = max(3, (k // 5) | 1)                       # … and so is the bright rim that compression leaves around every stroke
        return cv2.dilate(mask, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (g, g)))

    def _inpaint(self, roi, mask):
        import cv2
        np = self.np
        src = roi if roi.shape[2] == 3 else roi[:, :, 0]
        fixed = cv2.inpaint(np.ascontiguousarray(src), mask, 4, cv2.INPAINT_TELEA)
        return fixed if roi.shape[2] == 3 else fixed[:, :, None]

    def erase(self, rects):
        """remove ink inside the rects, keep the paper (texture, shadows, colour)."""
        import cv2
        np = self.np
        for rect in rects:
            x0, y0, x1, y1 = self.px(rect)
            if x1 - x0 < 2 or y1 - y0 < 2:
                continue
            thin = min(y1 - y0, x1 - x0)  # the line height in pixels (the image may be stored sideways)
            pad = max(4, thin // 3)
            X0, Y0, X1, Y1 = max(0, x0 - pad), max(0, y0 - pad), min(self.W, x1 + pad), min(self.H, y1 + pad)
            roi = self.arr[Y0:Y1, X0:X1]
            mask = self._ink_mask(roi, thin // 2)
            inner = np.zeros_like(mask); inner[y0 - Y0:y1 - Y0, x0 - X0:x1 - X0] = 255
            mask = cv2.dilate(mask & inner, np.ones((3, 3), np.uint8), iterations=2) & cv2.dilate(inner, np.ones((5, 5), np.uint8))
            if not mask.any():
                continue
            if mask.mean() > 150:  # nearly everything is "ink" → flat fill with the surrounding colour
                ring = np.concatenate([roi[0].reshape(-1, roi.shape[2]), roi[-1].reshape(-1, roi.shape[2])])
                roi[y0 - Y0:y1 - Y0, x0 - X0:x1 - X0] = np.median(ring, axis=0).astype(np.uint8)
            else:
                roi[:] = self._inpaint(roi, mask)
            self.dirty = True

    def move(self, rect, delta):
        """shift the pixels of `rect` by delta page-points downwards (negative = up). The place they leave keeps its paper
        (only the ink is removed – a flat fill would show as a band on textured or unevenly lit paper) and the moved piece
        is blended in at its edges."""
        import cv2
        np = self.np
        x0, y0, x1, y1 = self.px(rect)
        d = pymupdf.Point(0, delta) * pymupdf.Matrix(self.inv.a, self.inv.b, self.inv.c, self.inv.d, 0, 0)
        sx, sy = int(round(d.x * self.W)), int(round(d.y * self.H))
        if (sx == 0 and sy == 0) or x1 <= x0 or y1 <= y0:
            return
        src = self.arr[y0:y1, x0:x1].copy()
        h, w = src.shape[:2]
        ppp = max(abs(sx), abs(sy)) / max(0.01, abs(delta))                     # picture pixels per page point
        f = int(max(1, min(8, 1.5 * ppp, h // 4, w // 4)))                       # width of the soft edge
        # 1) the area the piece leaves behind: what is not covered again by the piece at its new place, plus the rim under its soft edge
        vac = np.ones((h, w), bool)
        vac[max(0, sy) + f:min(h, h + sy) - f, max(0, sx) + f:min(w, w + sx) - f] = False
        ys, xs = np.where(vac)
        if len(ys):
            pad = int(8 * ppp) + 8
            a0, a1 = max(0, ys.min() - pad), min(h, ys.max() + 1 + pad)
            b0, b1 = max(0, xs.min() - pad), min(w, xs.max() + 1 + pad)
            roi = self.arr[y0 + a0:y0 + a1, x0 + b0:x0 + b1]
            mask = self._ink_mask(roi, int(6 * ppp))
            mask = cv2.dilate(mask, np.ones((3, 3), np.uint8), iterations=2)
            gone = vac[a0:a1, b0:b1]
            if mask[gone].mean() > 150:
                edge = self.arr[max(0, y0 - 3):y0 + 1, x0:x1].reshape(-1, self.arr.shape[2])
                roi[gone] = np.median(edge, axis=0).astype(np.uint8) if len(edge) else 255
            elif mask[gone].any():
                # the ink next to the gap is masked as well, so that it is not smeared into the gap – only the gap itself is rewritten
                roi[gone] = self._inpaint(roi, mask)[gone]
        # 2) the piece at its new place, with soft edges
        tx0, ty0 = x0 + sx, y0 + sy
        cx0, cy0, cx1, cy1 = max(0, tx0), max(0, ty0), min(self.W, tx0 + w), min(self.H, ty0 + h)
        if cx1 > cx0 and cy1 > cy0:
            ay = np.minimum(np.arange(h) + 1, np.arange(h)[::-1] + 1).clip(max=f) / f
            ax = np.minimum(np.arange(w) + 1, np.arange(w)[::-1] + 1).clip(max=f) / f
            alpha = np.minimum.outer(ay, ax)[cy0 - ty0:cy1 - ty0, cx0 - tx0:cx1 - tx0, None].astype(np.float32)
            part = src[cy0 - ty0:cy1 - ty0, cx0 - tx0:cx1 - tx0].astype(np.float32)
            under = self.arr[cy0:cy1, cx0:cx1].astype(np.float32)
            self.arr[cy0:cy1, cx0:cx1] = (part * alpha + under * (1 - alpha) + 0.5).astype(np.uint8)
        self.dirty = True

    def commit(self):
        if not (self.ok and self.dirty):
            return
        from PIL import Image
        a = self.arr
        im = Image.fromarray(a[:, :, 0] if a.shape[2] == 1 else a)
        buf = io.BytesIO()
        if self.bilevel:
            im.convert("L").point(lambda v: 255 if v > 127 else 0).convert("1").save(buf, "PNG", optimize=True)
        else:
            im.save(buf, "JPEG", quality=86)
        self.pg.replace_image(self.xref, stream=buf.getvalue())
        self.dirty = False


def rasterize_page(doc, pg, dpi=200):
    """Unusual scans (tiled strips, masks, skew): replace the page content by one clean picture of itself."""
    pix = pg.get_pixmap(dpi=dpi, alpha=False, annots=False)
    data = pix.tobytes("jpeg", jpg_quality=90)
    doc.xref_set_key(pg.xref, "Contents", "null")
    pg = doc.reload_page(pg)
    pg.insert_image(pg.rect, stream=data)
    return pg


def _drop_text(pg, rects):
    """remove (hidden OCR) text inside rects – pictures and graphics are not touched."""
    n = 0
    for r in rects:
        r = pymupdf.Rect(r)
        if not r.is_empty:
            pg.add_redact_annot(r, fill=False); n += 1
    if n:
        pg.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_NONE, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE)


# ------------------------------------------------------------------ operations
FOOT = 0.925  # blocks starting below this share of the page height are footers: they never move


def _limit(pg, blocks):
    foots = [b["bbox"].y0 for b in blocks if b["bbox"].y0 > pg.rect.height * FOOT]
    return (min(foots) - 4) if foots else pg.rect.height - 18


def op_edit_block(doc, pg, op, ctx):
    ctx.setdefault("touched", set()).add(pg.number)
    bbox = pymupdf.Rect(op["bbox"])
    paras = [[r for r in p if r.get("t")] for p in (op.get("paras") or [])]
    has_text = any(r["t"].strip() for p in paras for r in p)
    align, lh = op.get("align", "left"), float(op.get("lh") or 1.2)
    scanned, single = bool(op.get("scanned")), bool(op.get("single"))
    model = None
    if scanned:
        model = ctx["model"](pg.number)
        blocks = [{"bbox": pymupdf.Rect(b["bbox"])} for b in model["blocks"]]
        lines = [pymupdf.Rect(l) for l in (op.get("lines") or [list(bbox)])]
        target = []
    else:
        blocks = layout(pg, page_stats(pg)[3])
        target, lines = _spans_in(blocks, bbox), []
    cell = single and bool(_row_mates(blocks, bbox))
    lo, hi = _extent(blocks, bbox, pg.rect, () if scanned else _vrules(pg)) if blocks else (bbox.x0, bbox.x1)
    x0, x1 = _edit_x(bbox, align, single, lo, hi)
    x1 += 1.5
    base_y = op.get("base")
    src = None if scanned else doc
    foot = pg.rect.height * FOOT
    limit = _limit(pg, blocks) if bbox.y0 <= foot else pg.rect.height - 6
    region, delta, scale, nowrap = None, 0.0, 1.0, False
    reflow = op.get("reflow", True) and not cell

    def find_region():
        if not reflow:
            return None
        if not scanned:
            return _region_below(pg, blocks, bbox)
        below = [b for b in blocks if bbox.y1 - 1 <= b["bbox"].y0 <= foot and min(b["bbox"].x1, bbox.x1) - max(b["bbox"].x0, bbox.x0) > 2]
        if not below:
            return None
        return (_union(b["bbox"] for b in below) + (-2, -2, 2, 2)) & pg.rect, min(b["bbox"].y0 for b in below)

    if has_text and cell:  # table cell / form value: stay on one line, shrink a little if it does not fit
        nowrap = True
        m = measure(4000, *build_html(paras, align, lh, src, pg, 1.0, True))
        avail = max(10.0, x1 - x0 - 1.5)
        if m["width"] > avail:
            scale = max(0.55, avail / m["width"])
    elif has_text:
        fitted = False
        if op.get("fit"):  # translations: first try to stay inside the old box with slightly smaller letters
            for scale in (1.0, 0.95, 0.9, 0.85, 0.8):
                m = measure(max(10.0, x1 - x0), *build_html(paras, align, lh, src, pg, scale))
                y0 = (base_y - m["base"]) if base_y is not None else bbox.y0
                if y0 + m["bottom"] - bbox.y1 <= 1.5:
                    fitted = True
                    break
        if not fitted:
            region = find_region()
            if region:
                low, cap = region[0].y1, limit          # the travelling strip must stay above the footer
            else:                                       # nothing travels: the text may only grow into free space
                low = bbox.y1
                under = [b["bbox"].y0 for b in blocks if b["bbox"].y0 >= bbox.y1 - 1 and min(b["bbox"].x1, x1) - max(b["bbox"].x0, x0) > 2]
                cap = min([limit] + [y - 1 for y in under])
            for scale in ((0.85, 0.8, 0.75, 0.7, 0.65, 0.6, 0.55, 0.5) if op.get("fit") else (1.0, 0.95, 0.9, 0.85, 0.8, 0.75, 0.7, 0.65, 0.6)):
                m = measure(max(10.0, x1 - x0), *build_html(paras, align, lh, src, pg, scale))
                y0 = (base_y - m["base"]) if base_y is not None else bbox.y0
                delta = y0 + m["bottom"] - bbox.y1
                if delta <= 1.5 or low + delta <= cap:
                    break
            if not region or abs(delta) <= 1.5:
                delta = 0.0
            elif low + delta > limit:
                delta = max(0.0, limit - low)
    elif op.get("collapse"):  # paragraph deleted: pull the rest of the column up
        region = find_region()
        if region:
            delta = bbox.y0 - region[1]
    moving = bool(region) and abs(delta) > 1.5

    if scanned:
        cv = ctx["canvas"](pg)
        if not cv.ok and page_stats(pg)[0] < 20:
            pg = rasterize_page(doc, pg); ctx["reset"](pg); cv = ctx["canvas"](pg)
        strip = region[0] if moving else None
        if cv.ok:
            cv.erase([l + (-1, -1, 1, 1) for l in lines])
            if strip:
                cv.move(strip, delta)
            cv.commit()
        else:
            bg = _bg_color(pg, bbox)
            png = pg.get_pixmap(clip=strip, dpi=200).tobytes("png") if strip else None
            for r in [l + (-1, -1, 1, 1) for l in lines] + ([strip] if strip else []):
                pg.add_redact_annot(r, fill=bg)
            pg.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_PIXELS, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE)
            if png:
                pg.insert_image(strip + (0, delta, 0, delta), stream=png)
        vis, invis, _, inv = page_stats(pg)
        if invis:
            touched = lines + ([strip] if strip else [])
            _drop_text(pg, touched if vis < 20 else [i for i in inv if any(i.intersects(t) for t in touched)])
        if strip and model:  # keep the cached OCR model in step for further edits on this page
            for b in model["blocks"]:
                if b["bbox"][1] >= bbox.y1 - 1 and _mid(b["bbox"]) in strip:
                    b["bbox"][1] += delta; b["bbox"][3] += delta
                    b["lines"] = [[l[0], l[1] + delta, l[2], l[3] + delta] for l in b["lines"]]
                    b["base"] = b.get("base", 0) + delta
    else:
        relink = []
        for l in pg.get_links():
            lr = pymupdf.Rect(l["from"])
            if _mid(lr) in (bbox + (-2, -2, 2, 2)):
                words = "".join(s["text"] for s in target if _mid(s["bbox"]) in (lr + (-1, -3, 1, 3))).strip()
                relink.append((l, words))
        for s in target:
            pg.add_redact_annot(_band(s), fill=False)
        if target:
            pg.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_NONE, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE)
            pg.add_redact_annot(bbox + (-0.5, -0.5, 0.5, 1.5), fill=False)  # underlines / strike-through lines of the old text
            pg.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_NONE, graphics=pymupdf.PDF_REDACT_LINE_ART_REMOVE_IF_COVERED,
                                text=pymupdf.PDF_REDACT_TEXT_NONE)
            drop_empty_spans(pg)
        if moving:
            move_region(doc, pg, region[0], delta)
    if moving:
        ctx["shifts"].setdefault(pg.number, []).append((region[0].x0, region[0].x1, bbox.y1 - 1, delta))
    wrote = typeset(pg, x0, x1, base_y, paras, align, lh, src, scale, top_y=bbox.y0, nowrap=nowrap) if has_text else None
    if not scanned:
        for l, words in relink:
            hits = pg.search_for(words, clip=wrote) if (wrote and words) else []
            if hits:  # the link follows its words to their new position
                _put_link(pg, l, hits[0])
    return pg


def op_add_text(doc, pg, op):
    paras = op.get("paras") or [[{"t": op.get("text", ""), "b": op.get("bold"), "i": op.get("italic"), "c": op.get("color", "#000000"),
                                  "s": op.get("size", 12), "fam": op.get("family") or "liberationsans"}]]
    x, y = float(op["x"]), float(op["y"])
    w = float(op.get("w") or 0)
    x1 = min(pg.rect.width - 6, x + w) if w > 20 else pg.rect.width - 12
    typeset(pg, x, max(x + 30, x1), None, paras, op.get("align", "left"), float(op.get("lh") or 1.2), None, 1.0, top_y=y)


def op_shape(pg, op):
    import math
    k = op["type"]
    stroke = _rgb(op["stroke"]) if op.get("stroke") else None
    fill = _rgb(op["fill"]) if op.get("fill") else None
    w = float(op.get("width", 1.5)); opacity = float(op.get("opacity", 1))
    sh = pg.new_shape()
    if k in ("line", "arrow"):
        p1, p2 = pymupdf.Point(op["p1"]), pymupdf.Point(op["p2"])
        sh.draw_line(p1, p2)
        if k == "arrow":
            ang = math.atan2(p2.y - p1.y, p2.x - p1.x); L = 6 + w * 3
            for da in (2.6, -2.6):
                sh.draw_line(p2, pymupdf.Point(p2.x + L * math.cos(ang + da), p2.y + L * math.sin(ang + da)))
        sh.finish(color=stroke or (0, 0, 0), width=w, stroke_opacity=opacity, lineCap=1)
    else:
        r = pymupdf.Rect(op["rect"])
        sh.draw_oval(r) if k == "ellipse" else sh.draw_rect(r)
        sh.finish(color=stroke, fill=fill, width=w if stroke else 0, fill_opacity=opacity, stroke_opacity=opacity)
    sh.commit()


def op_whiteout(pg, op):
    r = pymupdf.Rect(op["rect"])
    color = _rgb(op.get("color", "#ffffff"))
    pg.add_redact_annot(r, fill=color)  # the text underneath is really removed, not just covered
    pg.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_PIXELS, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE)


def op_image(pg, op):
    data = op["data"].split(",", 1)[-1]
    pg.insert_image(pymupdf.Rect(op["rect"]), stream=base64.b64decode(data), keep_proportion=False)


def _remove_image_call(doc, pg, xref):
    """delete the command that paints one picture (the picture data disappears with garbage collection when the file is saved)."""
    done = 0
    try:
        for item in pg.get_images(full=True):
            if item[0] != xref:
                continue
            name, ref = item[7], item[9]
            for sx in ([ref] if ref else pg.get_contents()):
                raw = doc.xref_stream(sx)
                if not raw:
                    continue
                new, n = re.subn(rb"/" + re.escape(name.encode()) + rb"\s+Do\b", b"", raw)
                if n:
                    doc.update_stream(sx, new); done += n
    except Exception:
        return 0
    return done


def _find_image(pg, orig):
    """the picture at this place of the page (object numbers change every time a file is saved, positions do not)."""
    best = (0.6, None)
    for im in pg.get_image_info(xrefs=True):
        r = pymupdf.Rect(im["bbox"]) & pg.rect
        inter = (r & orig).get_area()
        union = r.get_area() + orig.get_area() - inter
        if im.get("xref") and union > 0 and inter / union > best[0]:
            best = (inter / union, im["xref"])
    return best[1]


def op_image_edit(doc, pg, op):
    """delete / move / resize / replace a picture that is already in the PDF."""
    orig = pymupdf.Rect(op["orig"])
    xref = _find_image(pg, orig) or int(op.get("xref") or 0)
    if not xref:
        raise ValueError("picture not found")
    data = None
    if op.get("data"):
        data = base64.b64decode(op["data"].split(",", 1)[-1])
    elif not op.get("delete"):
        try:
            pix = pymupdf.Pixmap(doc, xref)
            info = doc.extract_image(xref)
            if info.get("smask"):
                pix = pymupdf.Pixmap(pix if not pix.alpha else pymupdf.Pixmap(pix, 0), pymupdf.Pixmap(doc, info["smask"]))
            if pix.colorspace and pix.colorspace.n > 3:
                pix = pymupdf.Pixmap(pymupdf.csRGB, pix)
            data = pix.tobytes("png")
        except Exception:
            data = pg.get_pixmap(clip=orig, dpi=200).tobytes("png")
    uses = sum(1 for p in doc for im in p.get_images(full=True) if im[0] == xref)
    on_page = [i for i in pg.get_image_info(xrefs=True) if i.get("xref") == xref]
    if uses == 1 and len(on_page) == 1:
        if not _remove_image_call(doc, pg, xref):
            pg.delete_image(xref)
    else:  # shared picture (logo on every page): remove it here only
        pg.add_redact_annot(orig, fill=_bg_color(pg, orig))
        pg.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_PIXELS, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE, text=pymupdf.PDF_REDACT_TEXT_NONE)
    if data and not op.get("delete"):
        pg.insert_image(pymupdf.Rect(op.get("rect") or orig), stream=data, keep_proportion=False)


def op_markup(pg, op):
    quads = [pymupdf.Rect(r).quad for r in op["rects"]]
    a = {"highlight": pg.add_highlight_annot, "underline": pg.add_underline_annot, "strike": pg.add_strikeout_annot}[op["type"]](quads)
    if op.get("color"):
        a.set_colors(stroke=_rgb(op["color"])); a.update()


def op_ink(pg, op):
    a = pg.add_ink_annot([[tuple(p) for p in path] for path in op["paths"] if len(path) > 1])
    a.set_colors(stroke=_rgb(op.get("color", "#000000"))); a.set_border(width=float(op.get("width", 2))); a.update()


def op_link(pg, op):
    r = pymupdf.Rect(op["rect"])
    if op.get("url"):
        pg.insert_link({"kind": pymupdf.LINK_URI, "from": r, "uri": op["url"]})
    else:
        n = max(0, min(pg.parent.page_count - 1, int(op.get("target_page", 1)) - 1))
        pg.insert_link({"kind": pymupdf.LINK_GOTO, "from": r, "page": n, "to": pymupdf.Point(0, 0)})


def op_link_edit(pg, op):
    r = pymupdf.Rect(op["rect"])
    for l in pg.get_links():
        if (pymupdf.Rect(l["from"]) & r).get_area() > 0.6 * max(1e-3, r.get_area()):
            if op.get("delete") or not (op.get("url") or op.get("target_page")):
                pg.delete_link(l)
            else:
                if op.get("url"):
                    l.update(kind=pymupdf.LINK_URI, uri=op["url"])
                else:
                    l.update(kind=pymupdf.LINK_GOTO, page=int(op["target_page"]) - 1, to=pymupdf.Point(0, 0))
                pg.update_link(l)
            return


def op_field(pg, op):
    w = pymupdf.Widget()
    kinds = {"text": pymupdf.PDF_WIDGET_TYPE_TEXT, "multiline": pymupdf.PDF_WIDGET_TYPE_TEXT,
             "checkbox": pymupdf.PDF_WIDGET_TYPE_CHECKBOX, "radio": pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON,
             "dropdown": pymupdf.PDF_WIDGET_TYPE_COMBOBOX, "signature": pymupdf.PDF_WIDGET_TYPE_SIGNATURE}
    w.field_type = kinds[op["kind"]]
    w.field_name = op.get("name") or f"{op['kind']}_{int(op['rect'][0])}_{int(op['rect'][1])}"
    w.rect = pymupdf.Rect(op["rect"])
    w.text_fontsize = 0 if op["kind"] == "text" else 11
    if op["kind"] == "multiline":
        w.field_flags |= pymupdf.PDF_TX_FIELD_IS_MULTILINE
    if op["kind"] == "dropdown":
        w.choice_values = op.get("options") or ["Option 1", "Option 2"]
    if op.get("value") is not None and op["kind"] != "signature":
        w.field_value = op["value"] if op["kind"] not in ("checkbox", "radio") else bool(op["value"])
    if op.get("required"):
        w.field_flags |= pymupdf.PDF_FIELD_IS_REQUIRED
    w.border_color = (0.3, 0.4, 0.8); w.fill_color = (0.93, 0.95, 1)
    pg.add_widget(w)


def op_fill_forms(doc, op):
    vals = op.get("fields", {})
    for pg in doc:
        for w in pg.widgets():
            if w.field_name in vals:
                v = vals[w.field_name]
                if w.field_type == pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON:      # all buttons of a group share the name: the value says which one is on
                    w.field_value = w.on_state() if (v is True or (isinstance(v, str) and v == str(w.on_state()))) else "Off"
                elif w.field_type == pymupdf.PDF_WIDGET_TYPE_CHECKBOX:
                    w.field_value = w.on_state() if (v and v != "Off") else "Off"
                else:
                    w.field_value = str(v)
                w.update()


def _replace_runs(paras, find, repl, case=False):
    """replace inside rich-text runs; a match that crosses run borders takes the style of its first run."""
    n = 0
    flags = 0 if case else re.I
    pat = re.compile(re.escape(find), flags)
    out = []
    for p in paras:
        text = "".join(r["t"] for r in p)
        ms = list(pat.finditer(text))
        if not ms:
            out.append(p); continue
        n += len(ms)
        # character → run index
        owner = [i for i, r in enumerate(p) for _ in r["t"]]
        new = [dict(r, t="") for r in p]
        pos = 0
        for m in ms:
            for k in range(pos, m.start()):
                new[owner[k]]["t"] += text[k]
            new[owner[m.start()]]["t"] += repl
            pos = m.end()
        for k in range(pos, len(text)):
            new[owner[k]]["t"] += text[k]
        out.append([r for r in new if r["t"]])
    return out, n


def op_find_replace(doc, op, ctx):
    find, repl = op.get("find") or "", op.get("replace", "")
    if not find:
        return 0
    total = 0
    for pno in range(doc.page_count):
        pg = doc[pno]
        if find.lower() not in pg.get_text().lower() and not ctx["has_ocr"](pno):
            continue
        model = ctx["model"](pno, fresh=True)
        hits = []
        for b in model["blocks"]:
            paras, n = _replace_runs(b["paras"], find, repl, op.get("case"))
            if n:
                hits.append((b, paras)); total += n
        for b, paras in sorted(hits, key=lambda x: -x[0]["bbox"][1]):
            pg = op_edit_block(doc, pg, {"bbox": b["bbox"], "paras": paras, "align": b["align"], "lh": b["lh"], "base": b["base"],
                                         "single": b["single"], "scanned": b["scanned"], "lines": b["lines"]}, ctx)
    return total


# ------------------------------------------------------------------ apply
PAGE_OPS = ("delete_page", "rotate_page", "insert_blank")
EXISTING = ("image_edit", "link_edit", "annot_delete", "widget_delete")


def apply_ops(src, ops, dst, password="", cache_dir=None, lang="eng+hin", report=None):
    doc = pymupdf.open(src)
    if doc.needs_pass:
        doc.authenticate(password or "")
    models, canvases = {}, {}

    def model(pno, fresh=False):
        if pno not in models or (fresh and not models[pno].get("scanned") and not models[pno].get("hybrid")):
            models[pno] = page_model(doc, pno, lang, cache_dir)
        return models[pno]

    def canvas(pg):
        if pg.number not in canvases:
            canvases[pg.number] = ScanCanvas(doc, pg)
        return canvases[pg.number]

    ctx = {"model": model, "canvas": canvas, "reset": lambda pg: canvases.pop(pg.number, None), "shifts": {}, "touched": set(),
           "has_ocr": lambda pno: bool(cache_dir) and any(Path(cache_dir).glob(f"ocr_{pno}_*.json"))}

    def shifted(op, pg):
        """objects the user placed on text that has since moved travel with it."""
        for (sx0, sx1, sy, d) in ctx["shifts"].get(pg.number, []):
            for k in ("rect",):
                if k in op and op[k]:
                    r = pymupdf.Rect(op[k]); c = pymupdf.Point((r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2)
                    if sx0 <= c.x <= sx1 and c.y >= sy:
                        op[k] = list(r + (0, d, 0, d))
            if "rects" in op:
                op["rects"] = [list(pymupdf.Rect(r) + (0, d, 0, d)) if (sx0 <= (r[0] + r[2]) / 2 <= sx1 and (r[1] + r[3]) / 2 >= sy) else r for r in op["rects"]]
            if "y" in op and sx0 <= op.get("x", 0) <= sx1 and op["y"] >= sy:
                op["y"] += d
            for k in ("p1", "p2"):
                if k in op and sx0 <= op[k][0] <= sx1 and op[k][1] >= sy:
                    op[k] = [op[k][0], op[k][1] + d]
            if "paths" in op:
                op["paths"] = [[[p[0], p[1] + d] if (sx0 <= p[0] <= sx1 and p[1] >= sy) else p for p in path] for path in op["paths"]]
        return op

    def valid(op):
        try:
            return "page" not in op or 0 <= int(op["page"]) < doc.page_count or op["type"] == "insert_blank"
        except (TypeError, ValueError):
            return False

    ops = [o for o in ops if isinstance(o, dict) and isinstance(o.get("type"), str) and valid(o)]
    failed = []
    # 1) things that already exist in the PDF (positions refer to the untouched document)
    for op in [o for o in ops if o["type"] in EXISTING]:
        pg = doc[int(op["page"])]; t = op["type"]
        ctx["touched"].add(pg.number)
        try:
            if t == "image_edit":
                op_image_edit(doc, pg, op)
            elif t == "link_edit":
                op_link_edit(pg, op)
            elif t == "annot_delete":
                if op.get("rect"):                     # by position – object numbers are only valid for one saved file
                    want = pymupdf.Rect(op["rect"])
                    for a in list(pg.annots() or []):
                        if max(abs(x - y) for x, y in zip(a.rect, want)) < 1.5 and (not op.get("kind") or a.type[1] == op["kind"]):
                            pg.delete_annot(a)
                            break
                else:
                    a = pg.load_annot(int(op["xref"]))
                    if a:
                        pg.delete_annot(a)
            elif t == "widget_delete":
                for w in list(pg.widgets()):
                    if w.field_name == op.get("name") or w.xref == op.get("xref"):
                        pg.delete_widget(w)
        except Exception:
            pass
    # 2) text edits, bottom-up on every page so that reflow never invalidates a later edit
    def _top(o):
        try:
            return (int(o["page"]), -float(o["bbox"][1]))
        except Exception:
            return (0, 0.0)
    for op in sorted([o for o in ops if o["type"] == "edit_block"], key=_top):
        try:
            op_edit_block(doc, doc[int(op["page"])], op, ctx)
        except Exception as e:
            failed.append(("edit_block", repr(e)[:200]))
    for op in [o for o in ops if o["type"] == "find_replace"]:
        try:
            n = op_find_replace(doc, op, ctx)
            if report is not None:
                report["replaced"] = report.get("replaced", 0) + n
        except Exception as e:
            failed.append(("find_replace", repr(e)[:200]))
    # 3) everything new
    for op in ops:
        t = op["type"]
        if t in EXISTING or t in PAGE_OPS or t in ("edit_block", "find_replace"):
            continue
        try:
            if t == "fill_forms":
                op_fill_forms(doc, op); continue
            if "page" not in op:
                continue
            pg = doc[int(op["page"])]
            ctx["touched"].add(pg.number)
            op = shifted(op, pg)
            if t == "add_text":
                op_add_text(doc, pg, op)
            elif t in ("rect", "ellipse", "line", "arrow"):
                op_shape(pg, op)
            elif t == "whiteout":
                op_whiteout(pg, op)
            elif t in ("image", "signature"):
                op_image(pg, op)
            elif t in ("highlight", "underline", "strike"):
                op_markup(pg, op)
            elif t == "ink":
                op_ink(pg, op)
            elif t == "link":
                op_link(pg, op)
            elif t == "note":
                pg.add_text_annot(pymupdf.Point(op["x"], op["y"]), str(op.get("text", ""))[:5000]).update()
            elif t == "field":
                op_field(pg, op)
        except Exception as e:
            failed.append((t, repr(e)[:200]))
    # 4) page structure
    for op in [o for o in ops if o["type"] == "rotate_page"]:
        p = doc[int(op["page"])]
        try:
            ang = int(op.get("angle", 90)) // 90 * 90
        except (TypeError, ValueError):
            ang = 90
        p.set_rotation((p.rotation + ang) % 360)
        if p.rotation:
            p.remove_rotation()      # baked in, so that later edits of this page keep working with plain coordinates
    dels = sorted({int(o["page"]) for o in ops if o["type"] == "delete_page"}, reverse=True)
    if dels and len(dels) < doc.page_count:
        doc.delete_pages(dels)
    else:
        dels = []
    for op in sorted([o for o in ops if o["type"] == "insert_blank"], key=lambda o: -int(o["page"])):
        k = int(op["page"]); k -= sum(1 for x in dels if x < k)        # "before page k" of the original document
        r = doc[max(0, min(k, doc.page_count - 1))].rect
        doc.new_page(pno=max(0, min(k, doc.page_count)), width=r.width, height=r.height)
    if report is not None:
        report["failed"] = failed
        report["pages"] = sorted(ctx["touched"])
        report["structure"] = any(o["type"] in PAGE_OPS for o in ops)
        report["shifts"] = {str(k): [[round(a, 2), round(b, 2), round(c, 2), round(dl, 2)] for a, b, c, dl in v] for k, v in ctx["shifts"].items()}
        report["page_count"] = doc.page_count
    if failed and len(failed) == len(ops):
        doc.close()
        raise ValueError("The changes could not be applied to this PDF.")
    save(doc, dst)
    return dst


def save(doc, dst):
    try:
        doc.subset_fonts()  # embedded copies of Liberation / Noto … are cut down to the glyphs really used
    except Exception:
        pass
    doc.save(dst, garbage=4, deflate=True)
    doc.close()


def page_text(doc, pno):
    """Plain text of a page for converters, search and AI. Hindi / Indic text that a generic reader would garble
    (reordered glyphs, broken character maps) is taken from the paragraph model instead (exact /ActualText or OCR)."""
    pg = doc[pno]
    plain = pg.get_text(sort=True)
    try:
        if not (F.indic_suspicious(plain) or own_blocks(pg)):
            return plain
        blocks = sorted(page_model(doc, pno)["blocks"], key=lambda b: (round(b["bbox"][1] / 6), b["bbox"][0]))
        return "\n".join(b["text"] for b in blocks if b["text"].strip()) + "\n"
    except Exception:
        return plain


# ------------------------------------------------------------------ whole document: repair garbled Indic text
def repair_text(src, dst, lang="eng+hin", max_pages=80):
    """Hindi / Indic PDFs written by browsers and office programs often carry a broken character map: the page looks right,
    but copy, search and conversion give garbage. The affected paragraphs are read with OCR and written again as real
    Unicode text. → number of repaired paragraphs (0 = nothing to do, dst is not written)."""
    import shutil
    doc = pymupdf.open(src)
    try:
        pages = [p.number for p in doc if F.indic_suspicious(p.get_text())][:max_pages]
    finally:
        doc.close()
    if not pages:
        return 0
    work = str(dst) + ".work.pdf"
    shutil.copy(src, work); prepare(work)
    doc = pymupdf.open(work); ops = []
    try:
        for pno in pages:
            for b in page_model(doc, pno, lang)["blocks"]:
                if b.get("reread"):
                    ops.append({"type": "edit_block", "page": pno, "bbox": b["bbox"], "paras": b["paras"], "align": b["align"], "lh": b["lh"],
                                "base": b["base"], "single": b["single"], "scanned": False, "lines": b["lines"], "reflow": False, "fit": True})
    finally:
        doc.close()
    if ops:
        apply_ops(work, ops, str(dst))
    os.remove(work)
    return len(ops)


# ------------------------------------------------------------------ whole document: scan → real text
def scan_to_digital(src, dst, lang="eng+hin"):
    """Every scanned page becomes a digital page: OCR → erase the text pixels (inpainting) → write real text.
    Photos, logos, stamps and lines stay where they are."""
    doc = pymupdf.open(src)
    for pno in range(doc.page_count):
        pg = doc[pno]
        vis, invis, cover, inv = page_stats(pg)
        if cover < 0.6:
            continue
        m = page_model(doc, pno, lang)
        jobs = [b for b in m["blocks"] if b["scanned"] and b["text"].strip()]
        if not jobs:
            continue
        cv = ScanCanvas(doc, pg)
        if not cv.ok and vis < 20:
            pg = rasterize_page(doc, pg); cv = ScanCanvas(doc, pg)
        rects = [pymupdf.Rect(l) + (-1, -1, 1, 1) for b in jobs for l in b["lines"]]
        if cv.ok:
            cv.erase(rects); cv.commit()
        else:
            for b in jobs:
                bg = _bg_color(pg, b["bbox"])
                for l in b["lines"]:
                    pg.add_redact_annot(pymupdf.Rect(l) + (-1, -1, 1, 1), fill=bg)
            pg.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_PIXELS, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE)
        if invis:  # an older invisible OCR layer would duplicate the text
            _drop_text(pg, inv if vis >= 20 else [pg.rect])
        for b in jobs:
            run0 = b["paras"][0][0] if b["paras"] and b["paras"][0] else {"b": 0, "c": "#000000", "fam": "liberationsans"}
            texts = _line_texts(b)
            for lb, text in zip(b["lines"], texts):
                lr = pymupdf.Rect(lb)
                if not text.strip():
                    continue
                fam = run0.get("fam") or "liberationsans"
                size = fit_size(text.strip(), lr.width, lr.height, fam if fam not in COMPLEX else "liberationsans", bool(run0.get("b")))
                built = build_html([[dict(run0, t=text.strip(), s=size, f="")]], "left", 1.0, nowrap=True)
                htmlbox(doc, pg, pymupdf.Rect(lr.x0, lr.y0 - lr.height * 0.08, lr.x1 + lr.height * 3, lr.y1 + lr.height * 0.7), built, scale_low=0)
    save(doc, dst)
    return dst


def _line_texts(b):
    """text of each scanned line (the model keeps paragraphs; split them back by the recorded line count)."""
    lt = b.get("line_texts")
    if lt and len(lt) == len(b["lines"]):
        return lt
    words = b["text"].replace("\n", " ").split()
    n = len(b["lines"])
    if n == 1:
        return [" ".join(words)]
    widths = [l[2] - l[0] for l in b["lines"]]
    total = sum(widths) or 1
    out, i = [], 0
    chars = sum(len(w) + 1 for w in words)
    for k, w in enumerate(widths):
        want = chars * w / total
        cur, got = [], 0
        while i < len(words) and (got + len(words[i]) / 2 < want or not cur) and (len(words) - i > n - k - 1):
            cur.append(words[i]); got += len(words[i]) + 1; i += 1
        out.append(" ".join(cur))
    if i < len(words):
        out[-1] = (out[-1] + " " + " ".join(words[i:])).strip()
    return out

"""Extra PDF tools beyond Sejda (iLovePDF-level and more):
PDF/A, Redact, Compare, Remove blank pages, PDF→Markdown, Digital signature (certificate), AI summarize / translate / chat,
Excel→PDF / PPT→PDF aliases, Add image/QR stamp."""
import difflib, io, json, os, re, subprocess, datetime
from pathlib import Path
import pymupdf
from .tools import tool, _b, _f, _save, _stem, _multi_out, open_pdf, ensure_text, parse_ranges, OCR_LANGS, unrotate, table_rows, draw_text


# ------------------------------------------------------------------ PDF/A (archiving)
@tool("pdfa")
def pdfa(inputs, o, out):
    level = o.get("level", "2")  # 1, 2, 3
    dst = out / f"{_stem(inputs[0])}_pdfa.pdf"
    r = subprocess.run(["ocrmypdf", "--skip-text", "--tesseract-timeout", "0", "--output-type", f"pdfa-{level}",
                        "--optimize", "0", str(inputs[0]), str(dst)], capture_output=True, text=True, timeout=1200)
    if r.returncode not in (0, 6) or not dst.exists():
        raise RuntimeError("PDF/A conversion failed: " + r.stderr[-300:])
    return dst


# ------------------------------------------------------------------ Redact (true removal, not just black boxes)
PATTERNS = {
    "email": r"[\w.+-]+@[\w-]+\.[\w.-]+",
    "phone": r"(?:\+?\d{1,3}[\s-]?)?(?:\(?\d{2,5}\)?[\s-]?)\d{3,5}[\s-]?\d{3,5}",
    "aadhaar": r"\b\d{4}\s?\d{4}\s?\d{4}\b",
    "pan": r"\b[A-Z]{5}\d{4}[A-Z]\b",
    "card": r"\b(?:\d[ -]?){13,19}\b",
    "ifsc": r"\b[A-Z]{4}0[A-Z0-9]{6}\b",
    "gstin": r"\b\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]\b",
    "date": r"\b\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}\b",
    "url": r"https?://\S+",
}


@tool("redact")
def redact(inputs, o, out):
    src, _ = ensure_text(inputs[0], out, visible=False)
    d = open_pdf(src, o.get("password"))
    unrotate(d)
    words = [w.strip() for w in re.split(r"[\n,]", o.get("words") or "") if w.strip()]
    pats = [PATTERNS[k] for k in (o.get("patterns") or []) if k in PATTERNS]
    color = tuple(int((o.get("color") or "#000000").lstrip("#")[i:i + 2], 16) / 255 for i in (0, 2, 4))
    count = 0
    for i in parse_ranges(o.get("pages", "all"), d.page_count):
        pg = d[i]
        for w in words:
            for r in pg.search_for(w, flags=0 if _b(o, "case") else pymupdf.TEXT_DEHYPHENATE):
                pg.add_redact_annot(r, fill=color); count += 1
        if pats:
            text = pg.get_text()
            for pat in pats:
                for m in set(re.findall(pat, text)):
                    for r in pg.search_for(m):
                        pg.add_redact_annot(r, fill=color); count += 1
        for a in o.get("areas") or []:  # [{page, x0,y0,x1,y1} fractions]
            if int(a.get("page", -1)) == i:
                R = pg.rect; pg.add_redact_annot(pymupdf.Rect(R.width * a["x0"], R.height * a["y0"], R.width * a["x1"], R.height * a["y1"]), fill=color); count += 1
        pg.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_PIXELS)  # text under the box is deleted; image pixels blacked out
    if _b(o, "metadata", True):
        d.set_metadata({}); d.del_xml_metadata()
    if not count:
        raise ValueError("Nothing matched – check the words or patterns.")
    return _save(d, out / f"{_stem(inputs[0])}_redacted.pdf", garbage=4)


# ------------------------------------------------------------------ Compare two PDFs
@tool("compare", multi=True)
def compare(inputs, o, out):
    if len(inputs) != 2:
        raise ValueError("Upload exactly 2 PDF files to compare.")
    A, B = (open_pdf(ensure_text(p, out)[0]) for p in inputs)
    def words(doc):
        res = []
        for pg in doc:
            for w in pg.get_text("words", sort=True):
                res.append((w[4], pg.number, pymupdf.Rect(w[:4])))
        return res
    wa, wb = words(A), words(B)
    PA, PB = list(A), list(B)  # keep page objects alive while adding annotations
    sm = difflib.SequenceMatcher(a=[w[0] for w in wa], b=[w[0] for w in wb], autojunk=False)
    dele = ins = 0
    for tag, a0, a1, b0, b1 in sm.get_opcodes():
        if tag in ("delete", "replace"):
            for t, pn, r in wa[a0:a1]:
                h = PA[pn].add_highlight_annot(r); h.set_colors(stroke=(1, .55, .55)); h.set_info(content="Removed"); h.update(); dele += 1
        if tag in ("insert", "replace"):
            for t, pn, r in wb[b0:b1]:
                h = PB[pn].add_highlight_annot(r); h.set_colors(stroke=(.5, .9, .5)); h.set_info(content="Added"); h.update(); ins += 1
    del PA, PB
    A.bake(); B.bake()
    res = pymupdf.open(); cache = {}
    for i in range(max(A.page_count, B.page_count)):
        ra = A[i].rect if i < A.page_count else B[i].rect
        rb = B[i].rect if i < B.page_count else ra
        W, H = ra.width + rb.width + 30, max(ra.height, rb.height) + 40
        pg = res.new_page(width=W, height=H)
        draw_text(pg, f"{Path(inputs[0]).name}  (page {i+1})", 10, 22, 10, (.7, .1, .1), cache=cache)
        draw_text(pg, f"{Path(inputs[1]).name}  (page {i+1})", ra.width + 25, 22, 10, (.1, .5, .1), cache=cache)
        if i < A.page_count: pg.show_pdf_page(pymupdf.Rect(5, 35, 5 + ra.width, 35 + ra.height), A, i)
        if i < B.page_count: pg.show_pdf_page(pymupdf.Rect(ra.width + 25, 35, ra.width + 25 + rb.width, 35 + rb.height), B, i)
        pg.draw_line((ra.width + 15, 30), (ra.width + 15, H - 5), color=(.8, .8, .8))
    first = res[0]
    first.insert_text((W / 2 - 80, 12), f"{dele} words removed (red) · {ins} words added (green)", fontsize=9, color=(0, 0, 0))
    return _save(res, out / "comparison.pdf")


# ------------------------------------------------------------------ Remove blank pages
@tool("remove_blank")
def remove_blank(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    thr = _f(o, "threshold", 99.3)  # % of near-white pixels
    blank = []
    for pg in d:
        if pg.get_text().strip() or pg.get_drawings() and len(pg.get_drawings()) > 3:
            continue
        pix = pg.get_pixmap(dpi=40, colorspace=pymupdf.csGRAY)
        white = sum(1 for v in pix.samples if v > 235) / max(1, len(pix.samples)) * 100
        if white >= thr:
            blank.append(pg.number)
    if len(blank) == d.page_count:
        raise ValueError("All pages look blank.")
    if not blank:
        raise ValueError("No blank pages found.")
    d.delete_pages(blank)
    return _save(d, out / f"{_stem(inputs[0])}_no_blanks.pdf")


# ------------------------------------------------------------------ PDF → Markdown (for ChatGPT / Notion / docs)
def own_markdown(src):
    """PDF → Markdown with our own reader: headings by font size, bold / italic, bullet lists, ruled tables.
    Used when the layout library garbles the text (it ignores the /ActualText of Hindi and other Indic PDFs)."""
    from collections import Counter
    from .editor import page_model
    doc = pymupdf.open(src)
    models = [page_model(doc, i) for i in range(doc.page_count)]
    sizes = Counter()
    for m in models:
        for b in m["blocks"]:
            sizes[round(b["size"])] += len(b["text"])
    body = sizes.most_common(1)[0][0] if sizes else 11
    out = []
    for m in models:
        pg = doc[m["page"]]
        try:
            tabs = list(pg.find_tables().tables)
        except Exception:
            tabs = []
        rects = [pymupdf.Rect(t.bbox) + (-2, -2, 2, 2) for t in tabs]
        done = set()
        for b in m["blocks"]:
            r = pymupdf.Rect(b["bbox"]); c = pymupdf.Point((r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2)
            k = next((i for i, tr in enumerate(rects) if c in tr), None)
            if k is not None:
                if k not in done:
                    done.add(k)
                    rows = [[v.replace("|", "\\|") for v in row] for row in table_rows(pg, tabs[k])]
                    if rows:
                        out.append("|" + "|".join(rows[0]) + "|\n|" + "|".join("---" for _ in rows[0]) + "|\n" + "\n".join("|" + "|".join(x) + "|" for x in rows[1:]))
                continue
            paras = []
            for para in b["paras"]:
                line = ""
                for run in para:
                    t = run["t"]; core = t.strip()
                    if not core:
                        line += t; continue
                    mark = "***" if run.get("b") and run.get("i") else "**" if run.get("b") else "_" if run.get("i") else ""
                    line += t[: len(t) - len(t.lstrip())] + mark + core + mark + t[len(t.rstrip()):]
                if line.strip():
                    paras.append(line.strip())
            if not paras:
                continue
            text = "\n\n".join(paras)
            allbold = all(r.get("b") for para in b["paras"] for r in para if r["t"].strip())
            if len(paras) == 1 and len(text) < 140 and (b["size"] >= body * 1.12 or (allbold and b["single"] and len(text) < 90 and not text.rstrip("*").endswith((".", ":", ",")))):
                lvl = "# " if b["size"] >= body * 1.6 else "## " if b["size"] >= body * 1.3 else "### "
                text = lvl + re.sub(r"^\*+|\*+$", "", text)
            out.append(re.sub(r"^[•●▪■◦‣·]\s*", "- ", text, flags=re.M))
    doc.close()
    return "\n\n".join(out) + "\n"


@tool("pdf_to_markdown", multi=True)
def pdf_to_markdown(inputs, o, out):
    import pymupdf4llm, contextlib
    paths = []
    for p in inputs:
        src, _ = ensure_text(p, out)
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                md = pymupdf4llm.to_markdown(str(src))
        except Exception:
            md = ""
        if not md.strip() or "\ufffd" in md:
            md = own_markdown(src)
        dst = out / f"{_stem(p)}.md"; dst.write_text(md, encoding="utf-8"); paths.append(dst)
    return _multi_out(paths, out, "markdown")


@tool("pdf_to_html")
def pdf_to_html(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    html = "<!doctype html><meta charset=utf-8><title>%s</title><body style='background:#eee'>" % _stem(inputs[0])
    html += "".join(f"<div style='margin:10px auto;background:#fff;width:fit-content'>{pg.get_text('html')}</div>" for pg in d)
    dst = out / f"{_stem(inputs[0])}.html"; dst.write_text(html, encoding="utf-8")
    return dst


# ------------------------------------------------------------------ Digital signature with a certificate (pyHanko)
def make_certificate(name, email, path):
    """Create a personal certificate (PKCS#12) – for users who have none from a CA / DSC provider. → password (bytes)"""
    from cryptography import x509
    from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.primitives.serialization import pkcs12
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subj = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, name[:60] or "Signer")] + ([x509.NameAttribute(NameOID.EMAIL_ADDRESS, email)] if email else []))
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(subj).issuer_name(subj).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(now - datetime.timedelta(minutes=5)).not_valid_after(now + datetime.timedelta(days=3650))
            .add_extension(x509.KeyUsage(True, True, False, False, False, False, False, False, False), critical=True)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.EMAIL_PROTECTION]), critical=False)
            .sign(key, hashes.SHA256()))
    pw = os.urandom(12).hex().encode()
    Path(path).write_bytes(pkcs12.serialize_key_and_certificates((name[:60] or "Signer").encode(), key, cert, None, serialization.BestAvailableEncryption(pw)))
    return pw


def sign_pdf(src, dst, p12, password, name=None, reason=None, location=None, page=None, position="bottom-right", field="Signature1"):
    """Cryptographically sign a PDF with a PKCS#12 certificate and show a visible signature box (pyHanko)."""
    from pyhanko.sign import signers, fields
    from pyhanko.pdf_utils.incremental_writer import IncrementalPdfFileWriter
    from pyhanko.stamp import TextStampStyle
    from pyhanko.pdf_utils.text import TextBoxStyle
    try:
        import tzlocal; tzlocal.get_localzone()
    except Exception:  # some servers have legacy TZ names (e.g. Asia/Calcutta) → fall back to UTC
        import time as _t; os.environ["TZ"] = "UTC"; _t.tzset()
    try:
        signer = signers.SimpleSigner.load_pkcs12(str(p12), passphrase=password or None)
    except Exception:
        signer = None
    if signer is None:
        raise ValueError("Could not open the certificate – check the file and its password.")
    d = pymupdf.open(src); n = d.page_count
    pno = max(0, min(n - 1, (int(page) - 1) if page else n - 1))
    pr = d[pno].rect; rot = d[pno].rotation; d.close()
    W, H = 220, 64
    pw_, ph_ = (pr.height, pr.width) if rot in (90, 270) else (pr.width, pr.height)
    x = 36 if "left" in position else pw_ - W - 36
    y = 36 if "bottom" in position else ph_ - H - 36
    with open(src, "rb") as f:
        w = IncrementalPdfFileWriter(f, strict=False)
        meta = signers.PdfSignatureMetadata(field_name=field, reason=reason or None, location=location or None, name=name or None)
        style = TextStampStyle(stamp_text="Digitally signed by %(signer)s\nDate: %(ts)s" + (f"\n{reason}" if reason else ""),
                               text_box_style=TextBoxStyle(font_size=9), border_width=1)
        fields.append_signature_field(w, sig_field_spec=fields.SigFieldSpec(field, on_page=pno, box=(x, y, x + W, y + H)))
        with open(dst, "wb") as outf:
            signers.PdfSigner(meta, signer=signer, stamp_style=style).sign_pdf(w, output=outf)
    return dst


def verify_signatures(path):
    """→ list of {field, signer, intact, valid, trusted, time, covers_whole_document}"""
    from pyhanko.pdf_utils.reader import PdfFileReader
    from pyhanko.sign.validation import validate_pdf_signature
    import logging
    logging.getLogger("pyhanko").setLevel(logging.CRITICAL); logging.getLogger("pyhanko_certvalidator").setLevel(logging.CRITICAL)
    out = []
    with open(path, "rb") as f:
        rd = PdfFileReader(f, strict=False)
        for s in rd.embedded_signatures:
            try:
                st = validate_pdf_signature(s)
                cert = s.signer_cert
                out.append({"field": s.field_name, "signer": cert.subject.human_friendly if cert else "?", "intact": bool(st.intact), "valid": bool(st.valid),
                            "trusted": bool(st.trusted), "time": str(st.signer_reported_dt or ""), "covers_whole_document": str(st.coverage).endswith("ENTIRE_FILE"),
                            "modified_after_signing": not str(getattr(st, "modification_level", "NONE")).endswith(("NONE", "LTA_UPDATES"))})
            except Exception as e:
                out.append({"field": s.field_name, "error": str(e)[:200], "intact": False, "valid": False, "trusted": False})
    return out


@tool("digital_sign")
def digital_sign(inputs, o, out):
    p12 = o.get("cert_path"); pw = (o.get("cert_password") or "").encode() or None
    made = None
    if not p12:
        if not (o.get("name") or "").strip():
            raise ValueError("Please enter the signer name (or upload your certificate).")
        made = out / "my_certificate.p12"
        pw = make_certificate(o["name"].strip(), (o.get("email") or "").strip(), made); p12 = made
    dst = out / f"{_stem(inputs[0])}_signed.pdf"
    sign_pdf(inputs[0], dst, p12, pw, o.get("name"), o.get("reason") or "I approve this document", o.get("location"),
             o.get("page") if str(o.get("page") or "").strip() else None, o.get("position", "bottom-right"))
    if made:
        made.unlink(missing_ok=True)
    return dst


@tool("verify_signature")
def verify_signature(inputs, o, out):
    sigs = verify_signatures(inputs[0])
    lines = [f"# Signature check – {Path(inputs[0]).name}", ""]
    if not sigs:
        lines.append("This PDF contains **no digital signatures**.")
    for i, s in enumerate(sigs, 1):
        ok = s.get("intact") and s.get("valid")
        lines += [f"## Signature {i}: {'VALID' if ok else 'NOT VALID'}", f"- Signer: {s.get('signer', '?')}", f"- Signed on: {s.get('time') or 'unknown'}",
                  f"- Document unchanged since signing: {'yes' if s.get('intact') else 'NO – the file was modified'}",
                  f"- Certificate trusted by a public authority: {'yes' if s.get('trusted') else 'no (self-signed or unknown issuer)'}",
                  f"- Covers the whole document: {'yes' if s.get('covers_whole_document') else 'no'}"] + ([f"- Error: {s['error']}"] if s.get("error") else []) + [""]
    dst = out / "signature_report.md"; dst.write_text("\n".join(lines), encoding="utf-8")
    return dst


# ------------------------------------------------------------------ AI (needs ANTHROPIC_API_KEY or an OpenAI-compatible server)
def ai_complete(prompt, max_tokens=4000, system=None):
    import httpx
    if os.environ.get("ANTHROPIC_API_KEY"):
        body = {"model": os.environ.get("AI_MODEL", "claude-haiku-4-5"), "max_tokens": max_tokens, "messages": [{"role": "user", "content": prompt}]}
        if system: body["system"] = system
        r = httpx.post("https://api.anthropic.com/v1/messages", headers={"x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01"},
                       json=body, timeout=180)
        r.raise_for_status(); return r.json()["content"][0]["text"]
    if os.environ.get("OPENAI_BASE_URL"):
        msgs = ([{"role": "system", "content": system}] if system else []) + [{"role": "user", "content": prompt}]
        r = httpx.post(os.environ["OPENAI_BASE_URL"].rstrip("/") + "/chat/completions", headers={"Authorization": f"Bearer {os.environ.get('OPENAI_API_KEY', 'x')}"},
                       json={"model": os.environ.get("AI_MODEL", "qwen2.5:7b"), "messages": msgs, "max_tokens": max_tokens}, timeout=300)
        r.raise_for_status(); return r.json()["choices"][0]["message"]["content"]
    raise RuntimeError("AI is not configured on this server (set ANTHROPIC_API_KEY or OPENAI_BASE_URL).")


def _doc_text(p, out, limit=180000):
    from .editor import page_text
    src, _ = ensure_text(p, out)
    doc = pymupdf.open(src)
    return "\n\n".join(f"[Page {i + 1}]\n{page_text(doc, i)}" for i in range(doc.page_count))[:limit]


@tool("ai_summarize")
def ai_summarize(inputs, o, out):
    lang = o.get("lang") or "English"
    style = {"short": "a short summary (5 bullet points)", "detailed": "a detailed summary with headings and bullet points",
             "key": "the key facts, numbers, dates, names and action items"}.get(o.get("style", "detailed"))
    text = ai_complete(f"Write {style} of this document in {lang}. Cite page numbers like (p. 3).\n\n<document>\n{_doc_text(inputs[0], out)}\n</document>")
    dst = out / f"{_stem(inputs[0])}_summary.md"; dst.write_text(text, encoding="utf-8")
    return dst


@tool("ai_chat")
def ai_chat(inputs, o, out):
    q = o.get("question") or "What is this document about?"
    ans = ai_complete(f"Answer the question using only this document. Cite page numbers.\nQuestion: {q}\n\n<document>\n{_doc_text(inputs[0], out)}\n</document>")
    dst = out / "answer.md"; dst.write_text(f"**Q:** {q}\n\n{ans}", encoding="utf-8")
    return dst


@tool("ai_translate")
def ai_translate(inputs, o, out, translate_fn=None):
    """Translate a PDF *keeping its layout*: every paragraph is translated and typeset again in its own place
    (same font size, colour, bold/italic, alignment). Longer text first shrinks a little, then pushes the rest of the page down."""
    import shutil
    from . import editor
    lang = o.get("lang") or "Hindi"
    src, _ = ensure_text(inputs[0], out, visible=True)   # scanned pages → real text first
    work = out / "_translate_src.pdf"; shutil.copy(src, work); editor.prepare(work)

    def tr(batch):
        if translate_fn:
            return translate_fn(batch)
        prompt = (f"Translate each item of this JSON array into {lang}. Keep numbers, names, codes, e-mail addresses and URLs unchanged. "
                  "Keep line breaks (\\n) where they are. Return ONLY a JSON array of strings with the same length and order.\n\n" + json.dumps(batch, ensure_ascii=False))
        raw = ai_complete(prompt, 8000)
        m = re.search(r"\[.*\]", raw, re.S)
        try:
            res = json.loads(m.group(0)) if m else []
        except Exception:
            res = []
        return [str(x) for x in res] if len(res) == len(batch) else batch

    doc = pymupdf.open(work)
    ops = []
    for pno in range(doc.page_count):
        model = editor.page_model(doc, pno)
        blocks = [b for b in model["blocks"] if re.search(r"[^\W\d_]{2,}", b["text"])]
        texts = [b["text"] for b in blocks]
        got = []
        for i in range(0, len(texts), 40):
            got += tr(texts[i:i + 40])
        for b, t in zip(blocks, got):
            if not t.strip() or t == b["text"]:
                continue
            run = {"b": b["bold"], "i": b["italic"], "c": b["color"], "s": b["size"], "fam": b["fam"], "f": ""}
            ops.append({"type": "edit_block", "page": pno, "bbox": b["bbox"], "paras": [[dict(run, t=line)] for line in t.split("\n")],
                        "align": b["align"] if b["align"] != "justify" else "left", "lh": b["lh"], "base": b["base"], "single": b["single"],
                        "scanned": b["scanned"], "lines": b["lines"], "fit": True})
    doc.close()
    if not ops:
        raise ValueError("No text found to translate.")
    dst = out / f"{_stem(inputs[0])}_{re.sub(r'[^A-Za-z]', '', lang)[:12] or 'translated'}.pdf"
    editor.apply_ops(str(work), ops, str(dst))
    work.unlink(missing_ok=True)
    return dst


# ------------------------------------------------------------------ office aliases (separate pages for SEO)
@tool("excel_to_pdf", multi=True, accept="office")
def excel_to_pdf(inputs, o, out):
    from .tools import office_to_pdf
    return office_to_pdf(inputs, o, out)


@tool("ppt_to_pdf", multi=True, accept="office")
def ppt_to_pdf(inputs, o, out):
    from .tools import office_to_pdf
    return office_to_pdf(inputs, o, out)

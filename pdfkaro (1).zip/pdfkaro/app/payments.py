"""Payments: Razorpay (India – UPI, cards, netbanking, wallets) and Stripe (international cards, Apple/Google Pay).

Both use plain HTTPS REST calls (no SDK) and verify signatures with HMAC-SHA256.
Env:  RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET, RAZORPAY_WEBHOOK_SECRET
      STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, (optional) STRIPE_PRICE_MONTH / STRIPE_PRICE_YEAR for auto-renew
"""
import hashlib, hmac, json, os, time
import httpx
from fastapi import APIRouter, HTTPException, Request
from .accounts import current_user, activate, db, SITE, SITE_NAME
from .plans import PLANS, STRIPE_PRICE_IDS

router = APIRouter()


def _need_user(req):
    u = current_user(req)
    if not u:
        raise HTTPException(401, "Please log in or create a free account first.")
    return u


def _plan(b):
    p = b.get("plan")
    if p not in PLANS:
        raise HTTPException(400, "Unknown plan")
    return p


# ------------------------------------------------------------------ Razorpay
@router.post("/api/pay/razorpay/order")
async def rzp_order(req: Request):
    u = _need_user(req); b = await req.json(); plan = _plan(b)
    kid, sec = os.environ.get("RAZORPAY_KEY_ID"), os.environ.get("RAZORPAY_KEY_SECRET")
    if not kid:
        raise HTTPException(501, "Razorpay is not configured.")
    amount = int(round(PLANS[plan]["inr"] * 100))  # paise
    async with httpx.AsyncClient(timeout=20) as c:
        r = await c.post("https://api.razorpay.com/v1/orders", auth=(kid, sec),
                         json={"amount": amount, "currency": "INR", "receipt": f"u{u['id']}-{int(time.time())}",
                               "notes": {"user_id": str(u["id"]), "plan": plan}})
    if r.status_code >= 300:
        raise HTTPException(502, f"Razorpay error: {r.text[:200]}")
    o = r.json()
    return {"key_id": kid, "order_id": o["id"], "amount": amount, "currency": "INR", "name": SITE_NAME,
            "description": PLANS[plan]["name"], "email": u["email"], "user_name": u["name"]}


@router.post("/api/pay/razorpay/verify")
async def rzp_verify(req: Request):
    """Called by the browser after Razorpay Checkout succeeds."""
    u = _need_user(req); b = await req.json()
    sec = os.environ.get("RAZORPAY_KEY_SECRET", "").encode()
    if not sec or not os.environ.get("RAZORPAY_KEY_ID"):
        raise HTTPException(501, "Razorpay is not configured.")
    msg = f"{b.get('razorpay_order_id')}|{b.get('razorpay_payment_id')}".encode()
    if not hmac.compare_digest(hmac.new(sec, msg, hashlib.sha256).hexdigest(), str(b.get("razorpay_signature", ""))):
        raise HTTPException(400, "Payment verification failed.")
    # fetch the order to know the plan & amount from the server side (never trust the browser)
    async with httpx.AsyncClient(timeout=20) as c:
        o = (await c.get(f"https://api.razorpay.com/v1/orders/{b['razorpay_order_id']}",
                         auth=(os.environ["RAZORPAY_KEY_ID"], os.environ["RAZORPAY_KEY_SECRET"]))).json()
    notes = o.get("notes") or {}
    plan = notes.get("plan")
    if plan not in PLANS or str(notes.get("user_id")) != str(u["id"]):
        raise HTTPException(400, "Order does not belong to this account.")
    need = int(round(PLANS[plan]["inr"] * 100))
    paid = o.get("status") == "paid" and int(o.get("amount_paid") or 0) >= need
    if not paid:   # the order is marked "paid" a moment after the payment is captured – ask for the payment itself
        async with httpx.AsyncClient(timeout=20) as c:
            pay = (await c.get(f"https://api.razorpay.com/v1/payments/{b['razorpay_payment_id']}",
                               auth=(os.environ["RAZORPAY_KEY_ID"], os.environ["RAZORPAY_KEY_SECRET"]))).json()
        paid = pay.get("status") == "captured" and pay.get("order_id") == b.get("razorpay_order_id") and int(pay.get("amount") or 0) >= need
    if not paid:
        raise HTTPException(402, "The payment has not been completed yet. If money was taken, your plan is activated automatically within a few minutes.")
    activate(u["id"], plan, "razorpay", b["razorpay_payment_id"], o["amount"] / 100, "INR", json.dumps(b))
    return {"ok": True}


@router.post("/api/pay/razorpay/webhook")
async def rzp_webhook(req: Request):
    """Backup path: Razorpay → server (works even if the user closes the browser)."""
    body = await req.body()
    sec = os.environ.get("RAZORPAY_WEBHOOK_SECRET", "").encode()
    if not sec:   # never accept webhooks without a secret – anybody could sign them with an empty key
        raise HTTPException(503, "Webhook secret is not configured.")
    if not hmac.compare_digest(hmac.new(sec, body, hashlib.sha256).hexdigest(), req.headers.get("x-razorpay-signature", "")):
        raise HTTPException(400, "bad signature")
    ev = json.loads(body)
    if ev.get("event") in ("payment.captured", "order.paid"):
        p = ev["payload"]["payment"]["entity"]
        notes = p.get("notes") or {}
        if not notes.get("plan") and p.get("order_id") and os.environ.get("RAZORPAY_KEY_ID"):  # notes live on the order
            try:
                async with httpx.AsyncClient(timeout=20) as c:
                    notes = (await c.get(f"https://api.razorpay.com/v1/orders/{p['order_id']}",
                                         auth=(os.environ["RAZORPAY_KEY_ID"], os.environ["RAZORPAY_KEY_SECRET"]))).json().get("notes") or {}
            except Exception:
                raise HTTPException(503, "Could not reach Razorpay – it will retry.")
        plan = notes.get("plan")
        if plan in PLANS and str(notes.get("user_id", "")).isdigit() and p.get("status") in ("captured", None) \
                and int(p.get("amount") or 0) >= int(round(PLANS[plan]["inr"] * 100)):
            activate(int(notes["user_id"]), plan, "razorpay", p["id"], p["amount"] / 100, p.get("currency", "INR"), body.decode()[:4000])
    return {"ok": True}


# ------------------------------------------------------------------ Stripe
@router.post("/api/pay/stripe/checkout")
async def stripe_checkout(req: Request):
    u = _need_user(req); b = await req.json(); plan = _plan(b)
    key = os.environ.get("STRIPE_SECRET_KEY")
    if not key:
        raise HTTPException(501, "Stripe is not configured.")
    data = {"success_url": f"{SITE}/account?paid=1", "cancel_url": f"{SITE}/pricing",
            "client_reference_id": str(u["id"]), "customer_email": u["email"],
            "metadata[user_id]": str(u["id"]), "metadata[plan]": plan, "allow_promotion_codes": "true"}
    price_id = STRIPE_PRICE_IDS.get(plan) if b.get("recurring") else None
    if price_id:  # auto-renewing subscription
        data.update({"mode": "subscription", "line_items[0][price]": price_id, "line_items[0][quantity]": "1",
                     "subscription_data[metadata][user_id]": str(u["id"]), "subscription_data[metadata][plan]": plan})
    else:
        data.update({"mode": "payment", "line_items[0][quantity]": "1",
                     "line_items[0][price_data][currency]": "usd",
                     "line_items[0][price_data][unit_amount]": str(int(round(PLANS[plan]["usd"] * 100))),
                     "line_items[0][price_data][product_data][name]": f"{SITE_NAME} {PLANS[plan]['name']}"})
    async with httpx.AsyncClient(timeout=20) as c:
        r = await c.post("https://api.stripe.com/v1/checkout/sessions", auth=(key, ""), data=data)
    if r.status_code >= 300:
        raise HTTPException(502, f"Stripe error: {r.json().get('error', {}).get('message', r.text[:200])}")
    return {"url": r.json()["url"]}


def _stripe_verify(body: bytes, header: str, secret: str, tolerance=300):
    parts = dict(p.strip().split("=", 1) for p in header.split(",") if "=" in p)
    t = parts.get("t", "0")
    if not secret or not t.isdigit():
        return False
    sigs = [v for k, v in (p.strip().split("=", 1) for p in header.split(",") if "=" in p) if k == "v1"]
    expected = hmac.new(secret.encode(), f"{t}.".encode() + body, hashlib.sha256).hexdigest()
    return any(hmac.compare_digest(expected, s) for s in sigs) and abs(time.time() - int(t)) < tolerance


@router.post("/api/pay/stripe/webhook")
async def stripe_webhook(req: Request):
    body = await req.body()
    secret = os.environ.get("STRIPE_WEBHOOK_SECRET", "")
    if not secret:
        raise HTTPException(503, "Webhook secret is not configured.")
    if not _stripe_verify(body, req.headers.get("stripe-signature", ""), secret):
        raise HTTPException(400, "bad signature")
    ev = json.loads(body); o = ev["data"]["object"]
    ok = lambda md: md.get("plan") in PLANS and str(md.get("user_id", "")).isdigit()
    if ev["type"] == "checkout.session.completed" and o.get("payment_status") == "paid":
        md = o.get("metadata") or {}
        if ok(md):
            activate(int(md["user_id"]), md["plan"], "stripe", o["id"], (o.get("amount_total") or 0) / 100, str(o.get("currency", "usd")).upper(), body.decode()[:4000])
            if o.get("mode") == "subscription" and str(o.get("customer") or "").startswith("cus_"):      # needed later to let the user cancel
                db().execute("UPDATE users SET stripe_customer=? WHERE id=?", (o["customer"], int(md["user_id"]))); db().commit()
    elif ev["type"] == "customer.subscription.deleted" and str(o.get("customer") or "").startswith("cus_"):      # cancelled: nothing to manage any more
        db().execute("UPDATE users SET stripe_customer=NULL WHERE stripe_customer=?", (o["customer"],)); db().commit()
    elif ev["type"] == "invoice.paid" and o.get("billing_reason") == "subscription_cycle":  # auto-renewal
        md = (o.get("subscription_details") or {}).get("metadata") or {}
        if ok(md):
            activate(int(md["user_id"]), md["plan"], "stripe", o["id"], (o.get("amount_paid") or 0) / 100, str(o.get("currency", "usd")).upper(), body.decode()[:4000])
    return {"ok": True}


@router.post("/api/pay/stripe/portal")
async def stripe_portal(req: Request):
    """Stripe's own page where a subscriber changes the card or cancels the automatic renewal."""
    u = _need_user(req)
    key = os.environ.get("STRIPE_SECRET_KEY")
    if not key:
        raise HTTPException(501, "Stripe is not configured.")
    if not u["stripe_customer"]:
        raise HTTPException(404, "You have no automatically renewing subscription.")
    async with httpx.AsyncClient(timeout=20) as c:
        r = await c.post("https://api.stripe.com/v1/billing_portal/sessions", auth=(key, ""), data={"customer": u["stripe_customer"], "return_url": f"{SITE}/account"})
    if r.status_code >= 300:
        raise HTTPException(502, f"Stripe error: {r.json().get('error', {}).get('message', r.text[:200])}")
    return {"url": r.json()["url"]}


async def cancel_subscriptions(customer):
    """Stop every running subscription of a Stripe customer (used when an account is deleted – nobody may be charged after that)."""
    key = os.environ.get("STRIPE_SECRET_KEY")
    if not key or not customer:
        return 0
    n = 0
    async with httpx.AsyncClient(timeout=20) as c:
        r = await c.get("https://api.stripe.com/v1/subscriptions", auth=(key, ""), params={"customer": customer, "limit": 50})
        if r.status_code >= 300:
            raise RuntimeError("Stripe did not answer")
        for sub in r.json().get("data") or []:
            if sub.get("status") in ("active", "trialing", "past_due", "unpaid"):
                d = await c.delete(f"https://api.stripe.com/v1/subscriptions/{sub['id']}", auth=(key, ""))
                if d.status_code >= 300:
                    raise RuntimeError("Stripe refused to cancel")
                n += 1
    return n

"""All PDF tools. Each tool: fn(inputs: list[Path], o: dict, out: Path) -> Path (result file).

Engines: PyMuPDF (render/edit/merge/split/stamp), pikepdf/qpdf (encrypt/repair),
Ghostscript (compress/grayscale), OCRmyPDF+Tesseract (OCR/deskew), pdf2docx (Word),
pdfplumber+openpyxl (Excel), python-pptx (PowerPoint), LibreOffice (Word->PDF),
Chromium/Playwright (HTML->PDF).
"""
import io, os, re, subprocess, shutil, math, json
from pathlib import Path
import pymupdf
import pikepdf
from .util import parse_ranges, zip_files, font_file, safe_name
from .editor import page_resource

TOOLS = {}


def tool(name, multi=False, accept="pdf"):
    def deco(fn):
        TOOLS[name] = dict(fn=fn, multi=multi, accept=accept)
        return fn
    return deco


def _b(o, k, d=False):
    v = o.get(k, d)
    return v if isinstance(v, bool) else str(v).lower() in ("1", "true", "on", "yes")


def _f(o, k, d=0.0):
    try:
        return float(o.get(k, d))
    except (TypeError, ValueError):
        return d


def _stem(p):
    return safe_name(Path(p).stem)


def open_pdf(p, password=""):
    doc = pymupdf.open(p)
    if doc.needs_pass and not doc.authenticate(password or ""):
        raise ValueError("This PDF is password protected. Enter the password.")
    return doc


def _save(doc, path, garbage=3, subset=False):
    if subset:  # fonts we embedded for stamps / watermarks are cut down to the glyphs used
        try:
            doc.subset_fonts()
        except Exception:
            pass
    doc.save(path, garbage=garbage, deflate=True)
    doc.close()
    return path


def unrotate(doc, pages=None):
    """bake /Rotate into the page content so that tool coordinates = what the user sees (appearance is unchanged)."""
    for i in (pages if pages is not None else range(doc.page_count)):
        if doc[i].rotation:
            doc[i].remove_rotation()


FAMS = {"sans": "liberationsans", "serif": "liberationserif", "mono": "liberationmono", "hindi": "notosansdevanagari", "noto": "notosans"}


def draw_text(pg, text, x, y, size, color=(0, 0, 0), family="sans", bold=False, anchor="left", angle=0.0, opacity=1.0, cache=None, overlay=True):
    """One line of text in any language at the baseline point (x, y) [anchor = left | center | right];
    with an angle, (x, y) is the centre of the text (counter-clockwise degrees). Fonts are embedded. → width"""
    import hashlib
    from . import editor, fonts as F
    fam = FAMS.get(family, family if F.has(family or "") else "liberationsans")
    if not F.has(fam):
        fam = "liberationsans"
    cache = cache if cache is not None else {}
    if editor.needs_shaping(text, fam):   # Hindi, Arabic, Tamil … must be shaped; missing glyphs get a fallback font
        return editor.put_text(pg, text, x, y, size, editor._hex(color), bold, False, fam, anchor, angle, opacity, overlay, cache)
    path, _ = F.face(fam, bold, False)
    font = cache.get(("font", path))
    if font is None:
        font = cache[("font", path)] = pymupdf.Font(fontfile=path)
    w = font.text_length(text, fontsize=size)
    name = "pk" + hashlib.md5(path.encode()).hexdigest()[:6]
    pg.insert_font(fontname=name, fontfile=path)
    if angle:
        c = pymupdf.Point(x, y)
        pg.insert_text(pymupdf.Point(x - w / 2, y + size * 0.33), text, fontsize=size, fontname=name, color=color, fill_opacity=opacity,
                       stroke_opacity=opacity, morph=(c, pymupdf.Matrix(angle)), overlay=overlay)
    else:
        x0 = x if anchor == "left" else x - w / 2 if anchor == "center" else x - w
        pg.insert_text(pymupdf.Point(x0, y), text, fontsize=size, fontname=name, color=color, fill_opacity=opacity, stroke_opacity=opacity, overlay=overlay)
    return w


def _multi_out(paths, out, name):
    paths = [Path(p) for p in paths]
    if len(paths) == 1:
        return paths[0]
    return zip_files(paths, out / f"{name}.zip")


IMG_EXT = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tif", ".tiff", ".webp", ".heic", ".heif", ".avif", ".svg", ".jfif"}
try:
    import pillow_heif
    pillow_heif.register_heif_opener()
except Exception:
    pass


def image_pages(p):
    """every frame of an image file → (insert_image kwargs | {"pdf": doc}, width_pt, height_pt).
    Phone photos (EXIF rotation), HEIC, WEBP, AVIF, CMYK and multi-page TIFF are handled; JPEG/PNG are embedded untouched."""
    from PIL import Image, ImageOps
    suf = Path(p).suffix.lower()
    if suf == ".svg":
        pd = pymupdf.open("pdf", pymupdf.open(p).convert_to_pdf()); r = pd[0].rect
        yield {"pdf": pd}, r.width, r.height
        return
    im = Image.open(p)
    n = getattr(im, "n_frames", 1) if suf in (".tif", ".tiff") else 1
    for k in range(n):
        if n > 1:
            im.seek(k)
        try:
            dpi = float((im.info.get("dpi") or (72, 72))[0])
        except Exception:
            dpi = 72.0
        if not 100 <= dpi <= 2400:
            dpi = 72.0
        orient = im.getexif().get(0x0112, 1) if hasattr(im, "getexif") else 1
        direct = n == 1 and orient in (0, 1) and suf in (".jpg", ".jpeg", ".png", ".bmp", ".gif") and im.mode in ("RGB", "L", "RGBA", "P", "1")
        if direct:
            w, h = im.size
            yield {"filename": str(p)}, w * 72 / dpi, h * 72 / dpi
        else:
            fr = ImageOps.exif_transpose(im)
            buf = io.BytesIO()
            if fr.mode in ("RGBA", "LA") or (fr.mode == "P" and "transparency" in fr.info):
                fr.convert("RGBA").save(buf, "PNG")
            else:
                fr.convert("RGB").save(buf, "JPEG", quality=92)
            w, h = fr.size
            yield {"stream": buf.getvalue()}, w * 72 / dpi, h * 72 / dpi


def _as_pdf_doc(p):
    """Open PDF, or turn an image file into a PDF document (one page per frame)."""
    if Path(p).suffix.lower() not in IMG_EXT:
        return open_pdf(p)
    d = pymupdf.open()
    for kw, w, h in image_pages(p):
        if "pdf" in kw:
            d.insert_pdf(kw["pdf"])
        else:
            pg = d.new_page(width=w, height=h); pg.insert_image(pg.rect, **kw)
    return d


# ------------------------------------------------------------------ MERGE
@tool("merge", multi=True, accept="pdf,image")
def merge(inputs, o, out):
    res = pymupdf.open()
    toc, cache = [], {}
    mode = o.get("bookmarks", "one_per_doc")  # keep | discard | one_per_doc | keep_under
    ranges = o.get("ranges") or {}
    same_size = _b(o, "same_size")
    footer = _b(o, "filename_footer")
    for idx, p in enumerate(inputs):
        d = _as_pdf_doc(p)
        sel = parse_ranges(ranges.get(str(idx), "") if isinstance(ranges, dict) else "", d.page_count)
        start = res.page_count
        sub_toc = d.get_toc() if mode in ("keep", "keep_under") else []
        if sel == list(range(d.page_count)):
            res.insert_pdf(d)
        else:
            for i in sel:
                res.insert_pdf(d, from_page=i, to_page=i)
        if mode in ("one_per_doc", "keep_under"):
            toc.append([1, Path(p).stem, start + 1])
        lvl_shift = 1 if mode == "keep_under" else 0
        for lvl, title, pg, *_ in sub_toc:
            if pg - 1 in sel:
                toc.append([lvl + lvl_shift, title, start + sel.index(pg - 1) + 1])
        if footer:
            unrotate(res, range(start, res.page_count))
            for i in range(start, res.page_count):
                pg = res[i]
                draw_text(pg, Path(p).name, 20, pg.rect.height - 10, 8, (0.3, 0.3, 0.3), cache=cache)
        d.close()
    if same_size and res.page_count:
        w, h = res[0].rect.width, res[0].rect.height
        new = pymupdf.open()
        for pg in res:
            np_ = new.new_page(width=w, height=h)
            np_.show_pdf_page(np_.rect, res, pg.number)
        res = new
    if toc and mode != "discard":
        # fix levels so they always start at 1 and never jump
        fixed, last = [], 0
        for lvl, t, pg in toc:
            lvl = min(lvl, last + 1)
            fixed.append([lvl, t, pg]); last = lvl
        res.set_toc(fixed)
    return _save(res, out / "merged.pdf", subset=footer)


@tool("alternate_mix", multi=True)
def alternate_mix(inputs, o, out):
    docs = [open_pdf(p) for p in inputs]
    every = max(1, int(_f(o, "every", 1)))
    reverse = o.get("reverse") or []  # list of indexes read in reverse
    seqs = []
    for i, d in enumerate(docs):
        s = list(range(d.page_count))
        if str(i) in map(str, reverse):
            s.reverse()
        seqs.append(s)
    res = pymupdf.open()
    pos = [0] * len(docs)
    while any(pos[i] < len(seqs[i]) for i in range(len(docs))):
        for i, d in enumerate(docs):
            for _ in range(every):
                if pos[i] < len(seqs[i]):
                    pg = seqs[i][pos[i]]
                    res.insert_pdf(d, from_page=pg, to_page=pg)
                    pos[i] += 1
    return _save(res, out / "mixed.pdf")


# ------------------------------------------------------------------ PAGES
@tool("organize", multi=True)
def organize(inputs, o, out):
    """o['order'] = [{"file": 0, "page": 3, "rotate": 90}, {"blank": true}, …] – pages may come from several files and repeat."""
    docs = [open_pdf(p, o.get("password")) for p in inputs]
    order = o.get("order") or [{"file": fi, "page": i} for fi, d in enumerate(docs) for i in range(d.page_count)]
    plain = len(docs) == 1 and all(not it.get("blank") and not it.get("rotate") and int(it.get("file", 0)) == 0 for it in order)
    if plain:  # pure reorder / delete / duplicate of one file: keeps links, forms and bookmarks intact
        seq = [int(it["page"]) for it in order]
        if not seq or min(seq) < 0 or max(seq) >= docs[0].page_count:
            raise ValueError("Invalid page order.")
        docs[0].select(seq)
        return _save(docs[0], out / f"{_stem(inputs[0])}.pdf")
    res = pymupdf.open()
    last = {}
    for k, it in enumerate(order):
        if not it.get("blank"):
            last[int(it.get("file", 0))] = k
    for k, it in enumerate(order):
        if it.get("blank"):
            r = res[-1].rect if res.page_count else docs[0][0].rect
            res.new_page(width=r.width, height=r.height)
            continue
        fi, i = int(it.get("file", 0)), int(it["page"])
        if not (0 <= fi < len(docs)) or not (0 <= i < docs[fi].page_count):
            raise ValueError("Invalid page order.")
        res.insert_pdf(docs[fi], from_page=i, to_page=i, final=1 if last.get(fi) == k else 0)
        if it.get("rotate"):
            p = res[-1]
            p.set_rotation((p.rotation + int(it["rotate"])) % 360)
    if not res.page_count:
        raise ValueError("The result would have no pages.")
    return _save(res, out / f"{_stem(inputs[0])}.pdf", garbage=4)


@tool("delete_pages")
def delete_pages(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    rm = set(parse_ranges(o.get("pages", ""), d.page_count))
    if len(rm) >= d.page_count:
        raise ValueError("You cannot delete all pages.")
    d.delete_pages(sorted(rm))
    if _b(o, "discard_bookmarks"):
        d.set_toc([])
    return _save(d, out / f"{_stem(inputs[0])}.pdf")


@tool("extract_pages")
def extract_pages(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    keep = parse_ranges(o.get("pages", "all"), d.page_count)
    d.select(keep)
    if _b(o, "discard_bookmarks"):
        d.set_toc([])
    return _save(d, out / f"{_stem(inputs[0])}_extracted.pdf")


@tool("rotate")
def rotate(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    per_page = o.get("per_page")  # {"0": 90, "3": 180}
    if per_page:
        for k, v in per_page.items():
            p = d[int(k)]; p.set_rotation((p.rotation + int(v)) % 360)
    else:
        ang = int(_f(o, "angle", 90))
        for i in parse_ranges(o.get("pages", "all"), d.page_count):
            p = d[i]; p.set_rotation((p.rotation + ang) % 360)
    return _save(d, out / f"{_stem(inputs[0])}.pdf")


@tool("flip")
def flip(inputs, o, out):
    """mirror every page (as it is displayed) left↔right or top↕bottom."""
    d = open_pdf(inputs[0], o.get("password"))
    horiz = o.get("direction", "horizontal") == "horizontal"
    try:
        d.bake(annots=True, widgets=True)  # comments / form fields are mirrored together with the page
    except Exception:
        pass
    for pg in d:
        links = pg.get_links()
        for l in links:
            pg.delete_link(l)
        box = d.xref_get_key(pg.xref, "CropBox")
        nums = [float(v) for v in re.findall(r"-?\d+\.?\d*", box[1])] if box[0] == "array" else []
        if len(nums) != 4:
            mb = pg.mediabox; nums = [mb.x0, mb.y0, mb.x1, mb.y1]
        h = horiz if pg.rotation in (0, 180) else not horiz
        cm = f"-1 0 0 1 {nums[0] + nums[2]:.4f} 0" if h else f"1 0 0 -1 0 {nums[1] + nums[3]:.4f}"
        pre, post = d.get_new_xref(), d.get_new_xref()
        d.update_object(pre, "<<>>"); d.update_stream(pre, f"q {cm} cm\n".encode())
        d.update_object(post, "<<>>"); d.update_stream(post, b"\nQ\n")
        inner = " ".join(f"{x} 0 R" for x in pg.get_contents())
        d.xref_set_key(pg.xref, "Contents", f"[{pre} 0 R {inner} {post} 0 R]")
        w0, h0 = abs(nums[2] - nums[0]), abs(nums[3] - nums[1])   # links stay clickable, at their mirrored place
        for l in links:
            r = l["from"]
            l["from"] = pymupdf.Rect(w0 - r.x1, r.y0, w0 - r.x0, r.y1) if h else pymupdf.Rect(r.x0, h0 - r.y1, r.x1, h0 - r.y0)
            try:
                pg.insert_link(l)
            except Exception:
                pass
    return _save(d, out / f"{_stem(inputs[0])}_flipped.pdf")


# ------------------------------------------------------------------ SPLIT
@tool("split")
def split(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    n = d.page_count
    mode = o.get("mode", "every_page")  # every_page | every_n | ranges | after_pages | even
    stem = _stem(inputs[0])
    groups = []
    if mode == "every_page":
        groups = [[i] for i in range(n)]
    elif mode == "every_n":
        k = max(1, int(_f(o, "n", 2)))
        groups = [list(range(i, min(i + k, n))) for i in range(0, n, k)]
    elif mode == "even":
        groups = [[0]] + [list(range(i, min(i + 2, n))) for i in range(1, n, 2)]
    elif mode == "after_pages":  # split after given pages, e.g. "3,7"
        cuts = sorted(set(parse_ranges(o.get("pages", ""), n)))
        start = 0
        for c in cuts + [n - 1]:
            if c >= start:
                groups.append(list(range(start, c + 1))); start = c + 1
    else:  # ranges: "1-3,4-6,7-"  each comma part is one document
        for part in (o.get("pages") or "").split(","):
            if part.strip():
                groups.append(parse_ranges(part, n))
    paths = []
    for gi, g in enumerate(groups, 1):
        nd = pymupdf.open(); nd.insert_pdf(d, from_page=g[0], to_page=g[0])
        for i in g[1:]:
            nd.insert_pdf(d, from_page=i, to_page=i)
        label = f"{g[0]+1}" if len(g) == 1 else f"{g[0]+1}-{g[-1]+1}"
        paths.append(_save(nd, out / f"{stem}_{label}.pdf"))
    return _multi_out(paths, out, f"{stem}_split")


@tool("split_bookmarks")
def split_bookmarks(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    level = int(_f(o, "level", 1))
    contains = (o.get("contains") or "").lower()
    toc = [t for t in d.get_toc() if t[0] == level and contains in t[1].lower() and t[2] > 0]
    if not toc:
        raise ValueError("No bookmarks found at this level.")
    starts = sorted({t[2] - 1 for t in toc} | {0})
    names = {t[2] - 1: t[1] for t in toc}
    paths = []
    for i, s in enumerate(starts):
        e = (starts[i + 1] - 1) if i + 1 < len(starts) else d.page_count - 1
        if _b(o, "extra_page") and e + 1 < d.page_count:
            e += 1
        nd = pymupdf.open(); nd.insert_pdf(d, from_page=s, to_page=e)
        paths.append(_save(nd, out / f"{i+1:02d}_{safe_name(names.get(s, 'start'))}.pdf"))
    return _multi_out(paths, out, f"{_stem(inputs[0])}_chapters")


@tool("split_size")
def split_size(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    limit = _f(o, "size", 1) * (1024 * 1024 if o.get("unit", "MB") == "MB" else 1024)
    if limit <= 0:
        raise ValueError("Please enter a size greater than 0.")
    n, stem = d.page_count, _stem(inputs[0])

    def size_of(a, b):
        nd = pymupdf.open(); nd.insert_pdf(d, from_page=a, to_page=b)
        return len(nd.tobytes(garbage=3, deflate=True))

    paths, start = [], 0
    while start < n:
        end, step = start, 1
        while end + step < n and size_of(start, end + step) <= limit:  # gallop …
            end += step; step *= 2
        lo, hi = end, min(n - 1, end + step)
        while lo < hi:                                                  # … then bisect
            mid = (lo + hi + 1) // 2
            if size_of(start, mid) <= limit:
                lo = mid
            else:
                hi = mid - 1
        nd = pymupdf.open(); nd.insert_pdf(d, from_page=start, to_page=lo)
        paths.append(_save(nd, out / f"{stem}_{len(paths)+1}.pdf"))
        start = lo + 1
    return _multi_out(paths, out, f"{stem}_split")


@tool("split_text")
def split_text(inputs, o, out):
    """Start a new document whenever the text after `prefix` changes (e.g. invoice numbers)."""
    d = open_pdf(inputs[0], o.get("password"))
    prefix = o.get("prefix") or ""
    pat = re.compile(re.escape(prefix) + r"\s*(\S+)") if prefix else None
    keys = []
    for pg in d:
        t = pg.get_text()
        m = pat.search(t) if pat else None
        keys.append(m.group(1) if m else (t.strip().split("\n")[0][:40] if not pat else None))
    groups, cur, curkey = [], [], object()
    for i, k in enumerate(keys):
        if k is not None and k != curkey and cur:
            groups.append((curkey, cur)); cur = []
        if k is not None:
            curkey = k
        cur.append(i)
    if cur:
        groups.append((curkey, cur))
    paths = []
    for gi, (k, g) in enumerate(groups, 1):
        nd = pymupdf.open()
        for i in g:
            nd.insert_pdf(d, from_page=i, to_page=i)
        paths.append(_save(nd, out / f"{gi:02d}_{safe_name(str(k), 'part')}.pdf"))
    return _multi_out(paths, out, f"{_stem(inputs[0])}_split")


@tool("split_half")
def split_half(inputs, o, out):
    src = open_pdf(inputs[0], o.get("password"))
    vertical = o.get("direction", "vertical") == "vertical"
    ratio = _f(o, "ratio", 0.5)
    rtl = _b(o, "rtl")
    res = pymupdf.open()
    for pg in src:
        r = pg.rect
        if vertical:
            a = pymupdf.Rect(r.x0, r.y0, r.x0 + r.width * ratio, r.y1)
            b = pymupdf.Rect(a.x1, r.y0, r.x1, r.y1)
        else:
            a = pymupdf.Rect(r.x0, r.y0, r.x1, r.y0 + r.height * ratio)
            b = pymupdf.Rect(r.x0, a.y1, r.x1, r.y1)
        for clip in ((b, a) if rtl else (a, b)):
            np_ = res.new_page(width=clip.width, height=clip.height)
            np_.show_pdf_page(np_.rect, src, pg.number, clip=clip)
    return _save(res, out / f"{_stem(inputs[0])}_split.pdf")


# ------------------------------------------------------------------ CROP / RESIZE / N-UP
def _content_bbox(pg):
    """smallest rectangle that contains everything visible on the page."""
    area = pg.rect.get_area()
    imgs = [pymupdf.Rect(i["bbox"]) & pg.rect for i in pg.get_image_info()]
    if not any(r.get_area() > 0.8 * area for r in imgs):
        r = pymupdf.Rect()
        for b in pg.get_text("blocks"):
            r |= pymupdf.Rect(b[:4])
        for x in imgs:
            r |= x
        for dr in pg.get_drawings():
            rr = dr["rect"]
            if rr.width < pg.rect.width * 0.98 or rr.height < pg.rect.height * 0.98:
                r |= rr
        for a in pg.annots() or []:
            r |= a.rect
        for w in pg.widgets() or []:
            r |= w.rect
        if not r.is_empty:
            return r & pg.rect
    # scans / full-page pictures: look at the pixels (anything that differs from the paper colour)
    import numpy as np
    pix = pg.get_pixmap(dpi=50, colorspace=pymupdf.csGRAY)
    a = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width).astype(np.int16)
    paper = int(np.median(np.concatenate([a[:3].ravel(), a[-3:].ravel(), a[:, :3].ravel(), a[:, -3:].ravel()])))
    ink = np.abs(a - paper) > 45
    ys, xs = np.where(ink)
    if not len(xs):
        return pymupdf.Rect()
    k = pg.rect.width / pix.width
    return pymupdf.Rect(xs.min() * k, ys.min() * k, (xs.max() + 1) * k, (ys.max() + 1) * k) & pg.rect


@tool("crop")
def crop(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    mode = o.get("mode", "auto")  # auto (same box for all) | auto_max (each page) | box
    margin = _f(o, "margin", 6)
    pages = parse_ranges(o.get("pages", "all"), d.page_count)
    unrotate(d, pages)

    def apply(pg, r):
        r = (pymupdf.Rect(r) & pg.rect)
        if r.width < 5 or r.height < 5:
            return
        tl = pg.cropbox.tl
        pg.set_cropbox(pymupdf.Rect(r.x0 + tl.x, r.y0 + tl.y, r.x1 + tl.x, r.y1 + tl.y))

    if mode == "box":  # fractions of the visible page, top-left origin
        bx = o.get("box") or {}
        try:
            x0, y0, x1, y1 = (min(1.0, max(0.0, float(bx[k]))) for k in ("x0", "y0", "x1", "y1"))
        except Exception:
            raise ValueError("Please select the area to keep.")
        for i in pages:
            R = d[i].rect
            apply(d[i], pymupdf.Rect(R.width * x0, R.height * y0, R.width * x1, R.height * y1))
    else:
        boxes = {i: _content_bbox(d[i]) for i in pages}
        union = pymupdf.Rect()
        for b in boxes.values():
            union |= b
        for i in pages:
            b = boxes[i] if mode == "auto_max" else union
            if not b.is_empty:
                apply(d[i], b + (-margin, -margin, margin, margin))
    return _save(d, out / f"{_stem(inputs[0])}_cropped.pdf")


SIZES = {"a3": (842, 1191), "a4": (595, 842), "a5": (420, 595), "letter": (612, 792), "legal": (612, 1008), "tabloid": (792, 1224)}


@tool("resize")
def resize(inputs, o, out):
    src = open_pdf(inputs[0], o.get("password"))
    pages = set(parse_ranges(o.get("pages", "all"), src.page_count))
    mode = o.get("mode", "margins")
    res = pymupdf.open()
    for pg in src:
        r = pg.rect
        if pg.number not in pages:
            res.insert_pdf(src, from_page=pg.number, to_page=pg.number); continue
        if mode == "margins":
            m = _f(o, "margin", 0.5) * 72  # inches
            np_ = res.new_page(width=r.width + 2 * m, height=r.height + 2 * m)
            np_.show_pdf_page(pymupdf.Rect(m, m, m + r.width, m + r.height), src, pg.number)
        else:
            w, h = SIZES.get((o.get("size") or "a4").lower(), SIZES["a4"])
            if (r.width > r.height) != (w > h):
                w, h = h, w
            np_ = res.new_page(width=w, height=h)
            np_.show_pdf_page(np_.rect, src, pg.number, keep_proportion=True)
    return _save(res, out / f"{_stem(inputs[0])}_resized.pdf")


@tool("nup")
def nup(inputs, o, out):
    src = open_pdf(inputs[0], o.get("password"))
    n = int(_f(o, "n", 2))
    cols = {2: 2, 4: 2, 8: 4, 16: 4, 32: 8}.get(n, 2)
    rows = n // cols
    r0 = src[0].rect
    if _b(o, "keep_size", True):
        W, H = r0.width, r0.height
    else:
        W, H = r0.width * cols, r0.height * rows
    if n == 2 and W < H:  # 2-up goes landscape
        W, H = H, W
        cols, rows = 2, 1
    vertical = o.get("order", "horizontal") == "vertical"
    rtl = _b(o, "rtl")
    res = pymupdf.open()
    cw, ch = W / cols, H / rows
    for start in range(0, src.page_count, n):
        sheet = res.new_page(width=W, height=H)
        for k in range(n):
            i = start + k
            if i >= src.page_count:
                break
            c, r = (k // rows, k % rows) if vertical else (k % cols, k // cols)
            if rtl:
                c = cols - 1 - c
            sheet.show_pdf_page(pymupdf.Rect(c * cw, r * ch, (c + 1) * cw, (r + 1) * ch), src, i)
    return _save(res, out / f"{_stem(inputs[0])}_{n}up.pdf")


# ------------------------------------------------------------------ COMPRESS / GRAYSCALE / FLATTEN / REPAIR
def _gs(args):
    gs = shutil.which("gs") or shutil.which("gswin64c")
    if not gs:
        raise RuntimeError("Ghostscript not installed")
    subprocess.run([gs, "-q", "-dNOPAUSE", "-dBATCH", "-dSAFER", "-sDEVICE=pdfwrite", "-dCompatibilityLevel=1.6"] + args,
                   check=True, capture_output=True, timeout=600)


@tool("compress")
def compress(inputs, o, out):
    q = o.get("quality", "medium")  # medium=most compression, good, best
    dpi = int(_f(o, "dpi", {"medium": 100, "good": 144, "best": 200}.get(q, 144)))
    jpegq = {"medium": 60, "good": 75, "best": 88}.get(q, 75)
    paths = []
    for p in inputs:
        dst = out / f"{_stem(p)}_compressed.pdf"
        tmp = out / f"_gs_{_stem(p)}.pdf"
        args = [f"-sOutputFile={tmp}", "-dDetectDuplicateImages=true", "-dCompressFonts=true", "-dSubsetFonts=true",
                "-dDownsampleColorImages=true", "-dDownsampleGrayImages=true", "-dDownsampleMonoImages=true",
                f"-dColorImageResolution={dpi}", f"-dGrayImageResolution={dpi}", f"-dMonoImageResolution={max(dpi*2,300)}",
                "-dColorImageDownsampleThreshold=1.1", "-dGrayImageDownsampleThreshold=1.1",
                "-dAutoFilterColorImages=false", "-dColorImageFilter=/DCTEncode", "-dAutoFilterGrayImages=false",
                "-dGrayImageFilter=/DCTEncode", f"-dJPEGQ={jpegq}"]
        if o.get("convert") == "grayscale":
            args += ["-sColorConversionStrategy=Gray", "-dProcessColorModel=/DeviceGray"]
        if o.get("password"):
            args.append(f"-sPDFPassword={o['password']}")
        try:
            _gs(args + [str(p)])
            # second pass: object streams + lossless recompression with qpdf/pikepdf
            with pikepdf.open(tmp) as pdf:
                if False and o.get("multimedia", "discard") == "discard":
                    for pg in pdf.pages:
                        if "/Annots" in pg:
                            pg.Annots = pikepdf.Array([a for a in pg.Annots if a.get("/Subtype") not in ("/RichMedia", "/Movie", "/Sound", "/Screen")])
                pdf.remove_unreferenced_resources()
                if o.get("multimedia", "discard") == "discard":
                    for pg in pdf.pages:
                        if "/Annots" in pg:
                            keep = [a for a in pg.Annots if str(a.get("/Subtype", "")) not in ("/RichMedia", "/Movie", "/Sound", "/Screen", "/3D")]
                            if len(keep) != len(pg.Annots):
                                pg.Annots = pikepdf.Array(keep)
                pdf.save(dst, compress_streams=True, object_stream_mode=pikepdf.ObjectStreamMode.generate,
                         recompress_flate=True, linearize=_b(o, "linearize"))
        except Exception:
            with pikepdf.open(p, password=o.get("password") or "") as pdf:
                pdf.remove_unreferenced_resources()
                pdf.save(dst, compress_streams=True, object_stream_mode=pikepdf.ObjectStreamMode.generate, recompress_flate=True)
        tmp.unlink(missing_ok=True)
        # never return a bigger file than the original
        if dst.stat().st_size >= Path(p).stat().st_size:
            shutil.copy(p, dst)
        paths.append(dst)
    return _multi_out(paths, out, "compressed")


@tool("grayscale")
def grayscale(inputs, o, out):
    dst = out / f"{_stem(inputs[0])}_grayscale.pdf"
    args = [f"-sOutputFile={dst}", "-sColorConversionStrategy=Gray", "-dProcessColorModel=/DeviceGray", "-dOverrideICC"]
    if o.get("password"):
        args.append(f"-sPDFPassword={o['password']}")
    _gs(args + [str(inputs[0])])
    return dst


@tool("flatten")
def flatten(inputs, o, out):
    mode = o.get("mode", "forms")  # forms | everything
    d = open_pdf(inputs[0], o.get("password"))
    stem = _stem(inputs[0])
    if mode == "everything":
        dpi = int(_f(o, "dpi", 150))
        res = pymupdf.open()
        for pg in d:
            pix = pg.get_pixmap(dpi=dpi, annots=True)
            np_ = res.new_page(width=pg.rect.width, height=pg.rect.height)
            np_.insert_image(np_.rect, stream=pix.tobytes("jpeg", jpg_quality=85))
        return _save(res, out / f"{stem}_flattened.pdf")
    d.bake(annots=True, widgets=True)  # turn form fields + annotations into page content
    return _save(d, out / f"{stem}_flattened.pdf")


@tool("repair")
def repair(inputs, o, out):
    dst = out / f"{_stem(inputs[0])}_repaired.pdf"
    try:  # qpdf reconstructs broken xref tables
        with pikepdf.open(inputs[0], password=o.get("password") or "", attempt_recovery=True) as pdf:
            pdf.save(dst)
        pymupdf.open(dst).close()
        return dst
    except Exception:
        pass
    try:  # MuPDF repair
        d = pymupdf.open(inputs[0])
        return _save(d, dst, garbage=4)
    except Exception:
        _gs([f"-sOutputFile={dst}", str(inputs[0])])  # last resort: re-distill
        return dst


# ------------------------------------------------------------------ SECURITY
@tool("protect")
def protect(inputs, o, out):
    user = o.get("password") or ""
    owner = o.get("owner_password") or user or os.urandom(8).hex()
    allow = o.get("allow") or {}
    perms = pikepdf.Permissions(
        modify_other=bool(allow.get("modify", False)),
        extract=bool(allow.get("copy", False)),
        print_lowres=bool(allow.get("print", True)),
        print_highres=bool(allow.get("print_hq", True)),
        modify_form=bool(allow.get("forms", True)),
        modify_annotation=bool(allow.get("comment", False)),
        modify_assembly=bool(allow.get("assemble", False)),
        accessibility=True,
    )
    R = {"rc4": 3, "aes128": 4, "aes256": 6}.get(o.get("encryption", "aes256"), 6)
    dst = out / f"{_stem(inputs[0])}_protected.pdf"
    with pikepdf.open(inputs[0]) as pdf:
        pdf.save(dst, encryption=pikepdf.Encryption(user=user, owner=owner, allow=perms, R=R, aes=R >= 4))
    return dst


@tool("unlock")
def unlock(inputs, o, out):
    dst = out / f"{_stem(inputs[0])}_unlocked.pdf"
    try:
        with pikepdf.open(inputs[0], password=o.get("password") or "") as pdf:
            pdf.save(dst)  # saving without encryption removes password + restrictions
    except pikepdf.PasswordError:
        raise ValueError("Wrong password. This PDF needs its open password to be unlocked.")
    return dst


def _parse_color(c, default=(0, 0, 0)):
    if not c:
        return default
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) / 255 for i in (0, 2, 4))


def _pos_rect(page_rect, pos, w, h, margin=24):
    """pos like 'top-left','bottom-center','center'."""
    R = page_rect
    v, _, hz = (pos or "bottom-center").partition("-")
    if v == "center":
        hz = "center"
    x = {"left": R.x0 + margin, "center": (R.width - w) / 2, "right": R.x1 - margin - w}.get(hz or "center")
    y = {"top": R.y0 + margin, "center": (R.height - h) / 2, "bottom": R.y1 - margin - h}.get(v, R.y1 - margin - h)
    return pymupdf.Rect(x, y, x + w, y + h)


@tool("watermark", multi=True)
def watermark(inputs, o, out):
    texts = [t for t in (o.get("text") or "").split("\n") if t.strip()] or [""]
    opacity = min(1.0, max(0.02, _f(o, "opacity", 0.3)))
    angle = _f(o, "rotation", 45)
    size = _f(o, "size", 48)
    color = _parse_color(o.get("color"), (0.8, 0, 0))
    position = o.get("position", "center")
    stamp, ratio = None, 1.0
    if o.get("image_path"):
        from PIL import Image
        im = Image.open(o["image_path"]).convert("RGBA")
        im.putalpha(im.getchannel("A").point(lambda v: int(v * opacity)))  # real transparency for picture watermarks
        buf = io.BytesIO(); im.save(buf, "PNG"); stamp = buf.getvalue(); ratio = im.height / im.width
    if not stamp and not any(texts):
        raise ValueError("Please enter the watermark text or choose an image.")
    paths = []
    for p in inputs:
        for t in texts:
            d = open_pdf(p, o.get("password"))
            pages = parse_ranges(o.get("pages", "all"), d.page_count)
            unrotate(d, pages)
            cache = {}
            fam = FAMS.get(o.get("font", "sans"), o.get("font") or "liberationsans")
            from . import editor as _ed
            tw = 0
            if t:   # width of the text (any script) – needed to place it in a corner
                tw = _ed.text_form(t, size, "#000000", _b(o, "bold", True), False, fam)[1] if _ed.needs_shaping(t, fam) else \
                    pymupdf.Font(fontfile=_ed.F.face(fam if _ed.F.has(fam) else "liberationsans", _b(o, "bold", True), False)[0]).text_length(t, fontsize=size)
            for i in pages:
                pg = d[i]; R = pg.rect
                if position == "mosaic":
                    nx, ny = 3, 4
                    spots = [pymupdf.Point(R.width * (c + 0.5) / nx, R.height * (r + 0.5) / ny) for r in range(ny) for c in range(nx)]
                elif position == "center":
                    spots = [pymupdf.Point(R.width / 2, R.height / 2)]
                else:
                    rr = _pos_rect(R, position, tw if t else R.width * _f(o, "img_scale", 0.3), size if t else R.width * _f(o, "img_scale", 0.3) * ratio)
                    spots = [pymupdf.Point((rr.x0 + rr.x1) / 2, (rr.y0 + rr.y1) / 2)]
                for c in spots:
                    if stamp:
                        W = R.width * _f(o, "img_scale", 0.3) * (0.6 if position == "mosaic" else 1); H = W * ratio
                        pg.insert_image(pymupdf.Rect(c.x - W / 2, c.y - H / 2, c.x + W / 2, c.y + H / 2), stream=stamp, overlay=not _b(o, "behind"))
                    if t:
                        fs = size * (0.45 if position == "mosaic" else 1)
                        if angle:
                            draw_text(pg, t, c.x, c.y, fs, color, fam, _b(o, "bold", True), "center", angle, opacity, cache, not _b(o, "behind"))
                        else:
                            draw_text(pg, t, c.x, c.y + fs / 3, fs, color, fam, _b(o, "bold", True), "center", 0, opacity, cache, not _b(o, "behind"))
            name = f"{_stem(p)}" + (f"_{safe_name(t)}" if len(texts) > 1 else "_watermarked")
            paths.append(_save(d, out / f"{name}.pdf", subset=True))
    return _multi_out(paths, out, "watermarked")


# ------------------------------------------------------------------ NUMBERS / HEADERS / BATES
def _stamp(d, pages, text_fn, o, fontfamily="sans"):
    size = _f(o, "size", 10)
    color = _parse_color(o.get("color"), (0, 0, 0))
    pos = o.get("position", "bottom-center")
    margin = _f(o, "margin", 24)
    grow = o.get("margins") == "increase"
    v, _, hz = pos.partition("-")
    hz = hz or "center"
    cache = {}
    unrotate(d, pages)
    for k, i in enumerate(pages):
        pg = d[i]
        if grow:  # add room above and below instead of printing over the content
            pad = size * 2.5
            mb = pg.mediabox
            pg.set_mediabox(pymupdf.Rect(mb.x0, mb.y0 - pad, mb.x1, mb.y1 + pad))
            pg = d[i]
        t = text_fn(k, i)
        if not t:
            continue
        R = pg.rect; m = margin if not grow else size * 0.8
        if o.get("mirror") and k % 2:   # book layout: outer corner on facing pages
            hz = {"left": "right", "right": "left"}.get(pos.partition("-")[2] or "center", "center")
        elif o.get("mirror"):
            hz = pos.partition("-")[2] or "center"
        x = {"left": R.x0 + m, "center": R.x0 + R.width / 2, "right": R.x1 - m}[hz if hz in ("left", "center", "right") else "center"]
        y = R.y0 + m + size * 0.8 if v == "top" else R.y1 - m - size * 0.2
        draw_text(pg, t, x, y, size, color, o.get("font", fontfamily), _b(o, "bold"), hz if hz in ("left", "center", "right") else "center", cache=cache)


@tool("page_numbers")
def page_numbers(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    pages = parse_ranges(o.get("pages", "all"), d.page_count)
    start = int(_f(o, "start", 1))
    fmt = o.get("format", "{n}")  # {n}, Page {n} of {total}
    total = len(pages) + start - 1
    _stamp(d, pages, lambda k, i: fmt.replace("{n}", str(k + start)).replace("{total}", str(total)), o)
    return _save(d, out / f"{_stem(inputs[0])}_numbered.pdf", subset=True)


@tool("header_footer")
def header_footer(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    pages = parse_ranges(o.get("pages", "all"), d.page_count)
    start = int(_f(o, "start", 1))
    name = Path(inputs[0]).name
    for key, default_pos in (("header", "top-center"), ("footer", "bottom-center")):
        txt = o.get(key)
        if not txt:
            continue
        oo = dict(o); oo["position"] = o.get(key + "_position", default_pos)
        _stamp(d, pages, lambda k, i, t=txt: t.replace("{n}", str(k + start)).replace("{total}", str(len(pages) + start - 1))
               .replace("{filename}", name).replace("{date}", __import__("datetime").date.today().strftime("%d %b %Y")), oo)
    return _save(d, out / f"{_stem(inputs[0])}.pdf", subset=True)


@tool("bates", multi=True)
def bates(inputs, o, out):
    prefix, suffix = o.get("prefix", ""), o.get("suffix", "")
    seq = int(_f(o, "start", 1)); digits = int(_f(o, "digits", 6))
    paths = []
    for fi, p in enumerate(inputs, int(_f(o, "file_start", 1))):
        d = open_pdf(p)
        def txt(k, i):
            nonlocal seq
            s = f"{prefix}{seq:0{digits}d}{suffix}"; seq += 1
            return s
        _stamp(d, list(range(d.page_count)), txt, dict(o, position=o.get("position", "bottom-right")))
        paths.append(_save(d, out / f"{fi}-{_stem(p)}.pdf", subset=True))
    return _multi_out(paths, out, "bates")


# ------------------------------------------------------------------ METADATA / BOOKMARKS / ANNOTATIONS
@tool("metadata")
def metadata(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    if o.get("mode") == "remove":
        d.set_metadata({}); d.del_xml_metadata()
    else:
        md = d.metadata or {}
        for k in ("title", "author", "subject", "keywords", "creator", "producer"):
            if k in o:
                md[k] = o[k]
        d.set_metadata(md)
    return _save(d, out / f"{_stem(inputs[0])}.pdf")


@tool("bookmarks")
def bookmarks(inputs, o, out):
    """o['toc'] = [[level, title, page(1-based)], ...]"""
    d = open_pdf(inputs[0], o.get("password"))
    toc, last = [], 0
    for it in o.get("toc") or []:
        try:
            lvl, title, pg = int(it[0]), str(it[1]).strip() or "Untitled", int(it[2])
        except Exception:
            continue
        lvl = max(1, min(lvl, last + 1)); last = lvl   # levels may only go one step deeper at a time
        toc.append([lvl, title[:200], max(1, min(d.page_count, pg))])
    d.set_toc(toc)
    return _save(d, out / f"{_stem(inputs[0])}.pdf")


ANNOT_TYPES = {"highlight": 8, "underline": 9, "strikeout": 11, "ink": 15, "polygon": 6, "square": 4, "circle": 5,
               "line": 3, "polyline": 7, "link": -1, "text": 0, "freetext": 2, "popup": 16, "stamp": 13, "squiggly": 10}


@tool("remove_annotations")
def remove_annotations(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    kinds = o.get("types") or ["all"]
    codes = None if "all" in kinds else {ANNOT_TYPES[k] for k in kinds if k in ANNOT_TYPES}
    for i in parse_ranges(o.get("pages", "all"), d.page_count):
        pg = d[i]
        for a in list(pg.annots() or []):
            if codes is None or a.type[0] in codes:
                pg.delete_annot(a)
        if codes is None or -1 in codes:
            for l in pg.get_links():
                pg.delete_link(l)
    return _save(d, out / f"{_stem(inputs[0])}.pdf")


# ------------------------------------------------------------------ OCR / DESKEW
OCR_LANGS = "eng+hin"


def ocr_lang(lang):
    """only installed Tesseract languages, e.g. 'eng+hin' (protects the command line, too)."""
    from .editor import ocr_langs
    return ocr_langs(re.sub(r"[^a-z_+]", "", (lang or OCR_LANGS).lower()))


def run_ocr(src, dst, lang=OCR_LANGS, deskew=False, force=False, sidecar=None):
    lang = ocr_lang(lang)
    cmd = ["ocrmypdf", "-l", lang, "--output-type", "pdf", "--optimize", "1", "--jobs", str(min(4, os.cpu_count() or 2))]
    cmd += ["--force-ocr"] if force else ["--skip-text"]
    if deskew:
        cmd += ["--deskew", "--rotate-pages"] if force else ["--deskew"]
    if sidecar:
        cmd += ["--sidecar", str(sidecar)]
    r = subprocess.run(cmd + [str(src), str(dst)], capture_output=True, text=True, timeout=1800)
    if r.returncode == 6:  # every page already has text
        shutil.copy(src, dst)
    elif r.returncode != 0 or not Path(dst).exists():
        # fallback: MuPDF's built-in Tesseract bridge
        d = pymupdf.open(src)
        res = pymupdf.open()
        for pg in d:
            res.insert_pdf(pymupdf.open("pdf", pg.get_pixmap(dpi=300).pdfocr_tobytes(language=lang)))
        res.save(dst)
    return dst


@tool("ocr", multi=True)
def ocr(inputs, o, out):
    lang = o.get("lang") or OCR_LANGS
    fmts = o.get("formats") or ["pdf"]
    paths = []
    for p in inputs:
        dst = out / f"{_stem(p)}_ocr.pdf"
        side = out / f"{_stem(p)}_ocr.txt"
        run_ocr(p, dst, lang, deskew=_b(o, "deskew"), force=_b(o, "force"), sidecar=side)
        if not side.exists() or not side.read_text(errors="ignore").strip():
            side.write_text("\n\n".join(pg.get_text() for pg in pymupdf.open(dst)), encoding="utf-8")
        if "pdf" in fmts:
            paths.append(dst)
        if "text" in fmts:
            paths.append(side)
    return _multi_out(paths, out, "ocr")


@tool("deskew")
def deskew(inputs, o, out):
    d = pymupdf.open(inputs[0])
    if not is_scanned(d, page_limit=d.page_count):
        raise ValueError("This PDF is not a scan – its pages are already straight.")
    d.close()
    dst = out / f"{_stem(inputs[0])}_deskewed.pdf"
    r = subprocess.run(["ocrmypdf", "--deskew", "--force-ocr", "-l", ocr_lang(o.get("lang")), "--output-type", "pdf", "--optimize", "1",
                        str(inputs[0]), str(dst)], capture_output=True, text=True, timeout=1800)
    if r.returncode != 0 or not dst.exists():
        raise RuntimeError("Could not straighten this document: " + r.stderr[-200:])
    return dst


def is_scanned(doc, page_limit=5):
    """True if the first pages are scans (image-only, or image + invisible OCR text layer)."""
    from .editor import is_scanned_page
    return any(is_scanned_page(pg) for pg in list(doc)[:page_limit])


def ensure_text(p, out, lang=OCR_LANGS, visible=False):
    """Return a PDF path that has a text layer (OCR it if it's a scan).
    visible=True → real, visible, editable text replaces the scanned glyphs (needed for Word/Excel export)."""
    d = pymupdf.open(p)
    if is_scanned(d):
        d.close()
        dst = out / f"_ocr_{_stem(p)}.pdf"
        if visible:
            from .editor import scan_to_digital
            return Path(scan_to_digital(p, dst, lang)), True
        return run_ocr(p, dst, lang), True
    d.close()
    return Path(p), False


@tool("scan_to_editable", multi=False)
def scan_to_editable(inputs, o, out):
    """Scanned PDF → digital PDF with real, editable text (pixels of the old text are erased)."""
    from .editor import scan_to_digital
    return Path(scan_to_digital(inputs[0], out / f"{_stem(inputs[0])}_editable.pdf", o.get("lang") or OCR_LANGS))


# ------------------------------------------------------------------ CONVERT FROM PDF
@tool("pdf_to_word", multi=True)
def pdf_to_word(inputs, o, out):
    from pdf2docx import Converter
    fmt = (o.get("format") or "docx").lower()
    paths = []
    for p in inputs:
        src, _ = ensure_text(p, out, o.get("lang") or OCR_LANGS, visible=True)
        dst = out / f"{_stem(p)}.docx"
        cv = Converter(str(src))
        try:
            cv.convert(str(dst), multi_processing=False)
        finally:
            cv.close()
        if fmt in ("odt", "rtf", "doc"):  # LibreOffice turns the Word file into the other formats
            soffice = shutil.which("soffice") or shutil.which("libreoffice")
            subprocess.run([soffice, "--headless", "--norestore", "--convert-to", fmt, "--outdir", str(out), str(dst)],
                           check=True, capture_output=True, timeout=300, env=dict(os.environ, HOME=str(out)))
            dst.unlink(); dst = out / f"{_stem(p)}.{fmt}"
        paths.append(dst)
    return _multi_out(paths, out, "word")


def table_rows(pg, tb):
    """cell texts of a table found by find_tables() – read cell by cell (Table.extract() scrambles numbers like 1,150.00)."""
    rows = []
    for row in tb.rows:
        rows.append([" ".join(pg.get_textbox(pymupdf.Rect(c) + (0.8, 0.8, -0.8, -0.8)).split()) if c else "" for c in row.cells])
    return [r for r in rows if any(r)]


@tool("pdf_to_excel", multi=True)
def pdf_to_excel(inputs, o, out):
    """PDF → Excel / CSV.  tables: ruled tables (cell borders), else rows that look like a table (bank statements, price lists);
    layout: the whole page as an aligned grid.  Numbers become real numbers (1,23,456.50 → 123456.5)."""
    import openpyxl, csv
    from openpyxl.styles import Font as XFont
    paths = []
    as_csv = o.get("format") == "csv"
    mode = o.get("mode", "layout")  # layout | tables
    one = o.get("sheets") == "one"
    for p in inputs:
        src, _ = ensure_text(p, out, o.get("lang") or OCR_LANGS, visible=True)
        wb = openpyxl.Workbook(); wb.remove(wb.active)
        rows_all = []
        ws = wb.create_sheet("All pages") if one else None
        r0 = 1
        doc = open_pdf(src, o.get("password"))
        for pg in doc:
            if not one:
                ws = wb.create_sheet(f"Page {pg.number+1}"); r0 = 1
            groups = []   # list of tables, each a list of rows
            if mode == "tables":
                try:
                    groups = [table_rows(pg, tb) for tb in pg.find_tables().tables]
                except Exception:
                    groups = []
                groups = [g for g in groups if g]
                if not groups:   # no cell borders: keep the lines that have several columns
                    grid = [row for row in _word_grid(pg) if sum(1 for v in row if v) >= 2]
                    keep = [i for i in range(len(grid[0]))] if grid else []
                    keep = [i for i in keep if any(row[i] for row in grid)]
                    groups = [[[row[i] for i in keep] for row in grid]] if grid else []
            else:  # keep layout: whole page as an aligned grid
                groups = [_word_grid(pg)]
            for g in groups:
                for k, row in enumerate(g):
                    for ci, v in enumerate(row, 1):
                        if v:
                            c = ws.cell(r0, ci, _num(v))
                            if isinstance(c.value, float) and re.search(r"\.\d\d\)?$", v.strip()):
                                c.number_format = "#,##0.00"
                            if mode == "tables" and k == 0:
                                c.font = XFont(bold=True)
                    rows_all.append(row); r0 += 1
                if mode == "tables":
                    r0 += 1
            if not one and ws.max_row <= 1 and not ws.cell(1, 1).value:
                ws.cell(1, 1, "(no tables found on this page)")
        for sh in wb.worksheets:
            for col in sh.columns:
                sh.column_dimensions[col[0].column_letter].width = min(60, max(8, max(len(str(c.value or "")) for c in col) + 2))
        if as_csv:
            dst = out / f"{_stem(p)}.csv"
            with open(dst, "w", newline="", encoding="utf-8-sig") as f:
                csv.writer(f).writerows(rows_all)
        else:
            dst = out / f"{_stem(p)}.xlsx"; wb.save(dst)
        paths.append(dst)
    return _multi_out(paths, out, "excel")


def _word_grid(pg):
    """Group words into rows (same baseline) and split a row into cells at big horizontal gaps.
    Column positions are aligned across rows by clustering cell start x."""
    words = pg.get_text("words", sort=True)
    rows = []
    for w in words:
        x0, y0, x1, y1, t = w[:5]
        if rows and abs(rows[-1]["y"] - y1) < (y1 - y0) * 0.5:
            rows[-1]["w"].append(w)
        else:
            rows.append({"y": y1, "w": [w]})
    cells_rows = []
    for r in rows:
        ws_ = sorted(r["w"], key=lambda w: w[0])
        cells, cur = [], [ws_[0]]
        for a, b in zip(ws_, ws_[1:]):
            h = a[3] - a[1]
            if b[0] - a[2] > h * 1.2:
                cells.append(cur); cur = [b]
            else:
                cur.append(b)
        cells.append(cur)
        cells_rows.append([(c[0][0], " ".join(w[4] for w in c)) for c in cells])
    xs = sorted(x for row in cells_rows for x, _ in row)
    cols = []
    for x in xs:
        if not cols or x - cols[-1][-1] > 12:
            cols.append([x])
        else:
            cols[-1].append(x)
    anchors = [sum(c) / len(c) for c in cols]
    grid = []
    for row in cells_rows:
        line = [""] * len(anchors)
        for x, t in row:
            ci = min(range(len(anchors)), key=lambda i: abs(anchors[i] - x))
            line[ci] = (line[ci] + " " + t).strip()
        grid.append(line)
    return grid


def _num(s):
    """'1,23,456.50' → 123456.5 · '(450.00)' → -450.0 · '120' → 120 · anything else stays text (phone numbers, codes with leading zeros …)"""
    t = s.strip().replace(",", "")
    neg = t.startswith("(") and t.endswith(")")
    if neg:
        t = "-" + t[1:-1]
    try:
        if re.fullmatch(r"-?\d{1,15}", t) and not (len(t.lstrip("-")) > 1 and t.lstrip("-").startswith("0")):
            return int(t)
        if re.fullmatch(r"-?\d+\.\d+", t):
            return float(t)
    except ValueError:
        pass
    return s


PPT_FONTS = {"liberationsans": "Arial", "liberationserif": "Times New Roman", "liberationmono": "Courier New", "carlito": "Calibri",
             "caladea": "Cambria", "dejavusans": "Verdana", "dejavuserif": "Georgia", "notosansdevanagari": "Nirmala UI"}


@tool("pdf_to_ppt")
def pdf_to_ppt(inputs, o, out):
    """Every page → one slide. Pictures and graphics become the slide background, every paragraph an EDITABLE text box."""
    from pptx import Presentation
    from pptx.util import Emu, Pt
    from pptx.dml.color import RGBColor
    from pptx.enum.text import PP_ALIGN, MSO_AUTO_SIZE
    from .editor import page_model
    from . import fonts as F
    src, _ = ensure_text(inputs[0], out, o.get("lang") or OCR_LANGS, visible=True)
    d = open_pdf(src, o.get("password"))
    unrotate(d)
    prs = Presentation()
    r0 = d[0].rect
    E = 12700  # EMU per point
    prs.slide_width, prs.slide_height = Emu(int(r0.width * E)), Emu(int(r0.height * E))
    blank = prs.slide_layouts[6]
    for pg in d:
        m = page_model(d, pg.number)
        tmp = pymupdf.open(); tmp.insert_pdf(d, from_page=pg.number, to_page=pg.number, annots=False, links=False, widgets=False)
        tp = tmp[0]
        if m["blocks"]:
            tp.add_redact_annot(tp.rect, fill=False)   # background picture = the page without its text
            tp.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_NONE, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE)
        s = prs.slides.add_slide(blank)
        kx, ky = r0.width / pg.rect.width, r0.height / pg.rect.height
        s.shapes.add_picture(io.BytesIO(tp.get_pixmap(dpi=150).tobytes("jpeg", jpg_quality=88)), 0, 0, prs.slide_width, prs.slide_height)
        for b in m["blocks"]:
            x0, y0, x1, y1 = b["bbox"]
            ex0, ex1 = b["box"] if b["single"] else (x0, x1)
            box = s.shapes.add_textbox(Emu(int(ex0 * kx * E)), Emu(int((y0 - 1) * ky * E)), Emu(int(max(10, ex1 - ex0 + 2) * kx * E)), Emu(int((y1 - y0 + 2) * ky * E)))
            tf = box.text_frame
            tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
            tf.word_wrap = not b["single"]; tf.auto_size = MSO_AUTO_SIZE.NONE
            for k, para in enumerate(b["paras"]):
                p = tf.paragraphs[0] if k == 0 else tf.add_paragraph()
                p.alignment = {"center": PP_ALIGN.CENTER, "right": PP_ALIGN.RIGHT, "justify": PP_ALIGN.JUSTIFY}.get(b["align"], PP_ALIGN.LEFT)
                p.line_spacing = max(0.8, min(2.5, b["lh"] / 1.2))
                for run in para:
                    r = p.add_run(); r.text = run["t"]
                    f = r.font; f.size = Pt(max(4, round(run["s"] * ky, 1))); f.bold = bool(run.get("b")); f.italic = bool(run.get("i"))
                    f.underline = bool(run.get("u")); f.name = PPT_FONTS.get(run.get("fam"), F.REG.get(run.get("fam"), {}).get("name", "Arial"))
                    c = run.get("c", "#000000").lstrip("#")
                    try:
                        f.color.rgb = RGBColor.from_string(c.upper())
                    except Exception:
                        pass
        tmp.close()
    dst = out / f"{_stem(inputs[0])}.pptx"; prs.save(dst)
    return dst


@tool("pdf_to_text", multi=True)
def pdf_to_text(inputs, o, out):
    paths = []
    for p in inputs:
        src, _ = ensure_text(p, out)
        dst = out / f"{_stem(p)}.txt"
        from .editor import page_text
        doc = pymupdf.open(src)
        dst.write_text("\n\n".join(page_text(doc, i) for i in range(doc.page_count)), encoding="utf-8")
        paths.append(dst)
    return _multi_out(paths, out, "text")


@tool("pdf_to_image")
def pdf_to_image(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    fmt = (o.get("format") or "jpg").lower().replace("jpeg", "jpg")
    if fmt not in ("jpg", "png", "tiff", "webp", "bmp", "gif"):
        fmt = "jpg"
    dpi = int(min(600, max(36, _f(o, "dpi", 150))))
    stem = _stem(inputs[0])
    pages = parse_ranges(o.get("pages", "all"), d.page_count)
    if _b(o, "one_image"):  # all pages stacked into one long picture (for WhatsApp / social media)
        from PIL import Image
        dpi = min(dpi, 150)
        tiles = []
        for i in pages[:60]:
            pix = d[i].get_pixmap(dpi=dpi); tiles.append(Image.frombytes("RGB", (pix.width, pix.height), pix.samples))
        W = max(t.width for t in tiles); H = sum(t.height for t in tiles) + 8 * (len(tiles) - 1)
        if H > 65000:
            raise ValueError("Too many pages for one image – choose fewer pages or a lower resolution.")
        sheet = Image.new("RGB", (W, H), "#d9dce3"); y = 0
        for t in tiles:
            sheet.paste(t, ((W - t.width) // 2, y)); y += t.height + 8
        dst = out / f"{stem}_long.{fmt if fmt in ('jpg', 'png', 'webp') else 'jpg'}"
        sheet.save(dst, quality=88)
        return dst
    paths = []
    for i in pages:
        pix = d[i].get_pixmap(dpi=dpi)
        dst = out / f"{stem}-{i+1}.{fmt}"
        if fmt == "jpg":
            dst.write_bytes(pix.tobytes("jpeg", jpg_quality=90))
        elif fmt == "png":
            pix.save(dst)
        else:
            pix.pil_save(dst, format={"tiff": "TIFF", "webp": "WEBP", "bmp": "BMP", "gif": "GIF"}[fmt], **({"compression": "tiff_lzw"} if fmt == "tiff" else {}))
        paths.append(dst)
    return _multi_out(paths, out, f"{stem}_images")


@tool("extract_images")
def extract_images(inputs, o, out):
    d = open_pdf(inputs[0], o.get("password"))
    paths, seen = [], set()
    for pg in d:
        for img in pg.get_images(full=True):
            xref = img[0]
            if xref in seen:
                continue
            seen.add(xref)
            try:
                info = d.extract_image(xref)
            except Exception:
                continue
            if not info or info["width"] < 16 or info["height"] < 16:
                continue
            data, ext = info["image"], info["ext"]
            if img[1]:  # picture with transparency: put the soft mask back → PNG with alpha
                try:
                    pix = pymupdf.Pixmap(pymupdf.Pixmap(d, xref), pymupdf.Pixmap(d, img[1]))
                    data, ext = pix.tobytes("png"), "png"
                except Exception:
                    pass
            elif ext not in ("jpeg", "jpg", "png", "jp2", "jpx", "tiff", "gif", "bmp"):
                try:
                    pix = pymupdf.Pixmap(d, xref)
                    if pix.n - pix.alpha >= 4:
                        pix = pymupdf.Pixmap(pymupdf.csRGB, pix)
                    data, ext = pix.tobytes("png"), "png"
                except Exception:
                    pass
            dst = out / f"page{pg.number+1}_img{len(paths)+1}.{'jpg' if ext == 'jpeg' else ext}"
            dst.write_bytes(data); paths.append(dst)
    if not paths:
        raise ValueError("No images found in this PDF.")
    return zip_files(paths, out / f"{_stem(inputs[0])}_images.zip")


@tool("rename", multi=True)
def rename(inputs, o, out):
    """New file name from text inside the PDF. [TEXT1] = text after a label (e.g. "Invoice number") or text in a drawn area;
    [TEXT2], [TEXT3] = further areas; [BASENAME] = old name."""
    pattern = o.get("pattern") or "[TEXT1]"
    label = (o.get("label") or "").strip()
    paths, used = [], set()
    for p in inputs:
        d = open_pdf(p)
        vals = {"BASENAME": _stem(p)}
        for k, a in enumerate(o.get("areas") or [], 1):
            pg = d[min(d.page_count - 1, max(0, int(a.get("page", 0))))]; r = pg.rect
            vals[f"TEXT{k}"] = " ".join(pg.get_textbox(pymupdf.Rect(r.width * a["x0"], r.height * a["y0"], r.width * a["x1"], r.height * a["y1"])).split())
        if label:
            m = re.search(re.escape(label) + r"[\s:#.\-–]*([\w/\-]+)", d[0].get_text(), re.I)
            vals["TEXT1"] = m.group(1) if m else vals.get("TEXT1", "")
        name = safe_name(re.sub(r"\[(\w+)\]", lambda m: vals.get(m.group(1), ""), pattern).strip(" -_"), _stem(p))
        base, n = name, 2
        while name.lower() in used:
            name = f"{base}_{n}"; n += 1
        used.add(name.lower())
        dst = out / f"{name}.pdf"
        d.close(); shutil.copy(p, dst); paths.append(dst)
    return _multi_out(paths, out, "renamed")


# ------------------------------------------------------------------ CONVERT TO PDF
@tool("image_to_pdf", multi=True, accept="image")
def image_to_pdf(inputs, o, out):
    size = (o.get("page_size") or "fit").lower()
    orient = o.get("orientation", "auto")
    m = max(0.0, _f(o, "margin", 0))
    res = pymupdf.open()
    for p in inputs:
        for kw, iw, ih in image_pages(p):
            if size == "fit":
                W, H = iw + 2 * m, ih + 2 * m
            else:
                W, H = SIZES.get(size, SIZES["a4"])
                if orient == "landscape" or (orient == "auto" and iw > ih):
                    W, H = H, W
            pg = res.new_page(width=W, height=H)
            box = pymupdf.Rect(m, m, W - m, H - m)
            if "pdf" in kw:
                pg.show_pdf_page(box, kw["pdf"], 0)
            else:
                pg.insert_image(box, keep_proportion=True, **kw)
    if not res.page_count:
        raise ValueError("No images found.")
    return _save(res, out / (f"{_stem(inputs[0])}.pdf" if len(inputs) == 1 else "images.pdf"))


@tool("office_to_pdf", multi=True, accept="office")
def office_to_pdf(inputs, o, out):
    """Word, Excel, PowerPoint, OpenDocument, RTF, CSV, Publisher, Visio, Apple Pages/Numbers/Keynote, HWP … → PDF (LibreOffice)."""
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        raise RuntimeError("LibreOffice is not installed on the server.")
    paths = []
    for k, p in enumerate(inputs):
        work = out / f"_lo{k}"; work.mkdir(exist_ok=True)
        target = "pdf"
        if o.get("sheets") == "one_page" and Path(p).suffix.lower() in (".xls", ".xlsx", ".xlsm", ".ods", ".csv", ".numbers"):
            target = 'pdf:calc_pdf_Export:{"SinglePageSheets":{"type":"boolean","value":"true"}}'   # no column falls onto another page
        r = subprocess.run([soffice, "--headless", "--norestore", "--convert-to", target, "--outdir", str(work), str(p)],
                           capture_output=True, text=True, timeout=600, env=dict(os.environ, HOME=str(work)))
        made = list(work.glob("*.pdf"))
        if not made:
            raise ValueError(f"Could not convert {Path(p).name}. The file may be damaged or password protected.")
        dst = out / f"{_stem(p)}.pdf"
        n = 2
        while dst.exists():
            dst = out / f"{_stem(p)}_{n}.pdf"; n += 1
        shutil.move(str(made[0]), dst); shutil.rmtree(work, ignore_errors=True)
        paths.append(dst)
    return _multi_out(paths, out, "converted")


@tool("html_to_pdf", accept="none")
def html_to_pdf(inputs, o, out):
    from playwright.sync_api import sync_playwright
    from .util import check_url, guard_browser
    urls = [check_url(u) for u in (o.get("urls") or "").splitlines() if u.strip()][:20]
    html = o.get("html")
    if not urls and not html:
        raise ValueError("Please enter a web address.")
    paths = []
    proxy = os.environ.get("HTML2PDF_PROXY") or os.environ.get("HTTPS_PROXY")
    vw = int(min(3000, max(320, _f(o, "viewport", 1280))))
    with sync_playwright() as pw:
        br = pw.chromium.launch(proxy={"server": proxy} if proxy else None)
        try:
            for k, src in enumerate(urls or [None], 1):
                page = br.new_page(viewport={"width": vw, "height": 900})
                guard_browser(page)  # no request may reach private / internal addresses
                try:
                    if src:
                        page.goto(src, wait_until="networkidle", timeout=60000)
                    else:
                        page.set_content(html, wait_until="networkidle", timeout=60000)
                except Exception as e:
                    raise ValueError(f"Could not load {src or 'the HTML'}: {str(e).splitlines()[0][:120]}")
                page.emulate_media(media="print" if _b(o, "print_media") else "screen")
                ps = (o.get("page_size") or "a4").lower()
                dst = out / f"{safe_name(re.sub(r'https?://', '', src or 'page'))}.pdf"
                if ps == "one_long_page":
                    h = page.evaluate("Math.max(document.documentElement.scrollHeight, document.body ? document.body.scrollHeight : 0)")
                    page.pdf(path=str(dst), width=f"{vw}px", height=f"{min(int(h) + 20, 14000)}px", print_background=True)
                else:
                    page.pdf(path=str(dst), format={"letter": "Letter", "legal": "Legal", "tabloid": "Tabloid"}.get(ps, ps.upper()),
                             landscape=o.get("orientation") == "landscape", print_background=True,
                             margin={k2: str(o.get("margin") or "10mm") for k2 in ("top", "bottom", "left", "right")})
                paths.append(dst); page.close()
        finally:
            br.close()
    return _multi_out(paths, out, "web_pages")



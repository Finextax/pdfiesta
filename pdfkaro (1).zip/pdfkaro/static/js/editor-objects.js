// PDF editor – everything on a page besides text editing: the things a user adds (text boxes, shapes, pictures, signatures,
// marks, notes, links, form fields), what already exists in the PDF (pictures, links, comments, form fields) and the tools that create them.
import { $, $$, h, toast, tr, esc } from "/static/js/common.js";
import { S, hooks, uid, clone, ovEl, ptOf, bounds, moveObj, pushHist, commit, model, clamp, pageSize, r2 } from "/static/js/editor-core.js";
import { renderParas, editObject, editBlock, closeEditor, editing, useFont, fontStack, paper } from "/static/js/editor-text.js";

const NS = "http://www.w3.org/2000/svg";
const svg = (tag, attrs = {}, ...kids) => { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) if (v != null) e.setAttribute(k, v); e.append(...kids); return e; };
const pos = (el, r) => Object.assign(el.style, { left: r[0] + "px", top: r[1] + "px", width: r[2] - r[0] + "px", height: r[3] - r[1] + "px" });
const hex = (css) => { const m = /rgb\((\d+),\s*(\d+),\s*(\d+)\)/.exec(css); return m ? "#" + [1, 2, 3].map((i) => (+m[i]).toString(16).padStart(2, "0")).join("") : css; };
const RECT_TOOLS = new Set(["rect", "ellipse", "whiteout", "link", "field", "highlight", "underline", "strike"]);
const DRAW_TOOLS = new Set([...RECT_TOOLS, "line", "arrow", "ink"]);
const base = (tool) => tool.split(":")[0];
const HINTS = () => ({
  select: tr("Click any text to change it · drag pictures and the things you added to move them"),
  text: tr("Click where the new text should start"), whiteout: tr("Drag over what you want to erase"), link: tr("Drag a box where the link should be · click a blue box to change a link"),
  highlight: tr("Drag over the text you want to mark"), underline: tr("Drag over the text you want to underline"), strike: tr("Drag over the text you want to strike out"),
  ink: tr("Draw with the mouse, pen or finger"), note: tr("Click where the note should be"), rect: tr("Drag to draw"), ellipse: tr("Drag to draw"), line: tr("Drag to draw · hold Shift for straight lines"),
  arrow: tr("Drag to draw · hold Shift for straight lines"), field: tr("Drag a box where the field should be"), place: tr("Click where it should go"), check: tr("Click to place a tick"), cross: tr("Click to place a cross"), date: tr("Click to place today's date"),
});
export function setTool(tool, sub = null) {
  closeEditor(true);
  S.tool = tool; S.sub = sub; S.inkObj = null; select(null);
  const groups = { annot: ["highlight", "underline", "strike", "ink", "note"], shape: ["rect", "ellipse", "line", "arrow"], form: ["field", "check", "cross"], sign: ["place", "date"] };
  $$("#toolbar [data-tool]").forEach((b) => b.classList.toggle("on", b.dataset.tool === tool));
  $$("#toolbar [data-menu]").forEach((b) => b.classList.toggle("on", (groups[b.dataset.menu] || []).includes(base(tool)) && !(tool === "place" && sub?.type === "image")));
  $("#imgbtn").classList.toggle("on", tool === "place" && sub?.type === "image");
  $$(".pg").forEach(modeClass);
  $("#hint").textContent = S.signer && tool === "select" ? tr("Use the buttons above to sign, add text or a date, then press “Finish signing”.") : (HINTS()[base(tool)] || "");
}
export function modeClass(pg) {
  const t = base(S.tool);
  pg.classList.toggle("sel", S.tool === "select"); pg.classList.toggle("textmode", S.tool === "text");
  pg.classList.toggle("draw", DRAW_TOOLS.has(t)); pg.classList.toggle("linkmode", S.tool === "link");
  pg.classList.toggle("formmode", t === "field" || (S.mode === "create-forms" && S.tool === "select"));
}

// ------------------------------------------------------------------ selection
export const selected = () => (S.cur === "x" ? S.x : S.objects.find((o) => o.id === S.cur)) || null;
export function select(id) {
  const before = selected();
  if (id !== "x") S.x = null;
  S.cur = id;
  const o = selected();
  for (const p of new Set([before?.page, o?.page])) if (p != null) drawObjects(p);
  showBar(o);
}

// ------------------------------------------------------------------ drawing the added objects of one page
export function drawObjects(p) {
  const ov = ovEl(p); if (!ov) return;
  const ed = editing();
  ov.querySelectorAll(".obj, svg.lay, .hd").forEach((x) => { if (!(ed && ed.el === x)) x.remove(); });
  const { w, h: H } = pageSize(p);
  const layer = (o, ...kids) => { const s = svg("svg", { class: "lay", width: w, height: H, viewBox: `0 0 ${w} ${H}` }, ...kids); ov.append(s); return s; };
  const grab = Math.max(10 / S.zoom, 6);
  for (const o of S.objects) {
    if (o.page !== p || (ed && ed.obj === o)) continue;
    const cur = S.cur === o.id ? " cur" : "";
    if (o.type === "add_text") {
      const el = h("div", { class: "obj txt" + cur, "data-id": o.id });
      Object.assign(el.style, { left: o.x + "px", top: o.y + "px", lineHeight: o.lh || 1.2, textAlign: o.align || "left", fontSize: Math.min(...o.paras.flat().map((r) => r.s || 11), 400) + "px", fontFamily: fontStack(o.paras[0]?.[0]?.fam || "liberationsans") });
      if (o.w > 20) el.style.width = o.w + "px"; else { el.style.maxWidth = Math.max(40, w - 12 - o.x) + "px"; el.style.width = "max-content"; }
      renderParas(el, o.paras); ov.append(el);
      o.h = el.offsetHeight; o.mw = el.offsetWidth;
    } else if (o.type === "image" || o.type === "signature") {
      const el = h("div", { class: "obj img" + cur, "data-id": o.id }); pos(el, o.rect); el.style.backgroundImage = `url(${o.data})`; ov.append(el);
    } else if (o.type === "whiteout") {
      const el = h("div", { class: "obj box" + cur, "data-id": o.id }); pos(el, o.rect); el.style.background = o.color || "#ffffff"; el.style.outline = cur ? "" : `${1 / S.zoom}px dashed #c0c6d0`; ov.append(el);
    } else if (o.type === "link") {
      const el = h("div", { class: "obj lnk" + cur, "data-id": o.id, title: o.url || tr("Page") + " " + o.target_page }); pos(el, o.rect); ov.append(el);
    } else if (o.type === "field") {
      const el = h("div", { class: "obj fld" + cur, "data-id": o.id }, { text: "Text", multiline: "Text ¶", checkbox: "☑", radio: "◉", dropdown: "▾", signature: "✍" }[o.kind] || ""); pos(el, o.rect); ov.append(el);
    } else if (o.type === "note") {
      const el = h("div", { class: "obj note" + cur, "data-id": o.id, title: o.text }, "✎"); el.style.left = o.x + "px"; el.style.top = o.y + "px"; ov.append(el);
    } else if (o.type === "highlight" || o.type === "underline" || o.type === "strike") {
      for (const r of o.rects) {
        const el = h("div", { class: "obj mark" + cur, "data-id": o.id });
        if (o.type === "highlight") { pos(el, r); el.style.background = o.color; el.style.opacity = .45; }
        else { const y = o.type === "underline" ? r[3] - 0.5 : (r[1] + r[3]) / 2 + 0.6; pos(el, [r[0], y - 3, r[2], y + 3]); el.style.background = `linear-gradient(${o.color},${o.color}) center/100% ${Math.max(0.7, (r[3] - r[1]) / 14)}px no-repeat`; el.style.mixBlendMode = "normal"; }
        ov.append(el);
      }
    } else if (o.type === "rect" || o.type === "ellipse") {
      const [x0, y0, x1, y1] = o.rect, a = { fill: o.fill || "none", stroke: o.stroke || "none", "stroke-width": o.stroke ? o.width : 0, opacity: o.opacity ?? 1, "data-id": o.id, style: `pointer-events:${o.fill ? "all" : "stroke"};cursor:move` };
      const shape = o.type === "rect" ? svg("rect", { x: x0, y: y0, width: x1 - x0, height: y1 - y0, ...a }) : svg("ellipse", { cx: (x0 + x1) / 2, cy: (y0 + y1) / 2, rx: (x1 - x0) / 2, ry: (y1 - y0) / 2, ...a });
      const hit = o.type === "rect" ? svg("rect", { x: x0, y: y0, width: x1 - x0, height: y1 - y0 }) : svg("ellipse", { cx: (x0 + x1) / 2, cy: (y0 + y1) / 2, rx: (x1 - x0) / 2, ry: (y1 - y0) / 2 });
      for (const [k, v] of Object.entries({ fill: "none", stroke: "transparent", "stroke-width": grab, class: "hit", "data-id": o.id })) hit.setAttribute(k, v);
      layer(o, shape, hit);
    } else if (o.type === "line" || o.type === "arrow") {
      const [ax, ay] = o.p1, [bx, by] = o.p2, parts = [svg("line", { x1: ax, y1: ay, x2: bx, y2: by })];
      if (o.type === "arrow") { const ang = Math.atan2(by - ay, bx - ax), L = 6 + o.width * 3; for (const da of [2.6, -2.6]) parts.push(svg("line", { x1: bx, y1: by, x2: bx + L * Math.cos(ang + da), y2: by + L * Math.sin(ang + da) })); }
      layer(o, svg("g", { stroke: o.stroke || "#000000", "stroke-width": o.width, "stroke-linecap": "round", opacity: o.opacity ?? 1 }, ...parts),
        svg("line", { x1: ax, y1: ay, x2: bx, y2: by, stroke: "transparent", "stroke-width": grab, class: "hit", "data-id": o.id }));
    } else if (o.type === "ink") {
      const d = (path) => path.map((q) => q.join(",")).join(" ");
      layer(o, ...o.paths.map((path) => svg("polyline", { points: d(path), fill: "none", stroke: o.color, "stroke-width": o.width, "stroke-linecap": "round", "stroke-linejoin": "round" })),
        ...o.paths.map((path) => svg("polyline", { points: d(path), fill: "none", stroke: "transparent", "stroke-width": grab, class: "hit", "data-id": o.id })));
    }
  }
  const cur = selected();
  if (cur && cur.page === p) {
    if (cur.type === "ximg") { const el = h("div", { class: "obj box cur", "data-id": "x" }); pos(el, cur.rect); el.style.background = "rgba(37,99,235,.15)"; ov.append(el); }
    else if (cur.type !== "add_text" && !cur.rect) { const b = bounds(cur), el = h("div", { class: "obj cur", style: "pointer-events:none" }); pos(el, [b[0] - 2, b[1] - 2, b[2] + 2, b[3] + 2]); ov.append(el); }
    handles(ov, cur);
  }
}
function handles(ov, o) {
  const b = bounds(o), hs = (matchMedia("(pointer:coarse)").matches ? 18 : 9) / S.zoom;
  const add = (x, y, k, round) => { const el = h("div", { class: "hd" + (round ? " r" : ""), "data-h": k }); Object.assign(el.style, { left: x - hs / 2 + "px", top: y - hs / 2 + "px", width: hs + "px", height: hs + "px", borderWidth: 1.5 / S.zoom + "px", cursor: k.length === 2 && k[0] !== "p" ? (k === "nw" || k === "se" ? "nwse-resize" : "nesw-resize") : k === "e" ? "ew-resize" : "move" }); ov.append(el); };
  if (o.p1) { add(o.p1[0], o.p1[1], "p1", true); add(o.p2[0], o.p2[1], "p2", true); }
  else if (o.rect) { add(b[0], b[1], "nw"); add(b[2], b[1], "ne"); add(b[0], b[3], "sw"); add(b[2], b[3], "se"); }
  else if (o.type === "add_text") add(b[2], (b[1] + b[3]) / 2, "e", true);
}

// ------------------------------------------------------------------ what is already in the PDF
export function drawExisting(p, m, flds) {
  const ov = ovEl(p); if (!ov) return;
  let ex = ov.querySelector(".ex"); if (!ex) { ex = h("div", { class: "ex" }); ov.prepend(ex); }
  ex.textContent = "";
  if (!m) return;
  if (!S.signer) {
    for (const im of m.images) { const el = h("div", { class: "ximg" }); pos(el, im.bbox); el._im = im; ex.append(el); }
    for (const b of m.blocks) { const el = h("div", { class: "blk" }); pos(el, [b.bbox[0] - 1, b.bbox[1] - 1, b.bbox[2] + 1, b.bbox[3] + 1]); el._b = b; ex.append(el); }
    for (const l of m.links) { const el = h("div", { class: "xlink", title: l.uri || tr("Page") + " " + l.page }); pos(el, l.rect); el._l = l; ex.append(el); }
    for (const a of m.annots) {                       // highlights, comments, drawings of the PDF: a small button deletes them (the text below stays clickable)
      const el = h("div", { class: "xannot" }, h("button", { class: "adel", title: tr("Delete this comment / mark"), onclick: (e) => { e.stopPropagation(); askDeleteAnnot(p, a); } }, "×"));
      pos(el, a.rect); ex.append(el);
    }
  }
  for (const f of (flds || []).filter((x) => x.page === p)) { const el = fieldEl(f, p); if (el) ex.append(el); }
}
function fieldEl(f, p) {
  const hgt = f.rect[3] - f.rect[1], cur = S.form[f.name];
  const box = h("div", { class: "xfield", title: f.name }); pos(box, f.rect); box.style.fontSize = clamp(hgt * 0.62, 5, 13) + "px";
  let inp;
  if (f.type === "Text") { inp = h(f.multiline ? "textarea" : "input", f.multiline ? {} : { type: "text" }); inp.value = cur ?? f.value ?? ""; inp.oninput = () => { S.form[f.name] = inp.value; }; inp.onchange = () => pushHist(); }
  else if (f.type === "CheckBox") { inp = h("input", { type: "checkbox" }); inp.checked = cur != null ? !!cur : !!f.value && f.value !== "Off"; inp.onchange = () => { S.form[f.name] = inp.checked; pushHist(); }; }
  else if (f.type === "RadioButton") { const on = String(f.on); inp = h("input", { type: "radio", name: "rf_" + f.name }); inp.checked = cur != null ? cur === on : f.value === on; inp.onchange = () => { S.form[f.name] = on; pushHist(); }; }
  else if (f.type === "ComboBox" || f.type === "ListBox") {
    inp = h("select", {}, h("option", { value: "" }, ""), (f.options || []).map((o) => { const v = Array.isArray(o) ? o[0] : o; return h("option", { value: v }, Array.isArray(o) ? o[1] : o); }));
    inp.value = cur ?? f.value ?? ""; inp.onchange = () => { S.form[f.name] = inp.value; pushHist(); };
  } else if (f.type === "Signature") {
    box.classList.add("sigbox"); box.append(tr("Sign here"));
    box.onclick = () => hooks.chooseSignature?.({ page: p, rect: f.rect });
    return box;
  } else return null;
  inp.addEventListener("pointerdown", (e) => e.stopPropagation()); inp.addEventListener("keydown", (e) => e.stopPropagation());
  box.append(inp);
  if (!S.signer) box.append(h("button", { class: "fx", title: tr("Delete this field"), onclick: (e) => { e.stopPropagation(); existing([{ type: "widget_delete", page: p, name: f.name, xref: f.xref }], p); } }, "×"));
  return box;
}
/** change something that is part of the PDF itself: the server writes a new version, the page is shown again */
async function existing(ops, p) {
  try { await commit(ops); delete S.x; S.cur = null; pushHist(); await hooks.pageChanged?.(p); hooks.redraw?.(); showBar(null); }
  catch (e) { toast(e.message, 6000); }
}

// ------------------------------------------------------------------ pointer work on a page
function track(ev, p, onMove, onEnd) {
  const a = ptOf(p, ev); let moved = false, raf = 0, lastQ = a, lastE = ev;
  const mv = (e) => {
    const q = ptOf(p, e);
    if (!moved && Math.hypot(q.x - a.x, q.y - a.y) * S.zoom < 3) return;
    moved = true; lastQ = q; lastE = e;
    if (!raf) raf = requestAnimationFrame(() => { raf = 0; onMove(lastQ, a, lastE); });
  };
  const up = (e) => {
    removeEventListener("pointermove", mv); removeEventListener("pointerup", up); removeEventListener("pointercancel", up);
    if (raf) { cancelAnimationFrame(raf); raf = 0; onMove(lastQ, a, lastE); }
    onEnd(moved, e.type === "pointercancel" ? lastQ : ptOf(p, e), a, e);
  };
  addEventListener("pointermove", mv); addEventListener("pointerup", up); addEventListener("pointercancel", up);
}
function inside(o, p) {                                 // keep at least the middle of an object on its page
  const { w, h: H } = pageSize(p), b = bounds(o), cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
  moveObj(o, clamp(cx, 0, w) - cx, clamp(cy, 0, H) - cy);
}
function dragObject(ev, p, o) {
  ev.preventDefault();
  const start = clone(o);
  track(ev, p, (q, a) => { const f = clone(start); moveObj(f, q.x - a.x, q.y - a.y); inside(f, p); Object.assign(o, f); drawObjects(p); },
    (moved) => { if (!moved) return; if (o.type === "ximg") moveExisting(o); else pushHist(); });
}
function resize(ev, p, k) {
  const o = selected(); if (!o) return;
  ev.preventDefault(); ev.stopPropagation();
  const start = clone(o), keep = ["image", "signature", "ximg"].includes(o.type);
  track(ev, p, (q, a, e) => {
    if (k === "p1" || k === "p2") o[k] = snap(k === "p1" ? start.p2 : start.p1, [q.x, q.y], e.shiftKey);
    else if (k === "e") o.w = Math.max(30, q.x - o.x);
    else {
      let [x0, y0, x1, y1] = start.rect;
      if (k.includes("w")) x0 = Math.min(q.x, x1 - 4); if (k.includes("e")) x1 = Math.max(q.x, x0 + 4);
      if (k.includes("n")) y0 = Math.min(q.y, y1 - 4); if (k.includes("s")) y1 = Math.max(q.y, y0 + 4);
      if (keep !== e.shiftKey) { const ratio = (start.rect[2] - start.rect[0]) / (start.rect[3] - start.rect[1]), nh = (x1 - x0) / ratio; if (k.includes("n")) y0 = y1 - nh; else y1 = y0 + nh; }
      o.rect = [x0, y0, x1, y1];
    }
    drawObjects(p);
  }, (moved) => { if (!moved) return; if (o.type === "ximg") moveExisting(o); else pushHist(); });
}
const moveExisting = (o) => existing([{ type: "image_edit", page: o.page, xref: o.xref, orig: o.orig, rect: o.rect.map(r2) }], o.page);
function snap(from, to, on) {
  if (!on) return to;
  const dx = to[0] - from[0], dy = to[1] - from[1], ang = Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) * (Math.PI / 4), len = Math.hypot(dx, dy);
  return [from[0] + len * Math.cos(ang), from[1] + len * Math.sin(ang)];
}

export function bindPage(ov, p) {
  ov.addEventListener("pointerdown", (ev) => down(ev, p));
  ov.addEventListener("click", (ev) => click(ev, p));
  ov.addEventListener("dblclick", (ev) => {
    const o = objAt(ev.target);
    if (o && o.type === "add_text" && !editing()) editObject(o, ev.target.closest("[data-id]"), ev);
  });
}
const objAt = (t) => { const el = t.closest?.("[data-id]"); return el ? (el.dataset.id === "x" ? S.x : S.objects.find((x) => x.id === el.dataset.id)) : null; };
function down(ev, p) {
  if (ev.button) return;
  const t = ev.target, ed = editing();
  if (ed && ed.el.contains(t)) return;                       // typing – the browser places the caret
  if (t.classList.contains("hd")) return resize(ev, p, t.dataset.h);
  const tool = base(S.tool), o = objAt(t);
  if (o && (tool === "select" || o.type === base(S.tool) || (tool === "text" && o.type === "add_text") || (tool === "place" && ["image", "signature"].includes(o.type)))) {
    if (tool === "text" && o.type === "add_text") return;     // a click edits it (see click)
    if (ed) closeEditor(true);
    if (S.cur !== o.id && o.type !== "ximg") select(o.id);
    return dragObject(ev, p, o);
  }
  if (tool === "select") {
    if (t.classList.contains("ximg")) {
      ev.preventDefault(); if (ed) closeEditor(true);
      const im = t._im; S.x = { id: "x", type: "ximg", page: p, rect: [...im.bbox], orig: [...im.bbox], xref: im.xref };
      select("x"); return dragObject(ev, p, S.x);
    }
    if (!t.classList.contains("blk") && !t.closest(".xfield") && !t.classList.contains("adel")) { if (ed) closeEditor(true); if (S.cur) select(null); }
    return;
  }
  if (ed) closeEditor(true);
  const a = ptOf(p, ev);
  if (RECT_TOOLS.has(tool)) return rubber(ev, p, a);
  if (tool === "line" || tool === "arrow") return drawLine(ev, p, a);
  if (tool === "ink") return drawInk(ev, p, a);
}
function click(ev, p) {
  const t = ev.target, tool = base(S.tool), ed = editing();
  if (ed && ed.el.contains(t)) return;
  if (t.classList.contains("hd")) return;
  const o = objAt(t), q = ptOf(p, ev);
  if (tool === "select") {
    if (t.classList.contains("blk") && !S.signer) return editBlock(p, t._b, ev);
    return;
  }
  if (tool === "link" && t.classList.contains("xlink")) return linkDialog(p, null, t._l);
  if (tool === "text") {
    if (o && o.type === "add_text") return editObject(o, t.closest("[data-id]"), ev);
    if (o) return;
    return newText(p, q.x, q.y - S.style.s * 0.75, "", {}, true);
  }
  if (o) return;
  if (tool === "note") return noteDialog(p, q);
  if (tool === "check" || tool === "cross") { const s = 16; return newText(p, q.x - s * 0.4, q.y - s * 0.7, tool === "check" ? "✓" : "✗", { fam: "dejavusans", s, b: 0, i: 0, c: "#000000" }); }
  if (tool === "date") return newText(p, q.x, q.y - S.style.s * 0.75, new Date().toLocaleDateString(undefined, { day: "2-digit", month: "2-digit", year: "numeric" }), {}, false, true);
  if (tool === "place" && S.sub) {
    const { w: pw, h: ph } = pageSize(p), w = Math.min(S.sub.w, pw * 0.9), hh = w / S.sub.ratio;
    const x = clamp(q.x - w / 2, 0, pw - w), y = clamp(q.y - hh / 2, 0, Math.max(0, ph - hh));
    const obj = { id: uid(), type: S.sub.type, page: p, rect: [x, y, x + w, y + hh].map(r2), data: S.sub.data };
    S.objects.push(obj); setTool("select"); select(obj.id); pushHist();
  }
}
/** a text box of the user; text = "" opens it for typing */
export function newText(p, x, y, text, style = {}, type = false, selectIt = false) {
  const st = { ...S.style, f: "", u: 0, st: 0, ...style };
  const o = { id: uid(), type: "add_text", page: p, x: r2(Math.max(2, x)), y: r2(Math.max(2, y)), w: 0, paras: [[{ ...st, t: text }]], align: "left", lh: 1.2 };
  S.objects.push(o); drawObjects(p);
  if (type) editObject(o, ovEl(p).querySelector(`[data-id="${o.id}"]`)).then(() => { const e = editing(); if (e && e.obj === o) e.fresh = true; });
  else { pushHist(); if (selectIt) { setTool("select"); select(o.id); } }
  return o;
}
function rubber(ev, p, a) {
  ev.preventDefault();
  const ov = ovEl(p), box = h("div", { class: "rub" }), { w, h: H } = pageSize(p);
  box.style.borderWidth = 1 / S.zoom + "px"; ov.append(box);
  const rect = (q) => [clamp(Math.min(a.x, q.x), 0, w), clamp(Math.min(a.y, q.y), 0, H), clamp(Math.max(a.x, q.x), 0, w), clamp(Math.max(a.y, q.y), 0, H)];
  track(ev, p, (q) => pos(box, rect(q)), (moved, q) => {
    box.remove();
    const r = rect(q).map(r2);
    if (moved && r[2] - r[0] >= 3 && r[3] - r[1] >= 3) create(p, r);
  });
}
async function create(p, r) {
  const tool = base(S.tool), kind = S.tool.split(":")[1];
  let o = null;
  if (tool === "rect" || tool === "ellipse") o = { type: tool, rect: r, stroke: S.shape.stroke, fill: S.shape.fill, width: S.shape.width, opacity: S.shape.opacity };
  else if (tool === "whiteout") o = { type: "whiteout", rect: r, color: hex(paper(p, r)) };
  else if (tool === "link") return linkDialog(p, r);
  else if (tool === "field") {
    const n = S.objects.filter((x) => x.type === "field").length + 1;
    if (kind === "checkbox" || kind === "radio") { const s = Math.max(10, Math.min(r[2] - r[0], r[3] - r[1])); r = [r[0], r[1], r2(r[0] + s), r2(r[1] + s)]; }
    o = { type: "field", kind, rect: r, name: `${kind}_${n}`, required: false, ...(kind === "dropdown" ? { options: ["Option 1", "Option 2"] } : {}) };
  } else {
    let rects = [r];
    try {
      const m = await model(p), hit = [];
      for (const b of m.blocks) for (const l of b.lines) {
        const ov = Math.min(l[3], r[3]) - Math.max(l[1], r[1]);
        if (ov > 0.4 * (l[3] - l[1]) && Math.min(l[2], r[2]) - Math.max(l[0], r[0]) > 1) hit.push([r2(Math.max(l[0], r[0])), l[1], r2(Math.min(l[2], r[2])), l[3]]);
      }
      if (hit.length) rects = hit;
    } catch {}
    o = { type: tool, rects, color: S.mark[tool] };
  }
  o.id = uid(); o.page = p; S.objects.push(o); select(o.id); pushHist();
}
function drawLine(ev, p, a) {
  ev.preventDefault();
  const o = { id: uid(), type: base(S.tool), page: p, p1: [r2(a.x), r2(a.y)], p2: [r2(a.x), r2(a.y)], stroke: S.shape.stroke, width: S.shape.width, opacity: 1 };
  let added = false;
  track(ev, p, (q, _a, e) => { if (!added) { S.objects.push(o); added = true; } o.p2 = snap(o.p1, [q.x, q.y], e.shiftKey).map(r2); drawObjects(p); },
    (moved) => { if (!moved || Math.hypot(o.p2[0] - o.p1[0], o.p2[1] - o.p1[1]) < 3) { S.objects = S.objects.filter((x) => x !== o); drawObjects(p); return; } select(o.id); pushHist(); });
}
function drawInk(ev, p, a) {
  ev.preventDefault();
  let o = S.inkObj && S.objects.includes(S.inkObj) && S.inkObj.page === p ? S.inkObj : null;
  if (!o) { o = S.inkObj = { id: uid(), type: "ink", page: p, paths: [], color: S.ink.color, width: S.ink.width }; S.objects.push(o); }
  const path = [[r2(a.x), r2(a.y)]]; o.paths.push(path);
  track(ev, p, (q) => { const l = path[path.length - 1]; if (Math.hypot(q.x - l[0], q.y - l[1]) > 0.8) { path.push([r2(q.x), r2(q.y)]); drawObjects(p); } },
    () => { if (path.length < 2) path.push([path[0][0] + 0.5, path[0][1] + 0.5]); drawObjects(p); pushHist(); });
}

// ------------------------------------------------------------------ small dialogs
export function dialog(title, body, buttons) {
  const box = $("#dlgbox"); box.textContent = "";
  const close = () => $("#dlg").classList.remove("on");
  box.append(h("h3", { style: "margin-top:0" }, title), body, h("div", { class: "row", style: "margin-top:14px" },
    buttons.map(([label, fn, cls]) => h("button", { class: "btn " + (cls || ""), onclick: async () => { if ((await fn?.()) !== false) close(); } }, label))));
  $("#dlg").classList.add("on");
  setTimeout(() => box.querySelector("input,textarea")?.focus(), 30);
  return close;
}
function linkDialog(p, rect, old) {
  const url = h("input", { type: "text", placeholder: "https://…", style: "width:100%", value: old?.uri || "" });
  const pg = h("input", { type: "number", min: 1, max: S.sizes.length, style: "width:90px", value: old?.page || "" });
  const body = h("div", {}, h("label", { class: "t" }, tr("Web address")), url, h("p", { class: "muted", style: "margin:10px 0 4px" }, tr("…or jump to page")), pg);
  const save = () => {
    let u = url.value.trim(); const n = parseInt(pg.value, 10);
    if (u && !/^[a-z][a-z0-9+.-]*:/i.test(u)) u = "https://" + u;
    if (!u && !(n >= 1 && n <= S.sizes.length)) { toast(tr("Type a web address or a page number.")); return false; }
    if (old) existing([{ type: "link_edit", page: p, rect: old.rect, ...(u ? { url: u } : { target_page: n }) }], p);
    else { const o = { id: uid(), type: "link", page: p, rect, ...(u ? { url: u } : { target_page: n }) }; S.objects.push(o); select(o.id); pushHist(); }
  };
  dialog(old ? tr("Change link") : tr("Add link"), body, [[tr("Save"), save, "primary"], old ? [tr("Delete link"), () => existing([{ type: "link_edit", page: p, rect: old.rect, delete: true }], p)] : null, [tr("Cancel")]].filter(Boolean));
}
function noteDialog(p, q, o) {
  const ta = h("textarea", { style: "width:100%;min-height:110px" }, o?.text || "");
  dialog(tr("Note"), ta, [[tr("Save"), () => {
    const text = ta.value.trim(); if (!text) return false;
    if (o) o.text = text; else { o = { id: uid(), type: "note", page: p, x: r2(q.x - 8), y: r2(q.y - 8), text }; S.objects.push(o); }
    select(o.id); pushHist();
  }, "primary"], [tr("Cancel")]]);
}
function fieldDialog(o) {
  const name = h("input", { type: "text", value: o.name, style: "width:100%" });
  const req = h("input", { type: "checkbox", checked: o.required ? "" : null });
  const opts = h("textarea", { style: "width:100%;min-height:90px" }, (o.options || []).join("\n"));
  const body = h("div", {}, h("label", { class: "t" }, tr("Field name")), name, o.kind === "dropdown" ? h("div", {}, h("label", { class: "t", style: "margin-top:10px" }, tr("Choices (one per line)")), opts) : "",
    h("label", { class: "chk", style: "margin-top:10px" }, req, tr("Must be filled in")));
  dialog(tr("Form field"), body, [[tr("Save"), () => { o.name = name.value.trim() || o.name; o.required = req.checked; if (o.kind === "dropdown") o.options = opts.value.split("\n").map((x) => x.trim()).filter(Boolean); drawObjects(o.page); pushHist(); }, "primary"], [tr("Cancel")]]);
}
function askDeleteAnnot(p, a) {
  dialog(tr("Delete this comment / mark?"), h("p", { class: "muted" }, a.type), [[tr("Delete"), () => existing([{ type: "annot_delete", page: p, rect: a.rect, kind: a.type, xref: a.xref }], p), "primary"], [tr("Cancel")]]);
}

// ------------------------------------------------------------------ bar of the selected object
function showBar(o) {
  const bar = $("#otb");
  if (!o || editing()) { bar.classList.add("hidden"); return; }
  bar.classList.remove("hidden"); $("#ftb").classList.add("hidden");
  const t = o.type, shape = t === "rect" || t === "ellipse", line = t === "line" || t === "arrow", mark = ["highlight", "underline", "strike"].includes(t);
  const show = (id, on) => $(id).classList.toggle("hidden", !on);
  show("#ostrokebox", shape || line || mark || t === "ink"); show("#ofillbox", shape || t === "whiteout"); show("#onofillbox", shape);
  show("#owidthbox", shape || line || t === "ink"); show("#oopbox", shape); show("#oedit", ["add_text", "link", "note", "field"].includes(t));
  show("#oreplace", t === "ximg"); show("#odup", t !== "ximg");
  $("#ostroke").value = (shape || line ? o.stroke : o.color) || "#000000"; $("#ofill").value = (t === "whiteout" ? o.color : o.fill) || "#ffffff";
  $("#onofill").checked = shape && !o.fill; $("#owidth").value = o.width || 1.5; $("#oopacity").value = Math.round((o.opacity ?? 1) * 100);
}
export function deleteSelected() {
  const o = selected(); if (!o) return;
  if (o.type === "ximg") return existing([{ type: "image_edit", page: o.page, xref: o.xref, orig: o.orig, delete: true }], o.page);
  S.objects = S.objects.filter((x) => x !== o); S.cur = null; drawObjects(o.page); showBar(null); pushHist();
}
export function initObjects() {
  const change = (fn, commitNow = true) => { const o = selected(); if (!o || o.type === "ximg") return; fn(o); drawObjects(o.page); if (commitNow) pushHist(); };
  $("#ostroke").oninput = (e) => change((o) => { const v = e.target.value; if (o.type === "ink") { o.color = v; S.ink.color = v; } else if (o.rects) { o.color = v; S.mark[o.type] = v; } else { o.stroke = v; S.shape.stroke = v; } }, false);
  $("#ofill").oninput = (e) => change((o) => { if (o.type === "whiteout") o.color = e.target.value; else { o.fill = e.target.value; S.shape.fill = o.fill; $("#onofill").checked = false; } }, false);
  $("#onofill").onchange = (e) => change((o) => { o.fill = e.target.checked ? "" : $("#ofill").value; S.shape.fill = o.fill; });
  $("#owidth").oninput = (e) => change((o) => { o.width = +e.target.value; if (o.type === "ink") S.ink.width = o.width; else S.shape.width = o.width; }, false);
  $("#oopacity").oninput = (e) => change((o) => { o.opacity = e.target.value / 100; S.shape.opacity = o.opacity; }, false);
  for (const id of ["#ostroke", "#ofill", "#owidth", "#oopacity"]) $(id).onchange = () => pushHist();
  $("#otb").addEventListener("click", (e) => {
    const cmd = e.target.closest("button")?.dataset.ocmd, o = selected(); if (!cmd || !o) return;
    if (cmd === "delete") deleteSelected();
    else if (cmd === "dup") { const c = clone(o); c.id = uid(); moveObj(c, 10, 10); S.objects.push(c); select(c.id); pushHist(); }
    else if (cmd === "edit") { if (o.type === "add_text") editObject(o, ovEl(o.page).querySelector(`[data-id="${o.id}"]`)); else if (o.type === "link") toast(tr("Delete the link and draw it again to change it.")); else if (o.type === "note") noteDialog(o.page, null, o); else if (o.type === "field") fieldDialog(o); }
    else if (cmd === "replace") { S.replace = o; $("#imgfile").click(); }
  });
  $("#imgbtn").onclick = () => { S.replace = null; $("#imgfile").click(); };
  $("#imgfile").onchange = async (e) => {
    const f = e.target.files[0]; e.target.value = ""; if (!f) return;
    try {
      const pic = await readImage(f, 2000);
      if (S.replace) { const o = S.replace; S.replace = null; return existing([{ type: "image_edit", page: o.page, xref: o.xref, orig: o.orig, rect: o.rect.map(r2), data: pic.data }], o.page); }
      setTool("place", { type: "image", data: pic.data, ratio: pic.w / pic.h, w: Math.min(pic.w * 0.75, 320) });
    } catch { toast(tr("This picture could not be read.")); }
  };
}
/** picture file → {data (data URL, at most max pixels wide/high), w, h} */
export function readImage(file, max = 2000) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight)), w = Math.max(1, Math.round(img.naturalWidth * k)), hh = Math.max(1, Math.round(img.naturalHeight * k));
      const c = document.createElement("canvas"); c.width = w; c.height = hh; const ctx = c.getContext("2d"); ctx.drawImage(img, 0, 0, w, hh);
      URL.revokeObjectURL(url);
      const d = ctx.getImageData(0, 0, w, hh).data; let alpha = false;
      for (let i = 3; i < d.length; i += 4 * 97) if (d[i] < 250) { alpha = true; break; }
      res({ data: c.toDataURL(alpha ? "image/png" : "image/jpeg", 0.9), w, h: hh, canvas: c });
    };
    img.onerror = () => { URL.revokeObjectURL(url); rej(new Error("bad image")); };
    img.src = url;
  });
}

// ------------------------------------------------------------------ signatures
const SIG_FONTS = ["dancingscript", "greatvibes", "caveat", "sacramento"], SIG_COLORS = ["#111827", "#1d4ed8", "#0b3fa6", "#b91c1c"];
export function savedSignatures() { try { return JSON.parse(localStorage.getItem("pk_sigs") || "[]").filter((s) => typeof s === "string" && s.startsWith("data:image/")); } catch { return []; } }
function storeSignatures(list) { try { localStorage.setItem("pk_sigs", JSON.stringify(list.slice(0, 6))); } catch {} }
export function forgetSignature(data) { storeSignatures(savedSignatures().filter((s) => s !== data)); }
function trim(c) {                                           // cut the empty border away
  const ctx = c.getContext("2d"), { width: w, height: hh } = c, d = ctx.getImageData(0, 0, w, hh).data;
  let x0 = w, y0 = hh, x1 = -1, y1 = -1;
  for (let y = 0; y < hh; y++) for (let x = 0; x < w; x++) if (d[(y * w + x) * 4 + 3] > 12) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  if (x1 < 0) return null;
  const pad = 4; x0 = Math.max(0, x0 - pad); y0 = Math.max(0, y0 - pad); x1 = Math.min(w - 1, x1 + pad); y1 = Math.min(hh - 1, y1 + pad);
  const out = document.createElement("canvas"); out.width = x1 - x0 + 1; out.height = y1 - y0 + 1;
  out.getContext("2d").drawImage(c, x0, y0, out.width, out.height, 0, 0, out.width, out.height);
  return out;
}
/** put a signature on the page: into a given box (signature field) or wherever the user clicks next */
export function useSignature(data, target) {
  const img = new Image();
  img.onload = () => {
    const ratio = img.naturalWidth / img.naturalHeight;
    if (target) {
      const [x0, y0, x1, y1] = target.rect, bw = x1 - x0, bh = y1 - y0, w = Math.min(bw, bh * ratio), hh = w / ratio;
      const o = { id: uid(), type: "signature", page: target.page, rect: [x0 + (bw - w) / 2, y0 + (bh - hh) / 2, x0 + (bw + w) / 2, y0 + (bh + hh) / 2].map(r2), data };
      S.objects.push(o); setTool("select"); select(o.id); pushHist();
    } else setTool("place", { type: "signature", data, ratio, w: Math.min(170, 60 * ratio) });
  };
  img.src = data;
}
export function initSignature() {
  let color = SIG_COLORS[1], tab = "draw", font = SIG_FONTS[0], upload = null, pad = null, target = null;
  const canvas = $("#sigpad");
  const fit = () => { const r = Math.max(1, window.devicePixelRatio || 1); canvas.width = canvas.offsetWidth * r; canvas.height = canvas.offsetHeight * r; canvas.getContext("2d").scale(r, r); pad?.clear(); };
  const colors = $("#sigcolors");
  const paintColors = () => { colors.textContent = ""; SIG_COLORS.forEach((c) => colors.append(h("button", { style: `background:${c}`, class: c === color ? "on" : "", "aria-label": c, onclick: () => { color = c; if (pad) { const d = pad.toData(); pad.penColor = c; d.forEach((s) => s.penColor = c); pad.fromData(d); } paintColors(); paintStyles(); } }))); };
  const paintStyles = () => {
    const box = $("#sigstyles"); box.textContent = "";
    const name = $("#signame").value.trim() || tr("Your name");
    SIG_FONTS.filter((f) => S.fonts.some((x) => x.key === f)).forEach((f) => box.append(h("button", { class: f === font ? "on" : "", style: `font-family:${useFont(f)},cursive;color:${color}`, onclick: () => { font = f; paintStyles(); } }, name)));
  };
  $("#signame").oninput = paintStyles;
  $$("#sigtabs button").forEach((b) => b.onclick = () => { tab = b.dataset.t; $$("#sigtabs button").forEach((x) => x.classList.toggle("on", x === b)); $$(".sigpane").forEach((x) => x.classList.toggle("hidden", x.id !== "sig-" + tab)); if (tab === "draw") fit(); });
  $("#sigclear").onclick = () => pad?.clear();
  $("#sigfile").onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    try {
      const { canvas: c } = await readImage(f, 900), ctx = c.getContext("2d"), im = ctx.getImageData(0, 0, c.width, c.height), d = im.data;
      const lum = []; for (let i = 0; i < d.length; i += 4 * 13) lum.push(0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]);
      lum.sort((a, b) => a - b); const paperL = lum[Math.floor(lum.length * 0.8)], ink = lum[Math.floor(lum.length * 0.02)], thr = paperL - (paperL - ink) * 0.35;
      for (let i = 0; i < d.length; i += 4) { const l = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]; d[i + 3] = l >= thr ? 0 : Math.min(255, Math.round(255 * (thr - l) / Math.max(1, thr - ink) * 1.6)); }
      ctx.putImageData(im, 0, 0); upload = trim(c);
      if (upload) $("#sigprev").src = upload.toDataURL("image/png");
    } catch { toast(tr("This picture could not be read.")); }
  };
  $("#sigsave").onclick = async () => {
    let out = null;
    if (tab === "draw") { if (!pad || pad.isEmpty()) return toast(tr("Please draw your signature first.")); out = trim(canvas); }
    else if (tab === "type") {
      const name = $("#signame").value.trim(); if (!name) return toast(tr("Please type your name."));
      const fam = useFont(font); try { await document.fonts.load(`96px "${fam}"`, name); } catch {}
      const c = document.createElement("canvas"), ctx = c.getContext("2d"); ctx.font = `96px "${fam}", cursive`;
      c.width = Math.ceil(ctx.measureText(name).width) + 80; c.height = 240;
      const x = c.getContext("2d"); x.font = `96px "${fam}", cursive`; x.fillStyle = color; x.textBaseline = "middle"; x.fillText(name, 40, 120); out = trim(c);
    } else { if (!upload) return toast(tr("Please choose a photo of your signature.")); out = upload; }
    if (!out) return toast(tr("The signature is empty."));
    if (out.width > 900) { const c = document.createElement("canvas"); c.width = 900; c.height = Math.round(out.height * 900 / out.width); c.getContext("2d").drawImage(out, 0, 0, c.width, c.height); out = c; }
    const data = out.toDataURL("image/png");
    if ($("#sigremember").checked) storeSignatures([data, ...savedSignatures().filter((s) => s !== data)]);
    $("#sigmodal").classList.remove("on");
    useSignature(data, target);
  };
  hooks.newSignature = (tgt = null) => {
    target = tgt; $("#sigmodal").classList.add("on");
    if (!pad && window.SignaturePad) pad = new window.SignaturePad(canvas, { penColor: color, minWidth: 0.8, maxWidth: 2.6 });
    if (pad) pad.penColor = color;
    paintColors(); paintStyles(); if (tab === "draw") fit();
  };
}

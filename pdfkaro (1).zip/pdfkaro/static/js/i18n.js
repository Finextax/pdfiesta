// Tiny i18n: /static/i18n/<lang>.json. Keys: "tool.<slug>", "desc.<slug>", "btn.<slug>", "cat.<name>", named UI keys,
// and "s.<English text>" for everything else (option labels, messages) – missing keys fall back to the English text.
import { AVAILABLE } from "/static/js/langs.js";
const NAMES = [
  ["en", "English"], ["hi", "हिन्दी"], ["bn", "বাংলা"], ["mr", "मराठी"], ["te", "తెలుగు"], ["ta", "தமிழ்"], ["gu", "ગુજરાતી"], ["kn", "ಕನ್ನಡ"],
  ["ml", "മലയാളം"], ["pa", "ਪੰਜਾਬੀ"], ["ur", "اردو"], ["ne", "नेपाली"], ["es", "Español"], ["pt", "Português"], ["fr", "Français"], ["de", "Deutsch"],
  ["it", "Italiano"], ["nl", "Nederlands"], ["pl", "Polski"], ["ru", "Русский"], ["uk", "Українська"], ["tr", "Türkçe"], ["ar", "العربية"],
  ["fa", "فارسی"], ["he", "עברית"], ["id", "Bahasa Indonesia"], ["ms", "Bahasa Melayu"], ["vi", "Tiếng Việt"], ["th", "ไทย"], ["zh", "简体中文"],
  ["tw", "繁體中文"], ["ja", "日本語"], ["ko", "한국어"], ["sw", "Kiswahili"], ["fil", "Filipino"],
];
export const LANGUAGES = NAMES.filter(([k]) => AVAILABLE.includes(k));   // only languages that really have translations (see scripts/build_i18n.py)
const RTL = new Set(["ar", "ur", "fa", "he"]);
let dict = {};
function detect() {
  const seg = location.pathname.split("/")[1];                       // /hi/tool/merge → the address decides
  if (LANGUAGES.some(([k]) => k === seg && k !== "en")) return seg;
  const q = new URLSearchParams(location.search).get("lang");
  let saved; try { saved = localStorage.getItem("pk_lang"); } catch {}
  const nav = (navigator.language || "en").toLowerCase();
  const c = q || saved || (nav.startsWith("zh-tw") || nav.startsWith("zh-hk") ? "tw" : nav.split("-")[0]);
  return LANGUAGES.some(([k]) => k === c) ? c : "en";
}
export const lang = detect();
export const prefix = LANGUAGES.some(([k]) => k === location.pathname.split("/")[1] && k !== "en") ? "/" + location.pathname.split("/")[1] : "";
export const path = prefix ? location.pathname.slice(prefix.length) || "/" : location.pathname;   // address without the language part
export const href = (p) => prefix + p;                                                              // link that keeps the language
document.documentElement.lang = lang;
if (RTL.has(lang)) document.documentElement.dir = "rtl";
export const ready = (async () => {
  if (lang === "en") return;
  try { dict = await (await fetch(`/static/i18n/${lang}.json`)).json(); } catch { dict = {}; }
})();
export function t(key, fallback) { return dict[key] || fallback || key; }
export function tr(text) { return (text && dict["s." + text]) || text; }
export function setLang(l) {
  try { localStorage.setItem("pk_lang", l); } catch {}
  location.href = (l === "en" ? "" : "/" + l) + (path === "/" && l !== "en" ? "" : path) + location.search;
}
export async function applyI18n(root = document) {
  await ready;
  root.querySelectorAll("[data-i18n]").forEach((el) => { const v = dict[el.dataset.i18n] || dict["s." + el.textContent.trim()]; if (v) el.textContent = v; });
  root.querySelectorAll("[data-i18n-ph]").forEach((el) => { const v = dict[el.dataset.i18nPh] || dict["s." + el.placeholder]; if (v) el.placeholder = v; });
  root.querySelectorAll("[data-tr]").forEach((el) => { const v = dict["s." + el.textContent.trim()]; if (v) el.textContent = v; });
}

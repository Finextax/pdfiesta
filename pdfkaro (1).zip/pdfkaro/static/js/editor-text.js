// PDF editor – rich text: paragraphs of styled runs ⇄ editable DOM, the formatting bar, editing of existing text blocks.
// A run is {t, b, i, u, st, c, s, f, fam}: text, bold, italic, underline, strike, colour, size (pt), original PDF font name, font family key.
import { $, $$, h, api, toast, tr } from "/static/js/common.js";
import { S, hooks, ovEl, commit, pushHist, model, idle } from "/static/js/editor-core.js";

// ------------------------------------------------------------------ fonts of the server, usable in the browser
const SCRIPTS = [[0x0900, 0x097F, "notosansdevanagari"], [0x0980, 0x09FF, "notosansbengali"], [0x0A00, 0x0A7F, "notosansgurmukhi"], [0x0A80, 0x0AFF, "notosansgujarati"],
  [0x0B80, 0x0BFF, "notosanstamil"], [0x0C00, 0x0C7F, "notosanstelugu"], [0x0C80, 0x0CFF, "notosanskannada"], [0x0D00, 0x0D7F, "notosansmalayalam"],
  [0x0E00, 0x0E7F, "notosansthai"], [0x0590, 0x05FF, "notosanshebrew"], [0x0600, 0x06FF, "notonaskharabic"]];
const registered = new Set();
export function useFont(fam) {
  const f = S.fonts.find((x) => x.key === fam);
  if (!f) return null;
  if (!registered.has(fam)) {
    registered.add(fam);
    for (const face of f.faces) {
      const b = face.includes("b"), i = face.includes("i");
      try { document.fonts.add(new FontFace("pk-" + fam, `url(/api/font/${fam}?b=${+b}&i=${+i})`, { weight: b ? "700" : "400", style: i ? "italic" : "normal" })); } catch {}
    }
  }
  return "pk-" + fam;
}
const SERIF = /serif|caladea|garamond|times/i, MONO = /mono|courier/i;
export function fontStack(fam, text = "") {
  const list = [useFont(fam)];
  for (const [lo, hi, key] of SCRIPTS) if (key !== fam) { for (const ch of text) { const c = ch.codePointAt(0); if (c >= lo && c <= hi) { list.push(useFont(key)); break; } } }
  list.push(MONO.test(fam) && !/sans/i.test(fam.replace("mono", "")) ? "monospace" : SERIF.test(fam) && !/sans/i.test(fam) ? "serif" : "sans-serif");
  return list.filter(Boolean).join(",");
}
const norm = (r) => ({ b: r.b ? 1 : 0, i: r.i ? 1 : 0, u: r.u ? 1 : 0, st: r.st ? 1 : 0, c: r.c || "#000000", s: +r.s || 11, f: r.f || "", fam: r.fam || "liberationsans" });
const same = (a, b) => a.b === b.b && a.i === b.i && a.u === b.u && a.st === b.st && a.c === b.c && a.s === b.s && a.f === b.f && a.fam === b.fam;
export const cssOf = (r) => `font-family:${fontStack(r.fam || "liberationsans", r.t || "")};font-size:${r.s || 11}px;color:${r.c || "#000000"};font-weight:${r.b ? 700 : 400};` +
  `font-style:${r.i ? "italic" : "normal"};text-decoration:${r.u ? "underline" : r.st ? "line-through" : "none"}`;
function span(r) {
  const s = document.createElement("span");
  s.style.cssText = cssOf(r); s.dataset.r = JSON.stringify(norm(r)); s.textContent = r.t || "";
  return s;
}
export function renderParas(el, paras, fallback = S.style) {
  el.textContent = "";
  for (const p of (paras.length ? paras : [[]])) {
    const d = document.createElement("div");
    if (!p.some((r) => r.t)) { const sp = span({ ...(p[0] || fallback), t: "" }); sp.append(document.createElement("br")); d.append(sp); }
    else for (const r of p) if (r.t) d.append(span(r));
    el.append(d);
  }
}
const BLOCK = /^(DIV|P|LI|H[1-6]|BLOCKQUOTE|PRE)$/;
function trailing(br, root) {                 // a <br> at the end of its paragraph is only the browser's placeholder
  for (let n = br; n && n !== root; n = n.parentNode) {
    for (let s = n.nextSibling; s; s = s.nextSibling) if (s.nodeType === 1 || s.nodeValue.replace(/​/g, "")) return false;
    if (BLOCK.test(n.parentNode?.tagName || "")) break;
  }
  return true;
}
/** DOM of an editable box → {paras, segs}; segs = text nodes with their paragraph and offset (used for the selection). */
export function scan(el, fallback = S.style) {
  const paras = [], segs = [];
  let cur = null;
  const open = () => { cur = []; paras.push(cur); };
  const styleFor = (node) => {
    const sp = node.parentElement?.closest("span[data-r]");
    if (sp && el.contains(sp)) { try { return norm(JSON.parse(sp.dataset.r)); } catch {} }
    return norm(fallback);
  };
  const walk = (node) => {
    for (const ch of node.childNodes) {
      if (ch.nodeType === 3) {
        const raw = ch.nodeValue;
        if (!raw) continue;
        const st = styleFor(ch);
        let pos = 0;
        raw.split("\n").forEach((piece, k) => {
          if (k > 0) cur = null;
          const t = piece.replace(/​/g, "").replace(/ /g, " ");
          if (t) {
            if (!cur) open();
            const start = cur.reduce((n, r) => n + r.t.length, 0);
            segs.push({ node: ch, p: paras.length - 1, a: start, from: pos, len: piece.length });
            const last = cur[cur.length - 1];
            if (last && same(last, st)) last.t += t; else cur.push({ ...st, t });
          } else if (k > 0 && !cur) open();
          pos += piece.length + 1;
        });
      } else if (ch.nodeType === 1) {
        if (ch.tagName === "BR") { if (!cur) open(); if (!trailing(ch, el)) cur = null; continue; }
        if (BLOCK.test(ch.tagName)) { cur = null; open(); walk(ch); cur = null; } else walk(ch);
      }
    }
  };
  walk(el);
  while (paras.length > 1 && !paras[paras.length - 1].length) paras.pop();
  return { paras: paras.length ? paras : [[]], segs };
}
export const readParas = (el, fallback) => scan(el, fallback).paras;
export const parasText = (paras) => paras.map((p) => p.map((r) => r.t).join("")).join("\n");
export const hasText = (paras) => paras.some((p) => p.some((r) => r.t.trim()));
export function dominant(paras, fallback = S.style) {
  let best = null;
  for (const p of paras) for (const r of p) if (!best || r.t.length > best.t.length) best = r;
  return norm(best || fallback);
}

// selection ⇄ [paragraph, offset]
function pointOf(el, segs, node, offset) {
  const mine = segs.filter((x) => x.node === node);
  const s = mine.find((x) => offset >= x.from && offset <= x.from + x.len) || mine.filter((x) => x.from <= offset).pop() || mine[0];
  if (s) return [s.p, s.a + Math.max(0, Math.min(s.len, offset - s.from))];
  const r = document.createRange();
  try { r.setStart(node, offset); } catch { return null; }
  r.collapse(true);
  for (const x of segs) if (r.comparePoint(x.node, x.from) >= 0) return [x.p, x.a];
  const last = segs[segs.length - 1];
  return last ? [last.p, last.a + last.len] : [0, 0];
}
export function getSel(el, segs) {
  const sel = getSelection();
  if (!sel.rangeCount || !el.contains(sel.anchorNode)) return null;
  const rg = sel.getRangeAt(0);
  const a = pointOf(el, segs, rg.startContainer, rg.startOffset), b = pointOf(el, segs, rg.endContainer, rg.endOffset);
  return a && b ? [a, b] : null;
}
function domPoint(el, [p, off]) {             // works on the canonical DOM made by renderParas
  const d = el.children[Math.min(p, el.children.length - 1)];
  if (!d) return [el, 0];
  let left = off;
  for (const sp of d.children) {
    const tn = sp.firstChild;
    if (tn && tn.nodeType === 3) { if (left <= tn.nodeValue.length) return [tn, left]; left -= tn.nodeValue.length; }
  }
  const lastSpan = d.lastElementChild, tn = lastSpan?.firstChild;
  return tn && tn.nodeType === 3 ? [tn, tn.nodeValue.length] : [lastSpan || d, 0];
}
export function setSel(el, a, b = a) {
  const rg = document.createRange();
  try { rg.setStart(...domPoint(el, a)); rg.setEnd(...domPoint(el, b)); const sel = getSelection(); sel.removeAllRanges(); sel.addRange(rg); } catch {}
}
function merge(runs) {
  const out = [];
  for (const r of runs) { const l = out[out.length - 1]; if (l && same(norm(l), norm(r))) l.t += r.t; else if (r.t) out.push({ ...r }); }
  return out;
}
export function patchRuns(paras, a, b, patch) {
  return paras.map((p, pi) => {
    if (pi < a[0] || pi > b[0]) return p;
    const from = pi === a[0] ? a[1] : 0, to = pi === b[0] ? b[1] : Infinity;
    const out = []; let pos = 0;
    for (const r of p) {
      const s = pos, e = pos + r.t.length; pos = e;
      const x = Math.max(s, from), y = Math.min(e, to);
      if (x >= y) { out.push(r); continue; }
      if (x > s) out.push({ ...r, t: r.t.slice(0, x - s) });
      out.push({ ...r, ...patch(r), t: r.t.slice(x - s, y - s) });
      if (y < e) out.push({ ...r, t: r.t.slice(y - s) });
    }
    return merge(out);
  });
}

// ------------------------------------------------------------------ the editing session (one text at a time)
let ED = null;     // {el, p, block | obj, orig, align, fallback, cover}
export const editing = () => ED;

/** colour of the paper around a rectangle of the page picture (to hide the old text while it is being edited) */
export function paper(p, bbox) {
  try {
    const img = ovEl(p).parentElement.querySelector(".pimg");
    if (!img.complete || !img.naturalWidth) return "#ffffff";
    const k = img.naturalWidth / S.sizes[p][0];
    const x = Math.max(0, (bbox[0] - 2.5) * k), y = Math.max(0, (bbox[1] - 2.5) * k);
    const w = Math.min(img.naturalWidth - x, (bbox[2] - bbox[0] + 5) * k), hh = Math.min(img.naturalHeight - y, (bbox[3] - bbox[1] + 5) * k);
    const cw = Math.max(4, Math.min(160, Math.round(w / 2))), ch = Math.max(4, Math.min(80, Math.round(hh / 2)));
    const c = document.createElement("canvas"); c.width = cw; c.height = ch;
    const ctx = c.getContext("2d", { willReadFrequently: true });
    ctx.drawImage(img, x, y, w, hh, 0, 0, cw, ch);
    const d = ctx.getImageData(0, 0, cw, ch).data, px = [[], [], []];
    const take = (i, j) => { const o = (j * cw + i) * 4; px[0].push(d[o]); px[1].push(d[o + 1]); px[2].push(d[o + 2]); };
    for (let i = 0; i < cw; i++) { take(i, 0); take(i, ch - 1); }
    for (let j = 0; j < ch; j++) { take(0, j); take(cw - 1, j); }
    const med = px.map((a) => a.sort((m, n) => m - n)[a.length >> 1]);
    return `rgb(${med[0]},${med[1]},${med[2]})`;
  } catch { return "#ffffff"; }
}

function caretAt(ev) {
  try {
    if (document.caretPositionFromPoint) { const c = document.caretPositionFromPoint(ev.clientX, ev.clientY); if (c) return [c.offsetNode, c.offset]; }
    if (document.caretRangeFromPoint) { const r = document.caretRangeFromPoint(ev.clientX, ev.clientY); if (r) return [r.startContainer, r.startOffset]; }
  } catch {}
  return null;
}
function focusAt(el, ev) {
  el.focus({ preventScroll: true });
  const c = ev && caretAt(ev);
  const sel = getSelection(), rg = document.createRange();
  if (c && el.contains(c[0])) { rg.setStart(c[0], c[1]); rg.collapse(true); } else { rg.selectNodeContents(el); rg.collapse(false); }
  sel.removeAllRanges(); sel.addRange(rg);
}

function begin(ed, ev) {
  ED = ed;
  const el = ed.el;
  el.contentEditable = "true"; el.spellcheck = false;
  el.onpaste = (e) => { e.preventDefault(); const txt = (e.clipboardData || window.clipboardData).getData("text/plain"); if (txt) document.execCommand("insertText", false, txt.replace(/\r\n?/g, "\n")); };
  el.ondrop = (e) => e.preventDefault();
  el.onkeydown = (e) => {
    const mod = e.ctrlKey || e.metaKey;
    if (e.key === "Escape") { e.preventDefault(); closeEditor(false); }
    else if (mod && e.key === "Enter") { e.preventDefault(); closeEditor(true); }
    else if (mod && !e.shiftKey && "biu".includes(e.key.toLowerCase())) { e.preventDefault(); toggle(e.key.toLowerCase()); }
    e.stopPropagation();
  };
  $("#ftb").classList.remove("hidden"); $("#otb").classList.add("hidden");
  $$("#falign button").forEach((x) => x.classList.toggle("on", x.dataset.a === ed.align));
  $("#aibtn").classList.toggle("hidden", !S.ai);
  focusAt(el, ev); syncBar();
}

/** Edit a text block that is already in the PDF. */
export async function editBlock(p, b, ev) {
  const pv = S.pv[p];
  await closeEditor(true); await idle();
  if (S.pv[p] !== pv) {                                   // the page was re-typeset meanwhile: find the same text again
    const m = await model(p).catch(() => null);
    b = m && m.blocks.filter((x) => x.text === b.text).sort((x, y) => Math.abs(x.bbox[1] - b.bbox[1]) - Math.abs(y.bbox[1] - b.bbox[1]))[0];
    if (!b) return;
    ev = null;
  }
  const ov = ovEl(p); if (!ov) return;
  const size = b.size || 11, lh = b.lh || 1.2, first = b.lines[0] || b.bbox;
  const top = Math.min(b.bbox[1], (first[1] + first[3]) / 2 - (lh * size) / 2);
  const bg = paper(p, b.bbox);
  const cover = h("div", { class: "cover", style: `left:${b.bbox[0] - 1}px;top:${b.bbox[1] - 1}px;width:${b.bbox[2] - b.bbox[0] + 2}px;height:${b.bbox[3] - b.bbox[1] + 2}px;background:${bg};z-index:5` });
  const el = h("div", { class: "ed" + (b.cell ? " nowrap" : "") });
  // font and size of the box itself = those of the text: otherwise the browser's line "strut" (from the page's own font) would push the lines apart
  Object.assign(el.style, { left: b.box[0] - 1 + "px", top: top + "px", width: b.box[1] - b.box[0] + 1.5 + "px", minHeight: b.bbox[3] - top + "px", lineHeight: lh, fontSize: size + "px", fontFamily: fontStack(b.fam || "liberationsans"), textAlign: b.align, padding: "0 1px", background: bg });
  const fallback = { b: b.bold, i: b.italic, c: b.color, s: size, fam: b.fam, f: "" };
  renderParas(el, b.paras, fallback);
  ov.append(cover, el);
  begin({ el, p, block: b, orig: JSON.stringify(readParas(el, fallback)), align: b.align, fallback, cover }, ev);
}

/** Edit a text box the user added (o = the object, el = its element on the page). */
export async function editObject(o, el, ev) {
  if (ED && ED.obj === o) return;
  await closeEditor(true);
  el.classList.add("editing");
  const fallback = { ...S.style, ...(o.paras[0]?.[0] || {}), t: "" };
  begin({ el, p: o.page, obj: o, orig: JSON.stringify(o.paras), align: o.align || "left", fallback }, ev);
}

export async function closeEditor(save = true) {
  if (!ED) return;
  const e = ED; ED = null;
  $("#ftb").classList.add("hidden");
  const paras = readParas(e.el, e.fallback);
  e.el.contentEditable = "false"; e.el.onkeydown = e.el.onpaste = null;
  getSelection().removeAllRanges();
  if (e.obj) {
    e.el.classList.remove("editing");
    const o = e.obj;
    if (save) { o.paras = paras; o.align = e.align; }
    const empty = !hasText(o.paras);
    if (empty) S.objects = S.objects.filter((x) => x !== o);
    if ((save && JSON.stringify(o.paras) !== e.orig) || empty || e.dirty) { if (!(empty && e.fresh)) pushHist(); }
    hooks.redraw?.();
    return;
  }
  const b = e.block;
  const changed = save && (JSON.stringify(paras) !== e.orig || e.align !== b.align);
  if (!changed) { e.el.remove(); e.cover.remove(); return; }
  e.el.classList.add("saving");
  try {
    const r = await commit([{ type: "edit_block", page: e.p, bbox: b.bbox, paras: hasText(paras) ? paras : [], align: e.align, lh: b.lh, base: b.base, single: b.single,
      scanned: b.scanned, lines: b.lines, reflow: true, collapse: !hasText(paras) }], tr("Typesetting…"));
    if (r.skipped) toast(tr("This text could not be changed in this PDF."), 5000);
    pushHist();
    await hooks.pageChanged?.(e.p);
    hooks.redraw?.();
  } catch (err) { toast(err.message, 6000); }
  e.el.remove(); e.cover.remove();
}

// ------------------------------------------------------------------ formatting bar
function current() {
  const sc = scan(ED.el, ED.fallback);
  const sel = getSel(ED.el, sc.segs) || [[0, 0], [0, 0]];
  return { paras: sc.paras, a: sel[0], b: sel[1] };
}
function apply(patch) {
  if (!ED) return;
  const { paras, a, b } = current();
  const collapsed = a[0] === b[0] && a[1] === b[1];
  const A = collapsed ? [0, 0] : a, B = collapsed ? [paras.length - 1, Infinity] : b;
  if (collapsed) { ED.fallback = { ...ED.fallback, ...patch(norm(ED.fallback)) }; if (ED.obj) Object.assign(S.style, patch(norm(S.style))); }
  ED.dirty = true;
  renderParas(ED.el, patchRuns(paras, A, B, patch), ED.fallback);
  setSel(ED.el, a, b); ED.el.focus({ preventScroll: true }); syncBar();
}
function selectedRuns() {
  const { paras, a, b } = current();
  const collapsed = a[0] === b[0] && a[1] === b[1];
  const out = [];
  paras.forEach((p, pi) => { let pos = 0; for (const r of p) { const s = pos, e = pos + r.t.length; pos = e;
    if (collapsed ? (pi === a[0] && a[1] >= s && a[1] <= e) : !(pi < a[0] || pi > b[0] || (pi === a[0] && e <= a[1]) || (pi === b[0] && s >= b[1]))) out.push(r); } });
  return out.length ? out : [norm(ED.fallback)];
}
function toggle(k) {
  const on = selectedRuns().every((r) => r[k]);
  // bold / italic need another cut of the font: the original PDF font (f) is one cut only, so the family takes over
  apply(() => (k === "u" ? { u: on ? 0 : 1, st: 0 } : k === "st" ? { st: on ? 0 : 1, u: 0 } : { [k]: on ? 0 : 1, f: "" }));
}
function syncBar() {
  if (!ED) return;
  const r = selectedRuns()[0];
  $("#ffam").value = S.fonts.some((f) => f.key === r.fam) ? r.fam : "liberationsans";
  $("#fsize").value = Math.round(r.s * 10) / 10; $("#fcolor").value = /^#[0-9a-f]{6}$/i.test(r.c) ? r.c : "#000000";
  for (const k of ["b", "i", "u", "st"]) $(`#ftb [data-cmd="${k}"]`).classList.toggle("on", !!r[k]);
}
export function initTextBar() {
  const fam = $("#ffam");
  for (const f of S.fonts) fam.append(h("option", { value: f.key }, f.name));
  const keep = (e) => e.preventDefault();                       // buttons must not steal the text selection
  $$("#ftb button").forEach((b) => b.addEventListener("pointerdown", keep));
  let saved = null;                                             // selects and inputs do take the focus: remember the selection
  const remember = () => { if (ED) { const sc = scan(ED.el, ED.fallback); saved = getSel(ED.el, sc.segs); } };
  const restore = () => { if (ED && saved) { renderParas(ED.el, readParas(ED.el, ED.fallback), ED.fallback); setSel(ED.el, saved[0], saved[1]); } };
  for (const id of ["#ffam", "#fsize", "#fcolor"]) { $(id).addEventListener("pointerdown", remember); $(id).addEventListener("focus", remember); }
  fam.onchange = () => { restore(); apply(() => ({ fam: fam.value, f: "" })); };
  $("#fsize").onchange = () => { const v = Math.max(3, Math.min(300, +$("#fsize").value || 11)); restore(); apply(() => ({ s: v })); };
  $("#fcolor").oninput = () => { restore(); apply(() => ({ c: $("#fcolor").value })); };
  $("#ftb").addEventListener("click", (e) => {
    const btn = e.target.closest("button"); if (!btn || !ED) return;
    const cmd = btn.dataset.cmd, al = btn.dataset.a;
    if (al) { ED.align = al; ED.el.style.textAlign = al; ED.dirty = true; $$("#falign button").forEach((x) => x.classList.toggle("on", x === btn)); }
    else if (["b", "i", "u", "st"].includes(cmd)) toggle(cmd);
    else if (cmd === "bigger" || cmd === "smaller") { const d = cmd === "bigger" ? 1 : -1; apply((r) => ({ s: Math.max(3, Math.round((r.s + d * (r.s >= 24 ? 2 : 1)) * 2) / 2) })); }
    else if (cmd === "delete") { renderParas(ED.el, [[]], ED.fallback); closeEditor(true); }
    else if (cmd === "cancel") closeEditor(false);
    else if (cmd === "done") closeEditor(true);
  });
  document.addEventListener("selectionchange", () => { if (ED && ED.el.contains(getSelection().anchorNode)) syncBar(); });
}
export async function aiRewrite(action, lang) {
  if (!ED) return;
  const { paras } = current();
  const text = parasText(paras).trim(); if (!text) return;
  const dom = dominant(paras, ED.fallback);
  const el = ED.el; el.style.opacity = .5;
  try {
    const r = await api("/api/ai", { action, text, lang });
    if (ED && ED.el === el) { renderParas(el, r.result.split("\n").map((line) => (line ? [{ ...dom, t: line }] : [])), ED.fallback); ED.dirty = true; }
  } catch (e) { if (!e.quota) toast(e.message, 5000); }
  el.style.opacity = 1;
}

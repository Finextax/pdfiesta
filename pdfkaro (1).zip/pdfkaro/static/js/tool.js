// One script drives every tool page. The page slug picks a definition from tools-config.js.
import { $, $$, h, chrome, api, upload, fmtSize, loadPdf, renderPage, lazy, t, tr, href, toast, debounce, esc } from "/static/js/common.js";
import { ready as i18nReady, path } from "/static/js/i18n.js";
await i18nReady;

const slug = path.split("/").filter(Boolean).pop();
const T = window.TOOLS;
const cfg = T[slug];
if (!cfg) location.replace(href("/"));
if (cfg.editor) location.replace(href("/edit") + `?mode=${slug}${location.search ? "&" + location.search.slice(1) : ""}`);
chrome();

const title = t(`tool.${slug}`, cfg.title), desc = t(`desc.${slug}`, cfg.desc), btnText = cfg.btn ? t(`btn.${slug}`, cfg.btn) : tr("Process");
$("#title").textContent = title;
if (cfg.pro) $("#title").append(h("span", { class: "badge pro" }, "PRO"));
$("#desc").textContent = desc;
if (cfg.note) $("#desc").after(h("p", { class: "muted note" }, tr(cfg.note)));
$("#go").textContent = btnText;
const accept = cfg.accept || ".pdf,application/pdf";
const isImg = /image\//.test(accept) && !accept.includes(".pdf");
const fi = $("#fi"); fi.accept = accept === "*/*" ? "" : accept; fi.multiple = !!cfg.multi;
$("#pick").textContent = isImg ? t("ui.uploadImages", "Upload images") : accept.includes(".pdf") ? (cfg.multi ? t("ui.uploadPdfs", "Upload PDF files") : t("ui.uploadPdf", "Upload PDF file")) : t("ui.uploadOffice", "Upload files");
$("#byurl").textContent = tr("From web address (URL)");
$("#dropnote").textContent = tr("or drop files here · paste with Ctrl+V · files stay private and are deleted after 2 hours");
if (cfg.camera) {
  const cam = h("input", { type: "file", accept: "image/*", capture: "environment", hidden: "" });
  cam.onchange = (e) => { addFiles([...e.target.files]); e.target.value = ""; };
  $("#byurl").before(cam, h("button", { class: "btn sm", onclick: () => cam.click() }, "📷 " + t("ui.camera", "Take photo")));
}
if (isImg || !accept.includes(".pdf")) $("#byurl").classList.add("hidden");

let files = [];              // metas of uploaded files
const local = new Map();     // file id → object URL of the picture on this device (for previews)
const state = {};            // option values
let showAdv = false;
const visual = {};           // data of the visual pickers (pages, crop box, areas …)

// ---------------------------------------------------------------- upload
async function addFiles(list) {
  if (!list.length) return;
  if (!cfg.multi) list = [list[0]];
  const bar = $("#upbar"); bar.classList.remove("hidden"); showErr("", $("#drop"));
  try {
    const metas = await upload(list, (p) => bar.firstChild.style.width = (p * 100).toFixed(0) + "%");
    metas.forEach((m, i) => { if (m.kind === "image" && list[i]) local.set(m.id, URL.createObjectURL(list[i])); });
    for (const m of metas) {
      if (m.encrypted && cfg.tool !== "unlock") await askPassword(m);
      if (m.damaged && cfg.tool !== "repair") showErr(tr("This file looks damaged. Try the Repair tool first.") + ` (${m.name})`, $("#drop"));
    }
    files = cfg.multi ? files.concat(metas) : metas;
    if (cfg.max && files.length > cfg.max) { files = files.slice(0, cfg.max); toast(tr("This tool takes at most") + " " + cfg.max + " " + tr("files")); }
    showWork(true);
  } catch (e) { if (!e.quota) showErr(e.message, $("#drop")); }
  bar.classList.add("hidden"); bar.firstChild.style.width = 0;
}
function askPassword(m) {
  return new Promise((res) => {
    $("#pwname").textContent = m.name; $("#pwerr").innerHTML = ""; $("#pwmodal").classList.add("on"); $("#pwin").value = ""; $("#pwin").focus();
    const go = async () => {
      try { Object.assign(m, await api(`/api/file/${m.id}/unlock`, { password: $("#pwin").value })); $("#pwmodal").classList.remove("on"); res(); }
      catch (e) { $("#pwerr").innerHTML = `<div class="err">${esc(e.message)}</div>`; }
    };
    $("#pwok").onclick = go; $("#pwin").onkeydown = (e) => e.key === "Enter" && go();
    $("#pwcancel").onclick = () => { $("#pwmodal").classList.remove("on"); res(); };
  });
}
$("#pick").onclick = () => fi.click();
fi.onchange = (e) => { addFiles([...e.target.files]); e.target.value = ""; };
$("#byurl").onclick = async () => {
  const u = prompt(tr("Web address of the PDF file:")); if (!u) return;
  try { const m = await api("/api/upload-url", { url: u }); files = cfg.multi ? files.concat([m]) : [m]; showWork(true); } catch (e) { showErr(e.message, $("#drop")); }
};
const drop = $("#drop");
["dragenter", "dragover"].forEach((ev) => document.addEventListener(ev, (e) => { if (e.dataTransfer?.types?.includes("Files")) { e.preventDefault(); drop.classList.add("over"); } }));
["dragleave", "drop"].forEach((ev) => document.addEventListener(ev, () => drop.classList.remove("over")));
document.addEventListener("drop", (e) => { if (e.dataTransfer?.files?.length) { e.preventDefault(); addFiles([...e.dataTransfer.files]); } });
document.addEventListener("paste", (e) => { const fs = [...(e.clipboardData?.files || [])]; if (fs.length && !e.target.closest("input,textarea")) addFiles(fs); });

for (const o of cfg.options || []) if (o.v !== undefined && state[o.k] === undefined) state[o.k] = structuredClone(o.v);
Object.assign(state, cfg.preset || {});

// ---------------------------------------------------------------- work panel
function showWork(filesChanged) {
  $("#work").classList.remove("hidden"); $("#result").classList.add("hidden");
  drop.classList.toggle("hidden", !!cfg.noUpload || !cfg.multi || (cfg.max && files.length >= cfg.max));
  if (cfg.multi) $("#pick").textContent = "+ " + tr("Add more files");
  renderFiles(); visualReady = renderVisual(filesChanged); renderOpts(); refreshPreview();
}
let visualReady = Promise.resolve();   // page thumbnails and pickers load in the background; "Go" waits for them

function renderFiles() {
  const box = $("#files"); box.innerHTML = "";
  if (cfg.noUpload) return;
  const move = (i, d) => { const j = i + d; if (j < 0 || j >= files.length) return; [files[i], files[j]] = [files[j], files[i]]; showWork(true); };
  files.forEach((f, i) => {
    const row = h("div", { class: "file" + (cfg.multi && (files.length > 1 || cfg.tool === "merge") ? " wide" : ""), draggable: cfg.multi ? "true" : null },
      local.get(f.id) ? h("img", { class: "mini", src: local.get(f.id) }) : null,
      h("span", { class: "nm" }, f.name),
      h("span", { class: "meta" }, [f.pages ? `${f.pages} ${tr("pages")}` : "", f.w && f.kind === "image" ? `${f.w}×${f.h}` : "", fmtSize(f.size), f.scanned ? tr("scanned") : ""].filter(Boolean).join(" · ")),
      cfg.tool === "merge" && f.pages > 1 ? h("input", { type: "text", class: "rng", placeholder: tr("pages: all"), value: (visual.ranges || {})[f.id] || "",
        oninput: (e) => { visual.ranges = visual.ranges || {}; visual.ranges[f.id] = e.target.value; } }) : null,
      cfg.multi && files.length > 1 ? h("span", { class: "mv" }, h("button", { title: tr("Move up"), onclick: () => move(i, -1) }, "↑"), h("button", { title: tr("Move down"), onclick: () => move(i, 1) }, "↓")) : null,
      h("button", { class: "x", title: tr("Remove"), onclick: () => { files.splice(i, 1); files.length ? showWork(true) : location.reload(); } }, "×"));
    if (cfg.multi) {
      row.ondragstart = (e) => e.dataTransfer.setData("text/idx", i);
      row.ondragover = (e) => e.preventDefault();
      row.ondrop = (e) => { e.preventDefault(); e.stopPropagation(); const from = +e.dataTransfer.getData("text/idx"); if (isNaN(from)) return; const [m] = files.splice(from, 1); files.splice(i, 0, m); showWork(true); };
    }
    box.append(row);
  });
  const fb = $("#filebtns"); fb.innerHTML = "";
  if (cfg.multi && files.length > 2) fb.append(
    h("button", { class: "btn sm", onclick: () => { files.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true })); showWork(true); } }, tr("Sort A–Z")),
    h("button", { class: "btn sm", onclick: () => { files.sort((a, b) => b.name.localeCompare(a.name, undefined, { numeric: true })); showWork(true); } }, tr("Sort Z–A")));
}

// ---------------------------------------------------------------- options form
function visible(o) {
  if (o.adv && !showAdv) return false;
  if (!o.when) return true;
  return Object.entries(o.when).every(([k, v]) => Array.isArray(v) ? v.includes(state[k]) : state[k] === v);
}

function renderOpts() {
  const box = $("#opts"); box.innerHTML = "";
  const opts = cfg.options || [];
  $("#more").classList.toggle("hidden", !opts.some((o) => o.adv));
  $("#more").textContent = showAdv ? tr("Fewer options") + " ▴" : tr("More options") + " ▾";
  $("#more").onclick = (e) => { e.preventDefault(); showAdv = !showAdv; renderOpts(); };
  for (const o of opts) {
    if (!visible(o)) continue;
    const wrap = h("div", { class: "opt" }, o.t && o.type !== "check" ? h("label", { class: "t" }, tr(o.t)) : null);
    const changed = () => { refreshPreview(); };
    const set = (v) => { state[o.k] = v; if (opts.some((x) => x.when && o.k in x.when)) renderOpts(); renderVisual(false); changed(); };
    if (o.type === "seg") wrap.append(h("div", { class: "seg" }, o.items.map(([v, l]) => h("button", { class: state[o.k] === v ? "on" : "", onclick: () => { set(v); renderOpts(); } }, tr(l)))));
    else if (o.type === "choice") wrap.append(h("div", { class: "choice" }, o.items.map(([v, l, d]) => h("button", { class: state[o.k] === v ? "on" : "", onclick: () => { set(v); renderOpts(); } }, h("b", {}, tr(l)), h("span", {}, tr(d || ""))))));
    else if (o.type === "select") wrap.append(h("select", { onchange: (e) => set(e.target.value) }, o.items.map(([v, l]) => h("option", { value: v, selected: state[o.k] === v ? "" : null }, tr(l)))));
    else if (o.type === "check") wrap.append(h("label", { class: "chk" }, h("input", { type: "checkbox", checked: state[o.k] ? "" : null, onchange: (e) => { state[o.k] = e.target.checked; changed(); } }), tr(o.t)));
    else if (o.type === "multi" || o.type === "flags") {
      const cur = state[o.k] || (o.type === "flags" ? {} : []);
      wrap.append(h("div", { class: "row wrapchk" }, o.items.map(([v, l]) => h("label", { class: "chk" },
        h("input", { type: "checkbox", checked: (o.type === "flags" ? cur[v] : cur.includes(v)) ? "" : null, onchange: (e) => {
          if (o.type === "flags") cur[v] = e.target.checked; else { const i = cur.indexOf(v); e.target.checked ? i < 0 && cur.push(v) : i >= 0 && cur.splice(i, 1); }
          state[o.k] = cur; } }), tr(l)))));
    } else if (o.type === "textarea") wrap.append(h("textarea", { placeholder: o.ph || "", oninput: (e) => { state[o.k] = e.target.value; changed(); } }, state[o.k] || ""));
    else if (o.type === "range") { const lab = h("span", { class: "muted" }, (state[o.k] ?? o.v) + (o.pct ? " %" : "")); wrap.append(h("div", { class: "row" },
        h("input", { type: "range", min: o.min, max: o.max, value: state[o.k] ?? o.v, oninput: (e) => { state[o.k] = +e.target.value; lab.textContent = e.target.value + (o.pct ? " %" : ""); changed(); } }), lab)); }
    else if (o.type === "file") {
      const cur = files2.get(o.k);
      wrap.append(cur ? h("div", { class: "file" }, h("span", { class: "nm" }, cur), h("button", { class: "x", onclick: () => { files2.delete(o.k); delete state[o.k]; renderOpts(); changed(); } }, "×"))
        : h("input", { type: "file", accept: o.accept || "image/*", onchange: async (e) => {
          const f = e.target.files[0]; if (!f) return;
          try { const [m] = await upload([f]); state[o.k] = m.id; files2.set(o.k, m.name); renderOpts(); changed(); } catch (err) { showErr(err.message); } } }));
    } else if (o.type === "combo") {
      const id = "dl_" + o.k;
      wrap.append(h("input", { type: "text", list: id, value: state[o.k] ?? "", oninput: (e) => { state[o.k] = e.target.value; changed(); } }), h("datalist", { id }, o.items.map((v) => h("option", { value: v }))));
    } else {
      const inp = h("input", { type: o.type === "number" ? "number" : o.type === "color" ? "color" : o.type === "password" ? "password" : "text",
        placeholder: o.ph || "", step: o.step || (o.type === "number" ? "any" : null), value: state[o.k] ?? (o.type === "color" ? "#000000" : ""), autocomplete: o.type === "password" ? "new-password" : "off",
        oninput: (e) => { state[o.k] = o.type === "number" ? (e.target.value === "" ? undefined : +e.target.value) : e.target.value; changed(); } });
      wrap.append(inp);
    }
    box.append(wrap);
  }
  if (cfg.meta && files[0] && files[0].metadata && !visual.metaFilled) {     // metadata tool: show the current values
    visual.metaFilled = true;
    for (const k of ["title", "author", "subject", "keywords", "creator", "producer"]) state[k] = files[0].metadata[k] || "";
    renderOpts();
  }
}
const files2 = new Map();   // option key → name of the extra file chosen (logo, certificate …)

// ---------------------------------------------------------------- visual pickers
async function renderVisual(filesChanged) {
  const box = $("#visual");
  try {
    if (cfg.ui === "thumbs" || cfg.ui === "organize") { if (filesChanged) await thumbs(box); }
    else if (cfg.ui === "crop") await cropUI(box, filesChanged);
    else if (cfg.ui === "areas") { if (filesChanged) await areasUI(box); }
    else if (cfg.ui === "brush") { if (filesChanged) await brushUI(box); }
    else if (cfg.ui === "bookmarks") { if (filesChanged) bookmarksUI(box); }
    else if (cfg.ui === "workflow") { if (!box.firstChild) workflowUI(box); }
    else if (cfg.ui === "invoice") { if (!box.firstChild) invoiceUI(box); }
    else box.innerHTML = "";
  } catch (e) { box.innerHTML = ""; box.append(h("p", { class: "muted center" }, tr("Preview is not available for this file."))); }
}

async function thumbs(box) {
  box.innerHTML = "";
  if (!files.length) return;
  const mode = cfg.ui === "organize" ? "organize" : cfg.thumbMode;
  const pdfs = await Promise.all(files.map((f) => loadPdf(f.id)));
  const old = visual.pages || [];
  const known = new Set(old.filter((p) => !p.blank).map((p) => p.fid));
  // keep what the user already arranged; pages of newly added files go to the end
  visual.pages = old.filter((p) => p.blank || files.some((f) => f.id === p.fid));
  files.forEach((f, fi2) => { if (!known.has(f.id)) for (let i = 0; i < pdfs[fi2].numPages; i++) visual.pages.push({ fid: f.id, page: i, rotate: 0, del: false, sel: false }); });
  const tools = h("div", { class: "row thumbtools" });
  const all = (fn) => { visual.pages.forEach(fn); paint(); };
  if (mode === "rotate" || mode === "organize") tools.append(...[
    h("span", { class: "muted" }, tr("All pages:")),
    ...[["↺", -90], ["↻", 90], ["180°", 180]].map(([l, a]) => h("button", { class: "btn sm", onclick: () => all((p) => { if (!p.blank) p.rotate = ((p.rotate || 0) + a + 360) % 360; }) }, l)),
    mode === "rotate" ? h("button", { class: "btn sm", onclick: () => all((p, i) => i % 2 === 0 && (p.rotate = (p.rotate + 90) % 360)) }, tr("Odd pages") + " ↻") : null,
    mode === "rotate" ? h("button", { class: "btn sm", onclick: () => all((p, i) => i % 2 === 1 && (p.rotate = (p.rotate + 90) % 360)) }, tr("Even pages") + " ↻") : null,
    h("button", { class: "btn sm", onclick: () => all((p) => { if (!p.blank) p.rotate = 0; }) }, tr("Reset"))].filter(Boolean));
  if (mode === "select" || mode === "delete") tools.append(
    h("button", { class: "btn sm", onclick: () => all((p, i) => p[mode === "delete" ? "del" : "sel"] = i % 2 === 0) }, tr("Odd pages")),
    h("button", { class: "btn sm", onclick: () => all((p, i) => p[mode === "delete" ? "del" : "sel"] = i % 2 === 1) }, tr("Even pages")),
    h("button", { class: "btn sm", onclick: () => all((p) => p.sel = p.del = false) }, tr("Reset")),
    h("span", { class: "muted" }, mode === "delete" ? tr("Tap the pages you want to delete") : tr("Tap the pages you want to keep (Shift = a range)")));
  if (mode === "organize") tools.append(h("button", { class: "btn sm", onclick: () => { visual.pages.reverse(); paint(); } }, tr("Reverse order")),
    h("span", { class: "muted" }, tr("Drag pages to move them · use the buttons on a page to rotate, copy, delete or add a blank page")));
  const grid = h("div", { class: "thumbs" + (mode === "organize" ? " big" : "") });
  box.append(tools, grid);
  let dragFrom = null;
  function paint() {
    grid.innerHTML = "";
    visual.pages.forEach((p, idx) => {
      const c = h("canvas");
      const fidx = files.findIndex((f) => f.id === p.fid);
      const el = h("div", { class: "th" + (p.del ? " del" : "") + (p.sel ? " sel" : "") + (p.blank ? " blank" : ""), draggable: mode === "organize" ? "true" : null },
        p.blank ? h("div", { class: "bp" }, tr("Blank page")) : c,
        h("div", { class: "n" }, p.blank ? "+" : (files.length > 1 ? String.fromCharCode(65 + fidx % 26) + "·" : "") + (p.page + 1)));
      if (!p.blank) { c.style.transform = `rotate(${p.rotate}deg)`; el._render = () => renderPage(pdfs[fidx], p.page + 1, c, mode === "organize" ? 130 : 104).catch(() => {}); lazy.observe(el); }
      const acts = h("div", { class: "acts" });
      const rot = (a) => (e) => { e.stopPropagation(); p.rotate = (p.rotate + a + 360) % 360; c.style.transform = `rotate(${p.rotate}deg)`; };
      if ((mode === "rotate" || mode === "organize") && !p.blank) acts.append(h("button", { title: tr("Rotate left"), onclick: rot(270) }, "↺"), h("button", { title: tr("Rotate right"), onclick: rot(90) }, "↻"));
      if (mode === "organize") acts.append(
        h("button", { title: tr("Move earlier"), onclick: (e) => { e.stopPropagation(); if (idx) { visual.pages.splice(idx - 1, 0, visual.pages.splice(idx, 1)[0]); paint(); } } }, "←"),
        h("button", { title: tr("Move later"), onclick: (e) => { e.stopPropagation(); if (idx < visual.pages.length - 1) { visual.pages.splice(idx + 1, 0, visual.pages.splice(idx, 1)[0]); paint(); } } }, "→"),
        p.blank ? null : h("button", { title: tr("Copy this page"), onclick: (e) => { e.stopPropagation(); visual.pages.splice(idx + 1, 0, { ...p }); paint(); } }, "⧉"),
        h("button", { title: tr("Add a blank page after"), onclick: (e) => { e.stopPropagation(); visual.pages.splice(idx + 1, 0, { blank: true }); paint(); } }, "+"),
        h("button", { title: tr("Delete"), onclick: (e) => { e.stopPropagation(); visual.pages.splice(idx, 1); paint(); } }, "✕"));
      el.append(acts);
      el.onclick = (e) => {
        const key = mode === "delete" ? "del" : mode === "select" ? "sel" : null; if (!key) return;
        if (e.shiftKey && visual.last != null) { const [a, b] = [visual.last, idx].sort((x, y) => x - y); for (let i = a; i <= b; i++) visual.pages[i][key] = true; paint(); }
        else { p[key] = !p[key]; el.classList.toggle(key); }
        visual.last = idx;
      };
      if (mode === "organize") {
        el.ondragstart = () => dragFrom = idx; el.ondragover = (e) => e.preventDefault();
        el.ondrop = (e) => { e.preventDefault(); e.stopPropagation(); if (dragFrom == null) return; const [m] = visual.pages.splice(dragFrom, 1); visual.pages.splice(idx, 0, m); dragFrom = null; paint(); };
      }
      grid.append(el);
    });
  }
  paint();
}

// a page preview on which rectangles can be drawn (crop box, areas to redact, areas to read)
async function pageCanvas(box, pno = 0, width = 560) {
  const pdf = await loadPdf(files[0].id);
  const c = h("canvas"); const wrapper = h("div", { class: "cropwrap" }, c);
  box.append(wrapper);
  const r = await renderPage(pdf, Math.min(pdf.numPages, pno + 1), c, Math.min(width, box.clientWidth - 20 || width));
  return { pdf, wrapper, W: parseFloat(c.style.width), H: parseFloat(c.style.height), pages: pdf.numPages };
}

async function cropUI(box, filesChanged) {
  if (state.mode !== "box") { box.innerHTML = ""; return; }
  if (box.querySelector(".cropwrap") && !filesChanged) return;
  box.innerHTML = "";
  box.append(h("p", { class: "muted center" }, tr("Drag the box or its corners: the area inside is kept (on all chosen pages).")));
  const holder = h("div", { class: "center" }); box.append(holder);
  const { wrapper, W, H } = await pageCanvas(holder);
  visual.box = visual.box || { x0: 0.1, y0: 0.1, x1: 0.9, y1: 0.9 };
  const cb = h("div", { class: "cropbox" }, ...["nw", "ne", "sw", "se"].map((k) => h("i", { "data-k": k, style: `${k[0] === "n" ? "top" : "bottom"}:-9px;${k[1] === "w" ? "left" : "right"}:-9px;cursor:${k}-resize` })));
  wrapper.append(cb);
  const place = () => Object.assign(cb.style, { left: visual.box.x0 * W + "px", top: visual.box.y0 * H + "px", width: (visual.box.x1 - visual.box.x0) * W + "px", height: (visual.box.y1 - visual.box.y0) * H + "px" });
  place();
  cb.onpointerdown = (e) => {
    e.preventDefault();
    const k = e.target.dataset.k || "move"; const sx = e.clientX, sy = e.clientY, b0 = { ...visual.box };
    const mv = (ev) => {
      const dx = (ev.clientX - sx) / W, dy = (ev.clientY - sy) / H, b = visual.box, cl = (v) => Math.max(0, Math.min(1, v));
      if (k === "move") { const w = b0.x1 - b0.x0, hh = b0.y1 - b0.y0; b.x0 = cl(Math.min(b0.x0 + dx, 1 - w)); b.y0 = cl(Math.min(b0.y0 + dy, 1 - hh)); b.x1 = b.x0 + w; b.y1 = b.y0 + hh; }
      else { if (k.includes("n")) b.y0 = cl(Math.min(b0.y0 + dy, b.y1 - .02)); if (k.includes("s")) b.y1 = cl(Math.max(b0.y1 + dy, b.y0 + .02)); if (k.includes("w")) b.x0 = cl(Math.min(b0.x0 + dx, b.x1 - .02)); if (k.includes("e")) b.x1 = cl(Math.max(b0.x1 + dx, b.x0 + .02)); }
      place();
    };
    const up = () => { removeEventListener("pointermove", mv); removeEventListener("pointerup", up); refreshPreview(); };
    addEventListener("pointermove", mv); addEventListener("pointerup", up);
  };
}

async function areasUI(box) {
  box.innerHTML = "";
  if (!files[0] || files[0].kind !== "pdf") return;
  visual.areas = []; let pno = 0;
  const head = h("div", { class: "row", style: "justify-content:center;margin:8px 0" });
  const holder = h("div", { class: "center" });
  box.append(h("p", { class: "muted center" }, cfg.tool === "redact" ? tr("Drag on the page to mark areas that should be blacked out.") : tr("Drag a box around the text that should become the file name.")), head, holder);
  async function show() {
    holder.innerHTML = "";
    const { wrapper, W, H, pages } = await pageCanvas(holder, pno);
    head.innerHTML = "";
    if (pages > 1 && cfg.tool === "redact") head.append(
      h("button", { class: "btn sm", onclick: () => { if (pno) { pno--; show(); } } }, "‹"), h("span", { class: "muted" }, `${tr("Page")} ${pno + 1} / ${pages}`),
      h("button", { class: "btn sm", onclick: () => { if (pno < pages - 1) { pno++; show(); } } }, "›"));
    head.append(h("button", { class: "btn sm", onclick: () => { visual.areas = visual.areas.filter((a) => a.page !== pno); show(); } }, tr("Clear boxes")));
    wrapper.style.cursor = "crosshair"; wrapper.style.touchAction = "none";
    const draw = () => { wrapper.querySelectorAll(".area").forEach((x) => x.remove());
      visual.areas.forEach((a, i) => { if (a.page !== pno) return;
        const el = h("div", { class: "area" + (cfg.tool === "redact" ? " black" : ""), style: `left:${a.x0 * W}px;top:${a.y0 * H}px;width:${(a.x1 - a.x0) * W}px;height:${(a.y1 - a.y0) * H}px` },
          cfg.tool === "redact" ? null : h("span", {}, "TEXT" + (visual.areas.indexOf(a) + 1)),
          h("button", { title: tr("Remove"), onpointerdown: (e) => { e.stopPropagation(); visual.areas.splice(i, 1); draw(); } }, "×"));
        wrapper.append(el); }); };
    wrapper.onpointerdown = (e) => {
      if (e.target.closest(".area")) return;
      e.preventDefault();
      const r = wrapper.getBoundingClientRect(); const x = (e.clientX - r.left) / W, y = (e.clientY - r.top) / H;
      const a = { page: pno, x0: x, y0: y, x1: x, y1: y }; visual.areas.push(a);
      const mv = (ev) => { const cl = (v) => Math.max(0, Math.min(1, v)); const x2 = cl((ev.clientX - r.left) / W), y2 = cl((ev.clientY - r.top) / H);
        a.x0 = Math.min(x, x2); a.x1 = Math.max(x, x2); a.y0 = Math.min(y, y2); a.y1 = Math.max(y, y2); draw(); };
      const up = () => { removeEventListener("pointermove", mv); removeEventListener("pointerup", up);
        if (a.x1 - a.x0 < 0.01 || a.y1 - a.y0 < 0.005) visual.areas.splice(visual.areas.indexOf(a), 1); draw(); };
      addEventListener("pointermove", mv); addEventListener("pointerup", up);
    };
    draw();
  }
  await show();
}

// paint over what should disappear from a photo
async function brushUI(box) {
  box.innerHTML = "";
  const f = files[0]; if (!f) return;
  const img = new Image(); img.crossOrigin = "anonymous";
  await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = local.get(f.id) || `/api/file/${f.id}`; });
  const maxW = Math.min(720, (box.clientWidth || 720) - 10), k = Math.min(1, maxW / img.naturalWidth, 560 / img.naturalHeight);
  const W = Math.round(img.naturalWidth * k), H = Math.round(img.naturalHeight * k);
  const base = h("img", { src: img.src, style: `width:${W}px;height:${H}px;display:block` });
  const cv = h("canvas", { width: W, height: H, class: "brush" }); const ctx = cv.getContext("2d");
  let size = Math.max(14, Math.round(W / 22)), strokes = [];
  visual.mask = () => {
    if (!strokes.length) return null;
    const s = Math.min(1, 1024 / Math.max(img.naturalWidth, img.naturalHeight));
    const m = h("canvas", { width: Math.round(img.naturalWidth * s), height: Math.round(img.naturalHeight * s) }); const x = m.getContext("2d");
    x.lineCap = x.lineJoin = "round"; x.strokeStyle = x.fillStyle = "#ff2020";
    for (const st of strokes) { x.lineWidth = st.size / k * s; x.beginPath(); st.pts.forEach(([a, b], i) => i ? x.lineTo(a / k * s, b / k * s) : x.moveTo(a / k * s, b / k * s)); if (st.pts.length === 1) x.lineTo(st.pts[0][0] / k * s + 0.1, st.pts[0][1] / k * s); x.stroke(); }
    return m.toDataURL("image/png");
  };
  const repaint = () => { ctx.clearRect(0, 0, W, H); ctx.lineCap = ctx.lineJoin = "round"; ctx.strokeStyle = "rgba(255,40,40,.55)";
    for (const st of strokes) { ctx.lineWidth = st.size; ctx.beginPath(); st.pts.forEach(([a, b], i) => i ? ctx.lineTo(a, b) : ctx.moveTo(a, b)); if (st.pts.length === 1) ctx.lineTo(st.pts[0][0] + 0.1, st.pts[0][1]); ctx.stroke(); } };
  cv.onpointerdown = (e) => {
    e.preventDefault(); cv.setPointerCapture(e.pointerId);
    const r = cv.getBoundingClientRect(); const st = { size, pts: [[e.clientX - r.left, e.clientY - r.top]] }; strokes.push(st); repaint();
    cv.onpointermove = (ev) => { st.pts.push([ev.clientX - r.left, ev.clientY - r.top]); repaint(); };
    cv.onpointerup = () => { cv.onpointermove = null; };
  };
  box.append(h("p", { class: "muted center" }, tr("Paint over the object, person, text or watermark you want to remove.")),
    h("div", { class: "row", style: "justify-content:center;margin-bottom:8px" }, h("span", { class: "muted" }, tr("Brush size")),
      h("input", { type: "range", min: 6, max: Math.max(60, Math.round(W / 5)), value: size, oninput: (e) => size = +e.target.value }),
      h("button", { class: "btn sm", onclick: () => { strokes.pop(); repaint(); } }, "↶ " + tr("Undo")), h("button", { class: "btn sm", onclick: () => { strokes = []; repaint(); } }, tr("Clear"))),
    h("div", { class: "center" }, h("div", { class: "cropwrap", style: `width:${W}px;height:${H}px` }, base, cv)));
}

function bookmarksUI(box) {
  const toc = (files[0] && files[0].toc || []).map(([l, x, p]) => ({ l, t: x, p }));
  visual.toc = toc;
  const list = h("div");
  const paint = () => {
    list.innerHTML = "";
    toc.forEach((b, i) => list.append(h("div", { class: "row bm", style: `margin-left:${(b.l - 1) * 22}px` },
      h("input", { type: "text", value: b.t, oninput: (e) => b.t = e.target.value }),
      h("span", { class: "muted" }, tr("page")), h("input", { type: "number", value: b.p, min: 1, style: "width:70px", oninput: (e) => b.p = +e.target.value }),
      h("button", { class: "btn sm", title: tr("Higher level"), onclick: () => { b.l = Math.max(1, b.l - 1); paint(); } }, "⇤"),
      h("button", { class: "btn sm", title: tr("Sub-entry"), onclick: () => { b.l = Math.min((toc[i - 1] || { l: 0 }).l + 1, b.l + 1); paint(); } }, "⇥"),
      h("button", { class: "btn sm", title: tr("Move up"), onclick: () => { if (i) { [toc[i - 1], toc[i]] = [toc[i], toc[i - 1]]; paint(); } } }, "↑"),
      h("button", { class: "btn sm", title: tr("Move down"), onclick: () => { if (i < toc.length - 1) { [toc[i + 1], toc[i]] = [toc[i], toc[i + 1]]; paint(); } } }, "↓"),
      h("button", { class: "btn sm", title: tr("Delete"), onclick: () => { toc.splice(i, 1); paint(); } }, "✕"))));
  };
  box.innerHTML = "";
  box.append(h("p", { class: "muted" }, toc.length ? tr("Bookmarks of this PDF:") : tr("This PDF has no bookmarks yet.")), list,
    h("button", { class: "btn sm", onclick: () => { toc.push({ l: 1, t: tr("New bookmark"), p: 1 }); paint(); } }, "+ " + tr("Add bookmark")));
  paint();
}

function workflowUI(box) {
  const choices = Object.entries(T).filter(([, x]) => x.tool && !x.noUpload && !x.isAlias && !x.ui && !x.min && (!x.accept || x.accept.includes(".pdf")) && !x.pro);
  let saved = []; try { saved = JSON.parse(localStorage.getItem("pk_workflow") || "[]").filter((s) => choices.some(([k]) => k === s.slug)); } catch {}
  visual.steps = saved.length ? saved : [{ slug: "ocr" }, { slug: "compress" }];
  const list = h("div");
  const save = () => { try { localStorage.setItem("pk_workflow", JSON.stringify(visual.steps)); } catch {} };
  const paint = () => {
    list.innerHTML = "";
    visual.steps.forEach((s, i) => list.append(h("div", { class: "file" }, h("b", {}, i + 1 + "."),
      h("select", { onchange: (e) => { s.slug = e.target.value; save(); } }, choices.map(([k, x]) => h("option", { value: k, selected: k === s.slug ? "" : null }, t(`tool.${k}`, x.title)))),
      h("span", { class: "nm muted" }, tr("standard settings")),
      h("button", { class: "x", onclick: () => { visual.steps.splice(i, 1); save(); paint(); } }, "×"))));
  };
  box.innerHTML = "";
  box.append(h("p", { class: "muted" }, tr("The result of each step goes into the next one.")), list,
    h("button", { class: "btn sm", onclick: () => { visual.steps.push({ slug: "compress" }); save(); paint(); } }, "+ " + tr("Add step")));
  paint();
}

// GST invoice form
function invoiceUI(box) {
  let s = {}; try { s = JSON.parse(localStorage.getItem("pk_invoice") || "{}"); } catch {}
  const today = new Date().toLocaleDateString("en-GB").replace(/\//g, "-");
  const d = visual.inv = { seller_name: "", seller_address: "", seller_gstin: "", bank: "", notes: "", color: "#1a3c8f", currency: "₹", tax_mode: "gst", ...s,
    buyer_name: "", buyer_address: "", buyer_gstin: "", place: "", number: "", date: today, due: "", shipping: "", round_off: true,
    items: [{ desc: "", hsn: "", qty: 1, rate: "", gst: 18, discount: "" }] };
  const f = (k, label, ph = "", type = "text") => h("div", { class: "opt" }, h("label", { class: "t" }, label),
    type === "area" ? h("textarea", { placeholder: ph, oninput: (e) => { d[k] = e.target.value; } }, d[k] || "")
      : h("input", { type, value: d[k] ?? "", placeholder: ph, oninput: (e) => { d[k] = e.target.value; totals(); } }));
  const rows = h("tbody"), tot = h("div", { class: "invtot" });
  const num = (v) => parseFloat(String(v ?? "").replace(/[^0-9.\-]/g, "")) || 0;
  const inr = (v) => v.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  function totals() {
    let sub = 0, tax = 0;
    for (const it of d.items) { if (!String(it.desc).trim()) continue; const a = (num(it.qty) || 1) * num(it.rate) * (1 - num(it.discount) / 100); sub += a; tax += d.tax_mode === "none" ? 0 : a * num(it.gst) / 100; }
    const total = sub + tax + num(d.shipping);
    tot.innerHTML = `<span>${tr("Subtotal")}: <b>${inr(sub)}</b></span><span>${d.tax_mode === "igst" ? "IGST" : d.tax_mode === "none" ? tr("Tax") : "CGST + SGST"}: <b>${inr(tax)}</b></span><span class="grand">${tr("Total")}: <b>${esc(d.currency)} ${inr(d.round_off ? Math.round(total) : total)}</b></span>`;
  }
  function paint() {
    rows.innerHTML = "";
    d.items.forEach((it, i) => {
      const cell = (k, w, type = "text", ph = "") => h("td", {}, h("input", { type, value: it[k] ?? "", placeholder: ph, style: `width:${w}`, step: "any", oninput: (e) => { it[k] = e.target.value; totals(); } }));
      rows.append(h("tr", {}, cell("desc", "100%", "text", tr("Item or service")), cell("hsn", "70px", "text", "HSN"), cell("qty", "60px", "number"), cell("rate", "90px", "number"),
        cell("gst", "60px", "number"), cell("discount", "60px", "number"), h("td", {}, h("button", { class: "x", title: tr("Remove"), onclick: () => { d.items.splice(i, 1); if (!d.items.length) d.items.push({ desc: "", qty: 1, gst: 18 }); paint(); } }, "×"))));
    });
    totals();
  }
  const seg = (k, items) => { const el = h("div", { class: "seg" }); const draw = () => { el.innerHTML = ""; items.forEach(([v, l]) => el.append(h("button", { class: d[k] === v ? "on" : "", onclick: () => { d[k] = v; draw(); totals(); } }, l))); }; draw(); return el; };
  box.innerHTML = "";
  box.append(h("div", { class: "inv" },
    h("div", { class: "invcol" }, h("h3", {}, tr("Your business")), f("seller_name", tr("Name"), tr("Your company name")), f("seller_address", tr("Address"), "", "area"), f("seller_gstin", tr("GSTIN"), "27ABCDE1234F1Z5"),
      h("div", { class: "opt" }, h("label", { class: "t" }, tr("Logo (optional)")), h("input", { type: "file", accept: "image/*", onchange: async (e) => { const x = e.target.files[0]; if (!x) return; try { const [m] = await upload([x]); d.logo_file = m.id; } catch (err) { showErr(err.message); } } }))),
    h("div", { class: "invcol" }, h("h3", {}, tr("Bill to")), f("buyer_name", tr("Customer name")), f("buyer_address", tr("Address"), "", "area"), f("buyer_gstin", tr("GSTIN (if any)")), f("place", tr("Place of supply"), "Maharashtra (27)")),
    h("div", { class: "invcol" }, h("h3", {}, tr("Invoice")), f("number", tr("Invoice number"), "INV/2026/001"), f("date", tr("Date")), f("due", tr("Due date (optional)")),
      h("div", { class: "opt" }, h("label", { class: "t" }, tr("Tax")), seg("tax_mode", [["gst", tr("CGST + SGST (same state)")], ["igst", tr("IGST (other state)")], ["none", tr("No tax")]])))),
    h("div", { class: "tablewrap" }, h("table", { class: "items" }, h("thead", {}, h("tr", {}, ...[tr("Description"), "HSN/SAC", tr("Qty"), tr("Rate"), "GST %", tr("Disc. %"), ""].map((x) => h("th", {}, x)))), rows)),
    h("div", { class: "row", style: "justify-content:space-between" }, h("button", { class: "btn sm", onclick: () => { d.items.push({ desc: "", hsn: "", qty: 1, rate: "", gst: d.items.at(-1)?.gst ?? 18, discount: "" }); paint(); } }, "+ " + tr("Add item")), tot),
    h("div", { class: "inv" }, h("div", { class: "invcol" }, f("shipping", tr("Shipping / other charges"), "", "number"), h("label", { class: "chk" }, h("input", { type: "checkbox", checked: "", onchange: (e) => { d.round_off = e.target.checked; totals(); } }), tr("Round off the total"))),
      h("div", { class: "invcol" }, f("bank", tr("Bank details"), "Bank, account number, IFSC, UPI ID", "area")), h("div", { class: "invcol" }, f("notes", tr("Notes / terms"), "Thank you for your business!", "area"))));
  paint();
}

// ---------------------------------------------------------------- live preview from the server
const pv = { page: 0, busy: false, again: false };
const refreshPreview = debounce(async () => {
  const box = $("#preview");
  if (!cfg.preview || !files[0] || files[0].kind !== "pdf" || (cfg.min && files.length < cfg.min)) { box.classList.add("hidden"); return; }
  if (cfg.tool === "crop" && state.mode === "box" && !visual.box) return;
  if (pv.busy) { pv.again = true; return; }
  pv.busy = true; box.classList.remove("hidden");
  if (!box.firstChild) box.append(h("div", { class: "row", style: "justify-content:center" },
      h("b", {}, tr("Preview")), h("button", { class: "btn sm", onclick: () => { if (pv.page) { pv.page--; refreshPreview(); } } }, "‹"), h("span", { class: "muted", id: "pvn" }),
      h("button", { class: "btn sm", onclick: () => { if (pv.page < (files[0].pages || 1) - 1) { pv.page++; refreshPreview(); } } }, "›")), h("img", { id: "pvimg", alt: "" }));
  $("#pvn").textContent = `${tr("Page")} ${pv.page + 1} / ${files[0].pages || 1}`; $("#pvimg").style.opacity = .45;
  try {
    let options; try { options = buildOptions(true); } catch { options = { ...state }; }
    const r = await fetch("/api/preview", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ tool: cfg.tool, files: files.map((f) => f.id), options, page: pv.page }) });
    if (r.ok) { const u = URL.createObjectURL(await r.blob()); const old = $("#pvimg").src; $("#pvimg").src = u; if (old.startsWith("blob:")) URL.revokeObjectURL(old); }
  } catch {}
  $("#pvimg").style.opacity = 1; pv.busy = false;
  if (pv.again) { pv.again = false; refreshPreview(); }
}, 450);

// ---------------------------------------------------------------- run
function defaults(c) { const o = {}; for (const x of c.options || []) if (x.v !== undefined) o[x.k] = structuredClone(x.v); return Object.assign(o, c.preset || {}); }

function buildOptions(forPreview) {
  const o = { ...state };
  for (const x of cfg.options || []) if (x.type === "range" && x.pct && o[x.k] != null) o[x.k] = o[x.k] / 100;
  if (cfg.ui === "thumbs") {
    const P = visual.pages || [];
    if (cfg.thumbMode === "delete") { const sel = P.filter((p) => p.del).map((p) => p.page + 1).join(","); o.pages = [sel, o.pages].filter(Boolean).join(","); if (!o.pages) throw new Error(tr("Tap the pages you want to delete (or type them).")); }
    if (cfg.thumbMode === "select") { const sel = P.filter((p) => p.sel).map((p) => p.page + 1).join(","); o.pages = [sel, o.pages].filter(Boolean).join(",") || "all"; }
    if (cfg.thumbMode === "rotate") { o.per_page = {}; P.forEach((p) => p.rotate && (o.per_page[p.page] = p.rotate)); if (!Object.keys(o.per_page).length && !forPreview) throw new Error(tr("Rotate at least one page.")); }
  }
  if (cfg.ui === "organize") { o.order = (visual.pages || []).map((p) => p.blank ? { blank: true } : { file: files.findIndex((f) => f.id === p.fid), page: p.page, rotate: p.rotate }); if (!o.order.some((x) => !x.blank)) throw new Error(tr("No pages left.")); }
  if (cfg.tool === "merge") { o.ranges = {}; files.forEach((f, i) => { const r = (visual.ranges || {})[f.id]; if (r) o.ranges[i] = r; }); }
  if (cfg.ui === "crop" && o.mode === "box") o.box = visual.box;
  if (cfg.ui === "areas") o.areas = visual.areas || [];
  if (cfg.ui === "brush") { o.mask = visual.mask && visual.mask(); if (!o.mask) throw new Error(tr("Paint over the object, person, text or watermark you want to remove.")); }
  if (cfg.ui === "bookmarks") o.toc = (visual.toc || []).map((b) => [b.l, b.t, b.p]);
  if (cfg.ui === "invoice") { Object.assign(o, visual.inv, { tax_mode: visual.inv.tax_mode === "gst" ? "" : visual.inv.tax_mode });
    const { seller_name, seller_address, seller_gstin, bank, notes, color, currency, tax_mode } = visual.inv;
    try { localStorage.setItem("pk_invoice", JSON.stringify({ seller_name, seller_address, seller_gstin, bank, notes, color, currency, tax_mode })); } catch {} }
  if (cfg.tool === "alternate_mix" && o.reverse_second) o.reverse = ["1"];
  if (cfg.tool === "compress" && !o.dpi) delete o.dpi;
  if (cfg.tool === "nup") o.n = +o.n;
  if (cfg.tool === "img_crop" && o.ratio === "auto") { delete o.ratio; o.mode = "auto"; }
  if (cfg.tool === "img_rotate") o.angle = +o.angle;
  return o;
}

$("#go").onclick = async () => {
  showErr("");
  if (!cfg.noUpload && cfg.ui !== "workflow" && !files.length) return showErr(tr("Please upload a file first."));
  if (cfg.ui === "workflow" && !files.length) return showErr(tr("Please upload a file first."));
  if (cfg.min && files.length < cfg.min) return showErr(tr("Please add at least") + ` ${cfg.min} ` + tr("files") + ".");
  const go = $("#go"); go.disabled = true;
  await visualReady;
  let options; try { options = buildOptions(); } catch (e) { go.disabled = false; return showErr(e.message); }
  $("#runbar").classList.remove("hidden"); go.textContent = tr("Working…");
  const slow = setTimeout(() => go.textContent = tr("Still working – large files and scans take a little longer…"), 9000);
  try {
    let res;
    if (cfg.ui === "workflow") {
      let fid = files[0].id;
      for (const [i, s] of visual.steps.entries()) {
        go.textContent = `${tr("Step")} ${i + 1}/${visual.steps.length}: ${t(`tool.${s.slug}`, T[s.slug].title)}…`;
        res = await api("/api/task", { tool: T[s.slug].tool, files: [fid], options: defaults(T[s.slug]) });
        if (!res.name.endsWith(".pdf") && i < visual.steps.length - 1) throw new Error(tr("This step did not produce a PDF, so the next step cannot continue:") + " " + res.name);
        fid = res.file_id;
      }
    } else res = await api("/api/task", { tool: cfg.tool, files: files.map((f) => f.id), options });
    showResult(res);
  } catch (e) { if (!e.quota) showErr(e.message); }
  clearTimeout(slow); go.disabled = false; go.textContent = btnText; $("#runbar").classList.add("hidden");
};

function showErr(msg, where = $("#err")) { where.querySelector(".err")?.remove(); if (msg) where.append(h("div", { class: "err", role: "alert" }, msg)); }

// ---------------------------------------------------------------- result
const isPic = (n) => /\.(png|jpe?g|webp|gif|bmp|avif)$/i.test(n);
function preview(r) {
  const url = r.download + "?inline=1";
  if (isPic(r.name)) {
    const img = h("img", { src: url, alt: r.name });
    const orig = files.length === 1 && local.get(files[0].id);
    const wrap = h("div", { class: "picprev" }, img);
    if (orig && cfg.tool !== "img_to_text") {
      const b = h("button", { class: "btn sm cmp" }, "👁 " + tr("Hold to see the original"));
      const on = (e) => { e.preventDefault(); img.src = orig; }, off = () => { img.src = url; };
      b.onpointerdown = on; b.onpointerup = b.onpointerleave = off;
      return h("div", {}, wrap, b);
    }
    return wrap;
  }
  if (/\.(md|txt|csv)$/i.test(r.name)) {
    const pre2 = h("pre", { class: "textprev" }, "…");
    fetch(url).then((x) => x.text()).then((x) => pre2.textContent = x.slice(0, 200000));
    return h("div", {}, pre2, h("button", { class: "btn sm", onclick: async () => { try { await navigator.clipboard.writeText(pre2.textContent); toast(tr("Copied")); } catch { toast(tr("Could not copy")); } } }, "⧉ " + tr("Copy text")));
  }
  if (/\.pdf$/i.test(r.name)) {
    const c = h("canvas"); const wrap = h("div", { class: "pdfprev" }, c);
    loadPdf(r.file_id).then((pdf) => renderPage(pdf, 1, c, 240).then(() => wrap.append(h("div", { class: "muted", style: "font-size:12px" }, `${pdf.numPages} ${tr("pages")}`)))).catch(() => wrap.remove());
    return wrap;
  }
  return null;
}

function showResult(r) {
  $("#work").classList.add("hidden"); drop.classList.add("hidden"); $("#preview").classList.add("hidden");
  const box = $("#result"); box.innerHTML = ""; box.classList.remove("hidden");
  const pdf = /\.pdf$/i.test(r.name), pic = isPic(r.name);
  const saved = r.input_size && /compress/.test(cfg.tool || "") && r.size ? Math.round((1 - r.size / r.input_size) * 100) : null;
  const next = pdf ? ["pdf-editor", "compress", "merge", "split", "organize", "protect", "pdf-to-word", "pdf-to-jpg", "watermark", "page-numbers", "ocr"]
    : pic ? ["compress-image", "resize-image", "crop-image", "convert-image", "remove-background", "remove-object", "jpg-to-pdf"] : [];
  const share = async () => {
    try { const blob = await (await fetch(r.download)).blob(); const file = new File([blob], r.name, { type: blob.type });
      if (navigator.canShare?.({ files: [file] })) await navigator.share({ files: [file], title: r.name }); else toast(tr("Sharing is not supported by this browser – use Download.")); } catch {}
  };
  box.append(...[h("div", { class: "okmark" }, "✓"), h("h2", {}, tr("Your file is ready")),
    h("p", { class: "stat" }, `${r.name} · ${fmtSize(r.size)}` + (saved != null ? ` · ${saved > 0 ? saved + "% " + tr("smaller") : tr("already as small as it gets")} (${tr("was")} ${fmtSize(r.input_size)})` : "")),
    preview(r),
    h("div", { class: "row", style: "justify-content:center;margin-top:14px" },
      h("a", { class: "btn primary big", href: r.download, download: r.name }, "⬇ " + t("ui.download", "Download")),
      pdf ? h("a", { class: "btn", href: r.download + "?inline=1", target: "_blank", rel: "noopener" }, tr("Open / Print")) : null,
      navigator.share ? h("button", { class: "btn", onclick: share }, "↗ " + tr("Share")) : null),
    cfg.ui === "brush" ? h("div", { class: "next" }, h("button", { class: "btn", onclick: async () => { const m = await api(`/api/file/${r.file_id}/meta`, null, "GET"); local.set(m.id, r.download + "?inline=1"); files = [m]; showWork(true); } }, "🩹 " + tr("Erase more in this picture"))) : null,
    next.length ? h("p", { class: "muted", style: "margin-top:22px" }, tr("Continue with this file:")) : null,
    next.length ? h("div", { class: "next" }, next.filter((s) => s !== slug && T[s]).map((s) => h("a", { class: "btn sm", href: href(`/tool/${s}`) + `?file=${r.file_id}` }, t(`tool.${s}`, T[s].title)))) : null,
    h("div", { class: "next" },
      h("button", { class: "btn sm", onclick: () => location.href = location.pathname }, "↺ " + tr("Start over")),
      h("button", { class: "btn sm", onclick: async (e) => { await fetch(`/api/task/${r.task}`, { method: "DELETE" }); e.target.replaceWith(h("span", { class: "muted" }, "✓ " + tr("Deleted from the server."))); $$("#result a.btn").forEach((a) => a.remove()); } }, "🗑 " + tr("Delete files now")))].filter(Boolean));
  box.scrollIntoView({ behavior: "smooth", block: "start" });
}

// ---------------------------------------------------------------- how-to (also read by search engines)
$("#howto").append(h("h2", {}, `${t("ui.howto", "How to use")} ${title}`),
  h("ol", {}, h("li", {}, cfg.noUpload ? tr("Fill in the details above.") : tr("Upload your file – or drop it on the page, paste it, or take a photo.")), h("li", {}, tr("Choose the settings you need.")),
    h("li", {}, h("span", {}, tr("Press")), " ", h("b", {}, btnText), " ", h("span", {}, tr("and download the result.")))),
  h("p", { class: "muted" }, "🔒 " + t("footer.privacy", "Files are processed over an encrypted connection and deleted automatically after 2 hours.")));
const rel = Object.entries(T).filter(([k, x]) => x.cat === cfg.cat && k !== slug && !x.isAlias).slice(0, 10);
if (rel.length) $("#howto").append(h("h3", {}, tr("Related tools")), h("div", { class: "next", style: "justify-content:flex-start" }, rel.map(([k, x]) => h("a", { class: "btn sm", href: href(`/tool/${k}`) }, t(`tool.${k}`, x.title)))));

// ---------------------------------------------------------------- start
if (cfg.noUpload) { drop.classList.add("hidden"); showWork(); }
const pre = new URLSearchParams(location.search).get("file");                 // "continue with this file" from another tool
if (pre && !cfg.noUpload) api(`/api/file/${pre}/meta`, null, "GET").then((m) => { files = [m]; showWork(true); }).catch(() => {});

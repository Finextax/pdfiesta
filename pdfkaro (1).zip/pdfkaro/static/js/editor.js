// PDF editor – start screen, pages, toolbar, menus, page operations, download, signature requests and the signing page.
// Pages are pictures rendered by the server (the same engine that writes the result), so what you see is what you get.
import { $, $$, h, chrome, api, upload, toast, t, tr, href, fmtSize, me, debounce } from "/static/js/common.js";
import { ready, path } from "/static/js/i18n.js";
import { S, hooks, pageEl, commit, pushHist, canUndo, canRedo, travel, model, fields, opsOf, busy, idle, modelKey, clamp, moveObj } from "/static/js/editor-core.js";
import { initTextBar, closeEditor, editing, aiRewrite } from "/static/js/editor-text.js";
import { setTool, modeClass, drawObjects, drawExisting, bindPage, initObjects, initSignature, select, selected, deleteSelected, savedSignatures, forgetSignature, useSignature, dialog } from "/static/js/editor-objects.js";

await ready;
chrome({ slim: true });
const q = new URLSearchParams(location.search), parts = path.split("/").filter(Boolean);
if (parts[0] === "sign") S.signer = parts[1];
S.mode = S.signer ? "sign" : (window.TOOLS[q.get("mode")]?.editor ? q.get("mode") : "pdf-editor");
const cfg = window.TOOLS[S.mode] || window.TOOLS["pdf-editor"];
if (!S.signer) { $("#etitle").textContent = t(`tool.${S.mode}`, cfg.title); $("#edesc").textContent = t(`desc.${S.mode}`, cfg.desc); document.title = t(`tool.${S.mode}`, cfg.title) + " – " + document.title.split("–").pop().trim(); }
$("#pick").textContent = t("ui.uploadPdf", "Upload PDF file");
let dirty = false;

// ------------------------------------------------------------------ start: upload, blank page, file from another tool, signing link
const startErr = (msg) => { $("#uperr").textContent = ""; if (msg) $("#uperr").append(h("div", { class: "err" }, msg)); };
async function addFile(file) {
  if (!file) return;
  const bar = $("#upbar"); bar.classList.remove("hidden"); startErr("");
  try {
    const [m] = await upload([file], (p) => bar.firstChild.style.width = (p * 100).toFixed(0) + "%");
    if (m.kind !== "pdf") throw new Error(tr("The editor opens PDF files. Convert your file to PDF first (Convert to PDF)."));
    await openFile(m);
  } catch (e) { if (!e.quota) startErr(e.message); }
  bar.classList.add("hidden"); bar.firstChild.style.width = 0;
}
function askPassword(m) {
  return new Promise((res, rej) => {
    const inp = h("input", { type: "password", style: "width:100%", autocomplete: "off" }), err = h("div");
    dialog(tr("This PDF is password protected"), h("div", {}, h("p", { class: "muted" }, m.name), inp, err), [[tr("Continue"), async () => {
      try { Object.assign(m, await api(`/api/file/${m.id}/unlock`, { password: inp.value })); res(); } catch (e) { err.textContent = ""; err.append(h("div", { class: "err" }, e.message)); return false; }
    }, "primary"], [tr("Cancel"), () => rej(new Error(tr("The password is needed to open this PDF.")))]]);
  });
}
let inited = false;
async function openFile(m) {
  if (m.encrypted) await askPassword(m);
  busy(tr("Opening…"));
  try {
    const r = await api(`/api/editor/${m.id}/prepare`, {});
    Object.assign(S, { fid: m.id, meta: r.meta, version: r.version, oldest: r.version, sizes: r.pages, pv: r.pages.map(() => r.version), fonts: r.fonts, ai: r.ai, ocrLangs: r.ocr_languages,
      objects: [], form: {}, hist: [], hi: -1, cur: null, fields: null });
    S.models.clear();
    $("#start").classList.add("hidden"); $("#editor").classList.remove("hidden"); document.body.classList.add("on");
    if (!inited) { inited = true; initTextBar(); initObjects(); initSignature(); initBars(); }
    fitZoom(); build(); pushHist(); dirty = false;
    setTool(S.mode === "create-forms" ? "field:text" : "select");
    if (!S.signer) history.replaceState(null, "", `${location.pathname}?mode=${S.mode}&file=${m.id}`);
    if (r.meta.scanned && !S.signer) toast(tr("This is a scanned document: its text is recognised when you open a page – then just click and type."), 6000);
  } finally { busy(null); }
}
$("#pick").onclick = () => $("#fi").click();
$("#fi").onchange = (e) => { addFile(e.target.files[0]); e.target.value = ""; };
$("#blank").onclick = async (e) => { e.preventDefault(); try { await openFile(await api("/api/blank", {})); } catch (err) { startErr(err.message); } };
["dragenter", "dragover"].forEach((ev) => document.addEventListener(ev, (e) => { if (!S.fid && e.dataTransfer?.types?.includes("Files")) { e.preventDefault(); $("#drop").classList.add("over"); } }));
["dragleave", "drop"].forEach((ev) => document.addEventListener(ev, () => $("#drop").classList.remove("over")));
document.addEventListener("drop", (e) => { if (!S.fid && e.dataTransfer?.files?.length) { e.preventDefault(); addFile(e.dataTransfer.files[0]); } });

if (S.signer) startSigning();
else {
  const pre = q.get("file");
  if (pre) api(`/api/file/${pre}/meta`, null, "GET").then(openFile).catch((e) => startErr(e.status === 404 ? tr("This file is no longer on the server (files are deleted after 2 hours). Please upload it again.") : e.message));
  $("#ehow").append(h("h2", {}, tr("What you can do")), h("ul", {},
    ...[tr("Change existing text: click it and type. The paragraph is re-typeset in the same font; text below moves up or down."),
      tr("Scanned pages work too: the text is recognised (Hindi, English and 28 more languages) and replaced cleanly."),
      tr("Add text, pictures, shapes, highlights, notes, links and form fields. Erase anything with the eraser."),
      tr("Sign: draw, type or photograph your signature – or send a link so that someone else signs."),
      tr("Rotate, delete and add pages. Undo any step.")].map((x) => h("li", {}, x))));
}

// ------------------------------------------------------------------ pages
const io = new IntersectionObserver((ents) => { for (const e of ents) if (e.isIntersecting && !e.target._shown) { e.target._shown = true; showPage(+e.target.dataset.p); } }, { rootMargin: "700px 0px" });
function build() {
  const box = $("#pages"), keep = topPage();
  box.textContent = ""; io.disconnect();
  S.sizes.forEach((_s, p) => {
    const ov = h("div", { class: "ov" });
    const act = (label, title, fn) => h("button", { title: tr(title), onclick: fn }, label);
    const pg = h("div", { class: "pg", "data-p": p }, h("img", { class: "pimg", alt: "", draggable: "false" }), ov,
      h("div", { class: "pbar" }, h("span", {}, `${p + 1} / ${S.sizes.length}`), S.signer ? null : h("span", { class: "acts" },
        act("↺", "Rotate left", () => pageOp("rotate", p, 270)), act("↻", "Rotate right", () => pageOp("rotate", p, 90)),
        act("＋", "Add a blank page after this one", () => pageOp("insert", p + 1)), act("🗑", "Delete this page", () => pageOp("delete", p)))));
    box.append(pg); bindPage(ov, p); modeClass(pg); io.observe(pg);
  });
  layout();
  if (keep > 0) pageEl(Math.min(keep, S.sizes.length - 1))?.scrollIntoView({ block: "start" });
}
function layout() {
  $$(".pg").forEach((pg) => {
    const [w, hh] = S.sizes[+pg.dataset.p], ov = pg.querySelector(".ov");
    pg.style.width = w * S.zoom + "px"; pg.style.height = hh * S.zoom + "px";
    ov.style.width = w + "px"; ov.style.height = hh + "px"; ov.style.transform = `scale(${S.zoom})`;
  });
  $("#zlabel").textContent = Math.round(S.zoom * 100) + "%";
}
function topPage() {
  let best = 0, bestV = -1;
  $$(".pg").forEach((pg) => { const r = pg.getBoundingClientRect(), v = Math.min(r.bottom, innerHeight) - Math.max(r.top, 0); if (v > bestV) { bestV = v; best = +pg.dataset.p; } });
  return best;
}
const renderScale = () => { const want = S.zoom * Math.min(2, window.devicePixelRatio || 1); return [1, 1.5, 2, 3, 4].find((s) => s >= want - 0.05) || 4; };
function loadImage(p) {
  const pg = pageEl(p); if (!pg) return Promise.resolve();
  const img = pg.querySelector(".pimg"), url = `/api/editor/${S.fid}/render/${p}?v=${S.pv[p]}&s=${renderScale()}`;
  if (img.dataset.url === url) return Promise.resolve();
  img.dataset.url = url;
  return new Promise((res) => {
    const pre = new Image();
    pre.onload = () => { if (img.dataset.url !== url) return res(); img.src = url; (img.decode ? img.decode() : Promise.resolve()).then(res, res); };
    pre.onerror = () => { if (img.dataset.url === url) delete img.dataset.url; res(); };
    pre.src = url;
  });
}
async function loadModel(p) {
  const pg = pageEl(p); if (!pg) return;
  const key = modelKey(p) + ":" + S.version; pg._key = key;
  let wait = null;
  const tm = setTimeout(() => { wait = h("div", { class: "wait clear" }, h("b", {}, tr("Reading the text of this page…"))); pg.append(wait); }, 600);
  try {
    const [m, fl] = await Promise.all([S.signer ? { blocks: [], images: [], links: [], annots: [] } : model(p), fields()]);
    if (pg._key === key && pageEl(p) === pg) { drawExisting(p, m, fl); drawObjects(p); if (m.scanned || m.hybrid) $("#ocrlang").classList.remove("hidden"); }
  } catch (e) { if (pg._key === key) toast(tr("The text of this page could not be read:") + " " + e.message, 5000); }
  clearTimeout(tm); wait?.remove();
}
function showPage(p) { loadImage(p); loadModel(p); drawObjects(p); }
hooks.pageChanged = async (p) => { const pg = pageEl(p); if (!pg || !pg._shown) return; await loadImage(p); loadModel(p); };
hooks.rebuild = () => { build(); };
hooks.redraw = () => {
  $$(".pg").forEach((pg) => {
    if (!pg._shown) return;
    const p = +pg.dataset.p; drawObjects(p);
    if (S.models.has(modelKey(p)) || S.signer) loadModel(p);
  });
};
hooks.toolbar = () => { $("#undo").disabled = !canUndo(); $("#redo").disabled = !canRedo(); dirty = S.hi > 0; };

// ------------------------------------------------------------------ zoom
function fitZoom() {
  const maxW = Math.max(...S.sizes.map((s) => s[0])), room = Math.max(280, document.documentElement.clientWidth - (innerWidth < 700 ? 10 : 40));
  S.zoom = clamp(Math.floor(room / maxW * 100) / 100, 0.3, 1.5);
}
const sharper = debounce(() => $$(".pg").forEach((pg) => pg._shown && loadImage(+pg.dataset.p)), 350);
function setZoom(z) {
  const keep = topPage();
  S.zoom = clamp(Math.round(z * 100) / 100, 0.25, 4); layout();
  pageEl(keep)?.scrollIntoView({ block: "start" });
  $$(".pg").forEach((pg) => pg._shown && drawObjects(+pg.dataset.p)); sharper();
}

// ------------------------------------------------------------------ menus
const menu = $("#menu");
const closeMenu = () => menu.classList.add("hidden");
function openMenu(btn, items) {
  menu.textContent = "";
  for (const it of items) {
    if (!it) continue;
    if (it === "hr") menu.append(h("hr")); else if (it.nodeType) menu.append(it);
    else menu.append(h("button", { onclick: () => { closeMenu(); it[1](); } }, it[0]));
  }
  menu.classList.remove("hidden");
  const r = btn.getBoundingClientRect(), w = menu.offsetWidth, hh = menu.offsetHeight;
  menu.style.left = clamp(r.left, 6, Math.max(6, innerWidth - w - 6)) + "px";
  menu.style.top = (r.bottom + 4 + hh > innerHeight ? Math.max(6, r.top - hh - 4) : r.bottom + 4) + "px";
}
document.addEventListener("pointerdown", (e) => { if (!e.target.closest("#menu, [data-menu]")) closeMenu(); }, true);
function signItems(target = null) {
  const saved = savedSignatures();
  return [
    ...saved.map((d) => h("div", { class: "sig" }, h("img", { src: d, alt: tr("Saved signature"), onclick: () => { closeMenu(); useSignature(d, target); } }),
      h("button", { title: tr("Remove"), onclick: (e) => { forgetSignature(d); e.target.closest(".sig").remove(); } }, "×"))),
    ["＋ " + tr("New signature"), () => hooks.newSignature(target)],
    target ? null : "hr", target ? null : ["📅 " + tr("Today's date"), () => setTool("date")], target ? null : ["✓ " + tr("Tick"), () => setTool("check")],
    !target && !S.signer ? "hr" : null, !target && !S.signer ? ["✉ " + tr("Ask someone else to sign…"), requestSignature] : null,
  ];
}
hooks.chooseSignature = (target) => { const saved = savedSignatures(); if (!saved.length) return hooks.newSignature(target); const el = document.querySelector(".xfield.sigbox:hover") || $("#toolbar [data-menu=sign]"); openMenu(el, signItems(target)); };
const MENUS = {
  sign: () => signItems(),
  annot: () => [["🖍 " + tr("Highlight"), () => setTool("highlight")], ["▁ " + tr("Underline"), () => setTool("underline")], ["─ " + tr("Strike out"), () => setTool("strike")],
    ["✏ " + tr("Draw"), () => setTool("ink")], ["🗨 " + tr("Note"), () => setTool("note")]],
  shape: () => [["▭ " + tr("Rectangle"), () => setTool("rect")], ["◯ " + tr("Ellipse"), () => setTool("ellipse")], ["╱ " + tr("Line"), () => setTool("line")], ["↗ " + tr("Arrow"), () => setTool("arrow")]],
  form: () => [["▭ " + tr("Text field"), () => setTool("field:text")], ["▤ " + tr("Text field with several lines"), () => setTool("field:multiline")], ["☑ " + tr("Checkbox"), () => setTool("field:checkbox")],
    ["◉ " + tr("Radio button"), () => setTool("field:radio")], ["▾ " + tr("Dropdown list"), () => setTool("field:dropdown")], ["✍ " + tr("Signature box"), () => setTool("field:signature")],
    "hr", ["✓ " + tr("Tick"), () => setTool("check")], ["✗ " + tr("Cross"), () => setTool("cross")], h("small", {}, tr("Fields that are already in the PDF can be filled in directly on the page."))],
  page: () => { const p = topPage(); return [h("small", {}, `${tr("Page")} ${p + 1}`), ["↻ " + tr("Rotate right"), () => pageOp("rotate", p, 90)], ["↺ " + tr("Rotate left"), () => pageOp("rotate", p, 270)],
    ["＋ " + tr("Add a blank page after this one"), () => pageOp("insert", p + 1)], ["＋ " + tr("Add a blank page before this one"), () => pageOp("insert", p)], ["🗑 " + tr("Delete this page"), () => pageOp("delete", p)],
    "hr", ["▦ " + tr("Reorder or merge pages…"), () => leaveTo("organize")]]; },
  ai: () => [[tr("Rewrite professionally"), () => aiRewrite("rewrite")], [tr("Fix spelling and grammar"), () => aiRewrite("fix")], [tr("Make shorter"), () => aiRewrite("shorter")], [tr("Make longer"), () => aiRewrite("longer")], "hr",
    ...[["Hindi", "हिन्दी"], ["English", "English"], ["Marathi", "मराठी"], ["Bengali", "বাংলা"], ["Tamil", "தமிழ்"], ["Telugu", "తెలుగు"], ["Gujarati", "ગુજરાતી"], ["Urdu", "اردو"], ["Spanish", "Español"], ["French", "Français"], ["Arabic", "العربية"]]
      .map(([l, n]) => [tr("Translate to") + " " + n, () => aiRewrite("translate", l)])],
};

// ------------------------------------------------------------------ page operations (rotate / delete / add) – each is one undo step
async function pageOp(kind, p, arg) {
  await closeEditor(true); select(null);
  if (kind === "delete" && S.sizes.length < 2) return toast(tr("A document needs at least one page."));
  const before = S.objects;
  let ops;
  if (kind === "rotate") {                              // what was added to this page is made part of it first, so that it turns with the page
    ops = [...opsOf(S.objects.filter((o) => o.page === p), false), { type: "rotate_page", page: p, angle: arg }];
    S.objects = S.objects.filter((o) => o.page !== p);
  } else if (kind === "delete") {
    ops = [{ type: "delete_page", page: p }];
    S.objects = S.objects.filter((o) => o.page !== p).map((o) => (o.page > p ? { ...o, page: o.page - 1 } : o));
  } else {
    ops = [{ type: "insert_blank", page: p }];
    S.objects = S.objects.map((o) => (o.page >= p ? { ...o, page: o.page + 1 } : o));
  }
  try { await commit(ops); build(); pushHist(); if (kind === "insert") pageEl(p)?.scrollIntoView({ block: "center" }); }
  catch (e) { S.objects = before; toast(e.message, 6000); hooks.redraw(); }
}

// ------------------------------------------------------------------ toolbar wiring
function initBars() {
  $("#toolbar").addEventListener("click", (e) => {
    const b = e.target.closest("button"); if (!b) return;
    if (b.dataset.tool) setTool(b.dataset.tool);
    else if (b.dataset.menu) { if (!menu.classList.contains("hidden") && menu._for === b) return closeMenu(); menu._for = b; openMenu(b, MENUS[b.dataset.menu]()); }
  });
  $("#aibtn").addEventListener("click", (e) => { menu._for = e.currentTarget; openMenu(e.currentTarget, MENUS.ai()); });
  $("#undo").onclick = () => undoRedo(-1); $("#redo").onclick = () => undoRedo(1);
  $("#zin").onclick = () => setZoom(S.zoom * 1.2); $("#zout").onclick = () => setZoom(S.zoom / 1.2); $("#zfit").onclick = () => { fitZoom(); setZoom(S.zoom); };
  $("#apply").onclick = download; $("#reqsign").onclick = requestSignature;
  $("#findbtn").onclick = () => { $("#findmodal").classList.add("on"); $("#findcount").textContent = ""; $("#findq").focus(); };
  $("#findok").onclick = findReplace;
  $$("[data-close]").forEach((b) => b.onclick = () => b.closest(".modal").classList.remove("on"));
  $$(".modal").forEach((m) => m.addEventListener("pointerdown", (e) => { if (e.target === m && m.id !== "dlg") m.classList.remove("on"); }));
  // a click on the grey area around the pages finishes what is being edited (composedPath: the clicked element may have been redrawn meanwhile)
  $("#pages").addEventListener("pointerdown", (e) => { if (!e.composedPath().some((n) => n.classList?.contains("ov"))) { closeEditor(true); if (S.cur) select(null); } });
  const names = Object.fromEntries(window.LANGS || []), sel = $("#ocrlang");
  sel.append(h("option", { value: "eng+hin" }, names["eng+hin"] || "English + हिन्दी"), ...S.ocrLangs.map((l) => h("option", { value: l }, names[l] || l)));
  sel.onchange = async () => { await closeEditor(true); S.lang = sel.value; $$(".pg").forEach((pg) => pg._shown && loadModel(+pg.dataset.p)); };
  // which buttons make sense in this mode
  const hide = (s) => $$(s).forEach((x) => x.classList.add("hidden"));
  if (S.mode !== "esign") hide("#reqsign");
  if (S.signer) { hide('#toolbar [data-tool="select"], #toolbar [data-tool="whiteout"], #toolbar [data-tool="link"], #toolbar [data-menu="annot"], #toolbar [data-menu="shape"], #toolbar [data-menu="form"], #toolbar [data-menu="page"], #findbtn, #imgbtn, #apply, #ocrlang'); $("#signbar").classList.remove("hidden"); }
  if (S.mode === "esign") $("#apply").classList.remove("primary"), $("#reqsign").classList.add("primary");
  document.addEventListener("keydown", (e) => {
    if (!S.fid || e.target.closest("input, textarea, select, [contenteditable=true]")) return;
    const mod = e.ctrlKey || e.metaKey, k = e.key.toLowerCase();
    if (mod && k === "z" && !e.shiftKey) { e.preventDefault(); undoRedo(-1); }
    else if (mod && (k === "y" || (k === "z" && e.shiftKey))) { e.preventDefault(); undoRedo(1); }
    else if (mod && k === "s") { e.preventDefault(); if (!S.signer) download(); }
    else if (mod && k === "f" && !S.signer) { e.preventDefault(); $("#findbtn").click(); }
    else if ((e.key === "Delete" || e.key === "Backspace") && selected()) { e.preventDefault(); deleteSelected(); }
    else if (e.key === "Escape") { closeMenu(); if (S.tool !== "select") setTool("select"); else select(null); }
    else if (e.key.startsWith("Arrow") && selected() && selected().type !== "ximg") {
      e.preventDefault(); const d = e.shiftKey ? 10 : 1, o = selected();
      moveObj(o, e.key === "ArrowLeft" ? -d : e.key === "ArrowRight" ? d : 0, e.key === "ArrowUp" ? -d : e.key === "ArrowDown" ? d : 0); drawObjects(o.page); nudged();
    }
  });
  addEventListener("beforeunload", (e) => { if (dirty) { e.preventDefault(); e.returnValue = ""; } });
  addEventListener("resize", debounce(() => { if (innerWidth < 700) { fitZoom(); setZoom(S.zoom); } }, 300));
}
const nudged = debounce(() => pushHist(), 500);
async function undoRedo(step) { await closeEditor(true); await idle(); travel(step); select(null); }
async function findReplace() {
  const find = $("#findq").value; if (!find) return;
  await closeEditor(true);
  $("#findok").disabled = true;
  try {
    const r = await commit([{ type: "find_replace", find, replace: $("#findr").value, case: $("#findcase").checked }], tr("Replacing…"));
    $("#findcount").textContent = r.replaced ? `${r.replaced} ${tr("replaced")}` : tr("Nothing found.");
    if (r.replaced) { pushHist(); for (const p of r.pages) hooks.pageChanged(p); hooks.redraw(); }
  } catch (e) { $("#findcount").textContent = e.message; }
  $("#findok").disabled = false;
}
function leaveTo(slug) { dirty = false; download(slug); }

// ------------------------------------------------------------------ download
async function download(next) {
  await closeEditor(true); await idle();
  busy(tr("Creating your PDF…"));
  try {
    const r = await api(`/api/editor/${S.fid}/apply`, { ops: opsOf(S.objects), version: S.version, lang: S.lang });
    dirty = false;
    if (typeof next === "string") { location.href = href(`/tool/${next}`) + `?file=${r.file_id}`; return; }
    const T = window.TOOLS, more = ["compress", "protect", "merge", "organize", "page-numbers", "watermark", "pdf-to-word", "pdf-to-jpg", "esign"].filter((s) => T[s] && s !== S.mode);
    const box = h("div", { class: "center" }, h("div", { class: "okmark" }, "✓"),
      h("p", { class: "muted" }, `${r.name} · ${fmtSize(r.size)}`),
      r.skipped ? h("div", { class: "err" }, `${r.skipped} ${tr("change(s) could not be applied to this PDF.")}`) : null,
      h("div", { class: "row", style: "justify-content:center" }, h("a", { class: "btn primary big", href: r.download, download: r.name }, "⬇ " + t("ui.download", "Download")),
        h("a", { class: "btn", href: r.download + "?inline=1", target: "_blank", rel: "noopener" }, tr("Open / Print"))),
      h("p", { class: "muted", style: "margin:16px 0 6px" }, tr("Continue with this file:")),
      h("div", { class: "next" }, more.map((s) => h("a", { class: "btn sm", href: T[s].editor ? href("/edit") + `?mode=${s}&file=${r.file_id}` : href(`/tool/${s}`) + `?file=${r.file_id}` }, t(`tool.${s}`, T[s].title)))));
    dialog(tr("Your document is ready"), box, [[tr("Keep editing")], [tr("Start a new document"), () => { location.href = location.pathname + `?mode=${S.mode}`; }]]);
  } catch (e) { if (!e.quota) toast(e.message, 6000); }
  busy(null);
}

// ------------------------------------------------------------------ ask someone else to sign (they get a link)
async function requestSignature() {
  await closeEditor(true); await idle();
  const who = await me();
  const title = h("input", { type: "text", style: "width:100%", value: (S.meta?.name || "Document").replace(/\.pdf$/i, "") });
  const msg = h("textarea", { style: "width:100%;min-height:70px", placeholder: tr("Message for the signer (optional)") });
  const to = h("input", { type: "email", style: "width:100%", placeholder: tr("E-mail of the signer (optional – we send the link)") });
  const mine = h("input", { type: "email", style: "width:100%", placeholder: tr("Your e-mail – to get the signed copy") , value: who?.user?.email || "" });
  const body = h("div", {}, h("p", { class: "muted", style: "margin-top:0" }, tr("We create a private link. The other person opens it, signs on their phone or computer, and both of you get the sealed PDF with a signature certificate page.")),
    h("label", { class: "t" }, tr("Document name")), title, h("div", { style: "height:8px" }), msg, h("div", { style: "height:8px" }), to, who?.user ? "" : h("div", { style: "height:8px" }), who?.user ? "" : mine);
  dialog(tr("Request a signature"), body, [[tr("Create signing link"), async () => {
    busy(tr("Preparing the document…"));
    try {
      const r = await api("/api/sign/create", { file_id: S.fid, version: S.version, ops: opsOf(S.objects), lang: S.lang, title: title.value, message: msg.value, signer_email: to.value, email: mine.value });
      dirty = false; setTimeout(() => shareLink(r.url, title.value, !!to.value), 50);
    } catch (e) { if (!e.quota) toast(e.message, 6000); busy(null); return false; }
    busy(null);
  }, "primary"], [tr("Cancel")]]);
}
function shareLink(url, title, mailed) {
  const inp = h("input", { type: "text", readonly: "", value: url, onfocus: (e) => e.target.select() });
  const text = encodeURIComponent(`${tr("Please sign this document:")} ${title}\n${url}`);
  const body = h("div", {}, h("p", { class: "muted", style: "margin-top:0" }, mailed ? tr("We e-mailed the link to the signer. You can also send it yourself:") : tr("Send this link to the person who should sign:")),
    h("div", { class: "sharebox" }, inp, h("button", { class: "btn", onclick: async () => { try { await navigator.clipboard.writeText(url); toast(tr("Copied")); } catch { inp.focus(); } } }, "⧉ " + tr("Copy"))),
    h("div", { class: "row" }, h("a", { class: "btn", href: `https://wa.me/?text=${text}`, target: "_blank", rel: "noopener" }, "WhatsApp"),
      h("a", { class: "btn", href: `mailto:?subject=${encodeURIComponent(tr("Please sign:") + " " + title)}&body=${text}` }, "✉ " + tr("E-mail")),
      navigator.share ? h("button", { class: "btn", onclick: () => navigator.share({ title, url }).catch(() => {}) }, "↗ " + tr("Share")) : null),
    h("p", { class: "muted", style: "font-size:13px" }, tr("The link works for 30 days. Open it yourself at any time to see whether the document was signed and to download it.")));
  dialog(tr("Signing link created"), body, [[tr("Done"), null, "primary"]]);
}

// ------------------------------------------------------------------ the signing page (/sign/<token>)
async function startSigning() {
  $("#drop").classList.add("hidden"); $("#edesc").textContent = "";
  let info;
  try { info = await api(`/api/sign/${S.signer}`, null, "GET"); }
  catch (e) { $("#etitle").textContent = tr("Signing link"); return startErr(e.message), $("#drop").classList.remove("hidden"), $("#drop").replaceChildren($("#uperr")); }
  $("#etitle").textContent = info.title;
  const signedView = (d) => {
    $("#editor").classList.add("hidden"); document.body.classList.remove("on"); $("#start").classList.remove("hidden");
    $("#edesc").textContent = "";
    $("#drop").classList.remove("hidden"); $("#drop").replaceChildren(h("div", { class: "okmark" }, "✓"), h("h2", {}, tr("This document is signed")),
      h("p", { class: "muted" }, d.signer ? `${tr("Signed by")} ${d.signer}${d.signed_at ? " · " + d.signed_at + " UTC" : ""}` : ""),
      h("a", { class: "btn primary big", href: d.download }, "⬇ " + tr("Download the signed PDF")),
      h("small", {}, tr("The PDF is sealed: any later change is detected by PDF readers. The last page is the signature certificate.")));
  };
  if (info.status === "signed") return signedView(info);
  try { await openFile(await api(`/api/file/${info.file_id}/meta`, null, "GET")); } catch (e) { return startErr(e.message); }
  if (info.message) toast(info.message, 9000);
  $("#sgdone").onclick = async () => {
    await closeEditor(true);
    const name = $("#sgname").value.trim();
    if (name.length < 2) { $("#sgname").focus(); return toast(tr("Please type your full name.")); }
    if (!$("#sgok").checked) return toast(tr("Please tick the box to confirm that you agree to sign."));
    if (!S.objects.some((o) => o.type === "signature" || o.type === "ink") && !confirm(tr("You have not placed a signature on the document. Finish anyway?"))) return;
    busy(tr("Signing…")); $("#sgdone").disabled = true;
    try {
      const r = await api(`/api/sign/${S.signer}/complete`, { name, email: $("#sgmail").value.trim(), consent: true, ops: opsOf(S.objects), lang: S.lang });
      dirty = false; signedView({ download: r.download, signer: name });
    } catch (e) { toast(e.message, 7000); }
    busy(null); $("#sgdone").disabled = false;
  };
}

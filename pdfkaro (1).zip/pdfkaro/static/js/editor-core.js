// PDF editor – shared state, coordinates, undo history and the "commit" call that turns a change into a new working version.
// All positions are PDF points of the page (origin top-left); the page layer is scaled by the zoom factor with CSS.
import { $, api, tr } from "/static/js/common.js";

export const S = {
  fid: null, meta: null, mode: "pdf-editor", signer: null,    // signer = token when this page is a signing link
  version: 0, oldest: 0,                                         // working version on the server; oldest step undo can go back to
  sizes: [], pv: [],                                             // page sizes [[w, h] …]; pv[p] = version in which page p last changed (for caching)
  zoom: 1, tool: "select", sub: null, lang: "eng+hin",
  objects: [], form: {},                                         // things the user added (kept in the browser until download); form field values
  models: new Map(), fields: null, fieldsV: -1,                  // text blocks per page; form fields of the document
  fonts: [], ai: false, ocrLangs: [],
  hist: [], hi: -1, cur: null,                                   // undo history; id of the selected object
  style: { fam: "liberationsans", s: 12, c: "#000000", b: 0, i: 0 },   // style of new text
  shape: { stroke: "#e5322d", fill: "", width: 1.5, opacity: 1 },
  mark: { highlight: "#ffe600", underline: "#e5322d", strike: "#e5322d" }, ink: { color: "#1d4ed8", width: 2 },
};
export const hooks = {};      // filled by editor.js: pageChanged(p), rebuild(), redraw(), toolbar()
let seq = 0;
export const uid = () => "o" + (++seq) + Math.random().toString(36).slice(2, 7);
export const clone = (x) => JSON.parse(JSON.stringify(x));
export const pageEl = (p) => document.querySelector(`.pg[data-p="${p}"]`);
export const ovEl = (p) => pageEl(p)?.querySelector(".ov");
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const r2 = (v) => Math.round(v * 100) / 100;
export function ptOf(p, ev) {                                   // pointer position in PDF points of page p
  const r = ovEl(p).getBoundingClientRect();
  return { x: (ev.clientX - r.left) / S.zoom, y: (ev.clientY - r.top) / S.zoom };
}
export const pageSize = (p) => ({ w: S.sizes[p][0], h: S.sizes[p][1] });

// ------------------------------------------------------------------ geometry of the things a user adds
export function bounds(o) {
  if (o.rect) return [...o.rect];
  if (o.p1) return [Math.min(o.p1[0], o.p2[0]), Math.min(o.p1[1], o.p2[1]), Math.max(o.p1[0], o.p2[0]), Math.max(o.p1[1], o.p2[1])];
  if (o.rects) return [Math.min(...o.rects.map((r) => r[0])), Math.min(...o.rects.map((r) => r[1])), Math.max(...o.rects.map((r) => r[2])), Math.max(...o.rects.map((r) => r[3]))];
  if (o.paths) { const pts = o.paths.flat(); return [Math.min(...pts.map((q) => q[0])), Math.min(...pts.map((q) => q[1])), Math.max(...pts.map((q) => q[0])), Math.max(...pts.map((q) => q[1]))]; }
  return [o.x, o.y, o.x + (o.w > 20 ? o.w : o.mw || 14), o.y + (o.h || 14)];
}
export function moveObj(o, dx, dy) {
  if (o.rect) o.rect = [o.rect[0] + dx, o.rect[1] + dy, o.rect[2] + dx, o.rect[3] + dy];
  if (o.p1) { o.p1 = [o.p1[0] + dx, o.p1[1] + dy]; o.p2 = [o.p2[0] + dx, o.p2[1] + dy]; }
  if (o.rects) o.rects = o.rects.map((r) => [r[0] + dx, r[1] + dy, r[2] + dx, r[3] + dy]);
  if (o.paths) o.paths = o.paths.map((path) => path.map((q) => [q[0] + dx, q[1] + dy]));
  if (o.x != null) { o.x += dx; o.y += dy; }
}
function shiftObjects(p, x0, x1, y, d) {                        // text below an edit moved: what the user placed there moves with it
  for (const o of S.objects) {
    if (o.page !== p) continue;
    const b = bounds(o), cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
    if (cx >= x0 && cx <= x1 && cy >= y) moveObj(o, 0, d);
  }
}

// what the server needs to know about an added object
export function opsOf(objects, withForm = true) {
  const out = [];
  for (const o of objects) {
    const { id, h: _h, mw: _w, ...op } = o;
    if (o.type === "add_text") { if (!o.paras.some((p) => p.some((r) => r.t.trim()))) continue; }
    for (const k of ["rect", "p1", "p2"]) if (op[k]) op[k] = op[k].map(r2);
    out.push(op);
  }
  if (withForm && Object.keys(S.form).length) out.push({ type: "fill_forms", fields: S.form });
  return out;
}

// ------------------------------------------------------------------ undo history (snapshots of version + added objects)
const snap = () => ({ version: S.version, pv: [...S.pv], sizes: clone(S.sizes), objects: clone(S.objects), form: clone(S.form) });
export function pushHist() {
  S.hist = S.hist.slice(0, S.hi + 1); S.hist.push(snap());
  if (S.hist.length > 150) S.hist.shift();
  S.hi = S.hist.length - 1; hooks.toolbar?.();
}
const reachable = (sn) => sn && (sn.version === 0 || sn.version >= S.oldest);
export const canUndo = () => S.hi > 0 && reachable(S.hist[S.hi - 1]);
export const canRedo = () => S.hi < S.hist.length - 1 && reachable(S.hist[S.hi + 1]);
export function travel(step) {
  const sn = S.hist[S.hi + step];
  if (!reachable(sn)) return;
  S.hi += step;
  const structure = JSON.stringify(sn.sizes) !== JSON.stringify(S.sizes);
  const pv = sn.pv.map((v) => (v && v < S.oldest ? sn.version : v));
  const changed = structure ? [] : pv.map((v, p) => (v !== S.pv[p] ? p : -1)).filter((p) => p >= 0);
  const vchanged = sn.version !== S.version;
  S.version = sn.version; S.pv = pv; S.sizes = clone(sn.sizes); S.objects = clone(sn.objects); S.form = clone(sn.form); S.cur = null;
  if (vchanged) S.fields = null;
  if (structure) hooks.rebuild?.(); else { changed.forEach((p) => hooks.pageChanged?.(p)); hooks.redraw?.(); }
  hooks.toolbar?.();
}

// ------------------------------------------------------------------ server round trips
export function busy(text) { $("#busy").classList.toggle("hidden", !text); if (text) $("#busytext").textContent = text; }
let chain = Promise.resolve();
/** Apply changes to the document itself (text edits, moved pictures, page operations): the server writes a new working version. */
export function commit(ops, label) {
  const run = async () => {
    busy(label || tr("Saving…"));
    try {
      const r = await api(`/api/editor/${S.fid}/commit`, { ops, base: S.version, lang: S.lang });
      S.version = r.version; S.oldest = r.oldest || 0; S.fields = null;
      if (r.structure) { S.sizes = r.sizes; S.pv = r.sizes.map(() => r.version); S.models.clear(); }
      else {
        for (const p of r.pages) S.pv[p] = r.version;
        S.pv = S.pv.map((v) => (v && v < S.oldest ? r.version : v));
      }
      for (const [p, list] of Object.entries(r.shifts || {})) for (const [x0, x1, y, d] of list) shiftObjects(+p, x0, x1, y, d);
      return r;
    } finally { busy(null); }
  };
  const pr = chain.then(run, run);
  chain = pr.catch(() => {});
  return pr;
}
export const idle = () => chain;
export const modelKey = (p) => `${S.pv[p]}:${p}:${S.lang}`;
export async function model(p) {                                 // text blocks, pictures, links of one page (scans are read with OCR on the server)
  const key = modelKey(p);
  if (!S.models.has(key)) S.models.set(key, api(`/api/editor/${S.fid}/page/${p}?v=${S.pv[p]}&lang=${encodeURIComponent(S.lang)}`, null, "GET").catch((e) => { S.models.delete(key); throw e; }));
  return S.models.get(key);
}
export async function fields() {
  if (!S.fields || S.fieldsV !== S.version) { S.fieldsV = S.version; S.fields = api(`/api/editor/${S.fid}/fields?v=${S.version}`, null, "GET").catch(() => []); }
  return S.fields;
}

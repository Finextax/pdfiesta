# PDFKaro – PDF editor, PDF tools and image tools in one website

A complete, self-hosted website: a PDF editor that changes existing text (also in scans and in Hindi), 107 PDF and image
tools on 124 pages, e-signatures, accounts, a free plan with daily limits, and paid Pro passes through Razorpay and Stripe.
Everything runs on your own server with open-source engines – the only outside services are the ones you switch on
(payments, e-mail, AI).

The site name, prices and limits are settings (`.env`), not code.

## What is inside

| Area | Tools |
|---|---|
| **PDF editor** | Click any text and type – the paragraph is typeset again in the same font and the text below moves up or down. Works on **scanned pages** (text is recognised, the old ink is removed from the paper, new text is set in a matching font) and in **Hindi and other Indian scripts** (results stay searchable and copyable). Add text, pictures, shapes, highlights, notes, links, form fields; move, resize, replace or delete pictures that are already in the PDF; fill forms; find & replace; rotate / delete / add pages; undo and redo for every step. |
| **Sign** | Draw, type or photograph a signature · **Request signatures**: send a link, the other person signs on phone or computer, both get a sealed PDF with a signature-certificate page · **Digital signature** with your own certificate (.pfx / DSC) · verify signatures |
| **Merge / split / pages** | Merge, alternate & mix, organise (also across several PDFs), overlay / letterhead, split by pages / bookmarks / size / text / in half, extract and delete pages, rotate, crop, resize, page numbers, header & footer, Bates numbers, N-up, booklet, poster, flip, grayscale, invert |
| **Scans** | OCR (Hindi, English and 28 more languages), scan to PDF from the phone camera, enhance scan, deskew, remove blank pages, scan → editable PDF |
| **Security** | Protect (AES-256, permissions), unlock, watermark, **redact** (really removes text; finds Aadhaar, PAN, phone, e-mail, card, IFSC, GSTIN), remove hidden data, flatten |
| **Convert** | PDF → Word, Excel / CSV (bank statements), PowerPoint, JPG / PNG / one long image, text, Markdown, HTML, EPUB, SVG, PDF/A · Word, Excel, PowerPoint, pictures, web pages, text / Markdown, EPUB, PostScript, ZIP → PDF |
| **Create** | GST invoice generator, QR codes (link, UPI payment, Wi-Fi), barcodes |
| **Images** | Remove background, remove objects, compress (also "not bigger than 50 KB"), resize, crop, convert (HEIC, WEBP, AVIF …), upscale 2× / 4×, watermark, blur faces, passport photo, exam-form photo & signature (SSC, UPSC, IBPS …), ID card to A4, profile picture, signature maker, collage, split, round, border, GIF, image → SVG, favicon set, EXIF viewer / remover, colour palette, DPI, meme, image → text, website screenshot |
| **AI** (needs an AI key) | Summarise, chat with PDF, translate a PDF keeping its layout, question generator, data extraction to Excel, rewrite / translate inside the editor |
| **Business** | Accounts (e-mail + password, optional Google login), password reset, free daily limits, Pro passes (7 days / month / year), Razorpay + Stripe, payment history, Stripe subscriptions with cancel link, admin page `/admin`, privacy / terms / refund / contact pages |
| **Languages** | English and Hindi are complete. 16 more languages (Bengali, Marathi, Telugu, Tamil, Gujarati, Urdu, Spanish, Portuguese, French, German, Russian, Turkish, Arabic, Indonesian, Chinese, Japanese) have the main texts and 48 tool names; the rest of their texts stay English until you run the one-command translation below. |

## Start

```bash
cp .env.example .env          # set SITE_URL; everything else is optional
docker compose up -d --build  # first build downloads about 3 GB (LibreOffice, OCR languages, fonts, Chromium, AI models)
# open http://localhost:8000   ·   server check: /healthz   ·   owner page: /admin (log in with an ADMIN_EMAILS address)
```

Put a reverse proxy with HTTPS in front (Caddy, nginx or Cloudflare). Behind Cloudflare set `BEHIND_CLOUDFLARE=1`,
behind your own proxy `TRUST_PROXY=1` – otherwise all visitors look like one visitor to the free-plan counter.

Without Docker (Ubuntu 24.04): install the apt packages listed in the `Dockerfile`, then
`pip install -r requirements.txt && playwright install --with-deps chromium && python scripts/get_models.py` and
`uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2`.

## Keys you may need

| Service | For | Where | Cost |
|---|---|---|---|
| **Razorpay** | Payments in India: UPI, cards, net-banking, wallets | dashboard.razorpay.com → API keys; webhook `…/api/pay/razorpay/webhook` (`payment.captured`, `order.paid`) | no monthly fee, about 2 % per payment |
| **Stripe** | International cards; optional automatic renewal | dashboard.stripe.com → API keys; webhook `…/api/pay/stripe/webhook` (`checkout.session.completed`, `invoice.paid`, `customer.subscription.deleted`) | no monthly fee, about 2.9 % + 30 ¢ |
| **SMTP e-mail** (Brevo, Resend, SES, Zoho …) | Password reset, signing links, "document signed" | any provider | free tiers are enough to start |
| **AI** – Anthropic API key, or any OpenAI-compatible server | The AI tools | console.anthropic.com | pay per use – a few paise to a few rupees per document |
| Google OAuth client id | "Sign in with Google" | console.cloud.google.com | free |

Nothing else costs money: PDF, OCR, image and AI-model engines all run on your server.

**Server:** 4 GB RAM runs it (2 workers); 8 GB / 4 cores is comfortable for a few thousand visitors a day
(for example Hetzner CPX31, about €17 a month). Idle AI models are unloaded from memory after 15 minutes.

## Licences

The site may be used commercially. One condition matters:

| Component | Licence | Note |
|---|---|---|
| **MuPDF / PyMuPDF / pymupdf4llm, Ghostscript** | **AGPL-3.0** | The website's source code must be offered to its users: publish this code (with your changes) and set `SOURCE_URL` – the footer links to it. The alternative is a commercial licence from Artifex. |
| This project | AGPL-3.0 (`LICENSE`) | |
| pikepdf / qpdf, OCRmyPDF, LibreOffice | MPL-2.0 / Apache-2.0 | |
| Tesseract and its language data, OpenCV, onnxruntime, Playwright / Chromium, PDF.js | Apache-2.0 / MIT / BSD | |
| pdf2docx, openpyxl, python-pptx, rembg, pyHanko, FastAPI, fontTools, vtracer, python-barcode, signature_pad | MIT | |
| segno, Markdown, Pillow, pillow-heif, numpy, uvicorn, httpx, cryptography | BSD / HPND / Apache-2.0 | HEIC photos are decoded with libheif / libde265 (LGPL). HEVC is patented in some countries – ask a lawyer before selling HEIC conversion at scale in the US or EU. |
| AI models: IS-Net (background), LaMa (object removal), EDSR / FSRCNN (upscale), YuNet (faces) | Apache-2.0 / MIT | |
| Fonts: Liberation, Noto, DejaVu, Carlito, Caladea, Roboto, Open Sans, Lato, Montserrat, Inter, EB Garamond, PT, Comic Neue, Dancing Script, Great Vibes, Caveat, Sacramento | OFL-1.1 / Apache-2.0 / Bitstream Vera | may be embedded in PDFs |

The privacy, terms and refund pages (`static/legal.html`) describe how this software really treats files and data.
They are a careful starting point, not legal advice – have them checked for your company and country.

## Translations

```bash
python scripts/build_i18n.py               # rebuild static/i18n/*.json after changing texts
python scripts/build_i18n.py --missing hi  # list texts that have no Hindi translation
python scripts/build_i18n.py --ai          # translate every missing text of all 34 languages with the AI key from .env
```

A language appears in the menu once it has the main texts and 40 tool names. Search engines are pointed only to languages
that are at least 60 % translated (`static/i18n.coverage.json`), so half-translated pages are not indexed.
Hand-made translations live in `scripts/i18n_source.py` and `scripts/i18n_hi.py`.

## Tests

```bash
pip install -r requirements-dev.txt
python tests/make_corpus.py /tmp/pdfkaro_corpus                      # sample PDFs, scans, photos
CORPUS=/tmp/pdfkaro_corpus python tests/run_all.py                    # 76 tests of every tool, the editor engine, accounts, payments, security
# with the site running:
CORPUS=/tmp/pdfkaro_corpus python tests/ui_pages.py  http://localhost:8000   # every page on desktop + phone
CORPUS=/tmp/pdfkaro_corpus python tests/ui_tools.py  http://localhost:8000   # every tool used through the browser
CORPUS=/tmp/pdfkaro_corpus python tests/ui_editor.py http://localhost:8000   # the editor, signing link included
```

Payments are tested against stand-ins for Razorpay and Stripe (signatures, amounts, double delivery, forged webhooks);
the AI tools against a local stand-in. Before you go live, make one real payment with each provider's test keys and try
one AI tool with your key.

## Known limits

- Text that runs sideways (a page you turned by 90°) is shown but cannot be edited; turn the page upright first.
- Signatures made with the built-in certificate are valid and tamper-evident, but PDF readers show "unknown signer"
  until you use a certificate from a certifying authority (`SIGN_CERT_P12`).
- Whether an electronic signature is enough for a given document depends on the law that applies to it.
- Right-to-left scripts (Arabic, Urdu, Hebrew) can be added and edited, but copy / search of the new text depends on the PDF reader.
- AI tools, payments and e-mail only work after you add their keys.

## Code map

```
app/main.py        web server: uploads, tools, editor API, e-sign, pages, security headers
app/editor.py      editor engine: page analysis, typesetting, scan inpainting, apply operations
app/tools*.py      PDF tools            app/images*.py   image tools
app/accounts.py    users, sessions, limits        app/payments.py   Razorpay, Stripe        app/plans.py   prices, limits
app/fonts.py       font registry and script detection
static/js/tools-config.js   every tool page (title, options) – add a tool here + a function in app/
static/js/tool.js           the tool pages          static/js/editor*.js   the editor
scripts/           translations, model download     tests/   test-suite
```

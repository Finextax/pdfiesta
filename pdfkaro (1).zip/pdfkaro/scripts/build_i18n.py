"""Build static/i18n/*.json and static/js/langs.js.

    python scripts/build_i18n.py                 build everything from scripts/i18n_source.py
    python scripts/build_i18n.py --missing hi    list the texts that have no Hindi translation yet
    python scripts/build_i18n.py --ai            fill every missing text of every language with the AI API
                                                 (needs ANTHROPIC_API_KEY or OPENAI_BASE_URL; results are kept in static/i18n/*.json)

Keys:  tool.<slug> / desc.<slug> / btn.<slug> / cat.<name>  come from static/js/tools-config.js
       named UI keys (nav.*, hero.*, …)                      come from UI_EN in i18n_source.py
       s.<English text>                                      every other text of the site (option labels, messages, buttons)
A language appears in the language menu when it has the core UI and at least 40 tool names.
Search engines are pointed only to languages with at least 60 % of all texts (static/i18n.coverage.json)."""
import html, json, re, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "scripts"))
import i18n_source as SRC

JS = r"""
global.window = {}; require(process.argv[1]);
const T = window.TOOLS, o = {}, s = new Set();
for (const [k, v] of Object.entries(T)) {
  o['tool.' + k] = v.title; o['desc.' + k] = v.desc; if (v.btn) o['btn.' + k] = v.btn; if (v.note) s.add(v.note);
  for (const op of v.options || []) {
    if (op.t) s.add(op.t);
    for (const it of op.items || []) if (Array.isArray(it)) { if (it[1]) s.add(it[1]); if (it[2]) s.add(it[2]); }
  }
}
for (const c of window.CATS) o['cat.' + c] = c;
console.log(JSON.stringify({ keys: o, strings: [...s] }));
"""
cfg = json.loads(subprocess.check_output(["node", "-e", JS, str(ROOT / "static/js/tools-config.js")]))
tools = cfg["keys"]


def site_strings():
    """Every English text the pages pass to tr("…") or mark with data-tr, plus the option labels of the tools."""
    found = dict.fromkeys(cfg["strings"])
    files = list((ROOT / "static/js").glob("*.js")) + list((ROOT / "static").glob("*.html"))
    for f in files:
        src = f.read_text("utf-8")
        for m in re.finditer(r'\btr\(\s*"((?:[^"\\]|\\.)+)"', src):
            found.setdefault(json.loads('"' + m.group(1) + '"'))
        for m in re.finditer(r"\btr\(\s*'((?:[^'\\]|\\.)+)'", src):
            found.setdefault(m.group(1).replace("\\'", "'"))
        for m in re.finditer(r"<[a-z0-9]+[^>]*\bdata-tr\b[^>]*>([^<]+)<", src):
            found.setdefault(html.unescape(m.group(1).strip()))
        for m in re.finditer(r'data-i18n-ph="s\.([^"]+)"', src):
            found.setdefault(m.group(1))
    # messages the server sends when something goes wrong (plain sentences only – those with file names or numbers stay English)
    for f in (ROOT / "app").glob("*.py"):
        for m in re.finditer(r'(?:HTTPException\(\s*\d+,\s*|raise (?:ValueError|RuntimeError)\(\s*)"((?:[^"\\]|\\.)+)"\s*\)', f.read_text("utf-8")):
            msg = m.group(1)
            if "{" not in msg and " " in msg:
                found.setdefault(msg.encode().decode("unicode_escape").encode("latin-1").decode("utf-8") if "\\" in msg else msg)
    # texts with no letters (numbers, symbols) need no translation
    return [s for s in found if s and re.search(r"[A-Za-z]{2}", s)]


STRINGS = site_strings()
EN = {**tools, **SRC.UI_EN}
out = ROOT / "static/i18n"; out.mkdir(exist_ok=True)
(out / "en.json").write_text(json.dumps(EN, ensure_ascii=False, indent=1), encoding="utf-8")

ALL = ["hi", "bn", "mr", "te", "ta", "gu", "kn", "ml", "pa", "ur", "ne", "es", "pt", "fr", "de", "it", "nl", "pl", "ru", "uk", "tr", "ar", "fa", "he",
       "id", "ms", "vi", "th", "zh", "tw", "ja", "ko", "sw", "fil"]
NAMES = {"hi": "Hindi", "bn": "Bengali", "mr": "Marathi", "te": "Telugu", "ta": "Tamil", "gu": "Gujarati", "kn": "Kannada", "ml": "Malayalam", "pa": "Punjabi (Gurmukhi)",
         "ur": "Urdu", "ne": "Nepali", "es": "Spanish", "pt": "Portuguese (Brazil)", "fr": "French", "de": "German", "it": "Italian", "nl": "Dutch", "pl": "Polish",
         "ru": "Russian", "uk": "Ukrainian", "tr": "Turkish", "ar": "Arabic", "fa": "Persian", "he": "Hebrew", "id": "Indonesian", "ms": "Malay", "vi": "Vietnamese",
         "th": "Thai", "zh": "Simplified Chinese", "tw": "Traditional Chinese", "ja": "Japanese", "ko": "Korean", "sw": "Swahili", "fil": "Filipino"}


def source(lg):
    """Hand-made translations of one language from i18n_source.py."""
    d = {}
    d.update(getattr(SRC, "MORE", {}).get(lg, {}))
    for slug, v in getattr(SRC, "TOOLS_" + lg.upper(), {}).items():
        if isinstance(v, str):
            d[f"tool.{slug}"] = v
        else:
            d[f"tool.{slug}"] = v[0]
            if len(v) > 1 and v[1]:
                d[f"desc.{slug}"] = v[1]
    d.update(getattr(SRC, "UI_" + lg.upper(), {}))
    d.update({"s." + k: v for k, v in getattr(SRC, "S_" + lg.upper(), {}).items()})
    return d


langs = {}
for lg in ALL:
    prev = {}
    if "--fresh" not in sys.argv and (out / f"{lg}.json").exists():       # keep earlier AI translations
        try:
            prev = json.loads((out / f"{lg}.json").read_text("utf-8"))
        except Exception:
            prev = {}
    langs[lg] = {**{k: v for k, v in prev.items() if k in EN or (k.startswith("s.") and k[2:] in STRINGS)}, **source(lg)}

WANT = {**EN, **{"s." + s: s for s in STRINGS}}

if "--missing" in sys.argv:
    lg = sys.argv[sys.argv.index("--missing") + 1]
    miss = [k for k in WANT if k not in langs.get(lg, {})]
    for k in miss:
        print(json.dumps(k if not k.startswith("s.") else k[2:], ensure_ascii=False) + ("" if k.startswith("s.") else "   # " + WANT[k][:80]))
    print(f"# {lg}: {len(miss)} of {len(WANT)} texts missing", file=sys.stderr)
    sys.exit(0)

if "--ai" in sys.argv:
    from app.tools_plus import ai_complete
    for lg in ALL:
        cur = langs[lg]
        keys = [k for k in WANT if k not in cur]
        for i in range(0, len(keys), 50):
            chunk = {k: WANT[k] for k in keys[i:i + 50]}
            res = ai_complete(f"Translate the JSON values into {NAMES[lg]} for the user interface of a PDF and image tools website. Keep the keys unchanged. "
                              "Keep product and format names (PDF, Word, Excel, JPG, PNG, OCR, GST, UPI, Pro), placeholders like {n} or [TEXT1], symbols and emoji as they are. "
                              "Use short, natural wording a native speaker would expect on a button or label. Return ONLY the JSON object.\n" + json.dumps(chunk, ensure_ascii=False), 8000)
            try:
                got = json.loads(res[res.index("{"):res.rindex("}") + 1])
                cur.update({k: v for k, v in got.items() if k in chunk and isinstance(v, str) and v.strip()})
            except Exception as e:
                print("  skipped a block of", lg, e)
        print(lg, len(cur), "/", len(WANT))

CORE = ["nav.alltools", "nav.pricing", "nav.login", "hero.title", "hero.cta", "ui.uploadPdf", "ui.download"]
menu = ["en"]
coverage = {"en": 1.0}
for lg in ALL:
    d = langs[lg]
    for k in [k for k in EN if k.startswith("btn.")]:      # a button falls back to the translated tool name
        if k not in d and "tool." + k[4:] in d:
            d[k] = d["tool." + k[4:]]
    ok = all(k in d for k in CORE) and sum(1 for k in d if k.startswith("tool.")) >= 40
    if ok:
        menu.append(lg)
        coverage[lg] = round(len([k for k in WANT if k in d]) / len(WANT), 3)
        (out / f"{lg}.json").write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    elif (out / f"{lg}.json").exists():
        (out / f"{lg}.json").unlink()                    # no half-translated pages in the menu or the sitemap
    print(f"{lg:4} {len([k for k in WANT if k in d]):5} / {len(WANT)}  {'in menu' if ok else 'not shown (too few texts – run with --ai)'}")
(ROOT / "static/js/langs.js").write_text("// generated by scripts/build_i18n.py – languages that have translations\nexport const AVAILABLE = "
                                         + json.dumps(menu) + ";\n", encoding="utf-8")
# how complete each language is: search engines are only pointed to languages that are (nearly) fully translated – see app/main.py
(ROOT / "static/i18n.coverage.json").write_text(json.dumps(coverage, indent=1), encoding="utf-8")
print("en.json:", len(EN), "keys ·", len(STRINGS), "site texts · languages in the menu:", len(menu), "· fully translated:", [l for l, c in coverage.items() if c >= 0.6])

"""Download the AI model files (all free: Apache-2.0 / MIT) into ./models – run once after installing:

    python scripts/get_models.py

  EDSR / FSRCNN            picture upscaling 2× / 4×                (OpenCV super-resolution models)
  YuNet                    face detection (blur faces, passport photo)
  LaMa                     "remove objects" – fills the erased area  (without it a simpler method is used)
  IS-Net (rembg)           background removal                        (fetched on first use if missing)
"""
import os, sys, urllib.request
from pathlib import Path

ROOT = Path(os.environ.get("MODELS_DIR") or Path(__file__).resolve().parent.parent / "models")
SAAFKE = "https://raw.githubusercontent.com/Saafke/{repo}/master/models/{name}"
ZOO = "https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/{dir}/{name}"
FILES = {
    "FSRCNN_x2.pb": SAAFKE.format(repo="FSRCNN_Tensorflow", name="FSRCNN_x2.pb"), "FSRCNN_x4.pb": SAAFKE.format(repo="FSRCNN_Tensorflow", name="FSRCNN_x4.pb"),
    "EDSR_x2.pb": SAAFKE.format(repo="EDSR_Tensorflow", name="EDSR_x2.pb"), "EDSR_x4.pb": SAAFKE.format(repo="EDSR_Tensorflow", name="EDSR_x4.pb"),
    "face_detection_yunet_2023mar.onnx": ZOO.format(dir="face_detection_yunet", name="face_detection_yunet_2023mar.onnx"),
    "inpainting_lama_2025jan.onnx": ZOO.format(dir="inpainting_lama", name="inpainting_lama_2025jan.onnx"),
}
MIN_SIZE = {"EDSR_x2.pb": 30e6, "EDSR_x4.pb": 30e6, "inpainting_lama_2025jan.onnx": 80e6, "face_detection_yunet_2023mar.onnx": 2e5}

ROOT.mkdir(parents=True, exist_ok=True)
bad = 0
for name, url in FILES.items():
    dst = ROOT / name
    if dst.exists() and dst.stat().st_size >= MIN_SIZE.get(name, 1e4):
        print("have ", name); continue
    try:
        print("fetch", name, flush=True)
        tmp = dst.with_suffix(dst.suffix + ".part")
        urllib.request.urlretrieve(url, tmp)
        if tmp.stat().st_size < MIN_SIZE.get(name, 1e4):
            raise RuntimeError("file is too small – download incomplete")
        tmp.replace(dst)
    except Exception as e:
        bad += 1; print("  FAILED:", e)
try:      # background removal model (about 170 MB)
    os.environ.setdefault("U2NET_HOME", str(ROOT / "rembg"))
    from rembg import new_session
    new_session(os.environ.get("REMBG_MODEL", "isnet-general-use")); print("have  background removal model")
except Exception as e:
    bad += 1; print("  background removal model FAILED:", e)
sys.exit(1 if bad else 0)

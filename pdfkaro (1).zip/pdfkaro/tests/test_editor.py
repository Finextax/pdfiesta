"""PDF editor – through the same API the browser uses: read the page model, send change operations, check the saved PDF."""
from helpers import *
import base64, subprocess
import numpy as np


def prep(name):
    fid = up(name)[0]
    r = client.post(f"/api/editor/{fid}/prepare"); assert r.status_code == 200, r.text
    return fid, r.json()


def model(fid, pno=0, lang="eng"):
    r = client.get(f"/api/editor/{fid}/page/{pno}?lang={lang}"); assert r.status_code == 200, r.text
    return r.json()


def apply(fid, ops, lang="eng", expect=200):
    r = client.post(f"/api/editor/{fid}/apply", json={"ops": ops, "lang": lang})
    assert r.status_code == expect, r.text[:300]
    if expect != 200:
        return None, r.json()
    j = r.json()
    return DATA / j["task"] / j["name"], j


def block(m, needle):
    return next(b for b in m["blocks"] if needle in b["text"])


def edit(b, text=None, paras=None, page=0, **kw):
    """the operation the browser sends when a paragraph was changed"""
    run0 = b["paras"][0][0]
    op = {"type": "edit_block", "page": page, "bbox": b["bbox"], "paras": paras if paras is not None else [[dict(run0, t=t)] for t in text.split("\n")],
          "align": b["align"], "lh": b["lh"], "base": b["base"], "single": b["single"], "scanned": b["scanned"], "lines": b["lines"]}
    op.update(kw)
    return op


def ocr(p, page=0, lang="eng", clip=None):
    """what a human would read on the page (text recognition of the rendered picture)"""
    pix = pdf(p)[page].get_pixmap(dpi=200, clip=clip)
    r = subprocess.run(["tesseract", "stdin", "stdout", "-l", lang, "--psm", "6"], input=pix.tobytes("png"), capture_output=True)
    return " ".join(r.stdout.decode("utf-8", "ignore").split())


def y_of(p, needle, page=0):
    return pdf(p)[page].search_for(needle)[0].y0


PNG = lambda color=(200, 30, 30), size=(60, 40): "data:image/png;base64," + base64.b64encode((lambda b: (Image.new("RGB", size, color).save(b, "PNG"), b.getvalue())[1])(io.BytesIO())).decode()


# ------------------------------------------------------------------ reading
def test_prepare_and_model():
    fid, info = prep("chrome_report.pdf")
    keys = {f["key"] for f in info["fonts"]}
    assert {"liberationsans", "liberationserif", "notosansdevanagari"} <= keys and len(keys) >= 12 and "hin" in info["ocr_languages"] and "eng" in info["ocr_languages"]
    m = model(fid)
    assert not m["scanned"] and abs(m["width"] - 595.3) < 1
    b = block(m, "Prepared by")
    runs = [(r["t"], r["b"], r["i"]) for r in b["paras"][0]]
    assert ("Ravi Sharma", 1, 0) in runs and ("Himalaya Textile", 0, 1) in runs and any(r.get("u") for r in b["paras"][0] if "example.com" in r["t"]), runs
    assert block(m, "Quarterly Sales Report")["size"] > 20 and block(m, "Quarterly Sales Report")["fam"] == "liberationserif"
    two = block(m, "Revenue grew strongly")
    assert two["align"] == "justify" and len(two["lines"]) >= 5 and len(two["paras"]) == 1 and two["bbox"][2] < 320, "two-column paragraph was not kept as one justified block"
    cell = block(m, "Cotton shirt"); assert cell["cell"] and cell["single"] and cell["text"] == "Cotton shirt"
    assert block(m, "हिन्दी अनुभाग")["text"] == "हिन्दी अनुभाग" and "कृपया भुगतान समय पर करें" in block(m, "परीक्षण")["text"]
    assert any(l["uri"] == "https://example.com" or (l["uri"] or "").rstrip("/") == "https://example.com" for l in m["links"])
    assert [f for f in m["blocks"] if f["bbox"][1] > 780], "footer block missing"
    # a page stored sideways is opened upright and stays upright
    fid, info = prep("letter_rot90.pdf"); assert info["meta"]["rotated_pages"] == 1
    m = model(fid); b = block(m, "Dear customer"); assert m["width"] < m["height"] and b["bbox"][0] < 80 and len(b["lines"]) == 2
    assert client.get(f"/api/editor/{fid}/page/7").status_code == 404
    assert client.post("/api/editor/doesnotexist/prepare").status_code == 404


def test_fonts_endpoint():
    r = client.get("/api/font/liberationsans?b=1"); assert r.status_code == 200 and r.content[:4] in (b"\x00\x01\x00\x00", b"OTTO", b"true") and "max-age" in r.headers["cache-control"]
    assert client.get("/api/font/notosansdevanagari").status_code == 200
    assert client.get("/api/font/nosuchfont").status_code == 404 and client.get("/api/font/..%2F..%2Fetc%2Fpasswd").status_code == 404


# ------------------------------------------------------------------ editing digital text
def test_edit_with_reflow():
    fid, _ = prep("chrome_report.pdf"); m = model(fid)
    b = block(m, "Important: prices")
    paras = [b["paras"][0] + [dict(b["paras"][0][0], t=" This offer cannot be combined with other discounts and applies to orders above 50 pieces only. "
                                                         "Please confirm your order in writing before the end of the month.", b=0)]]
    src = C / "chrome_report.pdf"
    p, j = apply(fid, [edit(b, paras=paras)])
    d = pdf(p); t = text(p)
    assert "applies to orders above 50 pieces only" in t and t.count("Important: prices are") == 1 and j["skipped"] == 0
    dy = y_of(p, "Summary") - y_of(src, "Summary")
    assert 20 < dy < 80, f"content below did not move down ({dy})"
    for needle in ("Orders", "Cotton shirt", "89,955.00", "Revenue grew strongly", "wedding season"):       # everything below travels by the same amount
        assert abs((y_of(p, needle) - y_of(src, needle)) - dy) < 0.6, needle
    assert abs(y_of(p, "Confidential") - y_of(src, "Confidential")) < 0.5 and abs(y_of(p, "Quarterly") - y_of(src, "Quarterly")) < 0.5, "header / footer must not move"
    lines = lambda path: sorted(round(dr["rect"].y0, 1) for dr in pdf(path)[0].get_drawings() if dr["rect"].width > 100 and dr["rect"].height < 2)
    a, bb = lines(src), lines(p); assert len(a) == len(bb) >= 12 and all(abs((y2 - y1) - dy) < 0.8 for y1, y2 in zip(a, bb)), "table borders did not move with the table"
    spans = {s["text"].strip(): s for bl in d[0].get_text("dict")["blocks"] if bl["type"] == 0 for l in bl["lines"] for s in l["spans"]}
    assert spans["valid for 30 days"]["flags"] & 16 and spans["18% GST"]["color"] == 0xCC0000, "bold / colour of the untouched words was lost"
    link = next(l for l in d[0].get_links() if "example.com" in (l.get("uri") or ""))
    assert abs(link["from"].y0 - d[0].search_for("example.com")[0].y0) < 4, "link no longer sits on its words"
    assert p.stat().st_size < src.stat().st_size * 2.2, "file grew too much"
    im = render(p, dpi=50); assert mean(im, (0.09, 0.2, 0.91, 0.24)) < 252, "the yellow box did not grow with its text"


def test_edit_shrink_and_delete():
    src = C / "chrome_report.pdf"
    fid, _ = prep("chrome_report.pdf"); m = model(fid)
    b = block(m, "Revenue grew strongly")
    p, _ = apply(fid, [edit(b, "Revenue grew.")])
    t = text(p); assert "Revenue grew." in t and "double digit growth" not in t and "Costs remained under control" in t
    assert abs(y_of(p, "Costs remained") - y_of(src, "Costs remained")) < 0.5, "the other column must not move"
    # delete a whole paragraph: the rest of the page closes the gap
    b = block(m, "Important: prices")
    p, _ = apply(fid, [edit(b, paras=[], collapse=True)])
    assert "Important: prices" not in text(p) and y_of(src, "Summary") - y_of(p, "Summary") > 15 and abs(y_of(p, "Confidential") - y_of(src, "Confidential")) < 0.5
    # without reflow nothing else moves and the text is made to fit
    b = block(m, "Prepared by")
    p, _ = apply(fid, [edit(b, "Prepared by the sales team of Himalaya Textile for the board meeting on 12 November 2026 in Mumbai, with figures from all stores and the web shop.", reflow=False)])
    assert abs(y_of(p, "Summary") - y_of(src, "Summary")) < 0.5 and "figures from all stores" in text(p)
    r = pdf(p)[0].search_for("web shop")[0]; nxt = pdf(p)[0].search_for("Important: prices")[0]; assert r.y1 <= nxt.y0 + 1, "text runs into the next paragraph"


def test_table_cell_and_fonts():
    fid, _ = prep("chrome_report.pdf"); m = model(fid); src = C / "chrome_report.pdf"
    b = block(m, "Cotton shirt")
    p, _ = apply(fid, [edit(b, "Cotton shirt, long sleeve, premium quality")])
    d = pdf(p); r = d[0].search_for("Cotton shirt, long sleeve")[0]
    assert abs(r.y0 - b["bbox"][1]) < 4 and abs(y_of(p, "Denim jeans") - y_of(src, "Denim jeans")) < 0.5, "a table cell must stay on its row"
    border = min(dr["rect"].x0 for dr in d[0].get_drawings() if dr["rect"].width < 2 and dr["rect"].height > 10 and dr["rect"].x0 > 150 and dr["rect"].y0 < r.y0 < dr["rect"].y1)
    end = d[0].search_for("premium quality")[0]; assert end.x1 < border, "cell text runs over the cell border"
    size = [s["size"] for bl in d[0].get_text("dict")["blocks"] if bl["type"] == 0 for l in bl["lines"] for s in l["spans"] if "premium" in s["text"]][0]
    assert size < b["size"], "long cell text was not shrunk to fit"
    # the PDF's own embedded font is reused for the new words (same look, no substitute font)
    b = block(m, "Costs remained under control"); p, _ = apply(fid, [edit(b, b["text"].replace("four percent", "six percent"))])
    fonts = {s["font"] for bl in pdf(p)[0].get_text("dict")["blocks"] if bl["type"] == 0 for l in bl["lines"] for s in l["spans"] if "six percent" in s["text"]}
    assert fonts and all("Liberation" in f for f in fonts), fonts
    # a different family, size, colour, underline chosen in the toolbar
    b = block(m, "Summary")
    p, _ = apply(fid, [edit(b, paras=[[{"t": "Executive ", "b": 1, "i": 0, "c": "#0a7d32", "s": 20, "fam": "liberationserif"}, {"t": "summary", "b": 0, "i": 1, "u": 1, "c": "#0a7d32", "s": 20, "fam": "liberationserif"}]])])
    sp = [s for bl in pdf(p)[0].get_text("dict")["blocks"] if bl["type"] == 0 for l in bl["lines"] for s in l["spans"] if s["text"].strip() in ("Executive", "summary")]
    assert len(sp) == 2 and all("Serif" in s["font"] and s["color"] == 0x0A7D32 and abs(s["size"] - 20) < 0.5 for s in sp) and sp[0]["flags"] & 16 and sp[1]["flags"] & 2
    r = pdf(p)[0].search_for("summary")[0]
    assert any(abs(dr["rect"].y0 - r.y1) < 4 and dr["rect"].width > 30 and dr["rect"].x0 >= r.x0 - 2 for dr in pdf(p)[0].get_drawings()), "underline missing"


def test_word_document():
    fid, _ = prep("word_doc.pdf"); m = model(fid)
    b = block(m, "The Employee is appointed")
    p, _ = apply(fid, [edit(b, b["text"].replace("Senior Merchandiser", "Regional Sales Manager for the western region with responsibility for all key accounts"))])
    t = text(p); assert "Regional Sales Manager for the western region" in t and t.count("The Employee is appointed") == 1 and "Senior Merchandiser" not in t
    assert y_of(p, "2. Salary") > y_of(C / "word_doc.pdf", "2. Salary") + 5 and "45,000" in t and pdf(p).page_count == 2
    m1 = model(fid, 1); p, _ = apply(fid, [edit(block(m1, "shall not disclose"), "Confidential information stays confidential.", page=1)])
    assert "stays confidential" in pdf(p)[1].get_text() and "Employment Agreement" in pdf(p)[0].get_text()


# ------------------------------------------------------------------ scans
SCANS = ["scan_clean.pdf", "scan_textured.pdf", "scan_bilevel.pdf", "scan_sandwich.pdf", "scan_hybrid.pdf", "scan_rotated.pdf", "scan_strips.pdf"]


def test_edit_scanned_pages():
    for name in SCANS:
        fid, _ = prep(name); m = model(fid)
        assert m["scanned"] or m["hybrid"], name
        b = block(m, "Dear customer")
        assert b["scanned"] and "thank you for your enquiry" in b["text"] and len(b["lines"]) == 2, f"{name}: paragraph not recognised: {b['text']}"
        p, _ = apply(fid, [edit(b, "Dear Mr. Sharma, your order number 4471 is confirmed.")])
        seen = ocr(p)
        assert "Sharma, your order number 4471 is confirmed" in seen, f"{name}: new text is not on the page: {seen[:200]}"
        assert "enquiry" not in seen and "pleased to offer" not in seen, f"{name}: old text is still visible"
        assert "Delivery will be made within fourteen working days" in seen and "Regards, Sales Team" in seen and "Quotation" in seen, f"{name}: neighbouring text was damaged"
        t = text(p); assert t.count("order number 4471") == 1 and "enquiry" not in t, f"{name}: text layer wrong: {t[:200]}"
        a = y_of(p, "your order") if pdf(p)[0].search_for("your order") else None
        assert a is not None and abs(a - b["bbox"][1]) < 12, f"{name}: new text is not where the old paragraph was"


def test_scan_details():
    # textured paper stays textured (no white box where the old words were)
    fid, _ = prep("scan_textured.pdf"); m = model(fid); b = block(m, "Dear customer")
    p, _ = apply(fid, [edit(b, "Short.")])
    px = np.asarray(render(p, dpi=60, clip=pymupdf.Rect(b["bbox"][0] + 120, b["bbox"][1], b["bbox"][2], b["bbox"][3]))).astype(int)
    assert px[..., 0].mean() - px[..., 2].mean() > 12 and px.mean() < 238, "inpainting left a white patch on the beige paper"
    assert px.std(axis=(0, 1)).max() < 12, "remains of the old letters are visible"
    # a 1-bit scan stays 1-bit (file does not explode)
    fid, _ = prep("scan_bilevel.pdf"); m = model(fid); p, _ = apply(fid, [edit(block(m, "Dear customer"), "Edited.")])
    info = pdf(p).extract_image(pdf(p)[0].get_images()[0][0]); assert info["bpc"] == 1 and p.stat().st_size < (C / "scan_bilevel.pdf").stat().st_size * 3
    # reflow inside a scan: a longer paragraph pushes the following lines of the picture down
    fid, _ = prep("scan_clean.pdf"); m = model(fid); b = block(m, "Dear customer")
    long = "Dear customer, thank you for your enquiry. " + "We can deliver cotton shirts, denim jeans and kurta sets in all sizes. " * 3
    p, _ = apply(fid, [edit(b, long.strip())])
    seen = ocr(p); assert "kurta sets in all sizes" in seen and "Delivery will be made within fourteen working days" in seen and "Regards, Sales Team" in seen
    m2 = model(up_path(p)); d2 = block(m2, "Delivery will")["bbox"][1]; d1 = block(m, "Delivery will")["bbox"][1]
    assert d2 > d1 + 10, "the lines below were not moved down inside the scan"
    # text typed on top of a scan (hybrid): digital text is edited as text, the scan underneath stays
    fid, _ = prep("scan_hybrid.pdf"); m = model(fid); b = block(m, "Received on"); assert not b["scanned"]
    p, _ = apply(fid, [edit(b, "Received on 15 November 2026 - Accounts")]); assert "15 November" in text(p) and "Dear customer" in ocr(p)
    # scan → fully digital document
    p = run("scan_to_editable", ["scan_textured.pdf"], {"lang": "eng"}); t = text(p)
    assert t.count("Dear customer") == 1 and "fourteen working days" in t and "Regards" in t
    m3 = model(up_path(p)); assert not m3["scanned"] and not block(m3, "Dear customer")["scanned"]


def up_path(p):
    r = client.post("/api/upload", files=[("files", (Path(p).name, open(p, "rb")))]); assert r.status_code == 200, r.text
    fid = r.json()[0]["id"]; assert client.post(f"/api/editor/{fid}/prepare").status_code == 200
    return fid


# ------------------------------------------------------------------ Hindi and other Indian languages
def test_hindi_editing():
    fid, _ = prep("chrome_report.pdf"); m = model(fid)
    b = block(m, "परीक्षण")
    new = "कृपया भुगतान 30 दिनों के भीतर करें। विलंब होने पर ब्याज लगेगा। धन्यवाद, विक्रय विभाग (Sales)।"
    p, _ = apply(fid, [edit(b, new)])
    assert "".join(actual_text(p)).replace(" ", "").find("विलंबहोनेपरब्याजलगेगा") >= 0, actual_text(p)
    rt = reader_text(p); assert rt is None or new in rt, f"other PDF readers do not get the Hindi text right: {rt[-300:] if rt else ''}"
    seen = ocr(p, lang="hin+eng"); assert "भुगतान 30 दिनों" in seen and "परीक्षण दस्तावेज़" not in seen
    # opening the saved file again gives exactly the words that were typed – and it can be edited again without leftovers
    fid2 = up_path(p); m2 = model(fid2); b2 = block(m2, "विलंब")
    assert b2["text"] == new and not b2.get("reread"), b2["text"]
    p2, _ = apply(fid2, [edit(b2, "नया पाठ: भुगतान प्राप्त हुआ।")])
    rt = reader_text(p2); assert rt is None or ("नया पाठ: भुगतान प्राप्त हुआ।" in rt and "ब्याज" not in rt)
    assert "ब्याज" not in "".join(actual_text(p2)) and block(model(up_path(p2)), "नया पाठ")["text"] == "नया पाठ: भुगतान प्राप्त हुआ।"
    # new text box with several Indian scripts, bold and colour
    paras = [[{"t": "বাংলা লেখা, ", "b": 0, "i": 0, "c": "#000000", "s": 12, "fam": "liberationsans"}, {"t": "தமிழ் உரை", "b": 1, "i": 0, "c": "#cc0000", "s": 12, "fam": "liberationsans"},
              {"t": ", తెలుగు, ગુજરાતી, ಕನ್ನಡ, മലയാളം, ਪੰਜਾਬੀ and English.", "b": 0, "i": 0, "c": "#000000", "s": 12, "fam": "liberationsans"}]]
    p3, _ = apply(fid, [{"type": "add_text", "page": 0, "x": 60, "y": 620, "w": 470, "paras": paras, "align": "left", "lh": 1.3}])
    want = "বাংলা লেখা, தமிழ் உரை, తెలుగు, ગુજરાતી, ಕನ್ನಡ, മലയാളം, ਪੰਜਾਬੀ and English."
    rt = reader_text(p3); assert rt is None or want in rt, rt[-250:] if rt else ""
    nb = block(model(up_path(p3)), "বাংলা"); assert nb["text"] == want and any(r["b"] and r["c"] == "#cc0000" and "தமிழ்" in r["t"] for r in nb["paras"][0])


# ------------------------------------------------------------------ adding things
def test_add_objects():
    fid, _ = prep("sample.pdf")
    ops = [
        {"type": "add_text", "page": 0, "x": 320, "y": 400, "w": 200, "align": "left", "lh": 1.2,
         "paras": [[{"t": "Approved ", "b": 1, "i": 0, "c": "#0a7d32", "s": 14, "fam": "liberationsans"}, {"t": "by manager", "b": 0, "i": 1, "c": "#000000", "s": 14, "fam": "liberationserif"}]]},
        {"type": "rect", "page": 0, "rect": [300, 430, 400, 470], "stroke": "#ff0000", "fill": "#ffff00", "width": 2, "opacity": 0.5},
        {"type": "ellipse", "page": 0, "rect": [420, 430, 500, 470], "stroke": "#0000ff", "width": 1.5},
        {"type": "line", "page": 0, "p1": [300, 490], "p2": [500, 490], "stroke": "#000000", "width": 1},
        {"type": "arrow", "page": 0, "p1": [300, 510], "p2": [500, 520], "stroke": "#cc0000", "width": 2},
        {"type": "whiteout", "page": 0, "rect": [70, 128, 420, 145], "color": "#ffffff"},
        {"type": "image", "page": 0, "rect": [72, 560, 132, 600], "data": PNG()},
        {"type": "signature", "page": 5, "rect": [400, 700, 520, 760], "data": PNG((10, 20, 120), (120, 60))},
        {"type": "highlight", "page": 1, "rects": [[72, 156, 250, 170]], "color": "#ffe600"},
        {"type": "underline", "page": 1, "rects": [[72, 174, 250, 188]], "color": "#ff0000"},
        {"type": "strike", "page": 1, "rects": [[72, 192, 250, 206]]},
        {"type": "ink", "page": 1, "paths": [[[100, 500], [150, 520], [200, 480]]], "color": "#0000ff", "width": 3},
        {"type": "link", "page": 2, "rect": [72, 90, 300, 110], "url": "https://katmanduapparel.com"},
        {"type": "link", "page": 2, "rect": [72, 120, 300, 140], "target_page": 6},
        {"type": "note", "page": 2, "x": 500, "y": 80, "text": "Check these figures"},
        {"type": "field", "page": 3, "kind": "text", "name": "customer", "rect": [72, 600, 300, 620], "value": "Rahul"},
        {"type": "field", "page": 3, "kind": "checkbox", "name": "paid", "rect": [72, 630, 86, 644], "value": True},
        {"type": "field", "page": 3, "kind": "dropdown", "name": "size", "rect": [72, 660, 200, 680], "options": ["S", "M", "L"], "value": "M"},
        {"type": "field", "page": 3, "kind": "signature", "name": "sig", "rect": [72, 700, 250, 750]},
        {"type": "fill_forms", "fields": {"fullname": "Ravi Sharma", "agree": True}},
    ]
    p, j = apply(fid, ops); d = pdf(p)
    assert j["skipped"] == 0
    t0 = d[0].get_text()
    assert "Approved by manager" in " ".join(t0.split()) and "Line 1 of page 1" not in t0 and "Line 2 of page 1" in t0, "white-out must really remove the text under it"
    raw = b"".join(d.xref_stream(x) or b"" for x in d[0].get_contents()); assert b"Line 1 of page 1" not in raw
    sp = {s["text"].strip(): s for bl in d[0].get_text("dict")["blocks"] if bl["type"] == 0 for l in bl["lines"] for s in l["spans"]}
    assert sp["Approved"]["flags"] & 16 and sp["Approved"]["color"] == 0x0A7D32 and sp["by manager"]["flags"] & 2 and abs(sp["Approved"]["bbox"][0] - 320) < 3
    kinds = [dr for dr in d[0].get_drawings()]
    assert any(abs(dr["rect"].x0 - 300) < 2 and abs(dr["rect"].y1 - 470) < 2 and dr.get("fill") == (1.0, 1.0, 0.0) and abs((dr.get("fill_opacity") or 1) - 0.5) < 0.05 for dr in kinds), "rectangle missing"
    assert any(abs(dr["rect"].x0 - 420) < 2 and dr.get("color") == (0.0, 0.0, 1.0) for dr in kinds) and any(abs(dr["rect"].y0 - 490) < 2 and dr["rect"].width > 190 for dr in kinds)
    img = [i for i in d[0].get_image_info() if abs(i["bbox"][0] - 72) < 1 and abs(i["bbox"][1] - 560) < 1]; assert len(img) == 1 and abs(img[0]["bbox"][2] - 132) < 1
    assert len(d[5].get_image_info()) == 1
    assert sorted(a.type[1] for a in d[1].annots()) == ["Highlight", "Ink", "StrikeOut", "Underline"]
    links = d[2].get_links(); assert any(l.get("uri") == "https://katmanduapparel.com" for l in links) and any(l["kind"] == pymupdf.LINK_GOTO and l["page"] == 5 for l in links)
    assert [a.info["content"] for a in d[2].annots()] == ["Check these figures"]
    w = {x.field_name: x for x in d[3].widgets()}
    assert w["customer"].field_value == "Rahul" and w["paid"].field_value in (True, "Yes", "On") and w["size"].field_value == "M" and w["size"].choice_values == ["S", "M", "L"]
    assert w["sig"].field_type == pymupdf.PDF_WIDGET_TYPE_SIGNATURE
    w0 = {x.field_name: x for x in d[0].widgets()}; assert w0["fullname"].field_value == "Ravi Sharma" and w0["agree"].field_value not in (False, "Off", None, "")
    # page operations
    p, _ = apply(fid, [{"type": "rotate_page", "page": 0, "angle": 90}, {"type": "insert_blank", "page": 2}, {"type": "delete_page", "page": 5}])
    d = pdf(p); assert d.page_count == 6 and d[0].rotation == 0 and d[0].rect.width > d[0].rect.height and not d[2].get_text().strip() and "Chapter 3" in d[3].get_text() and "Chapter 6" not in " ".join(pg.get_text() for pg in d)


def test_existing_objects():
    d = pymupdf.open(C / "letter.pdf"); d[0].insert_image(pymupdf.Rect(60, 320, 260, 453), filename=str(C / "photo.png"))
    d[0].insert_link({"kind": pymupdf.LINK_URI, "from": pymupdf.Rect(60, 60, 300, 100), "uri": "https://old.example.com"}); d.save(C / "_withimg.pdf")
    fid, _ = prep("_withimg.pdf"); m = model(fid)
    assert len(m["images"]) == 1 and abs(m["images"][0]["bbox"][0] - 60) < 1 and m["links"][0]["uri"] == "https://old.example.com"
    im = m["images"][0]
    p, _ = apply(fid, [{"type": "image_edit", "page": 0, "xref": im["xref"], "orig": im["bbox"], "rect": [300, 500, 500, 633]}])      # move
    info = pdf(p)[0].get_image_info(); assert len(info) == 1 and abs(info[0]["bbox"][0] - 300) < 1 and abs(info[0]["bbox"][1] - 500) < 1
    assert mean(render(p, dpi=40, clip=pymupdf.Rect(60, 320, 260, 453))) > 250, "old place of the picture is not empty"
    assert near_color(render(p, dpi=40, clip=pymupdf.Rect(304, 504, 330, 524)), (70, 130, 90)) and near_color(render(p, dpi=40, clip=pymupdf.Rect(390, 550, 410, 580)), (230, 60, 50))
    p, _ = apply(fid, [{"type": "image_edit", "page": 0, "xref": im["xref"], "orig": im["bbox"], "delete": True}]); assert not pdf(p)[0].get_image_info() and "Dear customer" in text(p)
    p, _ = apply(fid, [{"type": "image_edit", "page": 0, "xref": im["xref"], "orig": im["bbox"], "data": PNG((0, 0, 200), (200, 133))}])  # replace
    assert near_color(render(p, dpi=40, clip=pymupdf.Rect(70, 330, 250, 440)), (0, 0, 200))
    p, _ = apply(fid, [{"type": "link_edit", "page": 0, "rect": m["links"][0]["rect"], "url": "https://new.example.com"}]); assert [l["uri"] for l in pdf(p)[0].get_links()] == ["https://new.example.com"]
    p, _ = apply(fid, [{"type": "link_edit", "page": 0, "rect": m["links"][0]["rect"], "delete": True}]); assert not pdf(p)[0].get_links()
    fid, _ = prep("_annotated.pdf"); m = model(fid); hl = next(a for a in m["annots"] if a["type"] == "Highlight")
    p, _ = apply(fid, [{"type": "annot_delete", "page": 0, "xref": hl["xref"]}]); assert [a.type[1] for a in pdf(p)[0].annots()] == ["Text"]
    fid, _ = prep("sample.pdf")
    fields = client.get(f"/api/editor/{fid}/fields").json(); assert {f["name"] for f in fields} == {"fullname", "agree"}
    p, _ = apply(fid, [{"type": "widget_delete", "page": 0, "name": "fullname"}]); assert [w.field_name for w in pdf(p)[0].widgets()] == ["agree"]


def near_color(im, col, tol=30):
    px = np.asarray(im.convert("RGB")).reshape(-1, 3).mean(axis=0)
    return all(abs(a - b) <= tol for a, b in zip(px, col))


def test_find_replace():
    fid, _ = prep("sample.pdf")
    p, j = apply(fid, [{"type": "find_replace", "find": "INV-1003", "replace": "INV-9999"}])
    d = pdf(p); assert j["replaced"] == 20 and d[2].get_text().count("INV-9999") == 20 and "INV-1003" not in d[2].get_text() and d[1].get_text().count("INV-1002") == 20
    assert "Line 7 of page 3. Invoice number INV-9999. The quick brown fox jumps." in " ".join(d[2].get_text().split())
    p, j = apply(fid, [{"type": "find_replace", "find": "chapter", "replace": "Part", "case": True}]); assert j["replaced"] == 0 and "Chapter 1" in text(p)   # case sensitive: nothing to do
    p, j = apply(fid, [{"type": "find_replace", "find": "chapter", "replace": "Part"}]); assert j["replaced"] == 6 and "Part 4: Sample Heading" in " ".join(pdf(p)[3].get_text().split())
    fid, _ = prep("scan_clean.pdf"); model(fid)          # the scan is recognised when the page is opened
    p, j = apply(fid, [{"type": "find_replace", "find": "fourteen", "replace": "ten"}])
    seen = ocr(p); assert j["replaced"] == 1 and "within ten working days" in seen and "fourteen" not in seen and "Dear customer" in seen


def test_versions_and_rendering():
    fid, info = prep("chrome_report.pdf")
    assert info["version"] == 0 and len(info["pages"]) == 1 and abs(info["pages"][0][0] - 595.3) < 1 and all("faces" in f for f in info["fonts"])
    r = client.get(f"/api/editor/{fid}/render/0?v=0&s=1.5"); im = Image.open(io.BytesIO(r.content))
    assert r.status_code == 200 and r.headers["content-type"] == "image/jpeg" and abs(im.width - 595.3 * 1.5) < 2 and "max-age" in r.headers["cache-control"]
    assert client.get(f"/api/editor/{fid}/render/9?v=0").status_code == 404 and client.get(f"/api/editor/{fid}/render/0?v=3").status_code == 409
    m = model(fid); b = block(m, "Important: prices")
    commit = lambda ops, base: client.post(f"/api/editor/{fid}/commit", json={"ops": ops, "base": base, "lang": "eng"})
    j = commit([edit(b, b["text"] + " This offer cannot be combined with other discounts and applies to orders above 50 pieces only, as agreed.")], 0).json()
    assert j["version"] == 1 and j["pages"] == [0] and not j["structure"] and j["skipped"] == 0
    sh = j["shifts"]["0"][0]; assert sh[3] > 10 and sh[2] < 200, "the browser must learn how far the content below moved"
    m1 = client.get(f"/api/editor/{fid}/page/0?v=1&lang=eng").json()
    assert "applies to orders above 50 pieces" in block(m1, "Important: prices")["text"] and abs(block(m1, "Summary")["bbox"][1] - block(m, "Summary")["bbox"][1] - sh[3]) < 1
    assert "applies to orders" not in block(model(fid), "Important: prices")["text"], "version 0 must stay untouched (undo)"
    a = Image.open(io.BytesIO(client.get(f"/api/editor/{fid}/render/0?v=0&s=0.5").content)); bb = Image.open(io.BytesIO(client.get(f"/api/editor/{fid}/render/0?v=1&s=0.5").content))
    from PIL import ImageChops
    assert ImageChops.difference(a, bb).getbbox(), "the picture of the new version must show the change"
    j2 = commit([{"type": "find_replace", "find": "Cotton shirt", "replace": "Linen shirt"}], 1).json(); assert j2["version"] == 2 and j2["replaced"] >= 1
    # undo to version 1, then a different change: version 2 is replaced, version 3 does not exist
    j3 = commit([{"type": "delete_page", "page": 0}, {"type": "insert_blank", "page": 0}, {"type": "insert_blank", "page": 1}], 1).json()
    assert j3["version"] == 2 and j3["structure"] and len(j3["sizes"]) == 3, "the only page cannot be deleted; blank pages go before and after it"
    m2 = client.get(f"/api/editor/{fid}/page/1?v=2&lang=eng").json(); assert "Quarterly Sales Report" in " ".join(b["text"] for b in m2["blocks"]) and "Linen" not in str(m2)
    assert client.get(f"/api/editor/{fid}/render/0?v=3").status_code == 409 and commit([], 7).status_code == 409
    # final document: version 1 + an object placed in the browser
    r = client.post(f"/api/editor/{fid}/apply", json={"version": 1, "ops": [{"type": "rect", "page": 0, "rect": [50, 700, 150, 750], "stroke": "#ff0000", "width": 2}]})
    p = DATA / r.json()["task"] / r.json()["name"]; t = text(p)
    assert r.status_code == 200 and "applies to orders above 50 pieces" in t and "Linen shirt" not in t and any(abs(dr["rect"].y0 - 700) < 2 for dr in pdf(p)[0].get_drawings())
    # scans: the recognised text of untouched pages is carried over, edited pages are read again
    fid, _ = prep("scan_clean.pdf"); m = model(fid)
    j = client.post(f"/api/editor/{fid}/commit", json={"ops": [edit(block(m, "Dear customer"), "Dear Mr. Sharma, your order is confirmed.")], "base": 0, "lang": "eng"}).json()
    m1 = client.get(f"/api/editor/{fid}/page/0?v=1&lang=eng").json()
    assert block(m1, "Sharma")["text"] == "Dear Mr. Sharma, your order is confirmed." and not block(m1, "Sharma")["scanned"] and block(m1, "Delivery will")["scanned"]


def test_robust_apply():
    fid, _ = prep("letter.pdf")
    good = {"type": "add_text", "page": 0, "x": 60, "y": 400, "paras": [[{"t": "still works", "s": 12}]]}
    junk = [{"type": "rect", "page": 0}, {"type": "image", "page": 0, "rect": [0, 0, 10, 10], "data": "not an image"}, {"type": "edit_block", "page": 0, "bbox": "x"},
            {"type": "ink", "page": 99, "paths": []}, {"page": 0}, "garbage", {"type": "highlight", "page": 0, "rects": [["a", 1, 2, 3]]}, {"type": 42}]
    p, j = apply(fid, [good] + junk); assert "still works" in text(p) and j["skipped"] >= 3, "one broken change must not lose the others"
    apply(fid, junk[:3], expect=422); apply(fid, {"not": "a list"}, expect=422); apply(fid, [good] * 5001, expect=422)
    p, _ = apply(fid, []); assert "Dear customer" in text(p)


# ------------------------------------------------------------------ e-signature requests
def test_esign_flow():
    from app.tools_plus import verify_signatures
    fid = up("letter.pdf")[0]
    r = client.post("/api/sign/create", json={"file_id": fid, "title": "Supply agreement", "message": "Please sign by Friday.",
                                               "ops": [{"type": "add_text", "page": 0, "x": 60, "y": 330, "paras": [[{"t": "Customer signature:", "s": 11}]]}]})
    assert r.status_code == 200, r.text
    tok = r.json()["token"]; assert r.json()["url"].endswith("/sign/" + tok) and len(tok) == 40
    info = client.get(f"/api/sign/{tok}").json()
    assert info["status"] == "pending" and info["title"] == "Supply agreement" and "download" not in info
    sfid = info["file_id"]; assert "Customer signature:" in pymupdf.open(stream=client.get(f"/api/file/{sfid}").content)[0].get_text()
    assert client.get(f"/api/sign/{tok}/download").status_code == 409
    body = {"file_id": sfid, "name": "राहुल शर्मा", "email": "", "consent": True,
            "ops": [{"type": "signature", "page": 0, "rect": [180, 310, 300, 350], "data": PNG((10, 20, 120), (240, 80))}]}
    assert client.post(f"/api/sign/{tok}/complete", json=dict(body, consent=False)).status_code == 422
    assert client.post(f"/api/sign/{tok}/complete", json=dict(body, name=" ")).status_code == 422
    # the signer cannot swap the document or change its text: only additions are accepted, always on the original
    other = up("sample.pdf")[0]
    body = dict(body, file_id=other, ops=body["ops"] + [{"type": "whiteout", "page": 0, "rect": [50, 50, 550, 300]}, {"type": "find_replace", "find": "thirty", "replace": "ninety"},
                                                         {"type": "image", "page": 0, "rect": [0, 0, 595, 842], "data": PNG((255, 255, 255))}])
    r = client.post(f"/api/sign/{tok}/complete", json=body); assert r.status_code == 200 and r.json()["status"] == "signed", r.text
    assert client.post(f"/api/sign/{tok}/complete", json=body).status_code == 409, "a document can be signed only once"
    r = client.get(f"/api/sign/{tok}/download"); assert r.status_code == 200 and "letter_signed.pdf" in r.headers["content-disposition"]
    out = C / "_signed.pdf"; out.write_bytes(r.content); d = pdf(out)
    assert d.page_count == 2 and len(d[0].get_image_info()) == 1 and "Customer signature:" in d[0].get_text()
    assert "Dear customer" in d[0].get_text() and "thirty days" in d[0].get_text() and "Chapter 1" not in d[0].get_text(), "signer changed the document"
    cert = " ".join(d[1].get_text().split())
    assert "Signature certificate" in cert and "Supply agreement" in cert and tok in cert and "SHA-256" in cert
    rt = reader_text(out, 1); assert rt is None or "राहुल शर्मा" in rt, "signer name in Hindi is not readable on the certificate page"
    s = verify_signatures(out); assert len(s) == 1 and s[0]["intact"] and s[0]["valid"] and s[0]["covers_whole_document"]
    info = client.get(f"/api/sign/{tok}").json(); assert info["status"] == "signed" and info["signer"] == "राहुल शर्मा" and info["download"]
    assert client.get("/api/sign/" + "0" * 40).status_code == 404 and client.get("/api/sign/../../etc").status_code in (404, 405)


if __name__ == "__main__":
    sys.exit(1 if main(globals()) else 0)

"""PDF tools, part 2 – PDF/A, redaction, compare, signatures, print layouts, converters, generators, AI tools."""
from helpers import *
import xml.etree.ElementTree as ET


# ------------------------------------------------------------------ archive / privacy
def test_pdfa():
    p = run("pdfa", ["sample.pdf"], {"level": "2"})
    d = pdf(p); xml = d.get_xml_metadata()
    assert re.search(r"pdfaid:part[>=\"' ]+2", xml), "no PDF/A-2 claim in the metadata"
    assert d.page_count == 6 and "Chapter 3" in d[2].get_text()
    assert all(f[1] not in ("n/a", "") for pg in d for f in pg.get_fonts()), "PDF/A must embed every font"


def test_redact():
    p = run("redact", ["sample.pdf"], {"words": "INV-1001, quick brown", "pages": "1"})
    d = pdf(p); t0 = d[0].get_text()
    assert "INV-1001" not in t0 and "quick brown" not in t0 and "Line 1 of page 1" in t0 and "INV-1002" in d[1].get_text()
    raw = b"".join(d.xref_stream(x) or b"" for x in range(1, d.xref_length()) if d.xref_is_stream(x))
    assert b"INV-1001" not in raw, "redacted text is still inside the file"
    assert not (d.metadata or {}).get("producer") and not (d.metadata or {}).get("title")
    t = text(run("redact", ["chrome_report.pdf"], {"patterns": ["email", "url"]}))
    assert "sales@example.com" not in t and "Quarterly Sales Report" in t and "Cotton shirt" in t
    p = run("redact", ["scan_clean.pdf"], {"areas": [{"page": 0, "x0": 0.05, "y0": 0.13, "x1": 0.95, "y1": 0.22}]})
    im = render(p, dpi=50)
    assert mean(im, (0.1, 0.14, 0.9, 0.21)) < 20 and mean(im, (0.1, 0.5, 0.9, 0.9)) > 240, "scan pixels were not blacked out"
    pix = pdf(p)[0].get_images(); info = pdf(p).extract_image(pix[0][0]); scan = Image.open(io.BytesIO(info["image"])).convert("L")
    px = scan.crop((int(.1 * scan.width), int(.14 * scan.height), int(.9 * scan.width), int(.21 * scan.height))).getextrema()
    assert px[1] - px[0] < 4, "the words are still inside the scan image under the black box"
    assert "Dear customer" not in text(p) and "Delivery" in text(p)
    assert "Nothing matched" in run("redact", ["sample.pdf"], {"words": "zzzzunknownzzz"}, expect=422)["error"]


def test_sanitize():
    d = pdf(run("sanitize", ["dirty.pdf"]))
    assert d.embfile_count() == 0 and not any((d.metadata or {}).get(k) for k in ("title", "author", "keywords"))
    assert d.xref_get_key(d.pdf_catalog(), "OpenAction")[0] == "null" and not d.get_xml_metadata()
    assert "Chapter 1" in d[0].get_text() and d.page_count == 6
    raw = (run("sanitize", ["dirty.pdf"])).read_bytes()
    assert b"JavaScript" not in raw and b"Someone Private" not in raw


def test_compare():
    p = run("compare", ["cmp_a.pdf", "cmp_b.pdf"])
    d = pdf(p); t = d[0].get_text()
    assert "2 words removed" in t and "4 words added" in t and "cmp_a.pdf" in t and "cmp_b.pdf" in t
    assert d[0].rect.width > 1150   # both documents side by side
    run("compare", ["cmp_a.pdf"], expect=422)


def test_remove_blank():
    d = pdf(run("remove_blank", ["with_blanks.pdf"]))
    assert d.page_count == 6 and "Chapter 3" in d[2].get_text() and "Chapter 6" in d[5].get_text()
    run("remove_blank", ["sample.pdf"], expect=422)


# ------------------------------------------------------------------ signatures
def test_digital_signature():
    from app.tools_plus import verify_signatures, make_certificate
    p = run("digital_sign", ["sample.pdf"], {"name": "Ravi Sharma", "reason": "Approved", "position": "bottom-right"})
    s = verify_signatures(p)
    assert len(s) == 1 and s[0]["intact"] and s[0]["valid"] and "Ravi Sharma" in s[0]["signer"] and s[0]["covers_whole_document"]
    d = pdf(p); w = [x for x in d[5].widgets() if x.field_type == pymupdf.PDF_WIDGET_TYPE_SIGNATURE]
    assert len(w) == 1 and w[0].rect.x0 > 300 and w[0].rect.y0 > 700, "visible signature box is not at the bottom right of the last page"
    assert mean(render(p, 5, dpi=60, clip=w[0].rect)) < 250, "signature box is empty"
    rep = run("verify_signature", [str(p.name)] if False else up_path(p)).read_text()
    assert "Signature 1: VALID" in rep and "Ravi Sharma" in rep and "unchanged since signing: yes" in rep
    # tampering must be detected
    raw = bytearray(p.read_bytes()); i = raw.find(b"Chapter 1"); i = i if i > 0 else raw.find(b"stream") + 12
    raw[i] ^= 0x01; (C / "_tampered.pdf").write_bytes(bytes(raw))
    rep = run("verify_signature", ["_tampered.pdf"]).read_text()
    assert "NOT VALID" in rep, "a modified signed file was reported as valid"
    assert "no digital signatures" in run("verify_signature", ["sample.pdf"]).read_text()
    # own certificate (.p12 / .pfx from a certifying authority)
    pw = make_certificate("Himalaya Textile Pvt Ltd", "", C / "_own.p12").decode()
    ids = up("letter.pdf", "_own.p12")
    p2 = run("digital_sign", [ids[0]], {"cert_file": ids[1], "cert_password": pw, "position": "top-left", "page": 1})
    s = verify_signatures(p2); assert s[0]["valid"] and "Himalaya Textile" in s[0]["signer"]
    assert "certificate" in run("digital_sign", [ids[0]], {"cert_file": ids[1], "cert_password": "wrong"}, expect=422)["error"].lower()
    run("digital_sign", ["letter.pdf"], {}, expect=422)


def up_path(p):
    """upload a result file again (as the 'continue with another tool' button does)"""
    r = client.post("/api/upload", files=[("files", (p.name, open(p, "rb")))]); assert r.status_code == 200, r.text
    return [r.json()[0]["id"]]


# ------------------------------------------------------------------ layout tools
def test_overlay_invert():
    d = pdf(run("overlay", ["sample.pdf", "letter.pdf"], {"layer": "above", "mode": "repeat"}))
    assert d.page_count == 6 and all("Dear customer" in pg.get_text() and f"Chapter {pg.number + 1}" in pg.get_text() for pg in d)
    d = pdf(run("overlay", ["sample.pdf", "letter.pdf"], {"layer": "below", "mode": "pages"}))
    assert "Dear customer" in d[0].get_text() and "Dear customer" not in d[1].get_text()
    run("overlay", ["sample.pdf"], expect=422)
    p = run("invert", ["letter.pdf"]); im = render(p, dpi=40)
    assert mean(im) < 40 and max(im.convert("L").getdata()) > 200 and "Dear customer" in text(p), "page was not inverted"
    p = run("invert", ["sample.pdf"], {"pages": "2"})
    assert mean(render(p, 0)) > 200 and mean(render(p, 1)) < 60


def test_booklet_poster():
    d = pdf(run("booklet", ["sample.pdf"]))
    W = d[0].rect.width; half = lambda pg, k: pg.get_text(clip=pymupdf.Rect(k * W / 2, 0, (k + 1) * W / 2, pg.rect.height))
    assert d.page_count == 4 and abs(W - 2 * 595.27) < 1
    got = [("" if "Chapter" not in half(pg, k) else re.search(r"Chapter (\d)", half(pg, k)).group(1)) for pg in d for k in (0, 1)]
    assert got == ["", "1", "2", "", "6", "3", "4", "5"], f"wrong booklet order {got}"   # 8,1 | 2,7 | 6,3 | 4,5
    d = pdf(run("poster", ["letter.pdf"], {"cols": 2, "rows": 2, "size": "a4"}))
    assert d.page_count == 4 and "Himalaya" in d[0].get_text() and "Himalaya" not in d[3].get_text()
    assert d[0].get_text("dict")["blocks"] and max(s["size"] for b in d[0].get_text("dict")["blocks"] if b["type"] == 0 for l in b["lines"] for s in l["spans"]) > 30, "poster tiles are not enlarged"


def test_linearize_viewer_info():
    p = run("linearize", ["sample.pdf"])
    with pikepdf.open(p) as q:
        assert q.is_linearized and len(q.pages) == 6
    d = pdf(run("viewer_prefs", ["sample.pdf"], {"layout": "TwoColumnLeft", "mode": "UseOutlines", "fit_window": True, "show_title": True}))
    assert d.pagelayout == "TwoColumnLeft" and d.pagemode == "UseOutlines"
    assert d.xref_get_key(d.pdf_catalog(), "ViewerPreferences/FitWindow")[1] == "true" and d.xref_get_key(d.pdf_catalog(), "ViewerPreferences/HideToolbar")[1] == "false"
    md = run("pdf_info", ["sample.pdf"]).read_text()
    for want in ("Pages: 6", "210 × 297 mm (6)", "Bookmarks: 6", "Form fields: 2", "Scanned document: no", "Encrypted: no", "Helvetica-Bold"):
        assert want in md, f"PDF info misses “{want}”"
    assert "Scanned document: yes" in run("pdf_info", ["scan_clean.pdf"]).read_text()


def test_attachments_search():
    ids = up("letter.pdf", "photo.jpg", "sheet.xlsx")
    p = run("attachments", ids, {"mode": "add"}); d = pdf(p)
    assert d.embfile_count() == 2 and sorted(d.embfile_names()) == ["photo.jpg", "sheet.xlsx"] and d.embfile_get("photo.jpg") == (C / "photo.jpg").read_bytes()
    fs = unzip(run("attachments", up_path(p), {"mode": "extract"}))
    assert [f.name for f in fs] == ["photo.jpg", "sheet.xlsx"] and fs[1].read_bytes() == (C / "sheet.xlsx").read_bytes()
    run("attachments", ["letter.pdf"], {"mode": "extract"}, expect=422)
    fs = unzip(run("search", ["sample.pdf", "letter.pdf", "scan_clean.pdf"], {"query": "fourteen working days"}))
    rep = next(f for f in fs if f.suffix == ".md").read_text()
    assert "2 match(es)" in rep and "sample.pdf – not found" in rep and "letter.pdf – 1 match(es) on 1 page(s)" in rep and "scan_clean.pdf – 1 match(es)" in rep
    hl = [f for f in fs if f.suffix == ".pdf"]; assert len(hl) == 2 and all(any(a.type[1] == "Highlight" for a in pdf(f)[0].annots()) for f in hl)
    rep = run("search", ["sample.pdf"], {"query": "INV-1004", "highlight": False}).read_text(); assert "20 match(es) on 1 page(s)" in rep and "p. 4" in rep


# ------------------------------------------------------------------ more conversions
def test_pdf_to_markdown_html_svg_epub():
    md = run("pdf_to_markdown", ["chrome_report.pdf"]).read_text()
    assert "Quarterly Sales Report" in md and re.search(r"^#+ ", md, re.M) and "|Cotton shirt|120|450.00|54,000.00|" in md, "table missing in Markdown"
    assert "हिन्दी अनुभाग" in md and "विक्रय विभाग" in md and "\ufffd" not in md, "Hindi text is garbled in Markdown"
    md = run("pdf_to_markdown", ["word_doc.pdf"]).read_text(); assert "**Himalaya Textile Pvt. Ltd.**" in md and "Employment Agreement" in md
    h = run("pdf_to_html", ["sample.pdf"]).read_text(); assert "Chapter 1" in h and h.lstrip().lower().startswith("<!doctype html>")
    fs = unzip(run("pdf_to_svg", ["sample.pdf"], {"pages": "1-2"}))
    assert len(fs) == 2 and ET.parse(fs[0]).getroot().tag.endswith("svg")
    p = run("pdf_to_epub", ["sample.pdf"])
    z = zipfile.ZipFile(p); names = z.namelist()
    assert names[0] == "mimetype" and z.getinfo("mimetype").compress_type == 0 and z.read("mimetype") == b"application/epub+zip"
    for n in names:   # every XML part must be well-formed, otherwise e-readers refuse the book
        if n.endswith((".xhtml", ".opf", ".xml")):
            ET.fromstring(z.read(n))
    nav = z.read("OEBPS/nav.xhtml").decode(); assert nav.count("<li>") == 6 and "Chapter 3" in nav
    assert "Line 20 of page 2" in z.read("OEBPS/c1.xhtml").decode() and "Line 1 of page 3" not in z.read("OEBPS/c1.xhtml").decode()
    back = pdf(run("ebook_to_pdf", up_path(p), {"page_size": "a5"}))
    assert back.page_count >= 6 and "Line 1 of page 1" in back[0].get_text() + back[1].get_text() and abs(back[0].rect.width - 420) < 2
    assert len(back.get_toc()) >= 6


def test_text_office_ps_to_pdf():
    fs = unzip(run("markdown_to_pdf", ["notes.md", "plain.txt"]))
    t = text(fs[0]); d = pdf(fs[0])
    assert "Meeting notes" in t and "Launch winter line" in t and "print('hello')" in t and "कृपया" in t and "**" not in t and "|" not in t
    assert max(s["size"] for b in d[0].get_text("dict")["blocks"] if b["type"] == 0 for l in b["lines"] for s in l["spans"]) > 18, "heading not rendered"
    lines = [l for l in pdf(fs[1])[0].get_text().splitlines() if l.strip()]
    assert lines[0] == "First line of the text file." and "indented second line" in lines[1] and "Third paragraph" in lines[2]
    words = pdf(fs[1])[0].get_text("words"); assert [w for w in words if w[4] == "indented"][0][0] > [w for w in words if w[4] == "First"][0][0] + 8, "indentation lost"
    t = text(run("excel_to_pdf", ["sheet.xlsx"])); assert "Cotton shirt" in t and "1150" in t and "200" in t   # 200 = the SUM formula
    assert pdf(run("excel_to_pdf", ["wide.xlsx"])).page_count > 3 and pdf(run("excel_to_pdf", ["wide.xlsx"], {"sheets": "one_page"})).page_count == 1
    d = pdf(run("ppt_to_pdf", ["slides.pptx"])); assert d.page_count == 2 and "Sales Review 2026" in d[0].get_text() and d[0].rect.width > d[0].rect.height
    assert "Hello PostScript" in text(run("ps_to_pdf", ["hello.ps"]))
    (C / "_bad.ps").write_text("this is not postscript {{{ ) (")
    run("ps_to_pdf", ["_bad.ps"], expect=422)


def test_zip_and_any_to_pdf():
    d = pdf(run("zip_to_pdf", ["bundle.zip"]))
    toc = [t[1] for t in d.get_toc()]
    assert toc == ["a_photo", "c_plain", "d_contract", "b_letter"], toc      # file-name order, folders after files, path tricks ignored
    assert d.page_count == 5 and "First line" in d[1].get_text() and "Employment Agreement" in d[2].get_text() and "Dear customer" in d[4].get_text()
    assert not Path("/tmp/evil.txt").exists() and not (DATA / "evil.txt").exists() and not (DATA.parent / "evil.txt").exists(), "ZIP wrote outside its folder"
    fs = unzip(run("zip_to_pdf", ["bundle.zip"], {"mode": "separate"})); assert sorted(f.name for f in fs) == ["a_photo.pdf", "b_letter.pdf", "c_plain.pdf", "d_contract.pdf"]
    (C / "_not.zip").write_bytes(b"hello"); run("zip_to_pdf", ["_not.zip"], expect=422)
    fs = unzip(run("to_pdf", ["photo.png", "word_doc.docx", "notes.md", "hello.ps"]))
    assert [f.name for f in fs] == ["hello.pdf", "notes.pdf", "photo.pdf", "word_doc.pdf"] and all(pdf(f).page_count >= 1 for f in fs)


def test_enhance_scan():
    before = render(C / "scan_textured.pdf", dpi=40)
    p = run("enhance_scan", ["scan_textured.pdf"], {"mode": "color", "ocr": True, "lang": "eng"})
    after = render(p, dpi=40)
    assert mean(before, (0.1, 0.5, 0.9, 0.9)) < 225 and mean(after, (0.1, 0.5, 0.9, 0.9)) > 240, "paper is not white after enhancing"
    px = after.crop((0, int(after.height * .5), after.width, int(after.height * .9))).resize((8, 1)).convert("L").getdata()
    assert max(px) - min(px) < 8, "uneven lighting was not removed"
    assert "Dear customer" in text(p) and "fourteen working days" in text(p)
    p = run("enhance_scan", ["scan_textured.pdf"], {"mode": "bw", "ocr": False})
    info = pdf(p).extract_image(pdf(p)[0].get_images()[0][0]); assert info["bpc"] == 1 and p.stat().st_size < 60_000


# ------------------------------------------------------------------ generators
def _qr(p):
    import cv2, numpy as np
    im = cv2.imread(str(p)) if Path(p).suffix != ".pdf" else None
    if im is None:
        pix = pdf(p)[0].get_pixmap(dpi=150); im = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width, 3)[:, :, ::-1].copy()
    return cv2.QRCodeDetector().detectAndDecode(im)[0]


def test_qr_code():
    assert _qr(run("qr_code", [], {"text": "https://katmanduapparel.com/catalog?id=42"})) == "https://katmanduapparel.com/catalog?id=42"
    got = _qr(run("qr_code", [], {"kind": "upi", "vpa": "ravi@okhdfcbank", "payee": "Himalaya Textile", "amount": "499.5", "note": "Order 77"}))
    assert got == "upi://pay?pa=ravi@okhdfcbank&pn=Himalaya%20Textile&am=499.50&cu=INR&tn=Order%2077", got
    assert _qr(run("qr_code", [], {"kind": "wifi", "ssid": "Shop;WiFi", "wifi_password": "p:ss,1"})) == r"WIFI:T:WPA;S:Shop\;WiFi;P:p\:ss\,1;;"
    ids = up("photo.png")
    assert _qr(run("qr_code", [], {"text": "https://example.com/with-logo", "logo_file": ids[0], "scale": 20})) == "https://example.com/with-logo", "QR with logo is unreadable"
    p = run("qr_code", [], {"text": "नमस्ते PDFKaro", "format": "pdf", "caption": "Scan me"}); assert _qr(p) == "नमस्ते PDFKaro" and "Scan me" in text(p)
    assert ET.parse(run("qr_code", [], {"text": "svg please", "format": "svg"})).getroot().tag.endswith("svg")
    run("qr_code", [], {"kind": "upi", "vpa": "not a upi id"}, expect=422); run("qr_code", [], {"text": ""}, expect=422)


def test_barcode():
    p = run("barcode", [], {"kind": "code128", "text": "KA-2026-0001"}); im = Image.open(p).convert("L")
    row = [v < 128 for v in im.crop((0, im.height // 3, im.width, im.height // 3 + 1)).getdata()]
    assert sum(1 for a, b in zip(row, row[1:]) if a != b) > 60, "no bars in the barcode picture"
    p = run("barcode", [], {"kind": "ean13", "text": "590123412345"})
    import subprocess
    digits = re.sub(r"\D", "", subprocess.run(["tesseract", str(p), "stdout", "--psm", "6", "-c", "tessedit_char_whitelist=0123456789"], capture_output=True, text=True).stdout)
    assert "5901234123457" in digits, f"EAN-13 check digit missing ({digits})"
    assert "not valid" in run("barcode", [], {"kind": "ean13", "text": "ABC"}, expect=422)["error"]


def test_invoice():
    from app.tools_more import amount_in_words, _inr
    assert amount_in_words(123456.50) == "Rupees One Lakh Twenty-Three Thousand Four Hundred Fifty-Six And Fifty Paise Only"
    assert amount_in_words(10000000) == "Rupees One Crore Only" and _inr(12345678.9) == "1,23,45,678.90" and _inr(999) == "999.00"
    o = {"seller_name": "Himalaya Textile Pvt Ltd", "seller_address": "12 MG Road\nMumbai 400001", "seller_gstin": "27ABCDE1234F1Z5", "buyer_name": "Rahul Traders",
         "buyer_address": "Pune", "number": "KA/2026/041", "date": "17-11-2026", "place": "Maharashtra (27)", "bank": "HDFC Bank · A/c 1234", "notes": "Thank you!",
         "items": [{"desc": "Cotton shirt", "hsn": "6205", "qty": "10", "rate": "450", "gst": "5"}, {"desc": "Denim jeans", "hsn": "6203", "qty": 2, "rate": "1,150.50", "gst": "12%"}, {"desc": "", "qty": 5}]}
    p = run("invoice", [], o); t = text(p)
    for want in ("TAX INVOICE", "KA/2026/041", "27ABCDE1234F1Z5", "Cotton shirt", "4,500.00", "2,301.00", "6,801.00", "CGST 2.5% 112.50", "SGST 2.5% 112.50",
                 "CGST 6% 138.06", "SGST 6% 138.06", "Round off -0.12", "₹ 7,302.00", "Rupees Seven Thousand Three Hundred Two Only", "HDFC Bank", "Authorised signatory"):
        assert want in t, f"invoice misses “{want}” in: {t[:900]}"
    assert p.name == "invoice_KA_2026_041.pdf" and pdf(p).page_count == 1
    t = text(run("invoice", [], dict(o, tax_mode="igst", round_off=False)))
    assert "IGST 5% 225.00" in t and "IGST 12% 276.12" in t and "7,302.12" in t and "CGST" not in t and "Twelve Paise" in t
    t = text(run("invoice", [], dict(o, tax_mode="none", currency="$", title="INVOICE")))
    assert "6,801.00" in t and "GST" not in t.replace("GSTIN", "") and "Rupees" not in t
    run("invoice", [], {"items": []}, expect=422)


# ------------------------------------------------------------------ AI tools (against a local mock of the AI server)
def test_ai_tools():
    saved = {k: os.environ.pop(k, None) for k in ("ANTHROPIC_API_KEY", "OPENAI_BASE_URL")}
    assert "not configured" in run("ai_summarize", ["sample.pdf"], {}, expect=422)["error"]   # clear message without a key
    calls = mock_ai()
    md = run("ai_summarize", ["sample.pdf"], {"style": "short", "lang": "Hindi"}).read_text()
    assert "Mock answer" in md and "in Hindi" in calls[-1] and "[Page 6]" in calls[-1] and "Line 20 of page 6" in calls[-1]
    md = run("ai_chat", ["scan_clean.pdf"], {"question": "When is the delivery?"}).read_text()
    assert md.startswith("**Q:** When is the delivery?") and "fourteen working days" in calls[-1], "scanned PDF was not read (OCR) before asking the AI"
    md = run("ai_quiz", ["sample.pdf"], {"kind": "flashcards", "count": 5}).read_text(); assert "Mock answer" in md and "5 flashcards" in calls[-1]
    import openpyxl
    wb = openpyxl.load_workbook(run("ai_extract", ["sample.pdf", "letter.pdf"], {"fields": "Invoice number, Total, Missing field"}))
    rows = [[c.value for c in r] for r in wb.active.iter_rows()]
    assert rows[0] == ["File", "Invoice number", "Total", "Missing field"] and rows[1][:3] == ["sample.pdf", "INV-1001", "1700"] and rows[2][0] == "letter.pdf" and not rows[1][3]
    p = run("ai_translate", ["letter.pdf"], {"lang": "Hindi"}); t = text(p)
    at = actual_text(p); assert len(at) == 4 and all(a.startswith("यह अनुवादित पाठ है") for a in at), at   # real Unicode for other readers
    assert reader_text(p) is None or reader_text(p).count("यह अनुवादित पाठ है") == 4
    assert "Dear customer" not in t and "Delivery will" not in t and pdf(p).page_count == 1
    spans = [(s["bbox"], s["size"]) for b in pdf(p)[0].get_text("dict")["blocks"] if b["type"] == 0 for l in b["lines"] for s in l["spans"] if s["text"].strip()]
    assert spans and all(60 <= bb[0] and bb[2] <= 545 and bb[1] > 50 for bb, _ in spans), "translated text left its place"
    r = client.post("/api/ai", json={"action": "translate", "text": "Hello world", "lang": "Hindi"}); assert r.status_code == 200 and r.json()["result"] == "नमस्ते दुनिया"
    assert client.post("/api/ai", json={"action": "fix", "text": "  "}).status_code == 400
    for k, v in saved.items():
        if v:
            os.environ[k] = v


if __name__ == "__main__":
    sys.exit(1 if main(globals()) else 0)

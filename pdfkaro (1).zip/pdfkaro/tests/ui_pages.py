"""Browser test of every page (needs a running server and Playwright):
       python tests/ui_pages.py http://127.0.0.1:8000 [slug …]
   Opens every tool page on a desktop and a phone screen, fails on any JavaScript error, missing text or sideways scrolling."""
import json, os, re, subprocess, sys
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
BASE = sys.argv[1].rstrip("/") if len(sys.argv) > 1 else "http://127.0.0.1:8000"
ONLY = sys.argv[2:]
cfg = json.loads(subprocess.check_output(["node", "-e", "global.window={};require(process.argv[1]);console.log(JSON.stringify(window.TOOLS))", str(ROOT / "static/js/tools-config.js")]))
bad = []


def check(page, url, name, errors):
    errors.clear()
    r = page.goto(url, wait_until="networkidle")
    if not r or r.status != 200:
        bad.append(f"{name}: HTTP {r.status if r else '?'}"); return
    if errors:
        bad.append(f"{name}: {errors[:3]}")
    w = page.evaluate("[document.documentElement.scrollWidth, innerWidth]")
    if w[0] > w[1] + 2:
        bad.append(f"{name}: page is wider than the screen ({w[0]} > {w[1]})")


with sync_playwright() as pw:
    b = pw.chromium.launch()
    for label, ctx in (("desktop", b.new_context(viewport={"width": 1280, "height": 900})), ("phone", b.new_context(**pw.devices["Pixel 7"]))):
        page = ctx.new_page(); errors = []
        page.on("pageerror", lambda e: errors.append("JS error: " + str(e)[:300]))
        page.on("console", lambda m: errors.append("console: " + m.text[:300]) if m.type == "error" else None)
        page.on("requestfailed", lambda r: errors.append("failed: " + r.url) if BASE in r.url else None)
        for path in ([] if ONLY else ["/", "/hi", "/ar", "/es", "/pricing", "/login", "/login?m=signup", "/privacy", "/terms", "/refund", "/contact", "/hi/pricing", "/edit", "/edit?mode=fill-sign",
                                      "/hi/edit?mode=esign"]):
            check(page, BASE + path, f"{label} {path}", errors)
        if not ONLY:      # the editor with the site's security policy enforced: open a file, change a heading, add a signature
            errors.clear()
            page.goto(BASE + "/edit", wait_until="networkidle")
            page.set_input_files("#fi", str(Path(os.environ.get("CORPUS", "/tmp/pdfkaro_corpus")) / "chrome_report.pdf"))
            page.wait_for_selector(".blk", state="attached", timeout=60000)
            page.locator(".blk").nth(2).click(); page.wait_for_selector(".ed[contenteditable=true]"); page.keyboard.type(" – edited")
            page.click('#ftb [data-cmd="done"]'); page.wait_for_selector(".ed", state="detached", timeout=60000)
            page.click('#toolbar [data-menu="sign"]'); page.click('#menu button:has-text("New signature")'); page.click('#sigtabs [data-t="type"]')
            page.fill("#signame", "Test Person"); page.click("#sigsave"); page.wait_for_selector("#sigmodal", state="hidden")
            page.click("#apply"); page.wait_for_selector("#dlg.on a.btn.primary", timeout=120000)
            if errors:
                bad.append(f"{label} editor: {errors[:3]}")
            print(label, "editor works with the security policy on")
        n = 0
        for slug, t in cfg.items():
            if ONLY and slug not in ONLY:
                continue
            if t.get("editor"):
                continue                                             # the editor has its own test (tests/ui_editor.py)
            check(page, f"{BASE}/tool/{slug}", f"{label} /tool/{slug}", errors)
            title = page.text_content("#title") or ""
            if t["title"] not in title:
                bad.append(f"{label} {slug}: title is {title!r}")
            if t.get("noUpload") and not page.is_visible("#go"):
                bad.append(f"{label} {slug}: no button on a tool that needs no upload")
            if not t.get("noUpload") and not page.is_visible("#pick"):
                bad.append(f"{label} {slug}: upload button is not visible")
            n += 1
        print(label, "pages checked:", n)
        ctx.close()
    b.close()
print("\n".join(bad) if bad else "all pages fine")
sys.exit(1 if bad else 0)

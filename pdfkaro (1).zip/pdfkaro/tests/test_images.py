"""Image tools – every result is checked pixel by pixel where it matters."""
from helpers import *
import base64, subprocess
import xml.etree.ElementTree as ET
import numpy as np
from PIL import ImageChops, ImageDraw, ImageOps

SRC = lambda n="photo.jpg": Image.open(C / n)
GREEN, RED, YELLOW = (70, 130, 90), (230, 60, 50), (250, 210, 60)


def near(px, col, tol=30):
    return all(abs(int(a) - b) <= tol for a, b in zip(px[:3], col))


def arr(im):
    return np.asarray(im.convert("RGB")).astype(np.int16)


# ------------------------------------------------------------------ compress / resize
def test_compress():
    p = run("img_compress", ["photo.jpg"], {"level": "extreme"})
    assert p.stat().st_size < (C / "photo.jpg").stat().st_size * 0.8 and Image.open(p).size == (900, 600)
    p = run("img_compress", ["face.jpg"], {"target_kb": 20})
    assert p.stat().st_size <= 20 * 1024 and Image.open(p).size == (512, 512), "target size missed or picture was shrunk needlessly"
    p = run("img_compress", ["face.jpg"], {"target_kb": 4}); assert p.stat().st_size <= 4 * 1024 and Image.open(p).width < 512
    big = Image.fromarray(np.random.default_rng(3).integers(0, 255, (400, 600, 3), dtype=np.uint8)).filter(__import__("PIL.ImageFilter", fromlist=["x"]).GaussianBlur(3))
    big.save(C / "_noise.png")
    p = run("img_compress", ["_noise.png"]); assert p.stat().st_size < (C / "_noise.png").stat().st_size * 0.6 and Image.open(p).size == (600, 400)
    fs = unzip(run("img_compress", ["photo.jpg", "face.jpg"])); assert len(fs) == 2


def test_resize():
    size = lambda o, f="photo.jpg": Image.open(run("img_resize", [f], o)).size
    assert size({"mode": "pixels", "width": 300, "height": 300}) == (300, 200)                      # keeps the proportions
    assert size({"mode": "pixels", "width": 300, "height": 300, "keep_ratio": False}) == (300, 300)
    assert size({"mode": "pixels", "width": 450}) == (450, 300)
    assert size({"mode": "percent", "percent": 50}) == (450, 300)
    assert size({"mode": "preset", "preset": "instagram_story"}) == (1080, 1920)
    assert size({"mode": "cm", "width": 3.5, "height": 4.5, "dpi": 300}) == (413, 531)
    assert size({"mode": "pixels", "width": 4000, "no_enlarge": True}) == (900, 600)
    im = Image.open(run("img_resize", ["photo.jpg"], {"mode": "preset", "preset": "instagram_post", "fit": "contain", "bg": "#000000"}))
    assert im.size == (1080, 1080) and near(im.getpixel((540, 20)), (0, 0, 0)) and near(im.getpixel((540, 540)), RED)


def test_crop_rotate():
    im = Image.open(run("img_crop", ["photo.png"], {"box": {"x0": 0.25, "y0": 0.25, "x1": 0.75, "y1": 0.75}}))
    assert im.size == (450, 300) and near(im.getpixel((225, 150)), RED)
    assert Image.open(run("img_crop", ["photo.png"], {"ratio": "1:1"})).size == (600, 600)
    b = Image.new("RGB", (400, 300), "white"); ImageDraw.Draw(b).rectangle((100, 100, 299, 199), fill=(200, 30, 30)); b.save(C / "_border.png")
    assert Image.open(run("img_crop", ["_border.png"], {"mode": "auto"})).size == (200, 100)
    im = Image.open(run("img_rotate", ["photo.png"], {"angle": 90}))                  # clockwise: bottom-left corner goes to the top-left
    assert im.size == (600, 900) and near(im.getpixel((149, 190)), YELLOW) and near(im.getpixel((300, 450)), RED)
    im = Image.open(run("img_rotate", ["photo.png"], {"flip": "horizontal"}))
    assert im.size == (900, 600) and near(im.getpixel((709, 450)), YELLOW) and near(im.getpixel((190, 450)), GREEN)
    im = Image.open(run("img_rotate", ["photo.png"], {"angle": 180, "flip": "vertical"})); assert near(im.getpixel((709, 450)), YELLOW)
    pal = SRC("photo.png").convert("P"); pal.save(C / "_palette.gif")
    assert Image.open(run("img_rotate", ["_palette.gif"], {"angle": 90, "format": "png"})).size == (600, 900)


def test_convert():
    for fmt, pil in (("webp", "WEBP"), ("png", "PNG"), ("gif", "GIF"), ("bmp", "BMP"), ("tiff", "TIFF"), ("jpg", "JPEG")):
        im = Image.open(run("img_convert", ["photo.jpg"], {"format": fmt})); assert im.format == pil and im.size == (900, 600), fmt
    ico = Image.open(run("img_convert", ["face.jpg"], {"format": "ico"})); assert ico.format == "ICO" and (32, 32) in ico.info.get("sizes", set())
    d = pdf(run("img_convert", ["photo.jpg"], {"format": "pdf"})); assert d.page_count == 1 and d[0].get_images()
    SRC().save(C / "_phone.heic")                                                     # iPhone photos
    im = Image.open(run("img_convert", ["_phone.heic"], {"format": "jpg"})); assert im.format == "JPEG" and im.size == (900, 600) and near(im.getpixel((450, 300)), RED)
    rgba = SRC("photo.png").convert("RGBA"); rgba.putalpha(Image.new("L", rgba.size, 0)); rgba.save(C / "_clear.png")
    assert near(Image.open(run("img_convert", ["_clear.png"], {"format": "jpg"})).getpixel((10, 10)), (255, 255, 255)), "transparent areas must become white in JPG"
    im = Image.open(run("img_convert", ["phone_photo.jpg"], {"format": "png"})); assert im.size == (600, 900), "EXIF orientation ignored"


def test_adjust():
    a = arr(Image.open(run("img_adjust", ["photo.png"], {"filter": "grayscale"}))); assert (a[..., 0] == a[..., 1]).all() and (a[..., 1] == a[..., 2]).all()
    a = arr(Image.open(run("img_adjust", ["photo.png"], {"filter": "invert"}))); assert np.abs(a + arr(SRC("photo.png")) - 255).max() <= 1
    a = arr(Image.open(run("img_adjust", ["photo.png"], {"brightness": 150}))); assert a.mean() > arr(SRC("photo.png")).mean() + 25
    a = arr(Image.open(run("img_adjust", ["photo.png"], {"filter": "bw"}))); assert set(np.unique(a)) <= {0, 255}
    a = arr(Image.open(run("img_adjust", ["face.jpg"], {"filter": "pixelate", "format": "png"}))); assert (a[0:8, 0:8] == a[0, 0]).all() and not (a == a[0, 0]).all()
    s = arr(Image.open(run("img_adjust", ["face.jpg"], {"filter": "sepia", "format": "png"}))); assert s[..., 0].mean() > s[..., 2].mean() + 15
    sh = run("img_adjust", ["face.jpg"], {"filter": "sharpen", "format": "png"}); bl = run("img_adjust", ["face.jpg"], {"filter": "blur", "format": "png"})
    edge = lambda p: np.abs(np.diff(arr(Image.open(p)).mean(axis=2), axis=1)).mean()
    assert edge(sh) > edge(C / "face.jpg") > edge(bl)


# ------------------------------------------------------------------ AI: background, upscale, faces
def test_remove_bg():
    im = Image.open(run("remove_bg", ["face.jpg"])); a = np.asarray(im.getchannel("A"))
    assert im.mode == "RGBA" and im.size == (512, 512) and a[5:40, 5:40].mean() < 40 and a[90:150, 200:260].mean() > 215, "person was not cut out"
    im = Image.open(run("remove_bg", ["face.jpg"], {"background": "color", "color": "#00ff00", "format": "jpg"}))
    assert im.format == "JPEG" and near(im.getpixel((12, 12)), (0, 255, 0), 40) and not near(im.getpixel((230, 120)), (0, 255, 0), 80)
    ids = up("face.jpg", "photo.jpg")
    im = Image.open(run("remove_bg", [ids[0]], {"background": "image", "bg_image_file": ids[1]})); assert near(im.getpixel((8, 8)), GREEN, 35)
    im = Image.open(run("remove_bg", ["face.jpg"], {"background": "blur", "blur": 14})); src = SRC("face.jpg")
    d = np.abs(arr(im) - arr(src)).mean(axis=2); assert d[100:140, 210:250].mean() < 6 and d[10:60, 10:60].mean() > d[100:140, 210:250].mean()
    im = Image.open(run("remove_bg", ["face.jpg"], {"crop_subject": True})); assert im.width < 512 or im.height < 512
    sh = Image.open(run("remove_bg", ["face.jpg"], {"shadow": True})); a2 = np.asarray(sh.getchannel("A"))
    assert ((a2 > 5) & (a2 < 120)).sum() > ((a > 5) & (a < 120)).sum() + 500, "no soft shadow around the subject"


def test_upscale():
    im = Image.open(run("img_upscale", ["face.jpg"], {"scale": 2})); assert im.size == (1024, 1024)
    back = im.resize((512, 512), Image.LANCZOS); assert np.abs(arr(back) - arr(SRC("face.jpg"))).mean() < 6, "upscaled picture does not match the original"
    SRC("face.jpg").crop((150, 60, 310, 220)).save(C / "_small.png")
    im = Image.open(run("img_upscale", ["_small.png"], {"scale": 4, "quality": "max"})); assert im.size == (640, 640)
    bic = SRC("_small.png").resize((640, 640), Image.BICUBIC)
    edge = lambda x: np.abs(np.diff(arr(x).mean(axis=2), axis=1)).mean()
    assert edge(im) > edge(bic), "AI upscaling is not sharper than plain resizing"


def test_faces():
    import cv2
    from app.images import detect_faces
    src = SRC("face.jpg"); faces = detect_faces(cv2.cvtColor(np.array(src), cv2.COLOR_RGB2BGR))
    assert len(faces) == 1; x, y, w, h = faces[0]
    im = Image.open(run("blur_face", ["face.jpg"], {"format": "png"}))
    var = lambda i, box: float(np.asarray(i.convert("L").crop(box)).var())
    box = (x + w // 5, y + h // 5, x + w - w // 5, y + h - h // 5)
    assert var(im, box) < var(src, box) * 0.35, "face is still recognisable"
    assert np.abs(arr(im)[400:500, 20:120] - arr(src)[400:500, 20:120]).mean() < 4, "the rest of the photo must stay sharp"
    assert not detect_faces(cv2.cvtColor(np.array(im.convert("RGB")), cv2.COLOR_RGB2BGR)), "a face detector still finds the face"
    px = Image.open(run("blur_face", ["face.jpg"], {"style": "pixelate", "format": "png"})); assert var(px, box) != var(im, box)
    fs = unzip(run("passport_photo", ["face.jpg"], {"country": "india", "color": "#ffffff"}))
    one = Image.open(next(f for f in fs if "sheet" not in f.name)); sheet = Image.open(next(f for f in fs if "sheet" in f.name))
    assert one.size == (413, 531) and sheet.size == (1800, 1200) and sheet.info.get("dpi", (0,))[0] in (300, 300.0)
    assert near(one.getpixel((6, 6)), (255, 255, 255), 14) and near(one.getpixel((406, 6)), (255, 255, 255), 14), "background is not plain white"
    f2 = detect_faces(cv2.cvtColor(np.array(one), cv2.COLOR_RGB2BGR)); assert len(f2) == 1
    fx, fy, fw, fh = f2[0]
    assert abs((fx + fw / 2) - 413 / 2) < 30 and 0.5 < fh * 1.45 / 531 < 0.75 and fy > 40, "head is not centred at passport size"
    assert Image.open(next(f for f in unzip(run("passport_photo", ["face.jpg"], {"country": "us"})) if "sheet" not in f.name)).size == (602, 602)
    pr = Image.open(run("profile_photo", ["face.jpg"], {"color": "#2563eb", "size": 600}))
    assert pr.size == (600, 600) and pr.mode == "RGBA" and pr.getpixel((4, 4))[3] == 0 and pr.getpixel((300, 300))[3] == 255
    assert near(pr.getpixel((300, 14)), (37, 99, 235), 30) and len(detect_faces(cv2.cvtColor(np.array(pr.convert("RGB")), cv2.COLOR_RGB2BGR))) == 1
    sq = Image.open(run("profile_photo", ["face.jpg"], {"shape": "square", "color": "#ffffff", "color2": "#000000"})); assert sq.format == "JPEG" and sq.getpixel((790, 5))[0] > sq.getpixel((790, 260))[0] + 50, "gradient background missing"


def test_exam_photo():
    p = run("exam_photo", ["face.jpg"], {"preset": "ssc_photo"}); im = Image.open(p); im.load()
    assert im.size == (413, 531) and 20 * 1024 <= p.stat().st_size <= 50 * 1024 and im.format == "JPEG"
    p = run("exam_photo", ["signature_photo.jpg"], {"preset": "ssc_sign"}); im = Image.open(p); im.load()
    assert im.size == (472, 236) and 10 * 1024 <= p.stat().st_size <= 20 * 1024, p.stat().st_size
    p = run("exam_photo", ["face.jpg"], {"preset": "custom", "width": 300, "height": 400, "max_kb": 15}); assert Image.open(p).size == (300, 400) and p.stat().st_size <= 15 * 1024
    p = run("exam_photo", ["photo.png"], {"preset": "upsc_photo"})            # flat picture: tiny JPEG → padded up to the minimum the portal accepts
    im = Image.open(p); im.load(); assert im.size == (550, 550) and p.stat().st_size >= 20 * 1024
    assert p.read_bytes()[:4] == b"\xff\xd8\xff\xe0", "JFIF header must stay first"
    im = Image.open(run("exam_photo", ["face.jpg"], {"preset": "ibps_photo", "white_bg": True})); assert im.size == (200, 230) and near(im.getpixel((3, 3)), (255, 255, 255), 14)
    run("exam_photo", ["face.jpg"], {"preset": "custom", "width": 5, "height": 5}, expect=422)


# ------------------------------------------------------------------ watermark / meme / signature / OCR / scan
def test_watermark_meme():
    src = arr(SRC())
    a = arr(Image.open(run("img_watermark", ["photo.jpg"], {"text": "© Himalaya Textile", "position": "bottom-right", "opacity": 0.9})))
    d = np.abs(a - src).mean(axis=2); assert d[520:590, 450:880].mean() > 8 and d[0:300, 0:400].mean() < 2, "text watermark is not at the bottom right"
    a = arr(Image.open(run("img_watermark", ["photo.jpg"], {"text": "SAMPLE", "position": "tiled", "opacity": 0.5})))
    d = np.abs(a - src).mean(axis=2); assert all(d[y:y + 200, x:x + 300].mean() > 1.5 for y in (0, 200, 400) for x in (0, 300, 600)), "tiled watermark does not cover the picture"
    ids = up("photo.jpg", "_border.png")
    a = arr(Image.open(run("img_watermark", [ids[0]], {"image_file": ids[1], "position": "top-left", "opacity": 1, "img_scale": 0.3})))
    assert near(a[100, 150], (200, 30, 30), 40) and near(a[500, 800], GREEN), "logo watermark is missing"
    hi = arr(Image.open(run("img_watermark", ["photo.jpg"], {"text": "हिन्दी किताब", "position": "center", "opacity": 1, "size": 80, "color": "#ffffff"})))
    assert (np.abs(hi - src).mean(axis=2) > 60).sum() > 3000
    m = arr(Image.open(run("meme", ["face.jpg"], {"top": "when the pdf", "bottom": "finally opens"})))
    top, bottom, mid = m[5:70], m[440:505], m[200:300]
    white = lambda r: ((r > 245).all(axis=2)).mean()
    assert white(top) > 0.05 and white(bottom) > 0.05 and white(mid) < 0.02, "meme captions are not at the top and bottom"


def test_signature_clean():
    im = Image.open(run("signature_clean", ["signature_photo.jpg"], {"color": "#0b3fa6"})); a = np.asarray(im)
    assert im.mode == "RGBA" and im.width < 900 and a[2, 2, 3] == 0, "paper was not removed"
    ink = a[a[..., 3] > 200]; assert len(ink) > 3000 and near(ink.mean(axis=0), (11, 63, 166), 6), "ink colour is wrong"
    assert 0.02 < (a[..., 3] > 128).mean() < 0.5


def test_ocr_and_scan():
    pix = pdf(C / "letter.pdf")[0].get_pixmap(dpi=150); pix.save(C / "_letter.png")
    t = run("img_to_text", ["_letter.png"], {"lang": "eng"}).read_text()
    assert "Dear customer" in t and "fourteen working days" in t and "Regards" in t
    assert "Dear customer" in run("img_to_text", ["_letter.png"], {"lang": "eng; rm -rf /"}).read_text()      # odd input falls back to English
    p = run("scan_to_pdf", ["doc_photo.jpg"], {"mode": "color", "ocr": True, "lang": "eng"}); d = pdf(p)
    assert d.page_count == 1 and d[0].rect.height > d[0].rect.width * 1.15, "page was not cut out of the photo and straightened"
    t = text(p); assert sum(f"Invoice line {i}:" in t for i in range(1, 26)) >= 23, f"text of the photographed page is not readable: {t[:200]}"
    im = render(p, dpi=40); assert mean(im, (0.03, 0.02, 0.97, 0.05)) > 225 and mean(im) > 215, "dark table is still visible around the page"
    p2 = run("scan_to_pdf", ["doc_photo.jpg", "doc_photo.jpg"], {"mode": "bw", "ocr": False}); assert pdf(p2).page_count == 2
    info = pdf(p2).extract_image(pdf(p2)[0].get_images()[0][0]); assert info["bpc"] == 1 and p2.stat().st_size < 150_000, "black & white scan is not stored as a 1-bit picture"
    t = text(run("scan_to_pdf", ["doc_photo.jpg"], {"mode": "bw", "ocr": True, "lang": "eng"})); assert sum(f"Invoice line {i}:" in t for i in range(1, 26)) >= 23


def test_html_to_image():
    p = run("html_to_image", [], {"html": "<body style='margin:0;background:#c00'><h1 style='color:#fff'>Hello</h1></body>", "viewport": 800, "full_page": False})
    im = Image.open(p); assert im.size == (800, 800) and near(im.getpixel((700, 700)), (204, 0, 0), 4)
    p = run("html_to_image", [], {"html": "<div style='height:2000px;background:#00c'></div>", "viewport": 400, "format": "jpg"})
    im = Image.open(p); assert im.format == "JPEG" and im.width == 400 and im.height >= 2000
    for bad in ("http://localhost:8000/", "http://10.0.0.5/", "file:///etc/passwd"):
        run("html_to_image", [], {"url": bad}, expect=422)
    run("html_to_image", [], {}, expect=422)


# ------------------------------------------------------------------ object eraser
def _mask(kind):
    if kind == "bw":            # white = erase
        m = Image.new("L", (900, 600), 0); ImageDraw.Draw(m).rectangle((105, 365, 275, 535), fill=255)
    else:                        # what the brush in the browser sends: transparent canvas with red strokes
        m = Image.new("RGBA", (450, 300), (0, 0, 0, 0)); ImageDraw.Draw(m).rectangle((52, 182, 138, 268), fill=(255, 40, 40, 160))
    buf = io.BytesIO(); m.save(buf, "PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def test_erase_object():
    for kind in ("bw", "brush"):
        im = Image.open(run("img_erase", ["photo.png"], {"mask": _mask(kind)})); a = arr(im)
        region = a[390:510, 130:250].reshape(-1, 3)
        assert im.size == (900, 600) and near(region.mean(axis=0), GREEN, 22) and (np.abs(region - np.array(GREEN)).max(axis=1) < 70).mean() > 0.97, f"yellow square is still visible ({kind} mask)"
        assert near(a[300, 450], RED) and near(a[60, 60], GREEN), "the rest of the picture changed"
    from app import images_more
    saved = images_more.MODELS; images_more.MODELS = Path("/nonexistent")   # without the neural network: classic inpainting still does the job
    try:
        a = arr(Image.open(run("img_erase", ["photo.png"], {"mask": _mask("bw")}))); assert near(a[390:510, 130:250].reshape(-1, 3).mean(axis=0), GREEN, 25)
    finally:
        images_more.MODELS = saved
    # a real photo: remove the flag patch on the astronaut's suit – no hard edge may remain where the mask was
    m = Image.new("L", (512, 512), 0); ImageDraw.Draw(m).ellipse((30, 20, 150, 130), fill=255); buf = io.BytesIO(); m.save(buf, "PNG")
    out = Image.open(run("img_erase", ["face.jpg"], {"mask": "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode(), "format": "png"}))
    d = np.abs(arr(out) - arr(SRC("face.jpg"))).mean(axis=2)
    assert d[300:500, 300:500].mean() < 3 and d[40:110, 50:130].mean() > 4, "masked area was not repainted / untouched area changed"
    run("img_erase", ["photo.png"], {}, expect=422)
    empty = Image.new("RGBA", (90, 60), (0, 0, 0, 0)); buf = io.BytesIO(); empty.save(buf, "PNG")
    run("img_erase", ["photo.png"], {"mask": "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()}, expect=422)


# ------------------------------------------------------------------ small image utilities
def test_combine_split_shape():
    assert Image.open(run("img_combine", ["photo.jpg", "photo.png"], {"layout": "horizontal", "gap": 10})).size == (1830, 620)
    assert Image.open(run("img_combine", ["photo.jpg", "photo.png"], {"layout": "vertical", "gap": 10})).size == (920, 1230)
    im = Image.open(run("img_combine", ["photo.jpg", "face.jpg", "photo.png"], {"layout": "grid", "cols": 2, "cell": 300, "gap": 6, "background": "#000000", "format": "png"}))
    assert im.size == (2 * 300 + 3 * 6, 2 * 300 + 3 * 6) and near(im.getpixel((2, 2)), (0, 0, 0)) and near(im.getpixel((450, 450)), (0, 0, 0))
    run("img_combine", ["photo.jpg"], expect=422)
    fs = unzip(run("img_split", ["photo.png"], {"cols": 3, "rows": 3}))
    assert len(fs) == 9 and all(Image.open(f).size == (300, 200) for f in fs) and near(Image.open(fs[4]).getpixel((150, 100)), RED)
    im = Image.open(run("img_circle", ["photo.jpg"])); assert im.size == (600, 600) and im.mode == "RGBA" and im.getpixel((3, 3))[3] == 0 and im.getpixel((300, 300))[3] == 255
    im = Image.open(run("img_circle", ["photo.jpg"], {"shape": "rounded", "radius": 20})); assert im.size == (900, 600) and im.getpixel((2, 2))[3] == 0 and im.getpixel((450, 4))[3] == 255
    im = Image.open(run("img_circle", ["photo.jpg"], {"background": "#ff00ff"})); assert near(im.getpixel((3, 3)), (255, 0, 255))
    im = Image.open(run("img_border", ["photo.png"], {"width": 20, "color": "#112233"})); assert im.size == (940, 640) and near(im.getpixel((5, 5)), (17, 34, 51)) and near(im.getpixel((30, 30)), GREEN)
    assert Image.open(run("img_border", ["photo.png"], {"width": 20, "square": True})).size == (940, 940)


def test_gif_favicon_svg_palette():
    g = Image.open(run("gif_maker", ["photo.jpg", "photo.png", "face.jpg"], {"width": 300, "delay": 250}))
    assert g.format == "GIF" and g.n_frames == 3 and g.size == (300, 200) and g.info["duration"] == 250
    fs = {f.name: f for f in unzip(run("favicon", ["face.jpg"], {"name": "Himalaya"}))}
    assert {"favicon.ico", "favicon-16x16.png", "favicon-32x32.png", "apple-touch-icon.png", "android-chrome-192x192.png", "android-chrome-512x512.png", "site.webmanifest"} <= set(fs)
    assert {(16, 16), (32, 32), (48, 48)} <= Image.open(fs["favicon.ico"]).info["sizes"] and Image.open(fs["apple-touch-icon.png"]).size == (180, 180)
    assert json.loads(fs["site.webmanifest"].read_text())["name"] == "Himalaya"
    svg = run("img_to_svg", ["photo.png"]); root = ET.parse(svg).getroot()
    assert root.tag.endswith("svg") and len(list(root.iter("{http://www.w3.org/2000/svg}path"))) >= 3
    back = pymupdf.open(svg)[0].get_pixmap(); im = Image.frombytes("RGB", (back.width, back.height), back.samples).resize((900, 600))
    assert near(im.getpixel((450, 300)), RED, 40) and near(im.getpixel((190, 450)), YELLOW, 40) and near(im.getpixel((60, 60)), GREEN, 40), "vector drawing does not look like the picture"
    pal = Image.open(run("color_palette", ["photo.png"], {"count": 4})); assert pal.size == (4 * 140, 190)
    cols = [pal.getpixel((k * 140 + 70, 60)) for k in range(4)]
    assert near(cols[0], GREEN, 20) and any(near(c, RED, 25) for c in cols) and any(near(c, YELLOW, 25) for c in cols), cols


def test_metadata_dpi_idcard():
    md = run("img_metadata", ["phone_photo.jpg"], {"mode": "view"}).read_text()
    assert "TestPhone" in md and "GPS location is stored" in md and "900 × 600" in md
    p = run("img_metadata", ["phone_photo.jpg"], {"mode": "remove"}); im = Image.open(p)
    assert len(im.getexif()) == 0 and b"TestPhone" not in p.read_bytes() and b"Exif" not in p.read_bytes()[:2000], "private data is still in the file"
    assert im.size == (600, 900), "the photo must stay upright after its orientation tag is removed"
    p = run("img_dpi", ["photo.jpg"], {"dpi": 300}); im = Image.open(p); assert im.size == (900, 600) and tuple(round(v) for v in im.info["dpi"]) == (300, 300)
    assert Image.open(run("img_dpi", ["photo.jpg"], {"dpi": 144, "resample": True})).size == (1800, 1200)
    d = pdf(run("id_card_pdf", ["id_front.jpg", "id_back.jpg"], {"note": "Self attested – राहुल शर्मा"}))
    pg = d[0]; infos = pg.get_image_info()
    assert d.page_count == 1 and round(pg.rect.width) == 595 and len(infos) == 2
    for i in infos:
        r = pymupdf.Rect(i["bbox"]); assert 1.45 < r.width / r.height < 1.75 and abs(r.width - 85.6 / 25.4 * 72 * 1.6) < 2, "card is not straightened to ID-card shape"
    im = render(d.name if False else str(DATA / d.name) if False else pdf_path(d), dpi=50)
    assert mean(im) > 200, "dark table around the card was not removed"
    assert "Self attested" in pg.get_text() and (reader_text(pdf_path(d)) is None or "राहुल शर्मा" in reader_text(pdf_path(d)))


def pdf_path(d):
    return d.name


if __name__ == "__main__":
    sys.exit(1 if main(globals()) else 0)

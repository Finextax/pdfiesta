"""Builds a small corpus of realistic PDFs for the test-suite:  python tests/make_corpus.py [dir]"""
import io, os, subprocess, sys, random
from pathlib import Path
import pymupdf
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np

OUT = Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/pdfkaro_corpus"); OUT.mkdir(parents=True, exist_ok=True)
ROOT = Path(__file__).resolve().parent.parent

HTML = """<html><head><meta charset="utf-8"><style>
 body{font-family:'Liberation Sans',Arial,sans-serif;font-size:12pt;margin:20mm}
 h1{font-family:'Liberation Serif',serif;color:#1a3c8f} .two{column-count:2;column-gap:10mm;text-align:justify}
 table{border-collapse:collapse;width:100%} td,th{border:1px solid #888;padding:4px 8px} th{background:#e8eefc}
 .box{background:#fff3cd;padding:8px;border-left:4px solid #f0ad4e}
 footer{position:fixed;bottom:8mm;left:20mm;font-size:9pt;color:#666}
</style></head><body>
<h1>Quarterly Sales Report</h1>
<p>Prepared by <b>Ravi Sharma</b> for <i>Himalaya Textile</i> on 12 November 2026. Contact: <a href="https://example.com">example.com</a> or sales@example.com.</p>
<div class="box">Important: prices are <b>valid for 30 days</b> and exclude <span style="color:#c00">18% GST</span>.</div>
<h2>Summary</h2>
<div class="two"><p>Revenue grew strongly in the third quarter, driven by demand for cotton shirts and denim. Our stores in Mumbai, Pune and Delhi all reported double digit growth compared with the same period last year, and online orders doubled.</p>
<p>Costs remained under control. Logistics expenses fell by four percent after we consolidated two warehouses, while marketing spend was held flat. We expect the fourth quarter to benefit from the wedding season.</p></div>
<h2>Orders</h2>
<table><tr><th>Item</th><th>Qty</th><th>Rate</th><th>Amount</th></tr>
<tr><td>Cotton shirt</td><td>120</td><td>450.00</td><td>54,000.00</td></tr><tr><td>Denim jeans</td><td>80</td><td>1,150.00</td><td>92,000.00</td></tr><tr><td>Kurta set</td><td>45</td><td>1,999.00</td><td>89,955.00</td></tr></table>
<h2 style="font-family:'Noto Sans Devanagari'">हिन्दी अनुभाग</h2>
<p style="font-family:'Noto Sans Devanagari'">यह एक परीक्षण दस्तावेज़ है। कृपया भुगतान समय पर करें। धन्यवाद, विक्रय विभाग।</p>
<p dir="rtl" style="font-family:'Noto Naskh Arabic'">هذا مستند اختبار. شكرا لكم على تعاونكم.</p>
<footer>Himalaya Textile · Confidential · Page 1</footer>
</body></html>"""


def chrome():
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b = pw.chromium.launch(); p = b.new_page(); p.set_content(HTML)
        p.pdf(path=str(OUT / "chrome_report.pdf"), format="A4", print_background=True); b.close()


def word():
    import docx
    from docx.shared import Pt, RGBColor
    d = docx.Document()
    d.add_heading("Employment Agreement", 0)
    p = d.add_paragraph("This agreement is made between "); r = p.add_run("Himalaya Textile Pvt. Ltd."); r.bold = True
    p.add_run(" (the Employer) and "); r = p.add_run("Mr. Rahul Sharma"); r.italic = True; p.add_run(" (the Employee), effective 1 December 2026.")
    d.add_heading("1. Position", 1)
    d.add_paragraph("The Employee is appointed as Senior Merchandiser and shall report to the Head of Sales. The place of work is Mumbai. "
                    "The Employee agrees to devote full working time and attention to the business of the Employer.")
    d.add_heading("2. Salary", 1)
    t = d.add_table(rows=3, cols=3); t.style = "Table Grid"
    for i, row in enumerate([("Component", "Monthly (INR)", "Annual (INR)"), ("Basic", "45,000", "5,40,000"), ("HRA", "18,000", "2,16,000")]):
        for j, v in enumerate(row):
            t.cell(i, j).text = v
    d.add_paragraph("")
    d.add_paragraph("The salary will be reviewed every year in April. Statutory deductions apply.")
    d.add_heading("3. Notice", 1)
    d.add_paragraph("Either party may terminate this agreement by giving sixty days written notice.")
    d.add_page_break()
    d.add_heading("4. Confidentiality", 1)
    d.add_paragraph("The Employee shall not disclose confidential information of the Employer during or after employment.")
    for st in d.styles:
        try:
            if st.font and st.type == 1:
                pass
        except Exception:
            pass
    d.save(OUT / "word_doc.docx")
    subprocess.run(["soffice", "--headless", "--norestore", "--convert-to", "pdf", "--outdir", str(OUT), str(OUT / "word_doc.docx")],
                   check=True, capture_output=True, timeout=180, env=dict(os.environ, HOME=str(OUT)))


def letter():
    d = pymupdf.open(); p = d.new_page()
    css = "* {font-family: serif; font-size: 13px;} h2 {font-family: sans-serif; font-size: 18px;}"
    p.insert_htmlbox(pymupdf.Rect(60, 60, 540, 100), "<h2>Himalaya Textile - Quotation</h2>", css=css)
    p.insert_htmlbox(pymupdf.Rect(60, 110, 540, 200), "<p>Dear customer, thank you for your enquiry. We are pleased to offer the following cotton shirts at a special price valid for thirty days from the date of this letter.</p>", css=css)
    p.insert_htmlbox(pymupdf.Rect(60, 190, 540, 260), "<p>Delivery will be made within fourteen working days after receiving the advance payment. All goods are inspected before dispatch.</p>", css=css)
    p.insert_htmlbox(pymupdf.Rect(60, 250, 540, 290), "<p><b>Regards, Sales Team</b></p>", css=css)
    d.save(OUT / "letter.pdf"); return d


def scans(d):
    pg = d[0]
    pix = pg.get_pixmap(dpi=200)
    base = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
    W, H = base.size

    def page_from(img, name, fmt="JPEG", **kw):
        s = pymupdf.open(); sp = s.new_page(width=pg.rect.width, height=pg.rect.height)
        buf = io.BytesIO(); img.save(buf, fmt, **kw); sp.insert_image(sp.rect, stream=buf.getvalue()); s.save(OUT / name); return s

    page_from(base, "scan_clean.pdf", quality=85)
    # beige paper, uneven light, noise → inpainting must keep the texture
    rng = np.random.default_rng(1)
    arr = np.asarray(base).astype(np.float32)
    yy, xx = np.mgrid[0:H, 0:W]
    light = 0.82 + 0.18 * (xx / W) * (1 - 0.3 * yy / H)
    paper = np.array([238, 228, 205], np.float32)
    tex = (arr / 255.0) * paper * light[..., None] + rng.normal(0, 4, arr.shape)
    textured = Image.fromarray(np.clip(tex, 0, 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(0.6))
    page_from(textured, "scan_textured.pdf", quality=80)
    page_from(base.convert("L").point(lambda v: 255 if v > 150 else 0).convert("1"), "scan_bilevel.pdf", "PNG")
    subprocess.run(["ocrmypdf", "-l", "eng", "--output-type", "pdf", str(OUT / "scan_clean.pdf"), str(OUT / "scan_sandwich.pdf")], capture_output=True)
    # scan + real text stamped on top
    h = pymupdf.open(OUT / "scan_clean.pdf"); h[0].insert_text((330, 40), "Received on 14 November 2026 - Accounts", fontsize=10, color=(0.7, 0, 0))
    h.save(OUT / "scan_hybrid.pdf")
    # landscape scan stored with /Rotate 90
    r = pymupdf.open(); rp = r.new_page(width=pg.rect.width, height=pg.rect.height)
    buf = io.BytesIO(); base.rotate(90, expand=True).save(buf, "JPEG", quality=85)
    rp2 = r.new_page(width=pg.rect.height, height=pg.rect.width); rp2.insert_image(rp2.rect, stream=buf.getvalue()); rp2.set_rotation(90)
    r.delete_page(0); r.save(OUT / "scan_rotated.pdf")
    # scan cut into strips (some copiers do this)
    t = pymupdf.open(); tp = t.new_page(width=pg.rect.width, height=pg.rect.height)
    n = 6
    for k in range(n):
        strip = base.crop((0, k * H // n, W, (k + 1) * H // n)); buf = io.BytesIO(); strip.save(buf, "JPEG", quality=85)
        tp.insert_image(pymupdf.Rect(0, k * pg.rect.height / n, pg.rect.width, (k + 1) * pg.rect.height / n), stream=buf.getvalue())
    t.save(OUT / "scan_strips.pdf")


def variants(d):
    src = pymupdf.open(OUT / "letter.pdf"); r = pymupdf.open()   # stored sideways, /Rotate makes it display upright
    rp = r.new_page(width=842, height=595); rp.show_pdf_page(rp.rect, src, 0, rotate=90); rp.set_rotation(90); r.save(OUT / "letter_rot90.pdf")
    c = pymupdf.open(OUT / "letter.pdf"); c[0].set_cropbox(pymupdf.Rect(30, 40, 560, 500)); c.save(OUT / "letter_cropbox.pdf")
    # multi-page sample with bookmarks, a form and a picture
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.lib import colors
    cv = canvas.Canvas(str(OUT / "sample.pdf"), pagesize=A4); w, h = A4
    for i in range(1, 7):
        cv.bookmarkPage(f"p{i}"); cv.addOutlineEntry(f"Chapter {i}", f"p{i}", 0)
        cv.setFont("Helvetica-Bold", 24); cv.drawString(72, h - 100, f"Chapter {i}: Sample Heading")
        cv.setFont("Times-Roman", 12)
        for j in range(20):
            cv.drawString(72, h - 140 - j * 18, f"Line {j+1} of page {i}. Invoice number INV-{1000+i}. The quick brown fox jumps.")
        cv.setFillColor(colors.HexColor("#3a7bd5")); cv.rect(72, 120, 200, 120, fill=1); cv.setFillColor(colors.black)
        for rr, row in enumerate([["Item", "Qty", "Price"], ["Shirt", "2", "500"], ["Jeans", "1", "1200"]]):
            for k, v in enumerate(row):
                cv.drawString(320 + k * 70, 220 - rr * 20, v)
        if i == 1:
            cv.acroForm.textfield(name="fullname", x=320, y=280, width=200, height=20, tooltip="Name")
            cv.acroForm.checkbox(name="agree", x=320, y=250)
            cv.linkURL("https://example.com", (72, h - 110, 300, h - 80))
        cv.showPage()
    cv.save()
    import pikepdf
    with pikepdf.open(OUT / "sample.pdf") as pdf:
        pdf.save(OUT / "sample_encrypted.pdf", encryption=pikepdf.Encryption(user="open123", owner="owner123", R=6))
    data = (OUT / "sample.pdf").read_bytes()
    (OUT / "sample_damaged.pdf").write_bytes(data[: int(len(data) * 0.93)])  # cut off the xref table
    # photos for image tools
    im = Image.new("RGB", (900, 600), (70, 130, 90)); dr = ImageDraw.Draw(im)
    dr.ellipse((300, 120, 600, 480), fill=(230, 60, 50)); dr.rectangle((120, 380, 260, 520), fill=(250, 210, 60))
    im.save(OUT / "photo.jpg", quality=92); im.save(OUT / "photo.png")
    f = ImageFont.truetype(str(ROOT / "fonts/GreatVibes.ttf"), 140)
    sig = Image.new("RGB", (900, 400), (232, 228, 215)); ImageDraw.Draw(sig).text((80, 100), "Ravi S.", font=f, fill=(20, 25, 60))
    sig.filter(ImageFilter.GaussianBlur(1)).save(OUT / "signature_photo.jpg", quality=85)
    page = Image.new("RGB", (850, 1100), "white"); dd = ImageDraw.Draw(page); ft = ImageFont.truetype(str(ROOT / "fonts/LiberationSans-Regular.ttf"), 28)
    for i in range(25):
        dd.text((60, 60 + i * 40), f"Invoice line {i+1}: Cotton shirt qty {i+2} price {100+i*7}", font=ft, fill="black")
    bg = Image.new("RGB", (1400, 1600), (60, 50, 45)); bg.paste(page.rotate(8, expand=True, fillcolor=(60, 50, 45), resample=Image.BICUBIC), (180, 120)); bg.save(OUT / "doc_photo.jpg", quality=90)


def extras():
    """inputs for converters and image tools"""
    import openpyxl, zipfile
    from pptx import Presentation
    from pptx.util import Inches
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Orders"
    for row in [("Item", "Qty", "Rate"), ("Cotton shirt", 120, 450), ("Denim jeans", 80, 1150), ("Total", "=SUM(B2:B3)", "")]:
        ws.append(row)
    ws.column_dimensions["A"].width = 18
    wb.save(OUT / "sheet.xlsx")
    wb = openpyxl.Workbook(); ws = wb.active; ws.append([f"Column {i}" for i in range(1, 31)])
    for r in range(80):
        ws.append([r * i for i in range(1, 31)])
    wb.save(OUT / "wide.xlsx")
    prs = Presentation()
    for title, body in (("Sales Review 2026", "Himalaya Textile"), ("Targets", "Grow online orders by 40 percent")):
        sl = prs.slides.add_slide(prs.slide_layouts[1]); sl.shapes.title.text = title; sl.placeholders[1].text = body
    prs.save(OUT / "slides.pptx")
    (OUT / "notes.md").write_text("# Meeting notes\n\nDecisions for **Q4**:\n\n| Owner | Task |\n|---|---|\n| Ravi | Launch winter line |\n| Priya | Update price list |\n\n"
                                  "```\nprint('hello')\n```\n\nहिन्दी पंक्ति: कृपया समय पर आएँ।\n", encoding="utf-8")
    (OUT / "plain.txt").write_text("First line of the text file.\n    indented second line\n\nThird paragraph after a blank line.\n", encoding="utf-8")
    (OUT / "hello.ps").write_text("%!PS-Adobe-3.0\n/Helvetica findfont 24 scalefont setfont\n72 700 moveto (Hello PostScript) show\nshowpage\n")
    with zipfile.ZipFile(OUT / "bundle.zip", "w") as z:
        z.write(OUT / "letter.pdf", "docs/b_letter.pdf"); z.write(OUT / "photo.jpg", "a_photo.jpg"); z.write(OUT / "plain.txt", "c_plain.txt")
        z.write(OUT / "word_doc.docx", "d_contract.docx"); z.writestr("../../evil.txt", "should never leave the job folder"); z.writestr("__MACOSX/._junk", "x")
    # a phone photo: stored sideways (EXIF orientation 6) with GPS position
    im = Image.open(OUT / "photo.jpg"); ex = im.getexif(); ex[0x0112] = 6; ex[0x010F] = "TestPhone"; ex[0x0110] = "Model X"
    gps = ex.get_ifd(0x8825); gps[1] = "N"; gps[2] = (19.0, 4.0, 33.6); gps[3] = "E"; gps[4] = (72.0, 52.0, 39.0)
    im.save(OUT / "phone_photo.jpg", exif=ex, quality=90)
    # ID card lying on a dark table, slightly turned
    card = Image.new("RGB", (856, 540), (245, 245, 240)); dc = ImageDraw.Draw(card); ft = ImageFont.truetype(str(ROOT / "fonts/LiberationSans-Bold.ttf"), 34)
    dc.rectangle((0, 0, 855, 90), fill=(20, 60, 140)); dc.text((30, 25), "IDENTITY CARD", font=ft, fill="white")
    dc.rectangle((40, 140, 240, 400), fill=(170, 180, 190)); dc.text((280, 160), "Name: Rahul Sharma", font=ft, fill="black"); dc.text((280, 230), "No: 1234 5678 9012", font=ft, fill="black")
    table = Image.new("RGB", (1400, 1000), (40, 36, 34)); table.paste(card.rotate(6, expand=True, fillcolor=(40, 36, 34), resample=Image.BICUBIC), (250, 180)); table.save(OUT / "id_front.jpg", quality=90)
    table = Image.new("RGB", (1400, 1000), (40, 36, 34)); table.paste(card.rotate(-4, expand=True, fillcolor=(40, 36, 34), resample=Image.BICUBIC), (230, 200)); table.save(OUT / "id_back.jpg", quality=90)
    try:   # a real face (NASA portrait of Eileen Collins – public domain – ships with scikit-image); face tests are skipped without it
        from skimage import data
        Image.fromarray(data.astronaut()).save(OUT / "face.jpg", quality=92)
    except Exception as e:
        print("no face photo (pip install scikit-image to test face tools):", e)
    # documents for 'compare' and 'remove blank pages'
    for name, txt in (("cmp_a.pdf", "The price is 450 rupees per shirt. Delivery in 14 days."), ("cmp_b.pdf", "The price is 475 rupees per shirt. Delivery in 10 days. Thank you.")):
        d = pymupdf.open(); d.new_page().insert_text((72, 100), txt, fontsize=12); d.save(OUT / name)
    d = pymupdf.open(OUT / "sample.pdf"); d.new_page(pno=2); d.new_page(); d.save(OUT / "with_blanks.pdf")
    # a PDF that carries things a reader never sees
    d = pymupdf.open(OUT / "sample.pdf"); d.embfile_add("secret.txt", b"internal notes", filename="secret.txt")
    d.set_metadata({"title": "Internal draft", "author": "Someone Private", "keywords": "secret"})
    js = d.get_new_xref(); d.update_object(js, "<</S/JavaScript/JS(app.alert\\('hi'\\))>>"); d.xref_set_key(d.pdf_catalog(), "OpenAction", f"{js} 0 R")
    d.save(OUT / "dirty.pdf")


if __name__ == "__main__":
    chrome(); word(); d = letter(); scans(d); variants(d); extras()
    print("corpus:", sorted(p.name for p in OUT.iterdir()))

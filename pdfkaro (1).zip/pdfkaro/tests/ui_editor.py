"""Browser test of the PDF editor – every flow a visitor uses, checked in the downloaded PDF
(needs a running server, Playwright and the test corpus):
       CORPUS=/tmp/pdfkaro_corpus python tests/ui_editor.py http://127.0.0.1:8000 [test name …]"""
import os, re, subprocess, sys, tempfile, time, traceback
from pathlib import Path
import pymupdf
from playwright.sync_api import sync_playwright

C = Path(os.environ.get("CORPUS", "/tmp/pdfkaro_corpus"))
BASE = sys.argv[1].rstrip("/") if len(sys.argv) > 1 else "http://127.0.0.1:8000"
ONLY = sys.argv[2:]
TMP = Path(tempfile.mkdtemp(prefix="pk_ui_"))


def reader_text(p):
    """text as another PDF reader (Poppler) sees it"""
    return " ".join(subprocess.run(["pdftotext", "-enc", "UTF-8", str(p), "-"], capture_output=True, text=True).stdout.split())


class Ed:
    def __init__(self, ctx, file=None, mode="pdf-editor", url=None):
        self.p = p = ctx.new_page(); self.errors = []
        p.on("pageerror", lambda e: self.errors.append("JS: " + str(e)[:300]))
        p.on("console", lambda m: self.errors.append("console: " + m.text[:300]) if m.type == "error" else None)
        p.goto(url or f"{BASE}/edit?mode={mode}", wait_until="networkidle")
        if file:
            p.set_input_files("#fi", str(C / file))
            p.wait_for_selector("#editor:not(.hidden)", timeout=60000)
            self.settle()

    def settle(self, page=0):
        """wait until nothing is being saved and the page picture + text model are there"""
        p = self.p
        p.wait_for_function("document.querySelector('#busy').classList.contains('hidden')", timeout=120000)
        p.wait_for_function(f"(() => {{ const pg = document.querySelector('.pg[data-p=\"{page}\"]'); const i = pg && pg.querySelector('.pimg'); return i && i.complete && i.naturalWidth > 0 && !pg.querySelector('.wait') && !document.querySelector('.ed.saving'); }})()", timeout=120000)
        p.wait_for_timeout(250)

    def block(self, text, page=0):
        """the clickable area of the text block that contains `text`"""
        self.p.wait_for_function(f"[...document.querySelectorAll('.pg[data-p=\"{page}\"] .blk')].some((b) => b._b.text.includes({text!r}))", timeout=120000)
        return self.p.evaluate_handle(f"[...document.querySelectorAll('.pg[data-p=\"{page}\"] .blk')].find((b) => b._b.text.includes({text!r}))").as_element()

    def edit(self, text, page=0):
        self.p.click('#toolbar [data-tool="select"]')
        el = self.block(text, page); el.scroll_into_view_if_needed(); el.click()
        self.p.wait_for_selector(".ed[contenteditable=true]", timeout=10000)

    def done(self, page=0):
        self.p.click('#ftb [data-cmd="done"]')
        self.p.wait_for_selector(".ed", state="detached", timeout=120000)
        self.settle(page)

    def point(self, x, y, page=0):
        """page coordinates (PDF points) → screen coordinates"""
        k = float(self.p.evaluate("document.querySelector('#zlabel').textContent").strip("%")) / 100
        self.p.evaluate(f"(() => {{ const r = document.querySelector('.pg[data-p=\"{page}\"] .ov').getBoundingClientRect(); scrollBy(0, r.top + {y * k} - innerHeight / 2); }})()")
        self.p.wait_for_timeout(60)
        bb = self.p.evaluate(f"(() => {{ const r = document.querySelector('.pg[data-p=\"{page}\"] .ov').getBoundingClientRect(); return [r.left, r.top]; }})()")
        return bb[0] + x * k, bb[1] + y * k

    def click_at(self, x, y, page=0):
        self.p.mouse.click(*self.point(x, y, page))

    def drag(self, x0, y0, x1, y1, page=0, steps=8):
        a = self.point(x0, y0, page); k = float(self.p.evaluate("document.querySelector('#zlabel').textContent").strip("%")) / 100
        b = (a[0] + (x1 - x0) * k, a[1] + (y1 - y0) * k)
        self.p.mouse.move(*a); self.p.mouse.down(); self.p.mouse.move(*b, steps=steps); self.p.mouse.up()
        self.p.wait_for_timeout(120)

    def menu(self, name, item):
        self.p.click(f'#toolbar [data-menu="{name}"]'); self.p.click(f'#menu button:has-text("{item}")')

    def objects(self):
        return self.p.evaluate("import('/static/js/editor-core.js').then((m) => m.S.objects.map((o) => o.type))")

    def state(self, expr):
        return self.p.evaluate(f"import('/static/js/editor-core.js').then((m) => {{ const S = m.S; return {expr}; }})")

    def download(self, name="out.pdf"):
        p = self.p
        p.click("#apply")
        p.wait_for_selector("#dlg.on a.btn.primary", timeout=180000)
        with p.expect_download(timeout=60000) as dl:
            p.click("#dlg.on a.btn.primary")
        dst = TMP / f"{time.time_ns()}_{name}"; dl.value.save_as(dst)
        p.click('#dlg.on button:has-text("Keep editing")')
        return dst

    def ok(self):
        assert not self.errors, self.errors[:3]


# ------------------------------------------------------------------ tests
def test_edit_text_and_undo(ctx):
    e = Ed(ctx, "chrome_report.pdf")
    e.edit("Summary"); e.p.keyboard.press("Control+a"); e.p.keyboard.type("Overview"); e.done()
    e.edit("Revenue grew strongly"); e.p.keyboard.press("Control+End"); e.p.keyboard.type(" This sentence was added in the browser and makes the paragraph longer than before."); e.done()
    d = pymupdf.open(e.download()); t = " ".join(d[0].get_text().split())
    assert "Overview" in t and "Summary" not in t and "added in the browser" in t and "Orders" in t and "Costs remained under control" in t, t[:400]
    assert e.state("S.version") == 2 and e.state("S.hist.length") == 3
    e.p.click("#undo"); e.settle(); e.p.click("#undo"); e.settle()
    t = " ".join(pymupdf.open(e.download())[0].get_text().split())
    assert "Summary" in t and "Overview" not in t and "added in the browser" not in t
    e.p.click("#redo"); e.settle()
    t = " ".join(pymupdf.open(e.download())[0].get_text().split())
    assert "Overview" in t and "added in the browser" not in t
    # cancel leaves the page alone, Escape too
    e.edit("Orders"); e.p.keyboard.type("XYZ"); e.p.keyboard.press("Escape"); e.p.wait_for_selector(".ed", state="detached")
    assert e.state("S.version") == 1
    e.ok()


def test_hindi_and_formatting(ctx):
    e = Ed(ctx, "chrome_report.pdf")
    e.edit("हिन्दी अनुभाग"); e.p.keyboard.press("Control+a"); e.p.keyboard.insert_text("नया शीर्षक – किताबें"); e.done()
    # bold + colour + bigger on a whole block (no selection = whole block)
    e.edit("Important: prices"); e.p.click('#ftb [data-cmd="i"]'); e.p.click('#ftb [data-cmd="bigger"]')
    e.p.fill("#fcolor", "#0000ff"); e.p.dispatch_event("#fcolor", "input"); e.done()
    out = e.download(); d = pymupdf.open(out)
    assert "नया शीर्षक – किताबें" in reader_text(out), reader_text(out)[-300:]
    spans = [s for b in d[0].get_text("dict")["blocks"] for l in b.get("lines", []) for s in l["spans"] if "prices are" in s["text"]]
    assert spans and spans[0]["flags"] & 2 and spans[0]["color"] == 0x0000FF, spans[:1]
    # change only the selected word: double-click selects a word
    e.edit("Costs remained"); el = e.p.locator(".ed"); bb = el.bounding_box()
    e.p.mouse.dblclick(bb["x"] + 30, bb["y"] + 10); e.p.click('#ftb [data-cmd="b"]'); e.done()
    d = pymupdf.open(e.download())
    bold = [s["text"] for b in d[0].get_text("dict")["blocks"] for l in b.get("lines", []) for s in l["spans"] if s["flags"] & 16 and "Costs" in s["text"]]
    plain = [s["text"] for b in d[0].get_text("dict")["blocks"] for l in b.get("lines", []) for s in l["spans"] if not s["flags"] & 16 and "remained" in s["text"]]
    assert bold and plain, (bold, plain)
    e.ok()


def test_add_things(ctx):
    e = Ed(ctx, "sample.pdf")
    p = e.p
    p.click('#toolbar [data-tool="text"]'); e.click_at(300, 700); p.wait_for_selector(".obj.txt.editing"); p.keyboard.type("Added by the browser test"); p.keyboard.press("Control+Enter")
    p.click('#toolbar [data-tool="text"]'); e.click_at(80, 740); p.wait_for_selector(".obj.txt.editing"); p.keyboard.insert_text("हस्ताक्षर यहाँ करें"); e.click_at(500, 800)
    e.menu("shape", "Rectangle"); e.drag(60, 600, 200, 660)
    e.menu("shape", "Arrow"); e.drag(220, 610, 320, 650)
    e.menu("shape", "Ellipse"); e.drag(340, 600, 420, 660)
    e.menu("annot", "Highlight"); e.drag(70, 118, 260, 128)
    e.menu("annot", "Draw"); e.drag(450, 600, 520, 640); e.drag(520, 640, 450, 660)
    e.menu("annot", "Note"); e.click_at(540, 60); p.fill("#dlgbox textarea", "Please check this page"); p.click('#dlgbox button:has-text("Save")')
    p.click('#toolbar [data-tool="whiteout"]'); e.drag(68, 78, 310, 112)                       # the heading "Chapter 1: Sample Heading"
    p.click('#toolbar [data-tool="link"]'); e.drag(60, 680, 200, 700); p.fill("#dlgbox input[type=text]", "example.org/page"); p.click('#dlgbox button:has-text("Save")')
    e.menu("form", "Tick"); e.click_at(400, 720)
    p.set_input_files("#imgfile", str(C / "photo.png")); e.click_at(480, 740)
    kinds = e.objects()
    assert sorted(kinds) == sorted(["add_text", "add_text", "rect", "arrow", "ellipse", "highlight", "ink", "note", "whiteout", "link", "add_text", "image"]), kinds
    # move the rectangle, resize it, change its colour, duplicate, delete the duplicate
    p.click('#toolbar [data-tool="select"]'); e.drag(61, 630, 81, 640)
    assert abs(e.state("S.objects.find((o) => o.type === 'rect').rect[0]") - 80) < 3
    p.fill("#ofill", "#00ff00"); p.dispatch_event("#ofill", "input"); p.dispatch_event("#ofill", "change")
    p.click('#otb [data-ocmd="dup"]'); assert e.objects().count("rect") == 2
    p.keyboard.press("Delete"); assert e.objects().count("rect") == 1
    p.keyboard.press("Control+z"); assert e.objects().count("rect") == 2
    p.keyboard.press("Control+z"); assert e.objects().count("rect") == 1
    out = e.download(); d = pymupdf.open(out); pg = d[0]; t = pg.get_text()
    assert "Added by the browser test" in t and "Chapter 1: Sample Heading" not in t and "Line 3 of page 1" in t, t[:300]
    assert "हस्ताक्षर यहाँ करें" in reader_text(out)
    types = sorted(a.type[1] for a in pg.annots())
    assert types == ["Highlight", "Ink", "Text"], types
    assert any(l.get("uri") == "https://example.org/page" for l in pg.get_links()), pg.get_links()
    assert len(pg.get_images()) >= 1 and "✓" in t
    fills = [dr for dr in pg.get_drawings() if dr.get("fill") and abs(dr["fill"][1] - 1) < .01 and dr["fill"][0] < .01]
    assert fills, "green rectangle missing"
    e.ok()


def test_signature_and_forms(ctx):
    e = Ed(ctx, "sample.pdf", mode="fill-sign")
    p = e.p
    p.wait_for_selector(".xfield input[type=text]", timeout=30000)
    p.fill(".xfield input[type=text]", "Ravi Sharma"); p.dispatch_event(".xfield input[type=text]", "change")
    p.check(".xfield input[type=checkbox]")
    # typed signature
    e.menu("sign", "New signature"); p.click('#sigtabs [data-t="type"]'); p.fill("#signame", "Ravi Sharma"); p.click("#sigsave")
    p.wait_for_function("document.querySelector('#hint').textContent.length > 0"); e.click_at(420, 760)
    # drawn signature
    e.menu("sign", "New signature"); p.click('#sigtabs [data-t="draw"]'); bb = p.locator("#sigpad").bounding_box()
    p.mouse.move(bb["x"] + 40, bb["y"] + 120); p.mouse.down()
    for i in range(1, 30):
        p.mouse.move(bb["x"] + 40 + i * 12, bb["y"] + 100 + (30 if i % 2 else -30))
    p.mouse.up(); p.click("#sigsave"); p.wait_for_function("document.querySelector('#hint').textContent.length > 0"); e.click_at(150, 760)
    e.menu("sign", "Today's date"); e.click_at(300, 800)
    assert e.objects().count("signature") == 2 and e.objects().count("add_text") == 1, e.objects()
    assert p.evaluate("JSON.parse(localStorage.getItem('pk_sigs')).length") == 2
    d = pymupdf.open(e.download()); pg = d[0]
    w = {x.field_name: x.field_value for x in pg.widgets()}
    assert w["fullname"] == "Ravi Sharma" and w["agree"] not in (False, "Off", None, ""), w
    assert len(pg.get_images()) >= 2 and re.search(r"\d{2}[./-]\d{2}[./-]\d{4}", pg.get_text()), pg.get_text()[-200:]
    e.ok()


def test_pages_find_replace(ctx):
    e = Ed(ctx, "sample.pdf")
    p = e.p
    assert p.locator(".pg").count() == 6
    p.click('.pg[data-p="0"] .pbar button[title="Rotate right"]'); e.settle()
    assert e.state("S.sizes[0][0] > S.sizes[0][1]")
    p.click('.pg[data-p="0"] .pbar button[title="Add a blank page after this one"]'); e.settle(); assert p.locator(".pg").count() == 7
    p.click('.pg[data-p="2"] .pbar button[title="Delete this page"]'); e.settle(2); assert p.locator(".pg").count() == 6      # the view stays where the reader was
    p.click("#findbtn"); p.fill("#findq", "quick brown fox"); p.fill("#findr", "swift red fox"); p.click("#findok")
    p.wait_for_function("document.querySelector('#findcount').textContent.includes('replaced')", timeout=180000)
    n = int(re.search(r"\d+", p.text_content("#findcount")).group()); assert n == 80, n     # 4 upright pages × 20 lines (text of the turned page runs sideways and is left alone)
    p.click('#findmodal [data-close]')
    d = pymupdf.open(e.download())
    assert d.page_count == 6 and d[0].rect.width > d[0].rect.height and not d[1].get_text().strip() and "Chapter 3" in d[2].get_text()
    allt = " ".join(pg.get_text() for pg in d)
    assert allt.count("swift red fox") == 80 and "Chapter 2" not in allt
    p.click("#undo"); e.settle(2); p.click("#undo"); e.settle(2)                              # the replacement and the deletion are taken back
    assert p.locator(".pg").count() == 7
    d = pymupdf.open(e.download()); assert d.page_count == 7 and "quick brown fox" in d[2].get_text() and "Chapter 2" in d[2].get_text()
    e.ok()


def test_scanned_page(ctx):
    e = Ed(ctx, "scan_clean.pdf")
    p = e.p
    first = p.evaluate("new Promise((res) => { const t = setInterval(() => { const b = document.querySelector('.pg[data-p=\"0\"] .blk'); if (b) { clearInterval(t); res(b._b.text); } }, 200); })")
    words = first.split()
    e.edit(words[0]); p.keyboard.press("Control+a"); p.keyboard.type("Replaced heading of the scan"); e.done()
    assert e.state("S.version") == 1
    out = e.download(); d = pymupdf.open(out)
    assert "Replaced heading of the scan" in d[0].get_text(), d[0].get_text()[:200]
    assert d[0].get_images(), "the scanned page must still be a picture"
    e.ok()


def test_existing_picture_and_comment(ctx):
    e = Ed(ctx, "_withimg.pdf")
    p = e.p
    p.wait_for_selector(".ximg", timeout=30000)
    n0 = len(pymupdf.open(C / "_withimg.pdf")[0].get_image_info())
    box = p.evaluate("(() => { const b = document.querySelector('.ximg')._im.bbox; return b; })()")
    cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
    e.drag(cx, cy, cx + 60, cy + 40); e.settle()
    assert e.state("S.version") == 1
    d = pymupdf.open(e.download()); info = d[0].get_image_info()
    assert len(info) == n0 and any(abs(i["bbox"][0] - (box[0] + 60)) < 4 and abs(i["bbox"][1] - (box[1] + 40)) < 4 for i in info), (box, [i["bbox"] for i in info])
    # delete it
    p.wait_for_selector(".ximg"); b2 = p.evaluate("document.querySelector('.ximg')._im.bbox")
    e.click_at((b2[0] + b2[2]) / 2, (b2[1] + b2[3]) / 2); p.click('#otb [data-ocmd="delete"]'); e.settle()
    d = pymupdf.open(e.download()); assert len(d[0].get_image_info()) == n0 - 1
    e.ok()
    e2 = Ed(ctx, "_annotated.pdf"); p = e2.p
    p.wait_for_selector(".xannot", timeout=30000)
    n = len(list(pymupdf.open(C / "_annotated.pdf")[0].annots()))
    p.locator(".xannot .adel").first.click(); p.click('#dlgbox button:has-text("Delete")'); e2.settle()
    d = pymupdf.open(e2.download()); assert len(list(d[0].annots())) == n - 1
    e2.ok()


def test_request_signature(ctx):
    e = Ed(ctx, "letter.pdf", mode="esign")
    p = e.p
    p.click("#reqsign"); p.fill("#dlgbox input[type=text]", "Supply agreement"); p.fill("#dlgbox textarea", "Please sign on the last line.")
    p.click('#dlgbox button:has-text("Create signing link")')
    p.wait_for_selector("#dlg.on .sharebox input", timeout=120000)
    url = p.input_value("#dlg.on .sharebox input"); assert "/sign/" in url, url
    link = BASE + "/sign/" + url.rsplit("/", 1)[1]
    s = Ed(ctx, url=link); sp = s.p
    sp.wait_for_selector("#editor:not(.hidden)", timeout=60000); s.settle()
    assert sp.is_visible("#signbar") and not sp.is_visible("#apply") and not sp.is_visible('#toolbar [data-tool="whiteout"]')
    s.menu("sign", "New signature"); sp.click('#sigtabs [data-t="type"]'); sp.fill("#signame", "Priya Nair"); sp.click("#sigsave")
    sp.wait_for_function("document.querySelector('#hint').textContent.length > 0"); s.click_at(300, 500)
    sp.click("#sgdone"); assert sp.is_visible("#signbar")                                       # name and consent are required
    sp.fill("#sgname", "Priya Nair"); sp.fill("#sgmail", "priya@example.com"); sp.check("#sgok"); sp.click("#sgdone")
    sp.wait_for_selector("#drop a.btn.primary", timeout=180000)
    with sp.expect_download() as dl:
        sp.click("#drop a.btn.primary")
    out = TMP / "signed.pdf"; dl.value.save_as(out)
    d = pymupdf.open(out); n = pymupdf.open(C / "letter.pdf").page_count
    cert = d[-1].get_text()
    assert d.page_count == n + 1 and "Signature certificate" in cert and "Priya Nair" in cert and "priya@example.com" in cert
    assert d.get_sigflags() == 3 or any(w.field_type == pymupdf.PDF_WIDGET_TYPE_SIGNATURE for pg in d for w in pg.widgets()), "no digital seal"
    s.ok()
    again = Ed(ctx, url=link)                                                                    # the link now shows the signed state
    again.p.wait_for_selector("#drop a.btn.primary"); assert "signed" in again.p.text_content("#drop").lower()
    e.ok()


def test_phone(ctx_phone):
    e = Ed(ctx_phone, "chrome_report.pdf")
    p = e.p
    w = p.evaluate("[document.documentElement.scrollWidth, innerWidth]"); assert w[0] <= w[1] + 2, w
    el = e.block("Summary"); el.scroll_into_view_if_needed(); el.tap()
    p.wait_for_selector(".ed[contenteditable=true]"); p.keyboard.press("Control+a"); p.keyboard.type("Phone edit"); e.done()
    p.click('#toolbar [data-tool="text"]'); bb = p.locator('.pg[data-p="0"]').bounding_box()
    p.touchscreen.tap(bb["x"] + bb["width"] * .5, bb["y"] + 40); p.wait_for_selector(".obj.txt.editing"); p.keyboard.type("Tapped"); p.click('#ftb [data-cmd="done"]')
    t = pymupdf.open(e.download())[0].get_text()
    assert "Phone edit" in t and "Tapped" in t and "Summary" not in t
    e.ok()


TESTS = {k: v for k, v in globals().items() if k.startswith("test_")}
bad = 0
with sync_playwright() as pw:
    b = pw.chromium.launch()
    for name, fn in TESTS.items():
        if ONLY and not any(o in name for o in ONLY):
            continue
        phone = "phone" in name
        # bypass_csp: this test waits with page.wait_for_function, which Playwright runs through eval – the site's security policy forbids eval.
        # (tests/ui_pages.py opens the editor with the policy enforced.)
        ctx = (b.new_context(**pw.devices["Pixel 7"], accept_downloads=True, bypass_csp=True) if phone
               else b.new_context(viewport={"width": 1280, "height": 900}, accept_downloads=True, bypass_csp=True))
        t0 = time.time()
        try:
            fn(ctx); print(f"PASS {name} ({time.time() - t0:.1f}s)", flush=True)
        except Exception as ex:
            bad += 1; tb = traceback.extract_tb(ex.__traceback__)
            mine = [f for f in tb if f.filename == __file__ and f.name.startswith("test_")]
            print(f"FAIL {name}: {type(ex).__name__}: {str(ex)[:500]}\n     line {mine[-1].lineno if mine else '?'}: {(mine[-1].line if mine else '')[:200]}", flush=True)
            try:
                for i, pg in enumerate(ctx.pages):
                    pg.screenshot(path=f"/tmp/pk_fail_{name}_{i}.png")
            except Exception:
                pass
        ctx.close()
    b.close()
print("\nALL EDITOR UI TESTS PASSED" if not bad else f"\n{bad} FAILED")
sys.exit(1 if bad else 0)

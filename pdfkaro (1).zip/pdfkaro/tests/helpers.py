"""Shared helpers for the test-suite (works with `python tests/run_all.py` and with pytest)."""
import io, json, os, sys, tempfile, zipfile, re, threading, http.server
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
C = Path(os.environ.get("CORPUS", "/tmp/pdfkaro_corpus"))
os.environ.setdefault("PDFKARO_DATA", tempfile.mkdtemp(prefix="pdfkaro_test_"))
os.environ["FREE_GUEST_PER_DAY"] = "1000000"; os.environ["FREE_MAX_FILES"] = "50"; os.environ["FREE_MAX_PAGES"] = "100000"
os.environ["UPLOADS_PER_10MIN"] = "1000000"; os.environ["FREE_AI_PER_DAY"] = "1000000"
os.environ.setdefault("NO_PROXY", "127.0.0.1,localhost"); os.environ.setdefault("no_proxy", "127.0.0.1,localhost")
import logging, warnings
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)

import pymupdf, pikepdf
from PIL import Image
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)
DATA = Path(os.environ["PDFKARO_DATA"])


def up(*names):
    r = client.post("/api/upload", files=[("files", (Path(n).name, open(C / n, "rb"))) for n in names])
    assert r.status_code == 200, r.text
    return [m["id"] for m in r.json()]


def run(tool, files, opts=None, expect=200):
    ids = up(*files) if files and isinstance(files[0], str) and (C / files[0]).exists() else list(files)
    r = client.post("/api/task", json={"tool": tool, "files": ids, "options": opts or {}})
    assert r.status_code == expect, f"{tool}: HTTP {r.status_code} {r.text[:300]}"
    if expect != 200:
        return r.json()
    j = r.json()
    p = DATA / j["task"] / j["name"]
    assert p.exists() and p.stat().st_size > 0, f"{tool}: empty result"
    return p


def pdf(p, pw=None):
    d = pymupdf.open(p)
    if d.needs_pass:
        assert d.authenticate(pw or ""), "cannot open result"
    return d


def text(p, page=None):
    d = pdf(p)
    return " ".join((d[page].get_text() if page is not None else " ".join(pg.get_text() for pg in d)).split())


def unzip(p):
    z = zipfile.ZipFile(p)
    d = Path(tempfile.mkdtemp()); z.extractall(d)
    return sorted(d.iterdir())


def render(p, page=0, dpi=40, clip=None):
    pix = pdf(p)[page].get_pixmap(dpi=dpi, clip=clip)
    return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)


def mean(im, box=None):
    """average brightness (0–255) of an image / a region given in fractions of the picture."""
    if box:
        im = im.crop((int(box[0] * im.width), int(box[1] * im.height), int(box[2] * im.width), int(box[3] * im.height)))
    g = im.convert("L"); px = list(g.getdata())
    return sum(px) / max(1, len(px))


def actual_text(p, page=0):
    """the /ActualText strings of a page, in drawing order – this is what Acrobat, Chrome, Edge and Firefox copy and search
    for Hindi / Indic text (the glyphs themselves are reordered and cannot be read back letter by letter)."""
    d = pdf(p); pg = d[page]; out = []
    for x in [c for c in pg.get_contents()] + [xo[0] for xo in pg.get_xobjects()]:
        try:
            st = d.xref_stream(x) or b""
        except Exception:
            continue
        for h in re.findall(rb"/ActualText\s*<FEFF([0-9A-Fa-f]*)>", st):
            out.append(bytes.fromhex(h.decode()).decode("utf-16-be"))
    return out


def reader_text(p, page=0):
    """page text as other programs see it (Poppler's pdftotext, the engine of many PDF viewers) – None if it is not installed"""
    import shutil, subprocess
    if not shutil.which("pdftotext"):
        return None
    r = subprocess.run(["pdftotext", "-f", str(page + 1), "-l", str(page + 1), str(p), "-"], capture_output=True, text=True)
    return " ".join(r.stdout.split())


_ai = {}


def mock_ai():
    """A tiny OpenAI-compatible server on localhost – lets the AI tools be tested end-to-end without a paid key."""
    if _ai:
        return _ai["calls"]
    calls = []

    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_POST(self):
            body = json.loads(self.rfile.read(int(self.headers["content-length"])))
            prompt = body["messages"][-1]["content"]; calls.append(prompt)
            if "Translate each item of this JSON array" in prompt:
                items = json.loads(prompt.rsplit("\n\n", 1)[1])
                ans = json.dumps(["यह अनुवादित पाठ है " + re.sub(r"[^0-9 ]", "", t)[:12].strip() for t in items], ensure_ascii=False)
            elif "Extract these fields" in prompt:
                ans = 'Here you go:\n{"Invoice number": "INV-1001", "Total": "1700"}'
            elif "Translate this text" in prompt:
                ans = "नमस्ते दुनिया"
            else:
                ans = "## Mock answer\n\n- The document has six chapters (p. 1).\n- Invoice numbers start at INV-1001 (p. 1)."
            data = json.dumps({"choices": [{"message": {"role": "assistant", "content": ans}}]}).encode()
            self.send_response(200); self.send_header("content-type", "application/json"); self.send_header("content-length", str(len(data))); self.end_headers()
            self.wfile.write(data)

    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    os.environ["OPENAI_BASE_URL"] = f"http://127.0.0.1:{srv.server_port}/v1"; os.environ.pop("ANTHROPIC_API_KEY", None)
    _ai["calls"] = calls
    return calls


def main(g):
    import traceback
    only = [a for a in sys.argv[1:] if not a.startswith("-")]
    ok = bad = 0
    for name, t in sorted(g.items()):
        if not (name.startswith("test_") and callable(t)) or (only and not any(o in name for o in only)):
            continue
        try:
            t(); ok += 1; print(f"PASS {name}", flush=True)
        except Exception as e:
            bad += 1; print(f"FAIL {name}: {type(e).__name__}: {str(e)[:400]}", flush=True)
            tb = [f for f in traceback.extract_tb(e.__traceback__) if "test_" in Path(f.filename).name]
            if tb:
                print(f"     line {tb[-1].lineno}: {tb[-1].line[:200]}", flush=True)
            elif os.environ.get("TB"):
                traceback.print_exc()
    print(f"\n{ok} passed, {bad} failed", flush=True)
    return bad

"""Browser test that really uses every tool page like a visitor (needs a running server, Playwright and the test corpus):
       CORPUS=/tmp/pdfkaro_corpus python tests/ui_tools.py http://127.0.0.1:8000 [slug …]
   For each tool: upload a fitting sample through the page, set what the tool needs, press the button, wait for the result
   and download it. AI tools are skipped unless the server has an AI key."""
import json, os, subprocess, sys, time
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
C = Path(os.environ.get("CORPUS", "/tmp/pdfkaro_corpus"))
BASE = sys.argv[1].rstrip("/") if len(sys.argv) > 1 else "http://127.0.0.1:8000"
ONLY = sys.argv[2:]
cfg = json.loads(subprocess.check_output(["node", "-e", "global.window={};require(process.argv[1]);console.log(JSON.stringify(window.TOOLS))", str(ROOT / "static/js/tools-config.js")]))

# sample files per tool (default: sample.pdf for PDF tools, photo.jpg for picture tools)
FILES = {
    "merge": ["sample.pdf", "letter.pdf", "photo.jpg"], "alternate-mix": ["sample.pdf", "letter.pdf"], "overlay": ["sample.pdf", "letter.pdf"],
    "organize": ["sample.pdf", "letter.pdf"], "compare": ["cmp_a.pdf", "cmp_b.pdf"], "attachments": ["sample.pdf", "plain.txt"],
    "ocr": ["scan_clean.pdf"], "scan-to-editable": ["scan_clean.pdf"], "enhance-scan": ["scan_textured.pdf"], "deskew": ["scan_rotated.pdf"],
    "remove-blank-pages": ["with_blanks.pdf"], "repair": ["sample_damaged.pdf"], "unlock": ["sample_encrypted.pdf"], "scan-to-pdf": ["phone_photo.jpg", "doc_photo.jpg"],
    "word-to-pdf": ["word_doc.docx"], "excel-to-pdf": ["sheet.xlsx"], "ppt-to-pdf": ["slides.pptx"], "text-to-pdf": ["notes.md", "plain.txt"],
    "ps-to-pdf": ["hello.ps"], "zip-to-pdf": ["bundle.zip"], "convert-to-pdf": ["word_doc.docx", "photo.png", "plain.txt"], "epub-to-pdf": None,
    "verify-signature": ["_signed.pdf"], "remove-annotations": ["_annotated.pdf"], "extract-images": ["_withimg.pdf"], "pdf-to-excel": ["sample.pdf"],
    "bank-statement-to-excel": ["sample.pdf"], "pdf-to-csv": ["sample.pdf"], "id-card-pdf": ["id_front.jpg", "id_back.jpg"], "blur-face": ["face.jpg"],
    "passport-photo": ["face.jpg"], "exam-photo": ["face.jpg"], "profile-photo": ["face.jpg"], "signature-maker": ["signature_photo.jpg"],
    "combine-images": ["photo.jpg", "photo.png"], "gif-maker": ["photo.jpg", "photo.png"], "heic-to-jpg": ["_phone.heic"], "heic-to-pdf": ["_phone.heic"],
    "png-to-pdf": ["photo.png"], "png-to-jpg": ["photo.png"], "webp-to-jpg": None, "split-bookmarks": None, "split-text": ["sample.pdf"],
    "image-to-text": ["doc_photo.jpg"], "favicon": ["photo.png"], "image-to-svg": ["_letter.png"],
}
# what a visitor has to type before the button makes sense: {option key: value}
FILL = {"protect": {"password": "secret12"}, "unlock": {"password": "open123"}, "digital-sign": {"name": "Test Signer"}, "split-text": {"prefix": "Invoice"}, "search-pdf": {"query": "the"},
        "html-to-pdf": {"html": "<h1>Hello</h1><p>नमस्ते</p>"}, "qr-code": {"text": "https://example.com"}, "barcode": {"text": "INV-2026-0001"},
        "rename": {"label": "Invoice"}, "header-footer": {"footer": "Page {n} of {total}"}, "meme-generator": {"top": "HELLO", "bottom": "नमस्ते"},
        "html-to-image": None, "redact": {"words": "the"}, "ai-chat": {"question": "What is this about?"}}
SKIP = {"html-to-image": "needs the internet", "epub-to-pdf": "no sample e-book in the corpus", "webp-to-jpg": "same tool as convert-image", "split-bookmarks": "sample has no bookmarks",
        "workflows": "tested separately below"}
bad, done = [], 0


def run(page, slug, t, errors):
    errors.clear()
    page.goto(f"{BASE}/tool/{slug}", wait_until="networkidle")
    if not t.get("noUpload"):
        names = FILES.get(slug) or (["photo.jpg"] if t.get("accept") and ".pdf" not in t["accept"] else ["sample.pdf"])
        if not t.get("multi"):
            names = names[:1]
        page.set_input_files("#fi", [str(C / n) for n in names])
        page.wait_for_selector("#work:not(.hidden)", timeout=60000)
        if page.is_visible("#pwmodal.on"):
            page.fill("#pwin", "secret"); page.click("#pwok"); page.wait_for_selector("#pwmodal.on", state="hidden", timeout=20000)
    if page.is_visible("#more"):
        page.click("#more")
    for k, v in (FILL.get(slug) or {}).items():
        # options are plain inputs in the order of the visible labels: find the one whose label belongs to key k
        label = next(o["t"] for o in t.get("options", []) if o["k"] == k)
        box = page.locator("#opts .opt", has=page.locator("label.t", has_text=label)).first
        box.locator("input, textarea").first.fill(str(v))
    if t.get("ui") == "thumbs" and t.get("thumbMode") in ("delete", "select", "rotate"):
        page.wait_for_selector(".th", timeout=30000)
        if t["thumbMode"] == "rotate":
            page.locator(".th").first.hover(); page.locator(".th .acts button").first.click()
        else:
            page.locator(".th").first.click()
    if t.get("ui") == "brush":
        page.wait_for_selector("canvas.brush", timeout=30000)
        bb = page.locator("canvas.brush").bounding_box()
        page.mouse.move(bb["x"] + bb["width"] * .3, bb["y"] + bb["height"] * .5); page.mouse.down()
        page.mouse.move(bb["x"] + bb["width"] * .6, bb["y"] + bb["height"] * .5, steps=6); page.mouse.up()
    if t.get("ui") == "invoice":
        page.fill("table.items tbody tr td input", "Cotton shirt"); page.locator("table.items tbody tr td input").nth(3).fill("499")
        page.locator(".invcol input[type=text]").first.fill("Demo Traders")
    if t.get("ui") == "areas" and slug == "redact":
        page.wait_for_selector(".cropwrap canvas", timeout=30000)
    page.click("#go")
    page.wait_for_selector("#result:not(.hidden), #err .err, #upgmodal.on", timeout=240000)
    if page.is_visible("#upgmodal.on"):
        return "needs Pro / AI key"
    if page.is_visible("#err .err"):
        msg = page.text_content("#err .err") or ""
        return "needs Pro / AI key" if "AI is not" in msg else "error shown: " + msg[:200]
    with page.expect_download(timeout=60000) as dl:
        page.click("#result a.btn.primary")
    size = Path(dl.value.path()).stat().st_size
    if size < 60:
        return f"download is only {size} bytes"
    if errors:
        return "browser errors: " + "; ".join(errors[:3])
    return None


with sync_playwright() as pw:
    b = pw.chromium.launch()
    ctx = b.new_context(viewport={"width": 1280, "height": 900}, accept_downloads=True)
    page = ctx.new_page(); errors = []
    page.on("pageerror", lambda e: errors.append("JS: " + str(e)[:200]))
    page.on("console", lambda m: errors.append("console: " + m.text[:200]) if m.type == "error" and "402" not in m.text else None)
    for slug, t in cfg.items():
        if (ONLY and slug not in ONLY) or t.get("editor") or (slug in SKIP and not ONLY):
            continue
        t0 = time.time()
        try:
            res = run(page, slug, t, errors)
        except Exception as e:
            res = "test failed: " + str(e).split("\n")[0][:240]
        done += 1
        if res == "needs Pro / AI key":
            print(f"  skip {slug}: {res}")
        elif res:
            bad.append(f"{slug}: {res}"); print(f"  FAIL {slug}: {res}")
        else:
            print(f"  ok   {slug} ({time.time() - t0:.1f}s)")
    if not ONLY or "workflows" in ONLY:
        try:
            page.goto(f"{BASE}/tool/workflows", wait_until="networkidle")
            page.set_input_files("#fi", str(C / "scan_clean.pdf")); page.wait_for_selector("#work:not(.hidden)")
            page.click("#go"); page.wait_for_selector("#result:not(.hidden), #err .err", timeout=240000)
            if page.is_visible("#err .err"):
                bad.append("workflows: " + (page.text_content("#err .err") or ""))
            else:
                print("  ok   workflows")
        except Exception as e:
            bad.append("workflows: " + str(e)[:200])
    b.close()
print(f"\n{done} tools used through the browser, {len(bad)} failed")
print("\n".join(bad))
sys.exit(1 if bad else 0)

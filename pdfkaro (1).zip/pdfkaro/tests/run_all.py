"""Runs the whole test-suite:  CORPUS=/tmp/pdfkaro_corpus python tests/run_all.py [name filter …]
Each test file runs in its own process, so the AI models of one file do not stay in memory for the next."""
import subprocess, sys
from pathlib import Path

here = Path(__file__).parent
bad = 0
for mod in sorted(p.stem for p in here.glob("test_*.py")):
    print(f"\n=== {mod} ===", flush=True)
    code = ("import sys, importlib; here, mod = sys.argv[1:3]; sys.argv = sys.argv[:1] + sys.argv[3:]; sys.path.insert(0, here); "
            "import helpers; sys.exit(1 if helpers.main(vars(importlib.import_module(mod))) else 0)")
    bad += subprocess.run([sys.executable, "-c", code, str(here), mod, *sys.argv[1:]]).returncode
print("\nALL TESTS PASSED" if not bad else f"\n{bad} TEST(S) FAILED")
sys.exit(1 if bad else 0)

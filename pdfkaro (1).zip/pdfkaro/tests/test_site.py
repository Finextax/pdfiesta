"""Website, accounts, quota, payments and security checks."""
from helpers import *
import hashlib, hmac, time
from app import accounts, payments, plans


def test_pages_and_seo():
    r = client.get("/"); h = r.text
    assert r.status_code == 200 and "<title>" in h and "PDFiesta" in h and 'rel="canonical"' in h and 'hreflang="hi"' in h and 'hreflang="x-default"' in h
    r = client.get("/hi"); assert r.status_code == 200 and '<html lang="hi"' in r.text
    en = json.loads((ROOT / "static/i18n/en.json").read_text()); hi = json.loads((ROOT / "static/i18n/hi.json").read_text())
    r = client.get("/hi/tool/merge"); assert r.status_code == 200 and hi["tool.merge"] in r.text and "<title>" in r.text
    r = client.get("/ur"); assert 'dir="rtl"' in r.text if (ROOT / "static/i18n/ur.json").exists() else True
    slugs = [k[5:] for k in en if k.startswith("tool.")]
    assert len(slugs) >= 100, f"only {len(slugs)} tool pages"
    for s in slugs:   # every tool has a page with its own title and description
        r = client.get(f"/tool/{s}"); assert r.status_code == 200 and en[f"tool.{s}"] in r.text.replace("&amp;", "&"), s
        assert en.get(f"desc.{s}"), f"no description for {s}"
    assert client.get("/tool/no-such-tool").status_code == 404 and client.get("/nothing/here").status_code == 404
    for path in ("/edit", "/pricing", "/login", "/privacy", "/terms", "/refund", "/contact"):
        assert client.get(path).status_code == 200, path
    assert 'name="robots" content="noindex"' in client.get("/login").text and "noindex" in client.get("/sign/" + "a" * 40).text
    rb = client.get("/robots.txt").text; assert "Disallow: /api/" in rb and "Sitemap:" in rb
    sm = client.get("/sitemap.xml"); assert sm.headers["content-type"].startswith("application/xml") and sm.text.count("<loc>") >= len(slugs) * 2 and "/hi/tool/merge" in sm.text
    hz = client.get("/healthz").json(); assert hz["ok"] and not hz["missing"] and hz["tools"] >= 107 and hz["font_families"] > 20 and hz["text_shaping"]
    for f in ("/static/favicon.svg", "/static/icon-192.png", "/static/apple-touch-icon.png", "/static/js/common.js", "/static/js/langs.js", "/static/js/editor.js", "/static/css/app.css", "/static/vendor/pdf.min.mjs"):
        assert client.get(f).status_code == 200, f
    mf = client.get("/manifest.webmanifest").json(); assert mf["short_name"] and mf["icons"] and "/manifest.webmanifest" in h
    api = client.get("/api/tools").json(); cfg = (ROOT / "static/js/tools-config.js").read_text()
    missing = [t for t in api if not re.search(r"\btool:\s*[\"']" + re.escape(t) + r"[\"']", cfg)]
    assert not missing, f"tools without a page: {missing}"
    # the language menu only offers languages that have a translation file, and every menu language has its pages
    menu = json.loads(re.search(r"AVAILABLE = (\[.*?\])", (ROOT / "static/js/langs.js").read_text()).group(1))
    assert "en" in menu and "hi" in menu and all(l == "en" or (ROOT / f"static/i18n/{l}.json").exists() for l in menu)
    for l in menu[1:]:
        r = client.get(f"/{l}/tool/compress"); assert r.status_code == 200 and f'<html lang="{l}"' in r.text, l


def test_security_headers_and_origin():
    r = client.get("/")
    assert r.headers["x-content-type-options"] == "nosniff" and r.headers["x-frame-options"] == "SAMEORIGIN" and "referrer-policy" in r.headers
    csp = r.headers["content-security-policy"]; nonce = re.search(r"'nonce-([\w-]+)'", csp).group(1)
    assert "object-src 'none'" in csp and "'unsafe-inline'" not in csp.split("script-src")[1].split(";")[0] and "'unsafe-eval'" not in csp
    assert r.text.count("<script") == r.text.count(f'<script nonce="{nonce}"') > 0 and nonce not in client.get("/").headers["content-security-policy"]   # a new number every time
    big = client.post("/api/task", content=b"{}", headers={"content-length": str(200 * 1024 * 1024), "content-type": "application/json"}); assert big.status_code == 413
    fid = up("letter.pdf")[0]
    body = {"tool": "rotate", "files": [fid], "options": {"angle": 90}}
    assert client.post("/api/task", json=body, headers={"origin": "https://evil.example"}).status_code == 403, "cross-site POST must be refused"
    assert client.post("/api/task", json=body, headers={"origin": "http://testserver"}).status_code == 200
    assert client.post("/api/pay/razorpay/webhook", content=b"{}", headers={"origin": "https://evil.example"}).status_code != 403   # server-to-server calls carry no cookies


def test_upload_rules():
    (C / "_evil.exe").write_bytes(b"MZ\x90\x00"); (C / "_evil.html").write_text("<script>alert(1)</script>")
    (C / "_fake.pdf").write_text("this is not a pdf"); (C / "_empty.pdf").write_bytes(b"")
    post = lambda n: client.post("/api/upload", files=[("files", (n, open(C / n, "rb")))])
    assert post("_evil.exe").status_code == 415 and post("_evil.html").status_code == 415 and post("_empty.pdf").status_code == 400
    m = post("_fake.pdf").json()[0]; assert m.get("damaged") is True and not m.get("pages")
    m = post("sample.pdf").json()[0]
    assert m["pages"] == 6 and m["kind"] == "pdf" and m["has_forms"] and not m["scanned"] and len(m["toc"]) == 6 and "path" not in m, "server paths must never be sent to the browser"
    assert "path" not in client.get(f"/api/file/{m['id']}/meta").json()
    assert post("scan_clean.pdf").json()[0]["scanned"] is True
    r = client.post("/api/upload", files=[("files", ("../../etc/passwd.pdf", open(C / "letter.pdf", "rb")))]); assert r.json()[0]["name"] == "passwd.pdf"
    (C / "_drawing.svg").write_text('<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10"><script>alert(1)</script><rect width="10" height="10"/></svg>')
    sid = post("_drawing.svg").json()[0]["id"]; r = client.get(f"/api/file/{sid}")
    assert r.headers["content-type"] == "application/octet-stream" and "attachment" in r.headers.get("content-disposition", ""), "an uploaded SVG must never be shown as a web page"
    assert client.get("/api/file/..%2F..%2Fapp.db").status_code == 404 and client.get("/api/file/doesnotexist/meta").status_code == 404
    saved = accounts.FREE["max_mb"]; accounts.FREE["max_mb"] = 0
    try:
        assert post("sample.pdf").status_code == 402
    finally:
        accounts.FREE["max_mb"] = saved
    for bad in ("http://127.0.0.1:8000/x.pdf", "http://169.254.169.254/latest", "ftp://example.com/a.pdf", "file:///etc/passwd", "http://localhost/x.pdf"):
        assert client.post("/api/upload-url", json={"url": bad}).status_code == 422, bad
    b = client.post("/api/blank").json(); assert b["pages"] == 1 and b["kind"] == "pdf"


def test_no_server_paths_from_clients():
    """options ending in _path are internal – a browser must not be able to point a tool at files on the server"""
    assert "Please enter" in run("watermark", ["letter.pdf"], {"image_path": "/etc/passwd"}, expect=422)["error"]
    run("img_erase", ["photo.png"], {"mask_path": "/etc/passwd"}, expect=422)
    p = run("qr_code", [], {"text": "hello", "logo_path": "/etc/passwd"}); assert Image.open(p).size[0] > 100
    run("digital_sign", ["letter.pdf"], {"cert_path": "/etc/ssl/private/key.pem"}, expect=422)
    r = client.post("/api/task", json={"tool": "watermark", "files": up("letter.pdf"), "options": {"image_file": "0000000000000000"}}); assert r.status_code == 404
    r = client.post("/api/task", json={"tool": "watermark", "files": up("letter.pdf"), "options": {"image_file": "../../../etc"}}); assert r.status_code == 404


def test_task_validation_and_downloads():
    assert client.post("/api/task", json={"tool": "nope", "files": []}).status_code == 404
    run("rotate", ["photo.jpg"], {}, expect=422); run("img_resize", ["letter.pdf"], {}, expect=422); run("rotate", ["sample.pdf", "letter.pdf"], {}, expect=422)
    run("rotate", [], {}, expect=400); assert "password" in run("rotate", ["sample_encrypted.pdf"], {}, expect=422)["error"].lower()
    assert run("split", ["sample_damaged.pdf"], {"mode": "every_page"}, expect=None) if False else True
    fid = up("letter.pdf")[0]
    j = client.post("/api/task", json={"tool": "pdf_to_html", "files": [fid]}).json()
    r = client.get(j["download"] + "?inline=1")
    assert r.headers["content-type"] == "application/octet-stream" and "attachment" in r.headers["content-disposition"], "HTML results must never open inside our site"
    j2 = client.post("/api/task", json={"tool": "rotate", "files": [fid], "options": {"angle": 90}}).json()
    r = client.get(j2["download"] + "?inline=1"); assert r.headers["content-type"] == "application/pdf" and "inline" in r.headers["content-disposition"] and r.headers["x-content-type-options"] == "nosniff"
    assert "attachment" in client.get(j2["download"]).headers["content-disposition"] and j2["file_id"] and j2["input_size"] > 0
    assert client.get(f"/api/file/{j2['file_id']}/meta").json()["pages"] == 1, "result must be usable as input of the next tool"
    for bad in ("/api/download/../app.db/x", f"/api/download/{j2['task']}/..%2F..%2Fapp.db", "/api/download/zzzzzzzzzzzzzzzz/a.pdf", f"/api/download/{j2['task']}/nothere.pdf"):
        assert client.get(bad).status_code == 404, bad
    assert client.delete(f"/api/task/{j2['task']}").json()["deleted"] and client.get(j2["download"]).status_code == 404
    r = client.post("/api/preview", json={"tool": "watermark", "files": [fid], "options": {"text": "DRAFT"}, "page": 0})
    assert r.status_code == 200 and r.headers["content-type"] == "image/png" and Image.open(io.BytesIO(r.content)).width > 500
    assert client.post("/api/preview", json={"tool": "compress", "files": [fid]}).status_code == 404


def test_free_quota():
    fid = up("letter.pdf")[0]
    who = "iptestclient"; used = accounts.usage_today(who)
    saved = accounts.FREE["guest_per_day"]; accounts.FREE["guest_per_day"] = used + 2
    try:
        body = {"tool": "rotate", "files": [fid], "options": {"angle": 90}}
        assert client.post("/api/task", json=body).status_code == 200
        assert client.post("/api/task", json={"tool": "delete_pages", "files": [fid], "options": {"pages": "1"}}).status_code == 422   # a task that fails …
        assert accounts.usage_today(who) == used + 1, "… must not use up a free task"
        assert client.post("/api/task", json=body).status_code == 200
        r = client.post("/api/task", json=body); assert r.status_code == 402 and "free tasks" in r.json()["error"] and "Pro" in r.json()["error"]
        me = client.get("/api/me").json(); assert me["user"] is None and me["used_today"] == used + 2 and me["per_day"] == used + 2
    finally:
        accounts.FREE["guest_per_day"] = saved
    saved = accounts.FREE["max_pages"]; accounts.FREE["max_pages"] = 3
    try:
        r = client.post("/api/task", json={"tool": "rotate", "files": up("sample.pdf")}); assert r.status_code == 402 and "pages" in r.json()["error"]
    finally:
        accounts.FREE["max_pages"] = saved
    # the editor: working on a document is free, and a document counts once – however often it is downloaded
    fid = up("letter.pdf")[0]; assert client.post(f"/api/editor/{fid}/prepare").status_code == 200
    used = accounts.usage_today(who)
    assert client.post(f"/api/editor/{fid}/commit", json={"ops": [{"type": "rotate_page", "page": 0}], "base": 0}).status_code == 200
    assert accounts.usage_today(who) == used
    for _ in range(2):
        r = client.post(f"/api/editor/{fid}/apply", json={"ops": [{"type": "rect", "page": 0, "rect": [50, 50, 100, 100], "stroke": "#ff0000", "width": 1}], "version": 1})
        assert r.status_code == 200, r.text
    assert accounts.usage_today(who) == used + 1


def test_accounts():
    c = TestClient(app)
    mail = f"user{int(time.time() * 1000)}@example.com"
    assert c.post("/api/auth/signup", json={"email": "bad", "password": "longenough1"}).status_code == 400
    assert c.post("/api/auth/signup", json={"email": mail, "password": "short"}).status_code == 400
    assert c.post("/api/auth/signup", json={"email": mail, "password": "longenough1", "name": "Ravi"}).status_code == 200
    me = c.get("/api/me").json(); assert me["user"]["email"] == mail and me["user"]["name"] == "Ravi" and not me["user"]["pro"] and me["per_day"] == accounts.FREE["user_per_day"]
    assert TestClient(app).post("/api/auth/signup", json={"email": mail.upper(), "password": "longenough1"}).status_code == 409
    row = accounts.db().execute("SELECT pw FROM users WHERE email=?", (mail,)).fetchone(); assert row["pw"].startswith("scrypt$") and "longenough1" not in row["pw"]
    cookie = c.cookies.get("pk_session"); assert cookie and len(cookie) > 30
    assert c.post("/api/auth/logout").status_code == 200 and c.get("/api/me").json()["user"] is None
    assert accounts.db().execute("SELECT COUNT(*) n FROM sessions WHERE token=?", (cookie,)).fetchone()["n"] == 0, "logout must end the session on the server"
    assert c.post("/api/auth/login", json={"email": mail, "password": "wrongwrong"}).status_code == 401
    assert c.post("/api/auth/login", json={"email": mail, "password": "longenough1"}).status_code == 200
    # change password, profile
    assert c.post("/api/account/password", json={"old": "nope", "new": "anotherpass9"}).status_code == 403
    assert c.post("/api/account/password", json={"old": "longenough1", "new": "anotherpass9"}).status_code == 200 and c.get("/api/me").json()["user"]
    assert c.post("/api/account/profile", json={"name": "Ravi Sharma"}).status_code == 200 and c.get("/api/me").json()["user"]["name"] == "Ravi Sharma"
    # forgotten password: same answer for unknown addresses, one-time link
    assert c.post("/api/auth/forgot", json={"email": "nobody@example.com"}).json() == {"ok": True} and c.post("/api/auth/forgot", json={"email": mail}).json() == {"ok": True}
    tok = accounts.db().execute("SELECT token FROM resets r JOIN users u ON u.id=r.user_id WHERE u.email=?", (mail,)).fetchone()["token"]
    c2 = TestClient(app)
    assert c2.post("/api/auth/reset", json={"token": tok, "password": "short"}).status_code == 400
    assert c2.post("/api/auth/reset", json={"token": tok, "password": "resetpass77"}).status_code == 200 and c2.get("/api/me").json()["user"]["email"] == mail
    assert c2.post("/api/auth/reset", json={"token": tok, "password": "resetpass88"}).status_code == 400, "a reset link works only once"
    assert c.get("/api/me").json()["user"] is None, "other devices must be signed out after a password reset"
    # brute-force brake
    c3 = TestClient(app); codes = [c3.post("/api/auth/login", json={"email": "victim@example.com", "password": "x" * 9}).status_code for _ in range(12)]
    assert 429 in codes and codes[0] == 401
    accounts._attempts.clear()
    # admin area
    assert c2.get("/api/admin/stats").status_code == 403
    os.environ["ADMIN_EMAILS"] = mail; st = c2.get("/api/admin/stats").json(); assert st["users"] >= 1 and "tasks_today" in st; os.environ.pop("ADMIN_EMAILS")
    # delete account
    assert c2.post("/api/account/delete").status_code == 200 and c2.get("/api/me").json()["user"] is None
    assert TestClient(app).post("/api/auth/login", json={"email": mail, "password": "resetpass77"}).status_code == 401


class FakeHTTP:
    """stands in for Razorpay / Stripe so that the payment code paths run without real money"""
    routes, calls = {}, []

    def __init__(self, *a, **k): pass
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False

    async def _go(self, method, url, **kw):
        FakeHTTP.calls.append((method, url, kw))
        for key, fn in FakeHTTP.routes.items():
            if key in url:
                code, data = fn(kw)
                return type("R", (), {"status_code": code, "text": json.dumps(data), "json": lambda self: data})()
        raise AssertionError("unexpected call " + url)

    async def post(self, url, **kw): return await self._go("POST", url, **kw)
    async def get(self, url, **kw): return await self._go("GET", url, **kw)
    async def delete(self, url, **kw): return await self._go("DELETE", url, **kw)


def _user(tag):
    c = TestClient(app); mail = f"{tag}{int(time.time() * 1000)}@example.com"
    assert c.post("/api/auth/signup", json={"email": mail, "password": "longenough1"}).status_code == 200
    return c, c.get("/api/me").json()["user"]["id"], mail


def test_payments_razorpay():
    c, uid, mail = _user("rzp")
    assert TestClient(app).post("/api/pay/razorpay/order", json={"plan": "month"}).status_code == 401
    for k in ("RAZORPAY_KEY_ID", "RAZORPAY_KEY_SECRET", "RAZORPAY_WEBHOOK_SECRET"):
        os.environ.pop(k, None)
    assert c.post("/api/pay/razorpay/order", json={"plan": "month"}).status_code == 501
    body = json.dumps({"event": "payment.captured", "payload": {"payment": {"entity": {"id": "pay_forged", "amount": 39900, "currency": "INR", "status": "captured", "notes": {"user_id": str(uid), "plan": "year"}}}}}).encode()
    forged = hmac.new(b"", body, hashlib.sha256).hexdigest()
    assert client.post("/api/pay/razorpay/webhook", content=body, headers={"x-razorpay-signature": forged}).status_code == 503, "webhooks must be refused while no secret is set"
    assert not c.get("/api/me").json()["user"]["pro"]
    os.environ.update(RAZORPAY_KEY_ID="rzp_test_x", RAZORPAY_KEY_SECRET="keysecret", RAZORPAY_WEBHOOK_SECRET="whsecret")
    saved = payments.httpx.AsyncClient; payments.httpx.AsyncClient = FakeHTTP; FakeHTTP.calls.clear()
    order = {"id": "order_1", "amount": 39900, "amount_paid": 0, "status": "created", "notes": {"user_id": str(uid), "plan": "month"}}
    FakeHTTP.routes = {"/v1/orders/order_1": lambda kw: (200, order), "/v1/orders": lambda kw: (200, order), "/v1/payments/pay_1": lambda kw: (200, {"id": "pay_1", "status": "captured", "order_id": "order_1", "amount": 39900})}
    try:
        assert c.post("/api/pay/razorpay/order", json={"plan": "galaxy"}).status_code == 400
        o = c.post("/api/pay/razorpay/order", json={"plan": "month"}).json()
        assert o["order_id"] == "order_1" and o["amount"] == 39900 and o["currency"] == "INR" and o["key_id"] == "rzp_test_x" and "keysecret" not in json.dumps(o)
        sent = FakeHTTP.calls[0][2]["json"]; assert sent["amount"] == 39900 and sent["notes"] == {"user_id": str(uid), "plan": "month"}
        good = hmac.new(b"keysecret", b"order_1|pay_1", hashlib.sha256).hexdigest()
        assert c.post("/api/pay/razorpay/verify", json={"razorpay_order_id": "order_1", "razorpay_payment_id": "pay_1", "razorpay_signature": "0" * 64}).status_code == 400
        other, _, _ = _user("thief")
        assert other.post("/api/pay/razorpay/verify", json={"razorpay_order_id": "order_1", "razorpay_payment_id": "pay_1", "razorpay_signature": good}).status_code == 400, "an order pays for its own account only"
        assert c.post("/api/pay/razorpay/verify", json={"razorpay_order_id": "order_1", "razorpay_payment_id": "pay_1", "razorpay_signature": good}).status_code == 200
        me = c.get("/api/me").json(); assert me["user"]["pro"] and me["user"]["plan"] == "month" and me["per_day"] is None and me["payments"][0]["amount"] == 399
        until = accounts.db().execute("SELECT plan_until FROM users WHERE id=?", (uid,)).fetchone()["plan_until"]; assert 30 * 86400 < until - time.time() < 32 * 86400
        # the webhook for the same payment arrives later: nothing is added twice
        body = json.dumps({"event": "payment.captured", "payload": {"payment": {"entity": {"id": "pay_1", "order_id": "order_1", "amount": 39900, "currency": "INR", "status": "captured"}}}}).encode()
        sig = hmac.new(b"whsecret", body, hashlib.sha256).hexdigest()
        assert client.post("/api/pay/razorpay/webhook", content=body, headers={"x-razorpay-signature": sig}).status_code == 200
        assert accounts.db().execute("SELECT plan_until FROM users WHERE id=?", (uid,)).fetchone()["plan_until"] == until
        assert client.post("/api/pay/razorpay/webhook", content=body, headers={"x-razorpay-signature": "bad"}).status_code == 400
        # a second purchase extends the plan; a payment that is too small for the plan does nothing
        body = json.dumps({"event": "payment.captured", "payload": {"payment": {"entity": {"id": "pay_2", "amount": 299900, "currency": "INR", "status": "captured", "notes": {"user_id": str(uid), "plan": "year"}}}}}).encode()
        assert client.post("/api/pay/razorpay/webhook", content=body, headers={"x-razorpay-signature": hmac.new(b"whsecret", body, hashlib.sha256).hexdigest()}).status_code == 200
        until2 = accounts.db().execute("SELECT plan_until FROM users WHERE id=?", (uid,)).fetchone()["plan_until"]; assert 365 * 86400 < until2 - until < 367 * 86400
        body = json.dumps({"event": "payment.captured", "payload": {"payment": {"entity": {"id": "pay_3", "amount": 100, "currency": "INR", "status": "captured", "notes": {"user_id": str(uid), "plan": "year"}}}}}).encode()
        client.post("/api/pay/razorpay/webhook", content=body, headers={"x-razorpay-signature": hmac.new(b"whsecret", body, hashlib.sha256).hexdigest()})
        assert accounts.db().execute("SELECT plan_until FROM users WHERE id=?", (uid,)).fetchone()["plan_until"] == until2, "₹1 must not buy a year"
        # Pro limits apply
        assert accounts.limits_for(accounts.db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone())["max_files"] == 200
    finally:
        payments.httpx.AsyncClient = saved
        for k in ("RAZORPAY_KEY_ID", "RAZORPAY_KEY_SECRET", "RAZORPAY_WEBHOOK_SECRET"):
            os.environ.pop(k, None)


def test_payments_stripe():
    c, uid, mail = _user("stripe")
    os.environ.pop("STRIPE_SECRET_KEY", None); os.environ.pop("STRIPE_WEBHOOK_SECRET", None)
    assert c.post("/api/pay/stripe/checkout", json={"plan": "year"}).status_code == 501
    ev = {"type": "checkout.session.completed", "data": {"object": {"id": "cs_1", "payment_status": "paid", "amount_total": 4800, "currency": "usd", "metadata": {"user_id": str(uid), "plan": "year"}}}}
    body = json.dumps(ev).encode(); t = str(int(time.time()))
    sign = lambda secret, ts=t, b=body: f"t={ts},v1=" + hmac.new(secret.encode(), f"{ts}.".encode() + b, hashlib.sha256).hexdigest()
    assert client.post("/api/pay/stripe/webhook", content=body, headers={"stripe-signature": sign("")}).status_code == 503
    os.environ.update(STRIPE_SECRET_KEY="sk_test_x", STRIPE_WEBHOOK_SECRET="whsec_x")
    saved = payments.httpx.AsyncClient; payments.httpx.AsyncClient = FakeHTTP; FakeHTTP.calls.clear()
    FakeHTTP.routes = {"/v1/checkout/sessions": lambda kw: (200, {"url": "https://checkout.stripe.com/c/pay/cs_1"})}
    try:
        assert c.post("/api/pay/stripe/checkout", json={"plan": "year"}).json()["url"].startswith("https://checkout.stripe.com/")
        sent = FakeHTTP.calls[0][2]["data"]
        assert sent["mode"] == "payment" and sent["line_items[0][price_data][unit_amount]"] == "4800" and sent["metadata[user_id]"] == str(uid) and sent["customer_email"] == mail
        assert client.post("/api/pay/stripe/webhook", content=body, headers={"stripe-signature": sign("wrong")}).status_code == 400
        old = str(int(time.time()) - 4000); assert client.post("/api/pay/stripe/webhook", content=body, headers={"stripe-signature": sign("whsec_x", old)}).status_code == 400, "old (replayed) events must be refused"
        assert not c.get("/api/me").json()["user"]["pro"]
        assert client.post("/api/pay/stripe/webhook", content=body, headers={"stripe-signature": sign("whsec_x")}).status_code == 200
        me = c.get("/api/me").json(); assert me["user"]["pro"] and me["user"]["plan"] == "year" and me["payments"][0]["currency"] == "USD" and me["payments"][0]["amount"] == 48
        assert client.post("/api/pay/stripe/webhook", content=body, headers={"stripe-signature": sign("whsec_x")}).status_code == 200      # delivered twice
        assert len(c.get("/api/me").json()["payments"]) == 1
        unpaid = json.dumps(dict(ev, data={"object": dict(ev["data"]["object"], id="cs_2", payment_status="unpaid")})).encode()
        client.post("/api/pay/stripe/webhook", content=unpaid, headers={"stripe-signature": sign("whsec_x", t, unpaid)}); assert len(c.get("/api/me").json()["payments"]) == 1
        # an automatically renewing plan can be cancelled: the customer number is kept and opens Stripe's own page
        assert not c.get("/api/me").json()["subscription"] and c.post("/api/pay/stripe/portal").status_code == 404
        sub = json.dumps({"type": "checkout.session.completed", "data": {"object": {"id": "cs_3", "mode": "subscription", "customer": "cus_42", "payment_status": "paid",
                                                                              "amount_total": 600, "currency": "usd", "metadata": {"user_id": str(uid), "plan": "month"}}}}).encode()
        assert client.post("/api/pay/stripe/webhook", content=sub, headers={"stripe-signature": sign("whsec_x", t, sub)}).status_code == 200
        FakeHTTP.routes["/v1/billing_portal/sessions"] = lambda kw: (200, {"url": "https://billing.stripe.com/p/session/x"})
        assert c.get("/api/me").json()["subscription"] and c.post("/api/pay/stripe/portal").json()["url"].startswith("https://billing.stripe.com/")
        assert FakeHTTP.calls[-1][2]["data"]["customer"] == "cus_42" and TestClient(app).post("/api/pay/stripe/portal").status_code == 401
        # deleting the account stops the subscription at Stripe (nobody is charged for an account that no longer exists)
        c2, uid2, _m = _user("leaver")
        accounts.db().execute("UPDATE users SET stripe_customer='cus_77' WHERE id=?", (uid2,)); accounts.db().commit()
        FakeHTTP.routes["/v1/subscriptions"] = lambda kw: (200, {"data": [{"id": "sub_1", "status": "active"}, {"id": "sub_0", "status": "canceled"}]})
        n0 = len(FakeHTTP.calls); assert c2.post("/api/account/delete").status_code == 200
        gone = [u for mth, u, kw in FakeHTTP.calls[n0:] if mth == "DELETE"]; assert gone == ["https://api.stripe.com/v1/subscriptions/sub_1"], gone
        assert c2.get("/api/me").json()["user"] is None
        # AI tools are open to Pro users
        saved_ai = accounts.FREE["ai_per_day"]; accounts.FREE["ai_per_day"] = 0
        try:
            mock_ai(); fid = c.post("/api/upload", files=[("files", ("letter.pdf", open(C / "letter.pdf", "rb")))]).json()[0]["id"]
            assert c.post("/api/task", json={"tool": "ai_summarize", "files": [fid]}).status_code == 200
            assert client.post("/api/task", json={"tool": "ai_summarize", "files": up("letter.pdf")}).status_code == 402
        finally:
            accounts.FREE["ai_per_day"] = saved_ai
    finally:
        payments.httpx.AsyncClient = saved
        os.environ.pop("STRIPE_SECRET_KEY", None); os.environ.pop("STRIPE_WEBHOOK_SECRET", None)
    pl = client.get("/api/plans", headers={"accept-language": "hi-IN"}).json(); assert pl["currency"] == "INR" and pl["plans"]["month"]["price"] == plans.PLANS["month"]["inr"]
    assert client.get("/api/plans", headers={"accept-language": "en-US"}).json()["currency"] == "USD"


if __name__ == "__main__":
    sys.exit(1 if main(globals()) else 0)

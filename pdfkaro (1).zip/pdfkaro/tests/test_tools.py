"""PDF tools, part 1 – every tool must produce a CORRECT result (not just "no error").

    python tests/make_corpus.py /tmp/pdfkaro_corpus
    CORPUS=/tmp/pdfkaro_corpus python tests/run_all.py        # or: pytest tests/
"""
from helpers import *


# ------------------------------------------------------------------ merge / pages
def test_merge():
    p = run("merge", ["sample.pdf", "letter.pdf", "photo.png"], {"bookmarks": "one_per_doc", "filename_footer": True})
    d = pdf(p)
    assert d.page_count == 8
    assert [t[1] for t in d.get_toc()] == ["sample", "letter", "photo"]
    assert "sample.pdf" in d[0].get_text() and "Dear customer" in d[6].get_text()
    p = run("merge", ["sample.pdf", "letter.pdf"], {"bookmarks": "keep_under", "ranges": {"0": "1-2"}})
    d = pdf(p); assert d.page_count == 3
    toc = d.get_toc(); assert toc[0][:2] == [1, "sample"] and toc[1][:2] == [2, "Chapter 1"] and len([t for t in toc if t[0] == 2]) == 2


def test_alternate_mix():
    p = run("alternate_mix", ["sample.pdf", "letter.pdf"])
    d = pdf(p); assert d.page_count == 7
    assert "Chapter 1" in d[0].get_text() and "Dear customer" in d[1].get_text() and "Chapter 2" in d[2].get_text()


def test_organize():
    p = run("organize", ["sample.pdf"], {"order": [{"page": 2}, {"blank": True}, {"page": 0, "rotate": 90}]})
    d = pdf(p); assert d.page_count == 3
    assert "Chapter 3" in d[0].get_text() and not d[1].get_text().strip() and d[2].rotation == 90 and "Chapter 1" in d[2].get_text()
    ids = up("sample.pdf", "letter.pdf")   # pages from two files
    p = run("organize", ids, {"order": [{"file": 1, "page": 0}, {"file": 0, "page": 5}]})
    d = pdf(p); assert d.page_count == 2 and "Dear customer" in d[0].get_text() and "Chapter 6" in d[1].get_text()


def test_delete_extract_rotate():
    d = pdf(run("delete_pages", ["sample.pdf"], {"pages": "2-3,6"}))
    assert d.page_count == 3 and ["Chapter 1" in d[0].get_text(), "Chapter 4" in d[1].get_text(), "Chapter 5" in d[2].get_text()] == [True] * 3
    run("delete_pages", ["sample.pdf"], {"pages": "1-6"}, expect=422)
    d = pdf(run("extract_pages", ["sample.pdf"], {"pages": "even"}))
    assert d.page_count == 3 and "Chapter 2" in d[0].get_text() and "Chapter 6" in d[2].get_text()
    d = pdf(run("rotate", ["sample.pdf"], {"angle": 90, "pages": "odd"}))
    assert [p.rotation for p in d] == [90, 0, 90, 0, 90, 0]
    d = pdf(run("rotate", ["sample.pdf"], {"per_page": {"1": 180, "5": 270}}))
    assert [p.rotation for p in d] == [0, 180, 0, 0, 0, 270]


def test_flip():
    from PIL import ImageChops, ImageOps
    coarse = lambda im: im.convert("L").resize((60, 85), Image.BOX)   # compare the layout, not anti-aliasing
    differs = lambda a, b: sum(ImageChops.difference(coarse(a), coarse(b)).getdata()) / (60 * 85)
    src = render(C / "sample.pdf", dpi=72); p = run("flip", ["sample.pdf"], {"direction": "horizontal"}); out = render(p, dpi=72)
    assert differs(ImageOps.mirror(src), out) < 2 and differs(src, out) > 10, "page is not a mirror image"
    d = pdf(p); s0 = pdf(C / "sample.pdf")
    a, b = s0[0].search_for("Chapter 1")[0], d[0].search_for("Chapter 1")[0]
    assert abs(b.x0 - (s0[0].rect.width - a.x1)) < 1 and abs(b.y0 - a.y0) < 1
    l0, l1 = s0[0].get_links(), d[0].get_links()
    assert len(l0) == len(l1) >= 1 and abs(l1[0]["from"].x0 - (s0[0].rect.width - l0[0]["from"].x1)) < 1 and l1[0].get("uri") == l0[0].get("uri")
    out = render(run("flip", ["sample.pdf"], {"direction": "vertical"}), dpi=72)
    assert differs(ImageOps.flip(src), out) < 2
    src = render(C / "letter_rot90.pdf", dpi=72); out = render(run("flip", ["letter_rot90.pdf"], {"direction": "horizontal"}), dpi=72)
    assert out.size == src.size and differs(ImageOps.mirror(src), out) < 2, "rotated page is mirrored along the wrong axis"


# ------------------------------------------------------------------ split
def test_split():
    fs = unzip(run("split", ["sample.pdf"], {"mode": "every_page"})); assert len(fs) == 6 and all(pdf(f).page_count == 1 for f in fs)
    fs = unzip(run("split", ["sample.pdf"], {"mode": "every_n", "n": 4})); assert [pdf(f).page_count for f in fs] == [4, 2]
    fs = unzip(run("split", ["sample.pdf"], {"mode": "ranges", "pages": "1-2,3-6"})); assert [pdf(f).page_count for f in fs] == [2, 4]
    fs = unzip(run("split", ["sample.pdf"], {"mode": "after_pages", "pages": "1,4"})); assert sorted(pdf(f).page_count for f in fs) == [1, 2, 3]
    fs = unzip(run("split_bookmarks", ["sample.pdf"], {"level": 1})); assert len(fs) == 6 and "Chapter 3" in fs[2].name
    fs = unzip(run("split_text", ["sample.pdf"], {"prefix": "Invoice number"})); assert len(fs) == 6 and "INV-1004" in fs[3].name
    fs = unzip(run("split_size", ["sample.pdf"], {"size": 6, "unit": "KB"}))
    assert sum(pdf(f).page_count for f in fs) == 6 and len(fs) >= 2 and all(f.stat().st_size <= 6 * 1024 or pdf(f).page_count == 1 for f in fs)
    d = pdf(run("split_half", ["sample.pdf"], {"direction": "vertical"}))
    assert d.page_count == 12 and abs(d[0].rect.width - 595.27 / 2) < 1 and "Chapter 1" in d[0].get_text()


# ------------------------------------------------------------------ crop / resize / n-up
def test_crop_resize_nup():
    d = pdf(run("crop", ["letter.pdf"], {"mode": "auto", "margin": 5}))
    r = d[0].rect; assert 440 < r.width < 500 and 190 < r.height < 240 and "Dear customer" in d[0].get_text()
    d = pdf(run("crop", ["sample.pdf"], {"mode": "box", "box": {"x0": 0, "y0": 0, "x1": 0.5, "y1": 0.5}}))
    assert abs(d[0].rect.width - 297.6) < 1 and abs(d[0].rect.height - 420.9) < 1
    d = pdf(run("crop", ["scan_clean.pdf"], {"mode": "auto_max"})); assert d[0].rect.width < 520
    d = pdf(run("crop", ["letter_rot90.pdf"], {"mode": "auto", "margin": 5}))   # rotated page must still crop the right area
    assert "Dear customer" in d[0].get_text(clip=d[0].rect) and d[0].rect.width < 520 and d[0].rect.height < 300
    d = pdf(run("resize", ["sample.pdf"], {"mode": "size", "size": "letter"})); assert (round(d[0].rect.width), round(d[0].rect.height)) == (612, 792)
    d = pdf(run("resize", ["sample.pdf"], {"mode": "margins", "margin": 1})); assert abs(d[0].rect.width - (595.27 + 144)) < 1
    d = pdf(run("nup", ["sample.pdf"], {"n": 4})); assert d.page_count == 2 and "Chapter 4" in d[0].get_text() and "Chapter 5" in d[1].get_text()
    d = pdf(run("nup", ["sample.pdf"], {"n": 2})); assert d.page_count == 3 and d[0].rect.width > d[0].rect.height


# ------------------------------------------------------------------ compress / grayscale / flatten / repair
def test_compress_family():
    p = run("compress", ["scan_textured.pdf"], {"quality": "medium"})
    assert p.stat().st_size < (C / "scan_textured.pdf").stat().st_size * 0.8 and pdf(p).page_count == 1
    p = run("compress", ["sample.pdf"], {"quality": "good"}); assert text(p).count("Invoice number") == 120
    im = render(run("grayscale", ["chrome_report.pdf"]), dpi=30)
    assert max(max(px) - min(px) for px in im.getdata()) < 12, "colour left in grayscale result"
    d = pdf(run("flatten", ["sample.pdf"], {"mode": "forms"})); assert not list(d[0].widgets()) and "Chapter 1" in d[0].get_text()
    d = pdf(run("flatten", ["sample.pdf"], {"mode": "everything", "dpi": 72})); assert not d[0].get_text().strip() and d[0].get_images()
    d = pdf(run("repair", ["sample_damaged.pdf"])); assert d.page_count == 6 and "Chapter 2" in d[1].get_text()


# ------------------------------------------------------------------ security
def test_protect_unlock():
    p = run("protect", ["sample.pdf"], {"password": "s3cret", "encryption": "aes256", "allow": {"print": True, "copy": False}})
    d = pymupdf.open(p); assert d.needs_pass and not d.authenticate("wrong") and d.authenticate("s3cret")
    with pikepdf.open(p, password="s3cret") as q:
        assert q.encryption.bits == 256 and not q.allow.extract and q.allow.print_lowres
    ids = up("sample_encrypted.pdf")
    assert client.get(f"/api/file/{ids[0]}/meta").json()["encrypted"] is True
    assert client.post(f"/api/file/{ids[0]}/unlock", json={"password": "bad"}).status_code == 403
    assert client.post(f"/api/file/{ids[0]}/unlock", json={"password": "open123"}).json()["pages"] == 6
    d = pymupdf.open(run("unlock", ids)); assert not d.needs_pass and d.page_count == 6


def test_watermark_stamps():
    p = run("watermark", ["sample.pdf"], {"text": "CONFIDENTIAL", "opacity": 0.3, "rotation": 45})
    d = pdf(p); assert all("CONFIDENTIAL" in pg.get_text() for pg in d) and p.stat().st_size < 150_000
    fs = unzip(run("watermark", ["letter.pdf"], {"text": "Copy for Rahul\nCopy for Priya"})); assert len(fs) == 2 and "Priya" in text(fs[0]) + text(fs[1])
    d = pdf(run("page_numbers", ["sample.pdf"], {"format": "Page {n} of {total}", "position": "bottom-right", "start": 1}))
    assert "Page 3 of 6" in d[2].get_text() and d[2].search_for("Page 3 of 6")[0].y0 > 780 and d[2].search_for("Page 3 of 6")[0].x0 > 400
    d = pdf(run("page_numbers", ["sample.pdf"], {"format": "{n}", "pages": "2-", "start": 1})); assert "Page" not in d[0].get_text() and d[1].search_for("1")
    d = pdf(run("page_numbers", ["sample.pdf"], {"format": "- {n} -", "margins": "increase"}))
    assert d[0].rect.height > 842 and "Chapter 1" in d[0].get_text() and "- 1 -" in d[0].get_text()
    d = pdf(run("header_footer", ["sample.pdf"], {"header": "Himalaya Textile", "footer": "{filename} – {n}/{total}"}))
    assert d[0].search_for("Himalaya Textile")[0].y0 < 60 and "sample.pdf – 6/6" in d[5].get_text()
    fs = unzip(run("bates", ["sample.pdf", "letter.pdf"], {"prefix": "KA", "digits": 5, "start": 1}))
    assert "KA00006" in pdf(fs[0])[5].get_text() and "KA00007" in pdf(fs[1])[0].get_text()


def test_hindi_stamps():
    """Hindi must be SHAPED (matras and conjuncts in place) and must stay searchable / copyable in other PDF readers."""
    p = run("watermark", ["sample.pdf"], {"text": "गोपनीय दस्तावेज़", "opacity": 0.3, "rotation": 45, "size": 54})
    assert "गोपनीय दस्तावेज़" in "".join(actual_text(p, 3)) and p.stat().st_size < 120_000
    rt = reader_text(p, 3); assert rt is None or "गोपनीय दस्तावेज़" in rt, rt
    im = render(p, 0, dpi=40); im0 = render(C / "sample.pdf", 0, dpi=40)
    from PIL import ImageChops
    bb = ImageChops.difference(im, im0).convert("L").point(lambda v: 255 if v > 12 else 0).getbbox()
    assert bb and abs((bb[0] + bb[2]) / 2 - im.width / 2) < 12 and abs((bb[1] + bb[3]) / 2 - im.height / 2) < 12, "watermark is not in the middle of the page"
    def rising(pth):   # positive rotation = text climbs from bottom-left to top-right, in every script
        diff = ImageChops.difference(render(pth, 0, dpi=40), im0).convert("L").point(lambda v: 255 if v > 12 else 0)
        left = diff.crop((0, 0, diff.width // 2, diff.height)).getbbox(); right = diff.crop((diff.width // 2, 0, diff.width, diff.height)).getbbox()
        return (left[1] + left[3]) / 2 > (right[1] + right[3]) / 2
    assert rising(p) and rising(run("watermark", ["sample.pdf"], {"text": "CONFIDENTIAL", "opacity": 0.3, "rotation": 45}))
    p = run("page_numbers", ["sample.pdf"], {"format": "पृष्ठ {n} / {total}", "position": "bottom-right"})
    assert actual_text(p, 2) == ["पृष्ठ 3 / 6"] and (reader_text(p, 2) is None or "पृष्ठ 3 / 6" in reader_text(p, 2))
    p = run("header_footer", ["sample.pdf"], {"header": "कटमांडू अपैरल – गोपनीय", "footer": "Page {n} of {total}"})
    # this header has no reordered glyphs: it must read back as typed even without /ActualText
    assert "कटमांडू अपैरल – गोपनीय" in " ".join(pdf(p)[5].get_text().split()) and "Page 6 of 6" in pdf(p)[5].get_text()
    assert reader_text(p, 5) is None or "कटमांडू अपैरल – गोपनीय" in reader_text(p, 5)
    p = run("merge", ["sample.pdf", "letter.pdf"], {"filename_footer": True}); assert "letter.pdf" in pdf(p)[6].get_text()


def test_meta_bookmarks_annots():
    d = pdf(run("metadata", ["sample.pdf"], {"mode": "change", "title": "New Title", "author": "Ravi"})); assert d.metadata["title"] == "New Title" and d.metadata["author"] == "Ravi"
    d = pdf(run("metadata", ["sample.pdf"], {"mode": "remove"})); assert not any((d.metadata or {}).get(k) for k in ("title", "author", "producer", "creator"))
    d = pdf(run("bookmarks", ["sample.pdf"], {"toc": [[1, "Intro", 1], [2, "Details", 2], [1, "End", 6]]})); assert [t[:3] for t in d.get_toc()] == [[1, "Intro", 1], [2, "Details", 2], [1, "End", 6]]
    src = pymupdf.open(C / "sample.pdf"); src[0].add_highlight_annot(src[0].search_for("Chapter 1")[0]); src[0].add_text_annot((50, 50), "note")
    tmp = C / "_annotated.pdf"; src.save(tmp)
    d = pdf(run("remove_annotations", ["_annotated.pdf"], {"types": ["highlight"]})); assert [a.type[1] for a in d[0].annots()] == ["Text"]
    d = pdf(run("remove_annotations", ["_annotated.pdf"], {"types": ["all"]})); assert not list(d[0].annots()) and not d[0].get_links()


# ------------------------------------------------------------------ OCR
def test_ocr():
    fs = unzip(run("ocr", ["scan_clean.pdf"], {"lang": "eng", "formats": ["pdf", "text"]}))
    assert "Dear customer" in text(fs[0]) and "fourteen working days" in fs[1].read_text()
    p = run("scan_to_editable", ["scan_textured.pdf"], {"lang": "eng"})
    from app.editor import page_stats
    vis, invis, cover, _ = page_stats(pdf(p)[0]); assert vis > 250 and invis == 0 and text(p).count("Dear customer") == 1
    d = pdf(run("deskew", ["scan_clean.pdf"])); assert d.page_count == 1


# ------------------------------------------------------------------ convert from PDF
def test_pdf_to_office():
    import docx, openpyxl
    from pptx import Presentation
    dd = docx.Document(run("pdf_to_word", ["word_doc.pdf"])); t = " ".join(p.text for p in dd.paragraphs)
    assert "Senior Merchandiser" in t and len(dd.tables) >= 1 and any("45,000" in c.text for r in dd.tables[0].rows for c in r.cells)
    dd = docx.Document(run("pdf_to_word", ["scan_sandwich.pdf"])); t = " ".join(p.text for p in dd.paragraphs)
    assert "Dear customer" in t and t.count("Delivery will") == 1 and "Regards" in t, "scanned PDF did not become editable Word text"
    wb = openpyxl.load_workbook(run("pdf_to_excel", ["chrome_report.pdf"], {"mode": "tables"}))
    rows = [[c.value for c in r] for r in wb.worksheets[0].iter_rows()]
    assert ["Item", "Qty", "Rate", "Amount"] in rows and any(r[0] == "Denim jeans" and r[1] == 80 for r in rows)
    csvp = run("pdf_to_excel", ["chrome_report.pdf"], {"mode": "tables", "format": "csv"}); assert "Cotton shirt,120" in csvp.read_text(encoding="utf-8-sig")
    prs = Presentation(run("pdf_to_ppt", ["sample.pdf"])); assert len(prs.slides) == 6
    texts = [sh.text_frame.text for sh in prs.slides[0].shapes if sh.has_text_frame]
    assert any("Chapter 1" in t for t in texts), "PowerPoint slide has no editable text"
    assert "Line 20 of page 6" in run("pdf_to_text", ["sample.pdf"]).read_text()
    assert "fourteen" in run("pdf_to_text", ["scan_clean.pdf"]).read_text()


def test_pdf_to_image():
    fs = unzip(run("pdf_to_image", ["sample.pdf"], {"format": "png", "dpi": 72, "pages": "1-2"}))
    w, h = Image.open(fs[0]).size; assert len(fs) == 2 and abs(w - 595) <= 1 and abs(h - 842) <= 1
    p = run("pdf_to_image", ["letter.pdf"], {"format": "jpg", "dpi": 150}); w, h = Image.open(p).size
    assert abs(w - 1240) <= 1 and abs(h - 1754) <= 1 and Image.open(p).format == "JPEG"
    fs = unzip(run("extract_images", ["scan_strips.pdf"])); assert len(fs) == 3 and all(Image.open(f).width == 1653 for f in fs)   # identical strips are stored once


# ------------------------------------------------------------------ convert to PDF
def test_to_pdf():
    d = pdf(run("image_to_pdf", ["photo.jpg", "photo.png"], {"page_size": "a4", "margin": 20})); assert d.page_count == 2 and round(d[0].rect.width) == 842
    d = pdf(run("image_to_pdf", ["photo.jpg"], {"page_size": "fit"})); assert (round(d[0].rect.width), round(d[0].rect.height)) == (900, 600)
    im = Image.open(C / "photo.jpg"); ex = im.getexif(); ex[0x0112] = 6; im.save(C / "_exif6.jpg", exif=ex)   # phone photo stored sideways
    d = pdf(run("image_to_pdf", ["_exif6.jpg"], {"page_size": "fit"})); assert d[0].rect.height > d[0].rect.width, "EXIF orientation ignored"
    assert "Senior Merchandiser" in text(run("office_to_pdf", ["word_doc.docx"]))
    assert "Hello HTML" in text(run("html_to_pdf", [], {"html": "<h1>Hello HTML</h1><p>नमस्ते</p>", "page_size": "a4"}))
    for bad in ("http://127.0.0.1:8000/admin", "http://169.254.169.254/latest/meta-data", "file:///etc/passwd"):
        run("html_to_pdf", [], {"urls": bad}, expect=422)


def test_rename():
    p = run("rename", ["sample.pdf"], {"label": "Invoice number", "pattern": "[TEXT1]-[BASENAME]"}); assert p.name == "INV-1001-sample.pdf"
    p = run("rename", ["letter.pdf"], {"areas": [{"page": 0, "x0": 0.05, "y0": 0.07, "x1": 0.7, "y1": 0.13}], "pattern": "[TEXT1]"}); assert "Quotation" in p.name


if __name__ == "__main__":
    sys.exit(1 if main(globals()) else 0)

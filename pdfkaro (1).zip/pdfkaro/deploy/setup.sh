#!/bin/bash
# One-time server setup for Ubuntu 24.04 (run as root):   bash setup.sh yourdomain.com
set -euo pipefail
DOMAIN="${1:?usage: bash setup.sh yourdomain.com [SiteName] [cloudflare]}"
NAME="${2:-PDFiesta}"
MODE="${3:-direct}"      # direct = the domain points straight at this server (free Let's Encrypt certificate)
                         # cloudflare = the domain is proxied by Cloudflare (SSL mode "Full")
cd "$(dirname "$0")/.."
echo "== 1/5 updates, firewall, swap"
apt-get update -y && DEBIAN_FRONTEND=noninteractive apt-get upgrade -y
apt-get install -y ca-certificates curl ufw unattended-upgrades
ufw allow OpenSSH && ufw allow 80/tcp && ufw allow 443/tcp && ufw --force enable
if ! swapon --show | grep -q .; then fallocate -l 4G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile && echo '/swapfile none swap sw 0 0' >> /etc/fstab; fi
echo "== 2/5 Docker"
command -v docker >/dev/null || curl -fsSL https://get.docker.com | sh
echo "== 3/5 settings (.env)"
if [ ! -f .env ]; then
  cp .env.example .env
  sed -i "s|^SITE_URL=.*|SITE_URL=https://$DOMAIN|" .env
  sed -i "s|^SITE_NAME=.*|SITE_NAME=$NAME|; s|^MAIL_FROM=.*|MAIL_FROM=$NAME <no-reply@$DOMAIN>|" .env
  [ "$MODE" = cloudflare ] && sed -i "s|^BEHIND_CLOUDFLARE=.*|BEHIND_CLOUDFLARE=1|" .env
fi
if [ "$MODE" != cloudflare ]; then sed "s/DOMAIN/$DOMAIN/g" deploy/Caddyfile.domain > deploy/Caddyfile; fi
echo "== 4/5 building and starting (first time 15-30 minutes)"
docker compose -f deploy/docker-compose.prod.yml up -d --build
echo "== 5/5 daily backup of accounts / payments / signed documents to /root/backups (14 days kept)"
mkdir -p /root/backups
cat > /etc/cron.daily/pdfkaro-backup <<'CRON'
#!/bin/sh
docker run --rm -v deploy_pdfdata:/d:ro -v /root/backups:/b alpine tar czf /b/pdfkaro-$(date +%F).tar.gz -C /d . && find /root/backups -name 'pdfkaro-*.tar.gz' -mtime +14 -delete
CRON
chmod +x /etc/cron.daily/pdfkaro-backup
sleep 20; curl -fsS http://127.0.0.1:80 -o /dev/null -w "web server answers: %{http_code}\n" || true
docker compose -f deploy/docker-compose.prod.yml ps
IP=$(curl -fsS -4 https://ifconfig.me || hostname -I | cut -d' ' -f1)
echo "DONE. Server IP: $IP"
echo "DNS: A record  @  -> $IP   and   A record  www  -> $IP   (then open https://$DOMAIN – the certificate is made on the first visit)"
